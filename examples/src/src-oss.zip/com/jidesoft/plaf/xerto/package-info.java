/**
 * The package contains ComponentUI implementation for Xerto style.
 */
package com.jidesoft.plaf.xerto;