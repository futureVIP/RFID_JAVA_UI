/**
 * The package contains classes related to validation for JIDE Common Layer.
 */
package com.jidesoft.validation;