/*
 * @(#)ResourceProvider.java 11/15/2008
 *
 * Copyright 2002 - 2008 JIDE Software Inc. All rights reserved.
 *
 */

package com.jidesoft.utils;

public interface ResourceProvider {
    String getResourceString(String key);
}
