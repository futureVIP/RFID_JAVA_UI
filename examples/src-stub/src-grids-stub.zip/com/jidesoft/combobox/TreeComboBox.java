/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <code>TreeComboBox</code> is just like a normal JComboBox which you can choose a value from a drop-down tree.
 */
public class TreeComboBox extends AbstractComboBox {

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #getCellRenderer()
	 *  @see #setCellRenderer(javax.swing.tree.TreeCellRenderer)
	 */
	protected javax.swing.tree.TreeCellRenderer renderer;

	/**
	 *  This protected field is implementation specific. Do not access directly or override. Use the accessor methods
	 *  instead.
	 * 
	 *  @see #getMaximumRowCount
	 *  @see #setMaximumRowCount
	 */
	protected int maximumRowCount;

	protected Object _object;

	protected javax.swing.tree.TreeModel _treeModel;

	public static final String TREE_MODEL_PROPERTY = "treeModel";

	public TreeComboBox() {
	}

	/**
	 *  Creates a new <code>TreeComboBox</code>.
	 * 
	 *  @param objects the objects
	 */
	public TreeComboBox(Object[] objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBox</code>.
	 * 
	 *  @param objects the objects
	 */
	public TreeComboBox(java.util.Vector objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBox</code>.
	 * 
	 *  @param objects the objects
	 */
	public TreeComboBox(java.util.Hashtable objects) {
	}

	/**
	 *  Creates a new <code>TreeComboBox</code>.
	 * 
	 *  @param root the root node
	 */
	public TreeComboBox(javax.swing.tree.TreeNode root) {
	}

	/**
	 *  Creates a new <code>TreeComboBox</code>.
	 * 
	 *  @param root               the root node
	 *  @param asksAllowsChildren the flag indicating if allows children
	 */
	public TreeComboBox(javax.swing.tree.TreeNode root, boolean asksAllowsChildren) {
	}

	/**
	 *  Creates a new <code>TreeComboBox</code>.
	 * 
	 *  @param model the tree model
	 */
	public TreeComboBox(javax.swing.tree.TreeModel model) {
	}

	@java.lang.Override
	protected void initComponent(javax.swing.ComboBoxModel model) {
	}

	protected java.util.List populateTreePaths(javax.swing.JTree tree) {
	}

	@java.lang.Override
	public AbstractComboBox.EditorComponent createEditorComponent() {
	}

	@java.lang.Override
	public PopupPanel createPopupComponent() {
	}

	/**
	 *  Creates the TreeChooserPanel. Subclass can override this method to create its own TreeChooserPanel. Below is the
	 *  default implement of this method.
	 *  <pre><code>
	 *  TreeChooserPanel panel = new TreeChooserPanel(object) {
	 *       protected void setupTree(final JTree tree) {
	 *           super.setupTree(tree);
	 *           tree.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() {
	 *               public void valueChanged(TreeSelectionEvent e) {
	 *                   if (e.getPath() != null && !Boolean.TRUE.equals(tree.getClientProperty(PopupPanel.SELECTED_BY_MOUSE_ROLLOVER)))
	 *  {
	 *                       if (isValidSelection(e.getPath())) {
	 *                           setSelectedObject(item, false);
	 *                           getEditor().setItem(e.getPath());
	 *                           getEditor().selectAll();
	 *                       }
	 *                   }
	 *               }
	 *           });
	 *           TreeComboBox.this.setupTree(tree);
	 *       }
	 *  <p/>
	 *       protected boolean isValidSelection(TreePath path) {
	 *           return TreeComboBox.this.isValidSelection(path);
	 *       }
	 *  };
	 *  </code></pre>
	 * 
	 *  @param model the tree model
	 *  @return TreeChooserPanel.
	 */
	protected TreeChooserPanel createTreeChooserPanel(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Creates the tree. By default, we will return null, meaning the default JTree created by TreeChooserPanel will be
	 *  used. Subclass can override this method to create other types of tree.
	 * 
	 *  @param model the tree model.
	 *  @return the tree.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.JTree createTree(javax.swing.tree.TreeModel model) {
	}

	/**
	 *  Setups the JTree for the tree used in the popup panel. You can override this method to customize the JTree.
	 * 
	 *  @param tree the JTree instance
	 */
	protected void setupTree(javax.swing.JTree tree) {
	}

	/**
	 *  Sets the maximum number of rows the <code>JComboBox</code> displays. If the number of objects in the model is
	 *  greater than count, the combo box uses a scrollbar.
	 * 
	 *  @param count an integer specifying the maximum number of items to display in the list before using a scrollbar
	 *               description: The maximum number of rows the popup should have
	 */
	public void setMaximumRowCount(int count) {
	}

	/**
	 *  Returns the maximum number of items the combo box can display without a scrollbar.
	 * 
	 *  @return an integer specifying the maximum number of items that are displayed in the list before using a
	 *          scrollbar
	 */
	public int getMaximumRowCount() {
	}

	/**
	 *  Sets the renderer that paints the list items and the item selected from the list in the JComboBox field. The
	 *  renderer is used if the JComboBox is not editable. If it is editable, the editor is used to render and edit the
	 *  selected item.
	 *  <p/>
	 *  The default renderer displays a string or an icon. Other renderers can handle graphic images and composite
	 *  items.
	 *  <p/>
	 *  To display the selected item, <code>aRenderer.getListCellRendererComponent</code> is called, passing the list
	 *  object and an index of -1.
	 * 
	 *  @param aRenderer the <code>ListCellRenderer</code> that displays the selected item expert: true description: The
	 *                   renderer that paints the item selected in the list.
	 *  @see #setEditor
	 */
	public void setCellRenderer(javax.swing.tree.TreeCellRenderer aRenderer) {
	}

	/**
	 *  Returns the renderer used to display the selected item in the <code>JComboBox</code> field.
	 * 
	 *  @return the <code>ListCellRenderer</code> that displays the selected item.
	 */
	public javax.swing.tree.TreeCellRenderer getCellRenderer() {
	}

	/**
	 *  Gets the underlying JTree. It will return a not null value only when the tree has ever been displayed. If you
	 *  want to customize the tree, it's better to override {@link #createTreeChooserPanel(javax.swing.tree.TreeModel)}
	 *  method and create your own TreeChooserPanel and JTree.
	 *  <p/>
	 *  <p/>
	 *  If you want to programmatically set selected row on the JTree, you can use this method. However do not keep the
	 *  returned value and use it later because combobox may create a new JTree if the popup is volatile.
	 *  <p/>
	 *  Please note, this method will show the popup automatically if the combobox itself is showing (isShowing returns
	 *  true). Otherwise, it could return null if the popup was never shown before.
	 * 
	 *  @return tree
	 */
	public javax.swing.JTree getTree() {
	}

	@java.lang.Override
	protected javax.swing.JComponent getDelegateTarget() {
	}

	/**
	 *  Converts the element from object to string so that i can display in the text field of TreeComboBox. Subclass can
	 *  override this method to provide one's own conversion.
	 * 
	 *  @param object the object
	 *  @return the string representing the object.
	 */
	protected String convertElementToString(Object object) {
	}

	/**
	 *  Checks if a given tree path is a valid selection for combobox. By default it always return true, meaning all tree
	 *  path could be used as a valid value of combo box.Subclass can override this method to limit the valid selection
	 *  to certain tree path. For example, check if last node in the tree path is leaf node and only allow leaf node to
	 *  be a valid selection.
	 * 
	 *  @param path the tree path
	 *  @return true or false.
	 */
	protected boolean isValidSelection(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Gets the tree model that will be used by the tree in the popup.
	 * 
	 *  @return the tree model.
	 */
	public javax.swing.tree.TreeModel getTreeModel() {
	}

	/**
	 *  Sets the tree model that will be used by the tree in the popup.
	 * 
	 *  @param treeModel the tree model
	 */
	public void setTreeModel(javax.swing.tree.TreeModel treeModel) {
	}

	/**
	 *  Get the flag indicating if the mouse double click would expand the tree path instead of just select it.
	 *  <p/>
	 *  By default, the flag is false to keep the original behavior. You could set it to true if you want choose leaf node
	 *  only.
	 * 
	 *  @return true if the mouse double click would expand the tree path. Otherwise false.
	 */
	public boolean isDoubleClickExpand() {
	}

	/**
	 *  Set the flag indicating if the mouse double click would expand the tree path instead of just select it.
	 * 
	 *  @see #isDoubleClickExpand()
	 *  @param doubleClickExpand the flag
	 */
	public void setDoubleClickExpand(boolean doubleClickExpand) {
	}
}
