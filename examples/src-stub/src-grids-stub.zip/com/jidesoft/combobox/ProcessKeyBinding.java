/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  This is an interface to make a protected method processKeyBinding in JComponent public so that
 *  we can use it to pass the key event to a component.
 */
public interface ProcessKeyBinding {

	public boolean processKeyBinding(javax.swing.KeyStroke ks, java.awt.event.KeyEvent e, int condition, boolean pressed);
}
