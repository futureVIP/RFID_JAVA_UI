/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  The default implementation of ComboBoxModelWrapper.
 */
public class DefaultComboBoxModelWrapper extends javax.swing.AbstractListModel implements javax.swing.ComboBoxModel, ComboBoxModelWrapper {
 {

	protected javax.swing.ComboBoxModel _model;

	protected int[] _indexes;

	public DefaultComboBoxModelWrapper() {
	}

	/**
	 *  Creates a DefaultComboBoxModelWrapper from any list model.
	 * 
	 *  @param model
	 */
	public DefaultComboBoxModelWrapper(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Sets the actual list model.
	 * 
	 *  @param model the list model.
	 */
	public void setActualModel(javax.swing.ComboBoxModel model) {
	}

	/**
	 *  Gets the actual list model. Since ComboBoxModelWrapper is just a wrapper around another list model, this method
	 *  will return you the actual list model.
	 * 
	 *  @return the actual list model.
	 */
	public javax.swing.ComboBoxModel getActualModel() {
	}

	/**
	 *  Gets the actual row.
	 * 
	 *  @param row the row on the UI.
	 *  @return the actual row in the actual model. It will throw IllegalArgumentException if the row is out of range.
	 */
	public int getActualIndexAt(int row) {
	}

	/**
	 *  Gets the visual row.
	 * 
	 *  @param actualRow the actual row in actual model.
	 *  @return the row on UI. -1 if cannot find the row.
	 */
	public int getIndexAt(int actualRow) {
	}

	public Object getElementAt(int row) {
	}

	public int getSize() {
	}

	/**
	 *  Resets the index mapping.
	 */
	protected void reallocateIndexes() {
	}

	/**
	 *  Gets the indexes that maps from the visual row index to the actual row index.
	 * 
	 *  @return the indexes.
	 */
	public int[] getIndexes() {
	}

	/**
	 *  Sets the indexes of the row mapping. We exposed this method to allow quick access to the underlying indexes. The
	 *  method won't fire any list data events. So once you change the indexes, you need to fire corresponding list data
	 *  event so that table can update itself.
	 * 
	 *  @param indexes
	 */
	public void setIndexes(int[] indexes) {
	}

	/**
	 *  Set the value of the selected item. The selected item may be null.
	 *  <p/>
	 * 
	 *  @param anObject The combo box value or null for no selection.
	 */
	public void setSelectedItem(Object anObject) {
	}

	public Object getSelectedItem() {
	}
}
