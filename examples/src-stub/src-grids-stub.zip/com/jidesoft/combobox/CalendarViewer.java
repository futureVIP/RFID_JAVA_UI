/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  <tt>CalendarViewer</tt> is a component that can display multiple months and allow you to choose multiple dates across
 *  all month viewers.
 */
public class CalendarViewer extends javax.swing.JPanel {

	/**
	 *  Property of view only.
	 */
	public static final String VIEWONLY_PROPERTY = "viewonly";

	public static final String PROPERTY_VIEWONLY = "viewonly";

	public static final String PROPERTY_ENABLED = "enabled";

	public static final String PROPERTY_CALENDAR_DIMENSION = "calendarDimension";

	public CalendarViewer() {
	}

	public CalendarViewer(java.awt.Dimension calendarDimensions) {
	}

	public CalendarViewer(DateModel model) {
	}

	public CalendarViewer(DateModel model, java.awt.Dimension calendarDimensions) {
	}

	/**
	 *  Recalculates the number of rows and columns based on the CalendarViewer's size.
	 */
	public void recalculateCalendarDimension() {
	}

	/**
	 *  Customizes the DateChooserPanel. By default, this method will hide today and none buttons on all
	 *  DateChooserPanel. It will also hide next or previous month buttons for most DateChooserPanel and only leave next
	 *  month button on the on the right-most DateChooserPanel in the first row and previous button on the left-most
	 *  DateChooserPanel in the first row.
	 * 
	 *  @param dateChooserPanel DateChooserPanel to be customized
	 *  @param row              the row index of this DateChooserPanel
	 *  @param column           the column index of this DateChooserPanel
	 */
	protected void customizeDateChooserPanel(DateChooserPanel dateChooserPanel, int row, int column) {
	}

	/**
	 *  Creates a new DateChooserPanel.
	 * 
	 *  @param dateModel      the data model
	 *  @param selectionModel the selection model
	 *  @return a new DateChooserPanel.
	 */
	protected DateChooserPanel createDateChooserPanel(DateModel dateModel, DateSelectionModel selectionModel) {
	}

	/**
	 *  Gets the array of DateChooserPanels used by this CalendarViewer.
	 * 
	 *  @return the array of DateChooserPanels used by this CalendarViewer.
	 */
	public DateChooserPanel[] getDateChooserPanels() {
	}

	/**
	 *  Gets the number of rows and columns of months in the DateChooserPanel.
	 * 
	 *  @return the number of rows and columns of months in the DateChooserPanel. Width in the Dimension is the number of
	 *          rows; height is the number of columns.
	 */
	public java.awt.Dimension getCalendarDimension() {
	}

	/**
	 *  Sets the number of rows and columns of months in the DateChooserPanel. Width in the Dimension is the number of
	 *  rows and height is the number of columns. Please note, if isAutoChangeDimension is on, calling to this method
	 *  will be ignored because the dimension is automatically based on the size of CalendarViewer.
	 * 
	 *  @param calendarDimension the calendar dimension
	 */
	public void setCalendarDimension(java.awt.Dimension calendarDimension) {
	}

	/**
	 *  Checks if autoChangeDimension is true.
	 * 
	 *  @return the value of autoChangeDimension flag.
	 */
	public boolean isAutoChangeDimension() {
	}

	/**
	 *  Sets the autoChangeDimensino flag. If true, the number of rows and columns will change automatically when the
	 *  CalendarViewer size changes. Otherwise, it will resize each DateChooserPanel when the CalendarViewer is resized.
	 * 
	 *  @param autoChangeDimension the flag
	 */
	public void setAutoChangeDimension(boolean autoChangeDimension) {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize() {
	}

	public java.util.Calendar getMaxDisplayCalendar() {
	}

	public java.util.Calendar getMinDisplayCalendar() {
	}

	public DateSelectionModel getSelectionModel() {
	}

	public void setSelectionModel(DateSelectionModel selectionModel) {
	}

	public DateModel getDateModel() {
	}

	public void setDateModel(DateModel dateModel) {
	}

	/**
	 *  Sets the displayed month. It will use the first DateChooserPanel to display the specified month if the month is a
	 *  valid date in the DateModel.
	 * 
	 *  @param year  the year to be displayed
	 *  @param month the month to be displayed.
	 *  @return whether the new month is displayed successfully. False if the new month is out of the valid range of the
	 *          getDateModel().
	 */
	public boolean setDisplayedMonth(int year, int month) {
	}

	/**
	 *  Sets the displayed month. It will use the specified DateChooserPanel as in parameter index to display the
	 *  specified month if the month is a valid date in the DateModel.
	 * 
	 *  @param year  the year to be displayed
	 *  @param month the month to be displayed.
	 *  @param index the index of the DateChooserPanel to display the specified month.
	 *  @return whether the new month is displayed successfully. False if the new month is out of the valid range of the
	 *          getDateModel().
	 */
	public boolean setDisplayedMonth(int year, int month, int index) {
	}

	/**
	 *  If the DateChooserPanel is view-only.
	 * 
	 *  @return true if the DateChooserPanel is view-only
	 */
	public boolean isViewOnly() {
	}

	/**
	 *  Sets the view only attribute. If the DateChooserPanel is view-only, user will not be able to change the month or
	 *  year once it's set.
	 * 
	 *  @param viewOnly the flag
	 */
	public void setViewOnly(boolean viewOnly) {
	}

	/**
	 *  If the DateChooserPanel is view-only.
	 * 
	 *  @return true if the DateChooserPanel is view-only
	 */
	@java.lang.Override
	public boolean isEnabled() {
	}

	/**
	 *  Sets the view only attribute. If the DateChooserPanel is view-only, user will not be able to change the month or
	 *  year once it's set.
	 * 
	 *  @param enabled the flag
	 */
	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Gets the first day of the week is; e.g., Sunday in US, Monday in France.
	 * 
	 *  @return firstDayOfWeek. -1 if you never set before. If so, the default value in the locale will be used.
	 */
	public int getFirstDayOfWeek() {
	}

	/**
	 *  Sets the first day of the week is; e.g., Sunday in US, Monday in France. The values are defined in Calendar such
	 *  as {@link java.util.Calendar#SUNDAY},  {@link java.util.Calendar#MONDAY} etc.
	 * 
	 *  @param firstDayOfWeek the first day of the week
	 */
	public void setFirstDayOfWeek(int firstDayOfWeek) {
	}
}
