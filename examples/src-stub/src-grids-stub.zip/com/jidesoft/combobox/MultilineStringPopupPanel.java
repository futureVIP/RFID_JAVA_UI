/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  A popup panel for multiple line text.
 */
public class MultilineStringPopupPanel extends PopupPanel {

	public MultilineStringPopupPanel() {
	}

	public MultilineStringPopupPanel(String title) {
	}

	@java.lang.Override
	public Object getSelectedObject() {
	}

	@java.lang.Override
	public void setSelectedObject(Object selected) {
	}

	/**
	 *  Creates the text area.
	 * 
	 *  @return the text area.
	 */
	protected javax.swing.JTextArea createTextArea() {
	}
}
