/**
 *  The package contains all kinds of comboboxes for JIDE Grids product.
 */
package com.jidesoft.combobox;


/**
 *  FolderNameChooserPanel is a popup panel that can choose a folder name.
 */
public class FolderNameChooserPanel extends PopupPanel {

	/**
	 *  Creates a new <code>JPanel</code> with a double buffer
	 *  and a flow layout.
	 */
	public FolderNameChooserPanel() {
	}

	public FolderNameChooserPanel(String currentDirectoryPath) {
	}

	protected void initComponents() {
	}

	protected javax.swing.JComponent createFolderChooserPanel() {
	}

	protected FolderChooser createFileChooser() {
	}

	@java.lang.Override
	public boolean needsButtons() {
	}
}
