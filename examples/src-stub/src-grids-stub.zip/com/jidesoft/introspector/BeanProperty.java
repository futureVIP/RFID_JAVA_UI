/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  <code>BeanProperty</code> wraps {@link PropertyDescriptor} and provides an implementation for {@link Property}.
 * 
 *  @see BeanIntrospector
 *  @see IntrospectorManager
 */
public class BeanProperty extends com.jidesoft.grid.Property {

	protected Class _beanClass;

	protected java.beans.PropertyDescriptor _propertyDescriptor;

	protected Object _instance;

	protected reflect.Field _field;

	public static final String PROPERTY_AUTO_INTROSPECT = "autoIntrospect";

	public BeanProperty(java.beans.PropertyDescriptor pd) {
	}

	public BeanProperty(String name, Class beanClass) {
	}

	public BeanProperty(String name, Class beanClass, String description, Class type, String category) {
	}

	public Object getInstance() {
	}

	public void setInstance(Object instance) {
	}

	@java.lang.Override
	public void setType(Class type) {
	}

	public reflect.Field getField() {
	}

	public void setField(reflect.Field field) {
	}

	public reflect.Method getReadMethod() {
	}

	public void setReadMethod(reflect.Method readMethod) {
	}

	public reflect.Method getWriteMethod() {
	}

	public void setWriteMethod(reflect.Method writeMethod) {
	}

	@java.lang.Override
	public void setValue(Object value) {
	}

	@java.lang.Override
	public Object getValue() {
	}

	@java.lang.Override
	public boolean hasValue() {
	}

	public boolean isAutoIntrospect() {
	}

	public void setAutoIntrospect(boolean autoIntrospect) {
	}
}
