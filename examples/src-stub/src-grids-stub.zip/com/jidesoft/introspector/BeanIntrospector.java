/**
 *  The package contains classes related to bean introspection for JIDE Grids product.
 */
package com.jidesoft.introspector;


/**
 *  A helper class to introspect properties in a Java Bean and provide an easy way to integrate with {@link
 *  com.jidesoft.grid.PropertyTable}.
 *  <p/>
 */
public class BeanIntrospector implements Introspector {
 {

	public static final String PROPERTIES = "Properties";

	public static final String PROPERTY = "Property";

	/**
	 *  Creates a BeanIntrospector. It will use reflection to find out all properties on the Bean so that you can use
	 *  them to create a PropertyTableModel later.
	 * 
	 *  @param clazz the type of the object to be introspected.
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 */
	public BeanIntrospector(Class clazz) {
	}

	/**
	 *  Creates a BeanIntrospector and allow you to pass in known properties.
	 *  <p/>
	 *  There are two purposes to pass a properties parameter into the constructor. One is you might want to assign
	 *  different category and description for each property. Using reflection won't be able to get those information.
	 *  Secondly you might want to control the properties to be exposed.
	 *  <p/>
	 *  The format of properties array is
	 *  <code><pre>
	 *  new String[] {
	 *       "propertyName1", "propertyDescription1", "propertyCategory1",
	 *       "propertyName2", "propertyDescription2", "propertyCategory2",
	 *       ...
	 *  };
	 *  </pre></code>
	 * 
	 *  @param clazz      the type of the object to be introspected.
	 *  @param properties a single dimension String array. See above for the format.
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 */
	public BeanIntrospector(Class clazz, String[] properties) {
	}

	/**
	 *  Creates a BeanIntrospector and allow you to pass in known properties.
	 *  <p/>
	 *  There are two purposes to pass a properties parameter into the constructor. One is you might want to assign
	 *  different category and description for each property. Using reflection won't be able to get those information.
	 *  Secondly you might want to control the properties to be exposed.
	 *  <p/>
	 *  There are several way to format the properties array depending on the count. If count is 1, the format will be
	 *  <code><pre>
	 *  new String[] {
	 *       "propertyName1",
	 *       "propertyName2",
	 *       ...
	 *  };
	 *  </pre></code>
	 *  If count is 2, the format will be
	 *  <code><pre>
	 *  new String[] {
	 *       "propertyName1", "displayName11",
	 *       "propertyName2", "displayName12",
	 *       ...
	 *  };
	 *  </pre></code>
	 *  If count is 3, the format will be
	 *  <code><pre>
	 *  new String[] {
	 *       "propertyName1", "propertyDescription1", "propertyCategory1",
	 *       "propertyName2", "propertyDescription2", "propertyCategory2",
	 *       ...
	 *  };
	 *  </pre></code>
	 *  If count is 4, the format will be
	 *  <code><pre>
	 *  new String[] {
	 *       "propertyName1", "displayName11", "propertyDescription1", "propertyCategory1",
	 *       "propertyName2", "displayName12", "propertyDescription2", "propertyCategory2",
	 *       ...
	 *  };
	 *  </pre></code>
	 * 
	 *  @param clazz      the type of the object to be introspected.
	 *  @param properties a single dimension String array. See above for the format.
	 *  @param count      the count of the attributes for each property. See above.
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 */
	public BeanIntrospector(Class clazz, String[] properties, int count) {
	}

	/**
	 *  Creates a BeanIntrospector and allow you to pass in known properties. You also have the option to use the
	 *  <code>properties</code>array as a filter or not.
	 * 
	 *  @param clazz      the type of the object to be introspected.
	 *  @param properties a single dimension String array. See above for the format.
	 *  @param filtered   true if only properties defined in <code>properties</code> array are used. Otherwise, it will
	 *                    still use reflection to find all properties and add additional attributes defined in
	 *                    <code>properties</code> array to those properties.
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 */
	public BeanIntrospector(Class clazz, String[] properties, boolean filtered) {
	}

	/**
	 *  Creates a BeanIntrospector using property xml file. The property xml file is in the format of
	 *  <pre>
	 *  <Properties>
	 *       <Property name="..." displayName="..." description="..." category="..."/>
	 *       <Property name="..." displayName="..." description="..." category="..."/>
	 *       ...
	 *  </Properties>
	 *  </pre>
	 *  Possible attributes for <code>Property</code> element are "name", "displayName", "value", "type", "description";
	 *  "dependingProperties", "category", "converterContext", "editorContext", "editable", "autoIntrospect", "expert",
	 *  "hidden" and "preferred". The only required attribute is "name". All other are optional.
	 * 
	 *  @param clazz    the type of the object to be introspected.
	 *  @param fileName the file name
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 */
	public BeanIntrospector(Class clazz, String fileName) {
	}

	/**
	 *  Creates a BeanIntrospector using property xml file.
	 * 
	 *  @param clazz the type of the object to be introspected.
	 *  @param in    the input stream
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 *  @see #BeanIntrospector(Class, String) for the xml file format.
	 */
	public BeanIntrospector(Class clazz, java.io.InputStream in) {
	}

	/**
	 *  Creates a BeanIntrospector using BeanInfo.
	 * 
	 *  @param clazz    the type of the object to be introspected.
	 *  @param beanInfo the bean info
	 */
	public BeanIntrospector(Class clazz, java.beans.BeanInfo beanInfo) {
	}

	/**
	 *  Creates a BeanIntrospector using property xml file.
	 * 
	 *  @param clazz    the type of the object to be introspected.
	 *  @param fileName the file name
	 *  @param filtered true to use the properties defined in the file to filter the property list.
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 */
	public void introspectProperties(Class clazz, String fileName, boolean filtered) {
	}

	/**
	 *  Creates a BeanIntrospector using property xml file's input stream.
	 * 
	 *  @param clazz    the type of the object to be introspected.
	 *  @param in       the input stream
	 *  @param filtered true to use the properties defined in the input stream to filter the property list.
	 *  @throws java.beans.IntrospectionException
	 *           if the java bean introspection failed
	 */
	public void introspectProperties(Class clazz, java.io.InputStream in, boolean filtered) {
	}

	public com.jidesoft.grid.PropertyTableModel createPropertyTableModel(Object beanObject) {
	}

	public com.jidesoft.grid.BeanTableModel createBeanTableModel(java.util.List objects) {
	}

	public java.util.List createPropertyList(Object beanObject) {
	}

	public int getPropertyCount() {
	}

	public BeanProperty getProperty(String name) {
	}

	public void removeProperty(String name) {
	}

	public void addProperty(BeanProperty property) {
	}

	public String[] getPropertyNames() {
	}

	public static interface class LazyValue {


		public Object getValue() {
		}
	}
}
