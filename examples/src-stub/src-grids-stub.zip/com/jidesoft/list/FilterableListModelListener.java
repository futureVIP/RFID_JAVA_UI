/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  The listener interface for receiving FilterableListModel events.
 */
public interface FilterableListModelListener extends java.util.EventListener {
 {

	/**
	 *  Called whenever the FilterableListModel's filtered is changed.
	 * 
	 *  @param event FilterableListModelEvent.
	 */
	public void filterableListModelChanged(FilterableListModelEvent event);
}
