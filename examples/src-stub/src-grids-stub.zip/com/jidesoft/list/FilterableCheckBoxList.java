/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  This is a filterable {@link com.jidesoft.swing.CheckBoxList}. The major purpose is to enable the customer to apply filtering
 *  on the check box list while keeping the current selection even if the selected items were temporarily filtered out.
 *  <p/>
 *  The key of this class is to override {@link #createCheckBoxListSelectionModel(javax.swing.ListModel)} to return a
 *  {@link com.jidesoft.list.FilterableCheckBoxListSelectionModel} instead of {@link com.jidesoft.swing.CheckBoxListSelectionModel} only.
 */
public class FilterableCheckBoxList extends CheckBoxList {

	public FilterableCheckBoxList() {
	}

	public FilterableCheckBoxList(java.util.Vector listData) {
	}

	public FilterableCheckBoxList(Object[] listData) {
	}

	public FilterableCheckBoxList(javax.swing.ListModel dataModel) {
	}

	@java.lang.Override
	protected void init() {
	}

	@java.lang.Override
	protected CheckBoxListSelectionModel createCheckBoxListSelectionModel(javax.swing.ListModel model) {
	}

	@java.lang.Override
	protected Handler createHandler() {
	}
}
