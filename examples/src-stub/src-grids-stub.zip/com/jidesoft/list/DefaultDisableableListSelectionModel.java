/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


public class DefaultDisableableListSelectionModel extends javax.swing.DefaultListSelectionModel {

	protected java.util.Set _disabledIndices;

	protected javax.swing.DefaultListSelectionModel _delegate;

	/**
	 *  Creates an instance of <code>DefaultDisableableListSelectionModel</code>
	 */
	public DefaultDisableableListSelectionModel() {
	}

	/**
	 *  Set indices that are not allowed selecting
	 * 
	 *  @param disabledIndices indices that are not allowed selecting
	 *  @see #setDisabledSelectionInterval(int,int)
	 *  @see #getDisabledIndices()
	 */
	public void setDisabledIndices(int[] disabledIndices) {
	}

	/**
	 *  Change the disabled selection to be between index0 and index1 inclusive. Note that index0 doesn't have to be less
	 *  than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 *  @see #setDisabledIndices(int[])
	 *  @see #setSelectionInterval(int,int)
	 */
	public void setDisabledSelectionInterval(int index0, int index1) {
	}

	/**
	 *  Change the disabled selection to be the set union of the current selection and the indices between index0 and
	 *  index1 inclusive. Note that index0 doesn't have to be less than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 *  @see #addSelectionInterval(int,int)
	 */
	public void addDisabledSelectionInterval(int index0, int index1) {
	}

	/**
	 *  Change the disabled selection to be the set difference of the current selection and the indices between index0
	 *  and index1 inclusive. Note that index0 doesn't have to be less than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 *  @see #removeSelectionInterval(int,int)
	 *  @see #removeDisabledIndexInterval(int,int)
	 */
	public void removeDisabledSelectionInterval(int index0, int index1) {
	}

	/**
	 *  Remove the disabled indices in the interval index0,index1 (inclusive) from the selection model.  This is
	 *  typically called to sync the selection model width a corresponding change in the data model.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 *  @see #removeIndexInterval(int,int)
	 *  @see #removeDisabledSelectionInterval(int,int)
	 */
	public void removeDisabledIndexInterval(int index0, int index1) {
	}

	/**
	 *  Returns the indices that are not allowed selecting
	 * 
	 *  @return the indices that are not allowed selecting
	 *  @see #setDisabledIndices(int[])
	 */
	public int[] getDisabledIndices() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public boolean isSelectedIndex(int index) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public boolean isSelectionEmpty() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public int getMinSelectionIndex() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public int getMaxSelectionIndex() {
	}

	protected int originalGetMinSelectionIndex() {
	}

	protected int originalGetMaxSelectionIndex() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public boolean getValueIsAdjusting() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public int getSelectionMode() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setSelectionMode(int selectionMode) {
	}

	protected boolean originalIsSelectedIndex(int index) {
	}

	protected boolean originalIsSelectionEmpty() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void addListSelectionListener(javax.swing.event.ListSelectionListener l) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void removeListSelectionListener(javax.swing.event.ListSelectionListener l) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public javax.swing.event.ListSelectionListener[] getListSelectionListeners() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public java.util.EventListener[] getListeners(Class listenerType) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setLeadAnchorNotificationEnabled(boolean flag) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public boolean isLeadAnchorNotificationEnabled() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void clearSelection() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setSelectionInterval(int index0, int index1) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void addSelectionInterval(int index0, int index1) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void removeSelectionInterval(int index0, int index1) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void insertIndexInterval(int index, int length, boolean before) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void removeIndexInterval(int index0, int index1) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setValueIsAdjusting(boolean isAdjusting) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public String toString() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public DefaultDisableableListSelectionModel clone() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public int getAnchorSelectionIndex() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public int getLeadSelectionIndex() {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setAnchorSelectionIndex(int anchorIndex) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void moveLeadSelectionIndex(int leadIndex) {
	}

	/**
	 *  {@inheritDoc}
	 */
	@java.lang.Override
	public void setLeadSelectionIndex(int leadIndex) {
	}
}
