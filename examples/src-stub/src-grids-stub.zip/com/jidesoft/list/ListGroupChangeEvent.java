/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  An event to indicate the group information is changed in GroupableListModel.
 */
public class ListGroupChangeEvent extends java.util.EventObject {

	/**
	 *  Creates a new instance of ListGroupChangeEvent
	 * 
	 *  @param source the source for this event.
	 */
	public ListGroupChangeEvent(Object source) {
	}
}
