/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  A panel can display image icon along with the description and detail.
 */
public class ImagePreviewPanel extends javax.swing.JPanel {

	public ImagePreviewPanel() {
	}

	public ImagePreviewPanel(String title, javax.swing.ImageIcon icon, java.awt.Dimension size, String description, int showDetails) {
	}

	public ImagePreviewPanel(String title, javax.swing.ImageIcon icon) {
	}

	public java.awt.Dimension getImageSize() {
	}

	public void setImageSize(java.awt.Dimension imageSize) {
	}

	protected javax.swing.JComponent createDetailsPanel() {
	}

	protected javax.swing.JComponent createDescription(String text, javax.swing.JComponent field) {
	}

	protected javax.swing.JComponent createLabel(String text, javax.swing.JComponent field) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g) {
	}

	public boolean isSelected() {
	}

	public void setSelected(boolean selected) {
	}

	public boolean isFocused() {
	}

	public void setFocused(boolean focused) {
	}

	public javax.swing.ImageIcon getIcon() {
	}

	public void setIcon(javax.swing.ImageIcon icon) {
	}

	public String getImageTitle() {
	}

	public void setImageTitle(String imageTitle) {
	}

	public String getImageDescription() {
	}

	public void setImageDescription(String imageDescription) {
	}

	public int getShowDetails() {
	}

	public void setShowDetails(int showDetails) {
	}

	public java.awt.Color getGridForeground() {
	}

	public void setGridForeground(java.awt.Color gridForeground) {
	}

	public java.awt.Color getGridBackground() {
	}

	public void setGridBackground(java.awt.Color gridBackground) {
	}

	public java.awt.Color getHighlightBackground() {
	}

	public void setHighlightBackground(java.awt.Color highlightBackground) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string.
	 * 
	 *  @param key the key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}
}
