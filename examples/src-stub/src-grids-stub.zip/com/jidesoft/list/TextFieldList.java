/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>TextFieldList</code> is a pane that contains a JTextField on the left and a JList on the right and a bunch
 *  of buttons. The customer can input new items in the JTextField on the left and press the transfer button to move it to the list
 *  on the right.
 *  <p/>
 *  You could override {@link #isInputValid(String)}  to control which kind of inputs are allowed to be transferred to the list.
 *  <p/>
 */
public class TextFieldList extends JideSplitPane implements javax.swing.event.ListSelectionListener {
 {

	public static final String COMMAND_MOVE_LEFT = "moveLeft";

	public static final String COMMAND_MOVE_RIGHT = "moveRight";

	public static final String COMMAND_MOVE_UP = "moveUp";

	public static final String COMMAND_MOVE_DOWN = "moveDown";

	public static final String COMMAND_MOVE_TO_TOP = "moveToTop";

	public static final String COMMAND_MOVE_TO_BOTTOM = "moveToBottom";

	public javax.swing.JComponent _originalFieldPane;

	public javax.swing.JComponent _selectedListPane;

	public final String CLIENT_PROPERTY_ALWAYS_DISABLED = "DualList.alwaysDisabled";

	protected DefaultListModelWrapper _selectedListModel;

	public static final int FIELD_TRANSFERRED_NO_ACTION = 0;

	public static final int FIELD_TRANSFERRED_CLEAR_TEXT = 1;

	public static final int FIELD_TRANSFERRED_SELECT_ALL = 2;

	/**
	 * Constructs a <code>JList</code> with an empty model. 
	 */
	public TextFieldList() {
	}

	/**
	 *  Constructs a <code>JList</code> with a list with existing list data in the right.
	 * 
	 *  @param listModel the list model
	 */
	public TextFieldList(javax.swing.DefaultListModel listModel) {
	}

	/**
	 *  Create a DefaultListModelWrapper to wrap the original list model. By default, it will create a SortableListModel
	 *  without sorting. However, if you want to sort it and omit the up/down buttons, you could override this method to
	 *  sort it.
	 * 
	 *  @param listModel the original list model
	 *  @return the wrapper list model
	 */
	protected DefaultListModelWrapper createWrapperListModel(javax.swing.DefaultListModel listModel) {
	}

	/**
	 *  Creates the right JList. By default, we will create JList and set the name to "TextFieldTransferBox.rightList".
	 * 
	 *  @param model the list model
	 *  @return a JList.
	 */
	protected javax.swing.JList createList(javax.swing.ListModel model) {
	}

	/**
	 *  Customizes the JList.
	 * 
	 *  @param list the selected JList.
	 */
	protected void setupList(javax.swing.JList list) {
	}

	protected javax.swing.text.JTextComponent createTextField() {
	}

	/**
	 *  Get the original JTextField.
	 * 
	 *  @return the original JTextField.
	 */
	public javax.swing.text.JTextComponent getOriginalField() {
	}

	/**
	 *  Get the selected JList.
	 * 
	 *  @return the selected JList.
	 */
	public javax.swing.JList getSelectedList() {
	}

	/**
	 *  Gets the component containing the original JList.
	 * 
	 *  @return the component containing the original JList.
	 */
	public javax.swing.JComponent getOriginalFieldPane() {
	}

	/**
	 *  Gets the component containing the selected JList.
	 * 
	 *  @return the component containing the selected JList.
	 */
	public javax.swing.JComponent getSelectedListPane() {
	}

	/**
	 *  Adds ButtonPanel to DualList.
	 * 
	 *  @param container   the container between the two JLists.
	 *  @param buttonPanel the button panel
	 */
	protected void addButtonPanel(java.awt.Container container, java.awt.Component buttonPanel) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	protected java.awt.Container createButtonPanel() {
	}

	public void valueChanged(javax.swing.event.ListSelectionEvent e) {
	}

	/**
	 *  Creates the button. Our default code is
	 *  <code><pre>
	 *  protected AbstractButton createButton(Action action) {
	 *      AbstractButton button = new JideButton(action);
	 *      action.addPropertyChangeListener(new PropertyChangeListener() {
	 *          public void propertyChange(PropertyChangeEvent evt) {
	 *              if ("disabledIcon".equals(evt.getPropertyName())) {
	 *                  button.setDisabledIcon((Icon) action.getValue("disabledIcon"));
	 *              }
	 *          }
	 *      });
	 *      button.setName("" + action.getValue(Action.ACTION_COMMAND_KEY));
	 *      button.setDisabledIcon((Icon) action.getValue("disabledIcon"));
	 *      button.setRequestFocusEnabled(false);
	 *      return button;
	 *  }
	 *  </pre></code>
	 * 
	 *  @param action the action for the button.
	 *  @return a button.
	 */
	protected javax.swing.AbstractButton createButton(javax.swing.Action action) {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Check if current input in the JTextField is valid so that the "move to right" button will be enabled.
	 *  <p/>
	 *  The default implementation is as following:
	 * 
	 *  @param text the input text
	 *  @return true if the input is valid. Otherwise false.
	 */
	protected boolean isInputValid(String text) {
	}

	/**
	 *  Gets the selected indices. The index in the array is the index as in the original list.
	 * 
	 *  @return the selected indices.
	 *  @see com.jidesoft.list.DualListModel#getSelectedIndices()
	 */
	public Object[] getSelectedValues() {
	}

	protected void installKeyboardAction() {
	}

	/**
	 *  Sets the button visible or invisible.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @param visible true to show the button and false to hide.
	 */
	public void setButtonVisible(String command, boolean visible) {
	}

	/**
	 *  Checks if the button is visible.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @return true or false.
	 */
	public boolean isButtonVisible(String command) {
	}

	/**
	 *  Sets the button to always disabled.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @param enabled false to always disable the button.
	 */
	public void setButtonEnabled(String command, boolean enabled) {
	}

	/**
	 *  Checks if the button is always disabled.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @return false if the button is always disabled. Otherwise true. Note that this method still could return true
	 *          when the button isEnabled() return false.
	 */
	public boolean isButtonEnabled(String command) {
	}

	/**
	 *  Gets the list cell renderer for the left list.
	 * 
	 *  @return the list cell renderer for the left list.
	 */
	public javax.swing.ListCellRenderer getCellRenderer() {
	}

	/**
	 *  Sets the list cell renderer for the list on the left. If {@link #setSelectedCellRenderer(javax.swing.ListCellRenderer)}
	 *  is never called, the same renderer will be used for the list on the right too.
	 * 
	 *  @param cellRenderer the new list cell renderer
	 */
	public void setCellRenderer(javax.swing.ListCellRenderer cellRenderer) {
	}

	/**
	 *  Gets the list cell renderer for the right list. If you never set it, it will be the same as {@link
	 *  #getCellRenderer()}.
	 * 
	 *  @return the list cell renderer for the right list.
	 */
	public javax.swing.ListCellRenderer getSelectedCellRenderer() {
	}

	/**
	 *  Sets the list cell renderer for the list on the right.
	 * 
	 *  @param selectedCellRenderer the new list cell renderer
	 */
	public void setSelectedCellRenderer(javax.swing.ListCellRenderer selectedCellRenderer) {
	}

	/**
	 *  Returns the disabled cell renderer. It will be used for the list on the left for items that are selected when the
	 *  selection mode is DISABLE_SELECTION.
	 * 
	 *  @return the disabled cell renderer
	 */
	public javax.swing.ListCellRenderer getDisabledCellRenderer() {
	}

	/**
	 *  Sets the disabled cell renderer.
	 * 
	 *  @param disabledCellRenderer the new disabled cell renderer.
	 */
	public void setDisabledCellRenderer(javax.swing.ListCellRenderer disabledCellRenderer) {
	}

	/**
	 * Moves the selected items in the right list to the left list. 
	 */
	public void moveLeft() {
	}

	/**
	 * Moves the selected items in the left list to the right list. 
	 */
	public void moveRight() {
	}

	/**
	 * Moves the selected items in the right list up by one. 
	 */
	public void moveUp() {
	}

	/**
	 * Moves the selected items in the right list down by one. 
	 */
	public void moveDown() {
	}

	/**
	 * Moves the selected items in the right list to the top. 
	 */
	public void moveToTop() {
	}

	/**
	 * Moves the selected items in the right list to the bottom. 
	 */
	public void moveToBottom() {
	}

	/**
	 *  Sets the visible row count in the two lists. Please note, if you set a number too small, it will not have any
	 *  effect because the buttons also need vertical space.
	 * 
	 *  @param visibleRowCount an integer specifying the preferred number of rows to display without requiring scrolling
	 */
	public void setVisibleRowCount(int visibleRowCount) {
	}

	/**
	 *  Returns the value of the {@code visibleRowCount} from the list.
	 * 
	 *  @return the value of the {@code visibleRowCount} property.
	 *  @see #setVisibleRowCount
	 */
	public int getVisibleRowCount() {
	}

	/**
	 *  Get the field transferred mode. JTextField's behavior could be controled on clicking the "move to right" button.
	 *  <p/>
	 *  It could be #FIELD_TRANSFERRED_NO_ACTION which is the default value. In this mode, the JTextField just keep as is.
	 *  #FIELD_TRANSFERRED_CLEAR_TEXT means the JTextField will clear back to its default start string.
	 *  #FIELD_TRANSFERRED_SELECT_ALL means the JTextField will select all
	 * 
	 *  @return the field transferred mode.
	 *  @see #setFieldTransferredMode(int)
	 */
	public int getFieldTransferredMode() {
	}

	/**
	 *  Set the field transferred mode. JTextField's behavior could be controled on clicking the "move to right" button.
	 *  <p/>
	 *  It could be #FIELD_TRANSFERRED_NO_ACTION which is the default value. In this mode, the JTextField just keep as is.
	 *  #FIELD_TRANSFERRED_CLEAR_TEXT means the JTextField will clear back to its default start string.
	 *  #FIELD_TRANSFERRED_SELECT_ALL means the JTextField will select all
	 * 
	 *  @param fieldTransferredMode the field transferred mode
	 *  @see #getStartString()
	 */
	public void setFieldTransferredMode(int fieldTransferredMode) {
	}

	/**
	 *  Get the default start string for the JTextField.
	 * 
	 *  @return the default start string.
	 *  @see #setStartString(String)
	 */
	public String getStartString() {
	}

	/**
	 *  Set the default start string for the JTextField.
	 *  <p/>
	 *  For some scenarios, you may only want your customer to input IP address like "192.168.xx.xx". In this case, you
	 *  may set the start string to "192.168." to make the use easier if you set the field transferred mode to
	 *  #FIELD_TRANSFERRED_CLEAR_TEXT .
	 * 
	 *  @param startString the default start string.
	 */
	public void setStartString(String startString) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. For example,
	 *  you can customize the icons by overriding this method. The key for the icons will be in the format of
	 *  "dualList.moveLeft.icon" and "dualList.moveLeft.disabledIcon" for the move left button. There are a total of
	 *  eight buttons. Once you override, you can return a full qualified path to the icon resource such as
	 *  "/com/yourcompany/icons/moveLeft.png". Note that the icon must be in the class path so that we can access it as
	 *  resource.
	 * 
	 *  @param key the key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Performs the action.
	 * 
	 *  @param command the command
	 */
	protected void performAction(String command) {
	}

	/**
	 *  Get the flag if duplicate selection is allowed in the TextFieldTransferBox.
	 * 
	 *  @return true if duplicate selection is allowed. Otherwise false.
	 *  @see #setAllowDuplicates(boolean)
	 */
	public boolean isAllowDuplicates() {
	}

	/**
	 *  Set the flag if duplicate selection is allowed in the DualList.
	 *  <p/>
	 *  By default the flag is true to keep consistent with DualList.
	 * 
	 *  @param allowDuplicates the flag
	 */
	public void setAllowDuplicates(boolean allowDuplicates) {
	}
}
