/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <tt>ImagePreviewList</tt> is a component that can preview images. It takes any ListModel. The element in list can be
 *  either {@link PreviewImageIcon} or an {@link ImageIcon}. If it's NamedImageIcon, you can specify the size, title and
 *  description for each image. If it's ImageIcon, you can only specify title and description by calling {@link
 *  ImageIcon#setDescription(String)} and pass in a string that contains both title and description using
 *  "[title]\n[description]".
 *  <p/>
 *  By default, each image preview will have details about each image. You can use {@link #setShowDetails(int)} to show
 *  or hide certain details.
 *  <p/>
 *  The preview size can be changed using {@link #setCellDimension(java.awt.Dimension)}.
 *  <p/>
 *  This component is still in beta.
 */
public class ImagePreviewList extends javax.swing.JList {

	public static final int SHOW_NONE = 0;

	public static final int SHOW_TITLE = 1;

	public static final int SHOW_DESCRIPTION = 2;

	public static final int SHOW_SIZE = 4;

	public static final int SHOW_ALL = 255;

	public ImagePreviewList() {
	}

	public ImagePreviewList(java.util.Vector listData) {
	}

	public ImagePreviewList(Object[] listData) {
	}

	public ImagePreviewList(javax.swing.ListModel dataModel) {
	}

	/**
	 *  Configure the list.
	 */
	protected void configureList() {
	}

	/**
	 *  Gets the show details value. It's a boolean OR of {@link #SHOW_DESCRIPTION}, {@link #SHOW_SIZE}, {@link
	 *  #SHOW_TITLE}.
	 * 
	 *  @return the show details value.
	 */
	public int getShowDetails() {
	}

	/**
	 *  Sets the show details value. You can use boolean OR of {@link #SHOW_DESCRIPTION}, {@link #SHOW_SIZE}, {@link
	 *  #SHOW_TITLE}. Or you can use {@link #SHOW_ALL} or {@link #SHOW_NONE} for all the details or none of the details.
	 * 
	 *  @param showDetails the new show details value.
	 */
	public void setShowDetails(int showDetails) {
	}

	public java.awt.Dimension getCellDimension() {
	}

	public void setCellDimension(java.awt.Dimension cellDimension) {
	}

	/**
	 *  Gets the grid line color. This color is used to paint the grid line.
	 * 
	 *  @return the grid line color.
	 */
	public java.awt.Color getGridForeground() {
	}

	/**
	 *  Sets the grid line color. This color is used to paint the grid line.
	 * 
	 *  @param gridForeground the grid line color.
	 */
	public void setGridForeground(java.awt.Color gridForeground) {
	}

	/**
	 *  Gets the grid background. This color is used to paint the background inside each grid.
	 * 
	 *  @return the grid background color.
	 */
	public java.awt.Color getGridBackground() {
	}

	/**
	 *  Sets the grid background. This color is used to paint the background inside each grid.
	 * 
	 *  @param gridBackground the grid background color.
	 */
	public void setGridBackground(java.awt.Color gridBackground) {
	}

	/**
	 *  Gets the selection highlight color. This color is used to paint the grid background when it is selected. Please
	 *  note, you should have alpha value less than 255 on this color. Otherwise it will cover the whole grid.
	 * 
	 *  @return the grid selection highlight color.
	 */
	public java.awt.Color getHighlightBackground() {
	}

	/**
	 *  Sets the selection highlight color. This color is used to paint the grid background when it is selected. Please
	 *  note, you should have alpha value less than 255 on this color. Otherwise it will cover the whole grid.
	 * 
	 *  @param highlightBackground the grid selection highlight color.
	 */
	public void setHighlightBackground(java.awt.Color highlightBackground) {
	}

	/**
	 *  An interface to allow specify title, description and size information in addition to the icon itself. The size
	 *  information is only needed if you want to use a difference size from the icon size.
	 */
	public static interface class PreviewImageIcon {


		public javax.swing.ImageIcon getImageIcon() {
		}

		public String getTitle() {
		}

		public java.awt.Dimension getSize() {
		}

		public String getDescription() {
		}
	}
}
