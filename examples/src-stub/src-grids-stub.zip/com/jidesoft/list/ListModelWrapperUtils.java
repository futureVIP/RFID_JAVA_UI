/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  ListWrapperUtilsis a utility class that contains several useful methods for ListModelWrapper.
 */
public class ListModelWrapperUtils {

	public ListModelWrapperUtils() {
	}

	/**
	 *  Gets the actual row index at a list model  whose class is innerModelClass.
	 * 
	 *  @param outerModel      the outermost outerModel.
	 *  @param row             the row of outermost outerModel
	 *  @param innerModelClass the class of the inner outerModel
	 *  @return the row index of inner outerModel. If it can't find it, -1 will be returned.
	 */
	public static int getActualIndexAt(javax.swing.ListModel outerModel, int row, Class innerModelClass) {
	}

	/**
	 *  Gets the actual row index at a list model  which equals to the innerModel passed in as parameter.
	 * 
	 *  @param outerModel the outermost outerModel.
	 *  @param row        the row of outermost outerModel
	 *  @param innerModel the inner outerModel
	 *  @return the row index of inner outerModel. If it can't find it, -1 will be returned.
	 */
	public static int getActualIndexAt(javax.swing.ListModel outerModel, int row, javax.swing.ListModel innerModel) {
	}

	/**
	 *  Gets the actual row index at an outerModel.
	 * 
	 *  @param outerModel the outermost outerModel.
	 *  @param row        the row of outermost outerModel
	 *  @return the row index of nested model which is not a list wrapper. If it can't find it, -1 will be returned.
	 */
	public static int getActualIndexAt(javax.swing.ListModel outerModel, int row) {
	}

	/**
	 *  Gets the row at the outer model knowing the row index in an inner model
	 * 
	 *  @param outerModel the outer list model
	 *  @param innerModel the inner list model
	 *  @param rowInInnerModel the row index in the inner list model
	 *  @return the row at the outer list model.
	 */
	public static int getIndexAt(javax.swing.ListModel outerModel, javax.swing.ListModel innerModel, int rowInInnerModel) {
	}

	/**
	 *  Gets the row at the outermost model knowing the row index in an inner model
	 * 
	 *  @param outerModel the outer list model
	 *  @param rowInInnerModel the row index in the inner list model
	 *  @return the row at the outermost model.
	 */
	public static int getIndexAt(javax.swing.ListModel outerModel, int rowInInnerModel) {
	}

	/**
	 *  Gets the list model whose class is targetModelClass.
	 * 
	 *  @param outerModel       the outer list model
	 *  @param targetModelClass the target model class type
	 *  @return the list model whose class is targetModelClass.
	 */
	public static javax.swing.ListModel getActualListModel(javax.swing.ListModel outerModel, Class targetModelClass) {
	}

	/**
	 *  Gets the list model whose class is targetModelClass.
	 * 
	 *  @param outerModel       the outer list model
	 *  @return the inner most list model.
	 */
	public static javax.swing.ListModel getActualListModel(javax.swing.ListModel outerModel) {
	}
}
