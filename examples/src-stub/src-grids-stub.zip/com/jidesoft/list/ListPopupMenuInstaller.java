/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>ListPopupMenuInstaller</code> allows you to add a popup menu to a JList and customize it. To use it, you just need to call
 *  <pre><code>
 *  ListPopupMenuInstaller installer = new ListPopupMenuInstaller(list);
 *  </code></pre>
 *  Or if you want to uninstall it, call
 *  <pre><code>
 *  ListPopupMenuInstaller.getListPopupMenuCustomizers(list).uninstallListeners();
 *  </code></pre>
 *  However <code>ListPopupMenuInstaller</code> has no menu items. You need create your own <code>ListPopupMenuCustomizer</code> to do it.
 */
public class ListPopupMenuInstaller extends java.awt.event.MouseAdapter {

	/**
	 *  Client property used by JList to provide its own ListPopupMenuCustomizer.
	 */
	public static final String CLIENT_PROPERTY_POPUP_MENU_INSTALLER = "ListPopupMenuInstaller";

	/**
	 *  Creates a ListPopupMenuInstaller.
	 * 
	 *  @param list the JList.
	 */
	public ListPopupMenuInstaller(javax.swing.JList list) {
	}

	/**
	 *  Add a list popup menu customizer.
	 * 
	 *  @param customizer the customizer
	 */
	public void addListPopupMenuCustomizer(ListPopupMenuCustomizer customizer) {
	}

	/**
	 *  Remove a list popup menu customizer.
	 * 
	 *  @param customizer the customizer
	 */
	public void removeListPopupMenuCustomizer(ListPopupMenuCustomizer customizer) {
	}

	/**
	 *  Get the installed popup menu customizer.
	 * 
	 *  @return all popup menu customizer in array.
	 */
	public ListPopupMenuCustomizer[] getListPopupMenuCustomizers() {
	}

	@java.lang.Override
	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Create the popup menu.
	 *  <p/>
	 *  The default implementation is to return a new created JidePopupMenu instance.
	 * 
	 *  @return the popup menu.
	 */
	protected javax.swing.JPopupMenu createPopupMenu() {
	}

	/**
	 *  Customizes the menu items for the popup menu.
	 * 
	 *  @param list    the JList.
	 *  @param popup   the popup menu.
	 *  @param indices the target list items.
	 */
	protected void customizeMenuItems(javax.swing.JList list, javax.swing.JPopupMenu popup, int[] indices) {
	}

	/**
	 *  Installs the listeners needed in order to show the popup menu for the JList.
	 */
	public void installListeners() {
	}

	/**
	 *  Uninstalls the listeners needed in order to show the popup menu for the JList.
	 */
	public void uninstallListeners() {
	}

	/**
	 *  Gets the ListPopupMenuInstaller installed on the JList. Null is no ListPopupMenuInstaller was installed.
	 * 
	 *  @param list the JList
	 *  @return the ListPopupMenuInstaller installed. Null is no ListPopupMenuInstaller was installed.
	 */
	public static ListPopupMenuInstaller getListPopupMenuInstaller(javax.swing.JList list) {
	}

	/**
	 *  Finds the target list items the menu will install on.
	 *  <p/>
	 *  The default implementation is the current selected indices. You could override this method to have your own definition.
	 * 
	 *  @param list the JList
	 *  @param p    the point
	 *  @return the column or <code>null</code>
	 */
	protected int[] getTargetListItems(javax.swing.JList list, java.awt.Point p) {
	}

	/**
	 *  Adds a separator to the popup menu if there are menu items on it already.
	 * 
	 *  @param popup the popup menu.
	 */
	public static void addSeparatorIfNecessary(javax.swing.JPopupMenu popup) {
	}
}
