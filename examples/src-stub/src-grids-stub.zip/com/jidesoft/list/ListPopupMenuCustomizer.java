/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  An interface to allow user to customize for the ListPopupMenuInstaller.
 */
public interface ListPopupMenuCustomizer {

	/**
	 *  Customizes the popup menu.
	 * 
	 *  @param list           the JList
	 *  @param popup          the popup menu to be displayed
	 *  @param targetItems    the list items clicked
	 */
	public void customizePopupMenu(javax.swing.JList list, javax.swing.JPopupMenu popup, int[] targetItems);
}
