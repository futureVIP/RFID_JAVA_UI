/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  A collection of utility methods for JList.
 */
public class ListUtils {

	public ListUtils() {
	}

	/**
	 *  Save the selection of the JList as an array of integer.
	 * 
	 *  @param list
	 *  @return selection as an array
	 */
	public static int[] saveSelection(javax.swing.JList list) {
	}

	/**
	 *  Restore the selection in JList. It must used the array that created by saveSelection.
	 * 
	 *  @param list
	 *  @param selected an int array created by saveSelection
	 */
	public static void loadSelection(javax.swing.JList list, int[] selected) {
	}

	/**
	 *  Saves the selection of the JList as an array of objects. Different from {@link #saveSelection(javax.swing.JList)},
	 *  this method will return the actual values that are selected. If there are new values added to
	 *  or existing values removed from the list and cause the indices, this method will still be able to
	 *  restore the selected values correctly.
	 * 
	 *  @param list
	 *  @return selection as an array
	 */
	public static Object[] saveSelectionByValues(javax.swing.JList list) {
	}

	/**
	 *  Restores the selection in JList. It must used the array that created by
	 *  {@link #saveSelectionByValues(javax.swing.JList)}.
	 * 
	 *  @param list
	 *  @param selected an int array created by saveSelection
	 */
	public static void loadSelectionByValues(javax.swing.JList list, Object[] selected) {
	}

	public static void ensureSelectionVisible(javax.swing.JList list) {
	}
}
