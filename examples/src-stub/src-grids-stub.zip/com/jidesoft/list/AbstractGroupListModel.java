/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  This is an abstract implementation of <code>GroupListModel</code> However, some methods such as #getGroupStart(int)
 *  &amp; #getGroupEnd(int) may not have a good performance. Better override them.
 */
public abstract class AbstractGroupListModel extends javax.swing.AbstractListModel implements GroupListModel {
 {

	public AbstractGroupListModel() {
	}

	public int getGroupRowIndex(int row) {
	}

	public int getNextGroupRowIndex(int row) {
	}

	public int[] getGroupCellIndices() {
	}
}
