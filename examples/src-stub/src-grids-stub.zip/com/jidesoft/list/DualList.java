/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>DualList</code> is a pane that contains two JLists and a bunch of buttons. The list on the left contains all
 *  the items. The list on the right contains the items that are selected.
 *  <p/>
 *  <code>DualList</code> uses {@link DualListModel} which is the model of this component. With the help of
 *  DualListModel, it provides three kinds of selection modes. This mode controls what to display in the right list when
 *  items are selected. {@link DualListModel#REMOVE_SELECTION} mode means the left list will remove the items if they are
 *  selected to the right list. This mode can prevent user from selecting the selected item again if it is not allowed in
 *  certain cases. {@link DualListModel#DISABLE_SELECTION} mode means the selected items will be shown as disabled. User
 *  cannot select them anymore but they can still see them in the right list to show user a complete unchanged list.
 *  {@link DualListModel#KEEP_SELECTION} mode will not change the right list at all when items are selected. This is the
 *  only mode which can result duplicated items to be selected. If that's what you want in your situation, this mode is
 *  the one you should use. You could disable the duplicate selection option by invoking {link #setAllowDuplicates(false)}.
 *  <p/>
 *  <code>DualList</code> extends {@link JideSplitPane}, which makes users conveniently resize the width of either list.
 *  <p/>
 * 
 *  @see DualListModel
 *  @see AbstractDualListModel
 *  @see DefaultDualListModel
 */
public class DualList extends JideSplitPane {

	public static final String COMMAND_MOVE_LEFT = "moveLeft";

	public static final String COMMAND_MOVE_RIGHT = "moveRight";

	public static final String COMMAND_MOVE_ALL_LEFT = "moveAllLeft";

	public static final String COMMAND_MOVE_ALL_RIGHT = "moveAllRight";

	public static final String COMMAND_MOVE_UP = "moveUp";

	public static final String COMMAND_MOVE_DOWN = "moveDown";

	public static final String COMMAND_MOVE_TO_TOP = "moveToTop";

	public static final String COMMAND_MOVE_TO_BOTTOM = "moveToBottom";

	protected DualListModel _model;

	public javax.swing.JComponent _originalListPane;

	public javax.swing.JComponent _selectedListPane;

	public final String CLIENT_PROPERTY_ALWAYS_DISABLED = "DualList.alwaysDisabled";

	protected DefaultListModelWrapper _selectedListModel;

	protected DefaultListModelWrapper _originalListModel;

	/**
	 *  Constructs a <code>JList</code> with an empty _model.
	 */
	public DualList() {
	}

	/**
	 *  Constructs a <code>JList</code> that displays the elements in the specified array.  This constructor just
	 *  delegates to the <code>DualListModel</code> constructor.
	 * 
	 *  @param listData the array of Objects to be loaded into the data _model
	 */
	public DualList(Object[] listData) {
	}

	/**
	 *  Constructs a <code>DualList</code> that displays the elements in the specified <code>List</code>.  This
	 *  constructor just delegates to the <code>DualListModel</code> constructor.
	 * 
	 *  @param listData the <code>List</code> to be loaded into the data _model
	 */
	public DualList(java.util.List listData) {
	}

	/**
	 *  Constructs a <code>DualList</code> that displays the elements in the specified, non-<code>null</code> model. All
	 *  <code>DualList</code> constructors delegate to this one.
	 * 
	 *  @param model the data model for this list
	 *  @throws NullPointerException if <code>model</code> is <code>null</code>
	 */
	public DualList(DualListModel model) {
	}

	/**
	 *  Creates the JList. By default, we will create JList and set the name to "DualList.leftList" or
	 *  "DualList.rightList" depending on the parameter "left" value.
	 * 
	 *  @param model        the list model
	 *  @param originalList true if the JList is for the original list. False if the JList is for the selected list.
	 *  @return a JList.
	 */
	protected javax.swing.JList createList(javax.swing.ListModel model, boolean originalList) {
	}

	/**
	 *  Customizes the JList.
	 * 
	 *  @param list         the JList. It could be either the original JList or the selected JList.
	 *  @param originalList true if the JList is for the original list. False if the JList is for the selected list.
	 */
	protected void setupList(javax.swing.JList list, boolean originalList) {
	}

	/**
	 *  Get the original JList.
	 * 
	 *  @return the original JList.
	 */
	public javax.swing.JList getOriginalList() {
	}

	/**
	 *  Get the selected JList.
	 * 
	 *  @return the selected JList.
	 */
	public javax.swing.JList getSelectedList() {
	}

	/**
	 *  Gets the component containing the original JList.
	 * 
	 *  @return the component containing the original JList.
	 */
	public javax.swing.JComponent getOriginalListPane() {
	}

	/**
	 *  Gets the component containing the selected JList.
	 * 
	 *  @return the component containing the selected JList.
	 */
	public javax.swing.JComponent getSelectedListPane() {
	}

	/**
	 *  Adds ButtonPanel to DualList.
	 * 
	 *  @param container   the container between the two JLists.
	 *  @param buttonPanel the button panel
	 */
	protected void addButtonPanel(java.awt.Container container, java.awt.Component buttonPanel) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	protected java.awt.Container createButtonPanel() {
	}

	/**
	 *  Creates the button. Our default code is
	 *  <code><pre>
	 *  protected AbstractButton createButton(Action action) {
	 *      AbstractButton button = new JideButton(action);
	 *      action.addPropertyChangeListener(new PropertyChangeListener() {
	 *          public void propertyChange(PropertyChangeEvent evt) {
	 *              if ("disabledIcon".equals(evt.getPropertyName())) {
	 *                  button.setDisabledIcon((Icon) action.getValue("disabledIcon"));
	 *              }
	 *          }
	 *      });
	 *      button.setName("" + action.getValue(Action.ACTION_COMMAND_KEY));
	 *      button.setDisabledIcon((Icon) action.getValue("disabledIcon"));
	 *      button.setRequestFocusEnabled(false);
	 *      return button;
	 *  }
	 *  </pre></code>
	 * 
	 *  @param action the action for the button.
	 *  @return a button.
	 */
	protected javax.swing.AbstractButton createButton(javax.swing.Action action) {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Gets the selected indices. The index in the array is the index as in the original list.
	 * 
	 *  @return the selected indices.
	 *  @see DualListModel#getSelectedIndices()
	 */
	public int[] getSelectedIndices() {
	}

	@java.lang.SuppressWarnings("unchecked")
	public int[] getUnselectedIndices() {
	}

	/**
	 *  Registered keyboard actions for the original and selected lists.
	 *  <p/>
	 *  By default, pressing ENTER, RIGHT arrow at LTR or LEFT arrow at RTL orientation in the original list will make the
	 *  current selected item to the "selected" list. In the "selected" list, same key logic apply.
	 *  <p/>
	 *  In the "selected" list, CTRL+UP/DOWN/HOME/END will move the position of current selected items inside the "selected"
	 *  list. ESCAPE will clear the current selection so that new items could be inserted to the end.
	 */
	protected void installKeyboardAction() {
	}

	/**
	 *  Gets the DualListModel.
	 * 
	 *  @return the DualListModel.
	 */
	public DualListModel getModel() {
	}

	/**
	 *  Sets the DualListModel.
	 * 
	 *  @param model a new DualListModel.
	 */
	public void setModel(DualListModel model) {
	}

	/**
	 *  Gets the selected values from the DualList.
	 * 
	 *  @return the selected values.
	 */
	public Object[] getSelectedValues() {
	}

	/**
	 *  Returns the values that are not selected in <code>DaulList</code>
	 * 
	 *  @return the unselected values
	 */
	public Object[] getUnselectedValues() {
	}

	/**
	 *  Checks if the index is selected.
	 * 
	 *  @param index the index.
	 *  @return true or false.
	 */
	public boolean isSelectedIndex(int index) {
	}

	/**
	 *  Removes all the selections.
	 */
	public void clearSelection() {
	}

	/**
	 *  Change the selection to be the set union of the current selection and the indices between index0 and index1
	 *  inclusive.  If this represents a change to the current selection, then notify each ListSelectionListener. Note
	 *  that index0 doesn't have to be less than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 */
	public void addSelectionInteval(int index0, int index1) {
	}

	/**
	 *  Change the selection to be the set difference of the current selection and the indices between index0 and index1
	 *  inclusive.  If this represents a change to the current selection, then notify each ListSelectionListener.  Note
	 *  that index0 doesn't have to be less than or equal to index1.
	 * 
	 *  @param index0 one end of the interval.
	 *  @param index1 other end of the interval
	 */
	public void removeSelectionInteval(int index0, int index1) {
	}

	/**
	 *  Checks if there is any selection.
	 * 
	 *  @return true means no selection. Otherwise false.
	 */
	public boolean isSelectionEmpty() {
	}

	/**
	 *  Gets the selection mode from DualListModel.
	 * 
	 *  @return the selection mode.
	 *  @see DualListModel#getSelectionMode()
	 */
	public int getSelectionMode() {
	}

	/**
	 *  Sets the selection mode to <code>DualListModel</code>.
	 * 
	 *  @param selectionMode the new selection mode.
	 *  @see DualListModel#setSelectionMode(int)
	 */
	public void setSelectionMode(int selectionMode) {
	}

	/**
	 *  Sets the button visible or invisible.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @param visible true to show the button and false to hide.
	 */
	public void setButtonVisible(String command, boolean visible) {
	}

	/**
	 *  Checks if the button is visible.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @return true or false.
	 */
	public boolean isButtonVisible(String command) {
	}

	/**
	 *  Sets the button to always disabled.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @param enabled false to always disable the button.
	 */
	public void setButtonEnabled(String command, boolean enabled) {
	}

	/**
	 *  Checks if the button is always disabled.
	 * 
	 *  @param command the name defined in DualList. They are constants starting with "COMMAND_" such as
	 *                 COMMAND_MOVE_LEFT.
	 *  @return false if the button is always disabled. Otherwise true. Note that this method still could return true
	 *          when the button isEnabled() return false.
	 */
	public boolean isButtonEnabled(String command) {
	}

	/**
	 *  @param buttonPanelVisible the visibility
	 *  @deprecated Replaced by {@link #setMiddleButtonPanelVisible(boolean)}
	 */
	@java.lang.Deprecated
	public void setButtonPanelVisible(boolean buttonPanelVisible) {
	}

	/**
	 *  @return true if the button panel is visible. Otherwise false.
	 *  @deprecated Replaced by {@link #isMiddleButtonPanelVisible()}
	 */
	@java.lang.Deprecated
	public boolean isButtonPanelVisible() {
	}

	/**
	 *  Set the visibility of the middle button panel.
	 * 
	 *  @param middleButtonPanelVisible the visibility
	 */
	public void setMiddleButtonPanelVisible(boolean middleButtonPanelVisible) {
	}

	/**
	 *  Get the visibility of the middle button panel.
	 * 
	 *  @return true if the middle button panel is visible. Otherwise false.
	 */
	public boolean isMiddleButtonPanelVisible() {
	}

	/**
	 *  Set the visibility of the right button panel.
	 * 
	 *  @param middleButtonPanelVisible the visibility
	 */
	public void setRightButtonPanelVisible(boolean middleButtonPanelVisible) {
	}

	/**
	 *  Get the visibility of the right button panel.
	 * 
	 *  @return true if the right button panel is visible. Otherwise false.
	 */
	public boolean isRightButtonPanelVisible() {
	}

	/**
	 *  Gets the list cell renderer for the left list.
	 * 
	 *  @return the list cell renderer for the left list.
	 */
	public javax.swing.ListCellRenderer getCellRenderer() {
	}

	/**
	 *  Sets the list cell renderer for the list on the left. If {@link #setSelectedCellRenderer(javax.swing.ListCellRenderer)}
	 *  is never called, the same renderer will be used for the list on the right too.
	 * 
	 *  @param cellRenderer the new list cell renderer
	 */
	public void setCellRenderer(javax.swing.ListCellRenderer cellRenderer) {
	}

	/**
	 *  Gets the list cell renderer for the right list. If you never set it, it will be the same as {@link
	 *  #getCellRenderer()}.
	 * 
	 *  @return the list cell renderer for the right list.
	 */
	public javax.swing.ListCellRenderer getSelectedCellRenderer() {
	}

	/**
	 *  Sets the list cell renderer for the list on the right.
	 * 
	 *  @param selectedCellRenderer the new list cell renderer
	 */
	public void setSelectedCellRenderer(javax.swing.ListCellRenderer selectedCellRenderer) {
	}

	/**
	 *  Returns the disabled cell renderer. It will be used for the list whenever the item is not able to move left or right.
	 * 
	 *  @return the disabled cell renderer
	 */
	public javax.swing.ListCellRenderer getDisabledCellRenderer() {
	}

	/**
	 *  Sets the disabled cell renderer.
	 * 
	 *  @param disabledCellRenderer the new disabled cell renderer.
	 */
	public void setDisabledCellRenderer(javax.swing.ListCellRenderer disabledCellRenderer) {
	}

	/**
	 *  Moves the selected items in the right list to the left list.
	 */
	public void moveLeft() {
	}

	/**
	 *  Moves the selected items in the left list to the right list.
	 */
	public void moveRight() {
	}

	/**
	 *  Moves all items from the right list to the left list.
	 */
	public void moveAllLeft() {
	}

	/**
	 *  Moves all items from the left list to the right list.
	 */
	public void moveAllRight() {
	}

	/**
	 *  Moves the selected items in the right list up by one.
	 */
	public void moveUp() {
	}

	/**
	 *  Moves the selected items in the right list down by one.
	 */
	public void moveDown() {
	}

	/**
	 *  Moves the selected items in the right list to the top.
	 */
	public void moveToTop() {
	}

	/**
	 *  Moves the selected items in the right list to the bottom.
	 */
	public void moveToBottom() {
	}

	/**
	 *  Sets the visible row count in the two lists. Please note, if you set a number too small, it will not have any
	 *  effect because the buttons also need vertical space.
	 * 
	 *  @param visibleRowCount an integer specifying the preferred number of rows to display without requiring scrolling
	 */
	public void setVisibleRowCount(int visibleRowCount) {
	}

	/**
	 *  Returns the value of the {@code visibleRowCount} from the list.
	 * 
	 *  @return the value of the {@code visibleRowCount} property.
	 *  @see #setVisibleRowCount
	 */
	public int getVisibleRowCount() {
	}

	/**
	 *  Get the flag if duplicate selection is allowed in the DualList.
	 * 
	 *  @see #setAllowDuplicates(boolean)
	 *  @return true if duplicate selection is allowed. Otherwise false.
	 */
	public boolean isAllowDuplicates() {
	}

	/**
	 *  Set the flag if duplicate selection is allowed in the DualList.
	 *  <p/>
	 *  This flag will only take effective if {@link #getSelectionMode} returns {@link DualListModel#KEEP_SELECTION}
	 *  <p/>
	 *  By default the flag is true to keep original behavior.
	 * 
	 *  @see #setSelectionMode(int)
	 *  @param allowDuplicates the flag
	 */
	public void setAllowDuplicates(boolean allowDuplicates) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. For example,
	 *  you can customize the icons by overriding this method. The key for the icons will be in the format of
	 *  "dualList.moveLeft.icon" and "dualList.moveLeft.disabledIcon" for the move left button. There are a total of
	 *  eight buttons. Once you override, you can return a full qualified path to the icon resource such as
	 *  "/com/yourcompany/icons/moveLeft.png". Note that the icon must be in the class path so that we can access it as
	 *  resource.
	 * 
	 *  @param key the key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Performs the action.
	 * 
	 *  @param command the command
	 */
	protected void performAction(String command) {
	}
}
