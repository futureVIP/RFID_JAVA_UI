/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  An <code>AWTEvent</code> that adds support for <code>FilterableListModel</code> objects as the event source when
 *  filter is added or removed.
 */
public class FilterableListModelEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>FilterableListModel</code> events.
	 */
	public static final int FILTERABLE_LIST_MODEL_EVENT_FIRST = 7199;

	/**
	 *  The last number in the range of IDs used for <code>FilterableListModel</code> events.
	 */
	public static final int FILTERABLE_LIST_MODEL_EVENT_LAST = 7200;

	/**
	 *  This event is delivered when a <code>Filter</code> is added.
	 */
	public static final int FILTER_ADDED = 7199;

	/**
	 *  This event is delivered when a <code>Filter</code> is removed.
	 */
	public static final int FILTER_REMOVED = 7200;

	/**
	 *  Constructs an <code>FilterEvent</code> object.
	 * 
	 *  @param source the <code>Filter</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 */
	public FilterableListModelEvent(Object source, int id) {
	}

	public FilterableListModelEvent(Object source, int id, com.jidesoft.filter.Filter filter) {
	}

	public com.jidesoft.filter.Filter getFilter() {
	}
}
