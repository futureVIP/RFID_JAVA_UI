/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


public class DefaultGroupListModel extends javax.swing.DefaultListModel implements GroupListModel {
 {

	protected java.util.Set _headers;

	/**
	 *  Creates a new instance of DefaultGroupListModel
	 */
	public DefaultGroupListModel() {
	}

	public int getGroupRowIndex(int row) {
	}

	public int getNextGroupRowIndex(int row) {
	}

	/**
	 *  Returns true if the specified row is a header, false otherwise.
	 * 
	 *  @param row the row to be checked
	 *  @return true if the specified row is a header, false otherwise
	 */
	public boolean isGroupRow(int row) {
	}

	/**
	 *  Set the specified row be group or not
	 * 
	 *  @param row   the specified row to be set
	 *  @param group true if setting the row be group
	 */
	public void setGroupRow(int row, boolean group) {
	}

	public int[] getGroupCellIndices() {
	}
}
