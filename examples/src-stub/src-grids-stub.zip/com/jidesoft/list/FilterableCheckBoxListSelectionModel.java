/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  FilterableCheckBoxListSelectionModel is to work with {@link com.jidesoft.list.FilterableCheckBoxList}. Please be noted
 *  that, the index it used to operate is the visual index in the FilterableListModel although it stores selection in the
 *  index of actual list model.
 */
public class FilterableCheckBoxListSelectionModel extends CheckBoxListSelectionModel {

	public FilterableCheckBoxListSelectionModel() {
	}

	public FilterableCheckBoxListSelectionModel(javax.swing.ListModel model) {
	}

	@java.lang.Override
	public void insertIndexInterval(int index, int length, boolean before) {
	}

	@java.lang.Override
	public boolean isSelectedIndex(int index) {
	}

	@java.lang.Override
	public void setSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void addSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void removeSelectionInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void removeIndexInterval(int index0, int index1) {
	}

	@java.lang.Override
	public void setAnchorSelectionIndex(int anchorIndex) {
	}

	@java.lang.Override
	public void moveLeadSelectionIndex(int leadIndex) {
	}

	@java.lang.Override
	public void setLeadSelectionIndex(int leadIndex) {
	}

	@java.lang.Override
	public int getMinSelectionIndex() {
	}

	@java.lang.Override
	public int getMaxSelectionIndex() {
	}

	@java.lang.Override
	protected void fireValueChanged(int firstIndex, int lastIndex) {
	}

	@java.lang.Override
	protected void fireValueChanged(int firstIndex, int lastIndex, boolean isAdjusting) {
	}

	@java.lang.Override
	public int getAnchorSelectionIndex() {
	}

	@java.lang.Override
	public int getLeadSelectionIndex() {
	}
}
