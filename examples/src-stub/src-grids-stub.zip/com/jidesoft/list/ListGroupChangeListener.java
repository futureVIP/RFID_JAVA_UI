/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


public interface ListGroupChangeListener extends java.util.EventListener {
 {

	/**
	 *  Sent after the grouping of <code>GroupableListModel</code>
	 *  has been changed.
	 * 
	 *  @param e a <code>ListGroupChangeListener</code> encapsulating the
	 *           event information
	 */
	public void groupChanged(ListGroupChangeEvent e);
}
