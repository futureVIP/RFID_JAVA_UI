/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>QuickListFilterField</code> works along with any ListModel to provide searching feature.
 *  <p/>
 *  It is very simple to use it.
 *  <code><pre>
 *  QuickListFilterField filterField = new QuickListFilterField(anyListModel);</pre></code>
 *  Later on, when you display the list, instead using your original list model, use {@link #getDisplayListModel()}.
 *  <code><pre>
 *  JList list = new JList(quickSearchField.getDisplayListModel());
 *  filterField.setList(list); // optional. Only if you want the selection to be kept before and
 *  after filtering. The selection could not be kept if the selected row was filtered out.
 *  </pre></code>
 *  Usually you place <code>QuickListFilterField</code> somewhere close to the JList in the user interface. User can type
 *  in any text in the text field, you will see the JList automatically display the data that matches with the text.
 */
public class QuickListFilterField extends com.jidesoft.grid.QuickFilterField {

	/**
	 *  Creates an empty <code>QuickSearchField</code>. This method is useless since <code>QuickSearchField</code> has to
	 *  have a table model in order to work correctly. So we have this method in place mainly to make it JavaBean
	 *  compatible. You must call {@link #setListModel(ListModel)} after you create <code>QuickSearchField</code> using
	 *  this constructor.
	 */
	public QuickListFilterField() {
	}

	/**
	 *  Creates a <code>QuickSearchField</code> using the specified listModel.
	 * 
	 *  @param listModel the ListModel
	 */
	public QuickListFilterField(javax.swing.ListModel listModel) {
	}

	/**
	 *  Applies the filter.
	 */
	@java.lang.Override
	public void applyFilter(String text) {
	}

	/**
	 *  prepare other query based on the input text.
	 *  <p/>
	 *  By default, the implementation is null. You can update your information if you subclass this class.
	 * 
	 *  @param text the input text
	 */
	protected void prepareQuery(String text) {
	}

	/**
	 *  Sets the table model used by this component. It could be any table model, not necessarily be a
	 *  FilterableListModel.
	 * 
	 *  @param listModel the ListModel
	 */
	public void setListModel(javax.swing.ListModel listModel) {
	}

	protected FilterableListModel createDisplayListModel(javax.swing.ListModel listModel) {
	}

	/**
	 *  Gets the table model.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.ListModel getListModel() {
	}

	/**
	 *  Gets the display table model. <code>QuickSearchField</code> doesn't modify the table model that you passed in but
	 *  wrap it in FilterableListModel. So if you want to display the result after being filtered, you should use this
	 *  method to get the display table model and set it to your table.
	 * 
	 *  @return the table model to be displayed.
	 */
	public FilterableListModel getDisplayListModel() {
	}

	/**
	 *  Gets the list that is using the displayListModel.
	 * 
	 *  @return the list that is using the displayListModel.
	 */
	public javax.swing.JList getList() {
	}

	/**
	 *  Sets the list that is using the displayListModel. The only reason we want to know the list is to keep the
	 *  selection during filtering. For example, if node A is selected before filtering, and since it matches with the
	 *  searching text, the selection should be kept after filtering. If you didn't call this method to let
	 *  <code>QuickListFilterField</code> what the list is, the selection will be gone.
	 *  <p/>
	 *  Please note, this method will be set displayListModel onto the list. You still need to call {@link
	 *  #getDisplayListModel()} to get the model and set it to the list.
	 *  <p/>
	 *  Please note, even calling this method will not be able to keep selection in the following scenario. Node A is
	 *  selected before filtering. However, it does not match with the searching text and is filtered out. After clearing
	 *  the searching text, the node A come back but without selection.
	 * 
	 *  @param list the JList
	 */
	public void setList(javax.swing.JList list) {
	}
}
