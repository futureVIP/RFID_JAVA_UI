/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


public abstract class AbstractDualListModel extends javax.swing.AbstractListModel implements DualListModel, DelegateToDualListModelSupport {
 {

	protected java.beans.PropertyChangeSupport changeSupport;

	public AbstractDualListModel() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public boolean isSelectedIndex(int index) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public int[] getSelectedIndices() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void addSelectionInterval(int index0, int index1) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void removeSelectionInterval(int index0, int index1) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void moveSelection(int index0, int index1, int newIndex, boolean before) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void clearSelection() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public boolean isSelectionEmpty() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void selectAll() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setValueIsAdjusting(boolean valueIsAdjusting) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public boolean getValueIsAdjusting() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setSelectionMode(int selectionMode) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public int getSelectionMode() {
	}

	@java.lang.Override
	public void addFreezeIndex(int index) {
	}

	@java.lang.Override
	public void removeFreezeIndex(int index) {
	}

	@java.lang.Override
	public int[] getFrozenIndices() {
	}

	@java.lang.Override
	public boolean isFreezeIndex(int index) {
	}

	public void addListSelectionListener(javax.swing.event.ListSelectionListener l) {
	}

	public void removeListSelectionListener(javax.swing.event.ListSelectionListener l) {
	}

	/**
	 *  Returns an array of all the list selection listeners
	 *  registered on this <code>DefaultListSelectionModel</code>.
	 * 
	 *  @return all of this model's <code>ListSelectionListener</code>s
	 *          or an empty
	 *          array if no list selection listeners are currently registered
	 *  @see #addListSelectionListener
	 *  @see #removeListSelectionListener
	 *  @since 1.4
	 */
	public javax.swing.event.ListSelectionListener[] getListSelectionListeners() {
	}

	/**
	 *  Notifies <code>ListSelectionListeners</code> that the value of the selection, in the closed interval
	 *  <code>firstIndex</code>, <code>lastIndex</code>, has changed.
	 * 
	 *  @param firstIndex the first index in the interval
	 *  @param lastIndex  the last index in the interval
	 */
	protected void fireValueChanged(int firstIndex, int lastIndex) {
	}

	/**
	 *  @param firstIndex  the first index in the interval
	 *  @param lastIndex   the last index in the interval
	 *  @param isAdjusting true if this is the final change in a series of
	 *                     adjustments
	 *  @see DualListModelSupport
	 */
	protected void fireValueChanged(int firstIndex, int lastIndex, boolean isAdjusting) {
	}

	/**
	 *  Add a PropertyChangeListener to the listener list.
	 *  The listener is registered for all properties.
	 *  The same listener object may be added more than once, and will be called
	 *  as many times as it is added.
	 *  If <code>listener</code> is null, no exception is thrown and no action
	 *  is taken.
	 * 
	 *  @param listener The PropertyChangeListener to be added
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Remove a PropertyChangeListener from the listener list.
	 *  This removes a PropertyChangeListener that was registered
	 *  for all properties.
	 *  If <code>listener</code> was added more than once to the same event
	 *  source, it will be notified one less time after being removed.
	 *  If <code>listener</code> is null, or was never added, no exception is
	 *  thrown and no action is taken.
	 * 
	 *  @param listener The PropertyChangeListener to be removed
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners that were added to the
	 *  PropertyChangeSupport object with addPropertyChangeListener().
	 * 
	 *  @return all of the <code>PropertyChangeListeners</code> added or an
	 *          empty array if no listeners have been added
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Add a PropertyChangeListener for a specific property.  The listener
	 *  will be invoked only when a call on firePropertyChange names that
	 *  specific property.
	 *  The same listener object may be added more than once.  For each
	 *  property,  the listener will be invoked the number of times it was added
	 *  for that property.
	 *  If <code>propertyName</code> or <code>listener</code> is null, no
	 *  exception is thrown and no action is taken.
	 * 
	 *  @param propertyName The name of the property to listen on.
	 *  @param listener     The PropertyChangeListener to be added
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Remove a PropertyChangeListener for a specific property.
	 *  If <code>listener</code> was added more than once to the same event
	 *  source for the specified property, it will be notified one less time
	 *  after being removed.
	 *  If <code>propertyName</code> is null,  no exception is thrown and no
	 *  action is taken.
	 *  If <code>listener</code> is null, or was never added for the specified
	 *  property, no exception is thrown and no action is taken.
	 * 
	 *  @param propertyName The name of the property that was listened on.
	 *  @param listener     The PropertyChangeListener to be removed
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated
	 *  with the named property.
	 * 
	 *  @param propertyName The name of the property being listened to
	 *  @return all of the <code>PropertyChangeListeners</code> associated with
	 *          the named property.  If no such listeners have been added,
	 *          or if <code>propertyName</code> is null, an empty array is
	 *          returned.
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Report a bound property update to any registered listeners.
	 *  No event is fired if old and new are equal and non-null.
	 * 
	 *  @param propertyName The programmatic name of the property
	 *                      that was changed.
	 *  @param oldValue     The old value of the property.
	 *  @param newValue     The new value of the property.
	 */
	public void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Fire an existing PropertyChangeEvent to any registered listeners.
	 *  No event is fired if the given event's old and new values are
	 *  equal and non-null.
	 * 
	 *  @param evt The PropertyChangeEvent object.
	 */
	public void firePropertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Report a bound indexed property update to any registered
	 *  listeners.
	 *  <p/>
	 *  No event is fired if old and new values are equal
	 *  and non-null.
	 * 
	 *  @param propertyName The programmatic name of the property that
	 *                      was changed.
	 *  @param index        index of the property element that was changed.
	 *  @param oldValue     The old value of the property.
	 *  @param newValue     The new value of the property.
	 *  @since 1.5
	 */
	public void fireIndexedPropertyChange(String propertyName, int index, Object oldValue, Object newValue) {
	}

	/**
	 *  Check if there are any listeners for a specific property, including
	 *  those registered on all properties.  If <code>propertyName</code>
	 *  is null, only check for listeners registered on all properties.
	 * 
	 *  @param propertyName the property name.
	 *  @return true if there are one or more listeners for the given property
	 */
	public synchronized boolean hasListeners(String propertyName) {
	}

	@java.lang.Override
	public int[] internalGetSelectedIndices() {
	}
}
