/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  A filter for <code>FilterableListModel</code>. This filter tells you the value's row index in case you need it when
 *  determining if the value should be filtered. Of course, if you don't need row index when filtering a value, you can
 *  just use a regular <code>Filter</code>.
 */
public interface ListFilter extends com.jidesoft.filter.Filter {
 {

	/**
	 *  Sets the row index in the ListModel.
	 * 
	 *  @param rowIndex
	 */
	public void setRowIndex(int rowIndex);

	/**
	 *  Gets the row index in the ListModel.
	 * 
	 *  @return the row index.
	 */
	public int getRowIndex();
}
