/**
 *  The package contains all kinds of components and classes related to JList for JIDE Grids product.
 */
package com.jidesoft.list;


/**
 *  <code>FilterableListModel</code> is a list model which wraps another list model so that user can apply filters on
 *  it.
 *  <p/>
 *  You can use {@link #addFilter(com.jidesoft.filter.Filter)} to a filter to the ListModel. By default, filters won't
 *  take effect immediately. You need to call <code>setFiltersApplied(true)</code> to apply those filters. If
 *  <code>filtersApplied</code> flag is true already, you just need to call refresh(). We don't refresh automatically
 *  because you might have several filters to add. You can add all of them, then only call refresh once.
 *  <code>setFiltersApplied(boolean)</code> controls all the filters. Each filter has its own enabled flag which will
 *  control each individual filter.
 *  <p/>
 *  By default, if you have more than one filters, all filters will be used in AND mode. You can see javadoc of {@link
 *  #setAndMode(boolean)} to find more information.
 */
public class FilterableListModel extends DefaultListModelWrapper {

	/**
	 *  The data structure contains all the filters.
	 */
	protected java.util.List _filters;

	/**
	 *  A flag to turn on/off filters. {@link #setFiltersApplied(boolean)} with true will turn it on and {@link
	 *  #setFiltersApplied(boolean)} with false will turn it off.
	 */
	protected boolean _filtersApplied;

	public FilterableListModel() {
	}

	/**
	 *  Creates a FilterableListModel from any table model.
	 * 
	 *  @param model list model
	 */
	public FilterableListModel(javax.swing.ListModel model) {
	}

	@java.lang.Override
	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	/**
	 *  Reapply all filters after they are changed.
	 */
	public void refresh() {
	}

	/**
	 *  Applies filters and generates a new array of indices.
	 */
	protected void filter() {
	}

	/**
	 *  The method contains the algorithm to filter the specified row. If you want to filter the row, return true.
	 *  Otherwise, return false. The default algorithm will filter the row whose if any of columns filters return true.
	 *  Subclass can override this method to do a different way. Use getFilters(int col) to get filters. You should
	 *  always check for isFiltersApplied(). If it's false, always return false. You should also check for each filter to
	 *  see if it's enabled (filter.isEnabled()). If enabled return false, you should skip the filter.
	 * 
	 *  @param row     the row index
	 *  @param filters The list of filters
	 *  @return true if the row should be filtered. Otherwise, false.
	 */
	protected boolean shouldBeFiltered(int row, java.util.List filters) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterableListModelListener
	 */
	public void addFilterableListModelListener(FilterableListModelListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the filter occurs.
	 * 
	 *  @param l the FilterableListModelListener
	 */
	public void removeFilterableListModelListener(FilterableListModelListener l) {
	}

	/**
	 *  Returns an array of all the FilterableListModel listeners registered on this filter.
	 * 
	 *  @return all of this filter's <code>FilterableListModelListener</code>s or an empty array if no filter listeners
	 *          are currently registered
	 * 
	 *  @see #addFilterableListModelListener
	 *  @see #removeFilterableListModelListener
	 */
	public FilterableListModelListener[] getFilterableTableModelListeners() {
	}

	/**
	 *  Forwards the given notification event to all <code>FilterableTableModelListeners</code> that registered
	 *  themselves as listeners for this list model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addFilterableListModelListener
	 *  @see com.jidesoft.list.FilterableListModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireFilterChanged(FilterableListModelEvent e) {
	}

	/**
	 *  Adds a list of filters to the list model.
	 * 
	 *  @param filters the filters to be added
	 */
	public void addFilters(java.util.List filters) {
	}

	/**
	 *  Adds a filter to the list model. <p>You can use {@link AbstractFilter} to create new filter. If you need the row
	 *  index in order to decide if the value should be filtered, you can use {@link AbstractListFilter} and use
	 *  getRowIndex() to find out current row index.
	 * 
	 *  @param filter the filter to be added
	 */
	public void addFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes the filter from the list model.
	 * 
	 *  @param filter the filter to be removed
	 */
	public void removeFilter(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Removes all filters of this list model.
	 */
	public void clearFilters() {
	}

	/**
	 *  Gets all filters.
	 * 
	 *  @return the filters.
	 */
	public com.jidesoft.filter.Filter[] getFilters() {
	}

	/**
	 *  Applies or unapplies the filters. By default, the filters are not applied. So after user adds several filters,
	 *  this method should be called to make filters taking effect. When new filter is added or existing is removed, this
	 *  method should be called as well.
	 * 
	 *  @param apply true to apply the filters.
	 */
	public void setFiltersApplied(boolean apply) {
	}

	/**
	 *  Checks if the filters are in effect.
	 * 
	 *  @return true if filters are in effect.
	 */
	public boolean isFiltersApplied() {
	}

	/**
	 *  Checks if the <code>FilterableTableModel</code> has any filters.
	 * 
	 *  @return true if there are any filters. Otherwise false.
	 */
	public boolean hasFilter() {
	}

	/**
	 *  Sets the logic of filters on the list model. If true, filters are in AND mode, meaning if one of the filters
	 *  return true in isValueFiltered method, the value will be filtered. If false, filters are in OR mode, meaning if
	 *  one of the filters return false, the value will NOT be filtered.
	 * 
	 *  @return the AND/OR mode. Default is true which means AND mode.
	 */
	public boolean isAndMode() {
	}

	/**
	 *  Sets the logic of the filters on the same column.
	 * 
	 *  @param andMode the and mode flag
	 */
	public void setAndMode(boolean andMode) {
	}

	/**
	 *  Checks if the FilterableListModel is adjusting. If it is adjusting, FilterableListModel will not apply filter
	 *  when the actual list model changes.
	 * 
	 *  @return true if adjusting. Otherwise false.
	 */
	public boolean isAdjusting() {
	}

	/**
	 *  Sets the FilterableListModel to adjusting mode. If it is adjusting, FilterableListModel will not apply filter
	 *  when the actual list model changes. After you set adjusting to false, FilterableListModel will re-apply the
	 *  filter.
	 * 
	 *  @param adjusting the adjusting flag
	 */
	public void setAdjusting(boolean adjusting) {
	}
}
