/**
 *  The package contains Microsoft Excel(TM) exporting related classes using POI HSSF for JIDE Grids product.
 */
package com.jidesoft.hssf;


/**
 *  <code>HssfTableUtils</code> is a class that has methods to export any JTable's content to Excel (.xls) file format
 *  using HSSF-POI. You can find more information about HSSF-POI at http://poi.apache.org/spreadsheet/index.html.
 *  <p/>
 *  The export feature will not consider the cell contents conversion but you can use CellValueConverter to format the
 *  value if you want. It also supports cell span if the table model is SpanModel. It will also optionally consider table
 *  header as part of the export. Cell style is also supported as far as the Excel format allows.
 *  <p/>
 *  Please set the client property {@link #CLIENT_PROPERTY_EXCEL_OUTPUT_FORMAT} for the target JTable before you invoke
 *  this method so that you can choose the output format. If you didn't set the client property, we will use office2003
 *  format for backward compatibility concern.
 *  <p/>
 *  Please be noted that, if you use office2003 format, there is a limitation that the row count cannot exceed 65536. Although
 *  office2007 format looks solve the issue, it will consume extremely high memory which in most case is not realistic. So
 *  in general, we currently have limitation that the row count cannot exceed 65536. 
 */
public class HssfTableUtils {

	/**
	 *  The format for the component to export to excel. There are two formats defined.
	 * 
	 *  @see #EXCEL_OUTPUT_FORMAT_2003
	 *  @see #EXCEL_OUTPUT_FORMAT_2007
	 */
	public static final String CLIENT_PROPERTY_EXCEL_OUTPUT_FORMAT = "ExcelOutputFormat:";

	/**
	 *  A value for {@link #CLIENT_PROPERTY_EXCEL_OUTPUT_FORMAT} to support format on Microsoft Office 2003 and earlier
	 *  versions.
	 */
	public static final String EXCEL_OUTPUT_FORMAT_2003 = "2003";

	/**
	 *  A value for {@link #CLIENT_PROPERTY_EXCEL_OUTPUT_FORMAT} to support format on Microsoft Office 2007 and later
	 *  versions.
	 */
	public static final String EXCEL_OUTPUT_FORMAT_2007 = "2007";

	public HssfTableUtils() {
	}

	/**
	 *  Check if poi.jar is in the classpath. All <code>export</code> methods in this util called this method first
	 *  before continuing.
	 * 
	 *  @return true if poi.jar is in the classpath. Otherwise false.
	 */
	public static boolean isHssfInstalled() {
	}

	/**
	 *  Check if poi.jar is in the classpath. All <code>export</code> methods in this util called this method first
	 *  before continuing.
	 * 
	 *  @return true if poi.jar is in the classpath. Otherwise false.
	 */
	public static boolean isXssfInstalled() {
	}

	/**
	 *  Exports the table to an Excel file.
	 * 
	 *  @param table     the table to be exported.
	 *  @param fileName  the Excel file name. It should be the full path to the file.
	 *  @param sheetName the worksheet name.
	 *  @param append    whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName, String sheetName, boolean append) {
	}

	/**
	 *  Exports the table to an Excel file.
	 * 
	 *  @param table              the table to be exported.
	 *  @param fileName           the Excel file name. It should be the full path to the file.
	 *  @param sheetName          the worksheet name.
	 *  @param append             whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @param includeTableHeader whether to include the table header.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName, String sheetName, boolean append, boolean includeTableHeader) {
	}

	/**
	 *  Exports the table to an Excel file.
	 * 
	 *  @param table              the table to be exported.
	 *  @param fileName           the Excel file name. It should be the full path to the file.
	 *  @param sheetName          the worksheet name.
	 *  @param append             whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @param includeTableHeader whether to include the table header.
	 *  @param converter          the converter to convert cell value to the value that can be set to Excel cell.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, String fileName, String sheetName, boolean append, boolean includeTableHeader, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the table to an Excel file.
	 * 
	 *  @param table              the table to be exported.
	 *  @param firstRow           the first row to be exported
	 *  @param firstColumn        the first row to be exported
	 *  @param numberOfRows       number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns    number of columns to be exported. -1 means all columns.
	 *  @param fileName           the Excel file name. It should be the full path to the file.
	 *  @param sheetName          the worksheet name.
	 *  @param append             whether it appends to the existing Excel file or it creates a new Excel file.
	 *  @param includeTableHeader whether to include the table header.
	 *  @param converter          the converter to convert cell value to the value that can be set to Excel cell.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String fileName, String sheetName, boolean append, boolean includeTableHeader, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the table to as Excel file output steam.
	 * 
	 *  @param table     the table to be exported.
	 *  @param out       the output stream
	 *  @param sheetName the worksheet name.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, String sheetName) {
	}

	/**
	 *  Exports the table to as Excel file output steam.
	 * 
	 *  @param table              the table to be exported.
	 *  @param out                the output stream
	 *  @param sheetName          the worksheet name.
	 *  @param includeTableHeader whether to include the table header.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, String sheetName, boolean includeTableHeader) {
	}

	/**
	 *  Exports the table to as Excel file output steam.
	 * 
	 *  @param table              the table to be exported.
	 *  @param out                the output stream
	 *  @param sheetName          the worksheet name.
	 *  @param includeTableHeader whether to include the table header.
	 *  @param converter          the converter to convert cell value to the value that can be set to Excel cell.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, String sheetName, boolean includeTableHeader, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the table to as Excel file output steam.
	 * 
	 *  @param table              the table to be exported.
	 *  @param out                the output stream
	 *  @param firstRow           the first row to be exported
	 *  @param firstColumn        the first row to be exported
	 *  @param numberOfRows       number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns    number of columns to be exported. -1 means all columns.
	 *  @param sheetName          the worksheet name.
	 *  @param includeTableHeader whether to include the table header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to Excel cell.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String sheetName, boolean includeTableHeader, HssfTableUtils.CellValueConverter cellValueConverter) {
	}

	/**
	 *  Exports the table to as Excel file output steam.
	 * 
	 *  @param table               the table to be exported.
	 *  @param out                 the output stream
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param sheetName           the worksheet name.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to Excel cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 *  @return true if exporting succeed. If poi.jar is not in the classpath, false will be returned. Exception will be
	 *          thrown if there is error during the exporting.
	 * 
	 *  @throws IOException                   if the write to the file failed.
	 *  @throws java.io.FileNotFoundException if the file exists but is a directory rather than a regular file, does not
	 *                                        exist but cannot be created, or cannot be opened for any other reason
	 */
	public static boolean export(javax.swing.JTable table, java.io.OutputStream out, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, String sheetName, boolean includeTableHeader, HssfTableUtils.CellValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table       the table to be exported.
	 *  @param wb          the Workbook
	 *  @param sheet       the worksheet
	 *  @param startRow    the starting row. The first cell of the table will appear at this row index.
	 *  @param startColumn the starting column. The first cell of the table will appear at this row index.
	 */
	public static void exportToSheet(javax.swing.JTable table, Workbook wb, Sheet sheet, int startRow, int startColumn) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table       the table to be exported.
	 *  @param wb          the Workbook
	 *  @param sheet       the worksheet
	 *  @param startRow    the starting row. The first cell of the table will appear at this row index.
	 *  @param startColumn the starting column. The first cell of the table will appear at this row index.
	 *  @param converter   the converter to convert cell value to the value that can be set to Excel cell.
	 */
	public static void exportToSheet(javax.swing.JTable table, Workbook wb, Sheet sheet, int startRow, int startColumn, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table              the table to be exported.
	 *  @param wb                 the Workbook
	 *  @param sheet              the worksheet
	 *  @param startRow           the starting row. The first cell of the table will appear at this row index.
	 *  @param startColumn        the starting column. The first cell of the table will appear at this row index.
	 *  @param includeTableHeader whether to include the table header.
	 */
	public static void exportToSheet(javax.swing.JTable table, Workbook wb, Sheet sheet, int startRow, int startColumn, boolean includeTableHeader) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table              the table to be exported.
	 *  @param wb                 the Workbook
	 *  @param sheet              the worksheet
	 *  @param startRow           the starting row. The first cell of the table will appear at this row index.
	 *  @param startColumn        the starting column. The first cell of the table will appear at this row index.
	 *  @param includeTableHeader whether to include the table header.
	 *  @param converter          the converter to convert cell value to the value that can be set to Excel cell.
	 */
	public static void exportToSheet(javax.swing.JTable table, Workbook wb, Sheet sheet, int startRow, int startColumn, boolean includeTableHeader, HssfTableUtils.CellValueConverter converter) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table               the table to be exported.
	 *  @param wb                  the Workbook
	 *  @param sheet               the worksheet
	 *  @param startRow            the starting row. The first cell of the table will appear at this row index.
	 *  @param startColumn         the starting column. The first cell of the table will appear at this row index.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param converter           the converter to convert cell value to the value that can be set to Excel cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 */
	public static void exportToSheet(javax.swing.JTable table, Workbook wb, Sheet sheet, int startRow, int startColumn, boolean includeTableHeader, HssfTableUtils.CellValueConverter converter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table              the table to be exported.
	 *  @param firstRow           the first row to be exported
	 *  @param firstColumn        the first row to be exported
	 *  @param numberOfRows       number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns    number of columns to be exported. -1 means all columns.
	 *  @param wb                 the Workbook
	 *  @param sheet              the worksheet
	 *  @param startRow           the starting row. The first cell of the table will appear at this row index.
	 *  @param startColumn        the starting column. The first cell of the table will appear at this row index.
	 *  @param includeTableHeader whether to include the table header.
	 *  @param cellValueConverter the converter to convert cell value to the value that can be set to Excel cell.
	 */
	public static void exportToSheet(javax.swing.JTable table, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, Workbook wb, Sheet sheet, int startRow, int startColumn, boolean includeTableHeader, HssfTableUtils.CellValueConverter cellValueConverter) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table               the table to be exported.
	 *  @param firstRow            the first row to be exported
	 *  @param firstColumn         the first row to be exported
	 *  @param numberOfRows        number of rows to be exported, -1 means all rows.
	 *  @param numberOfColumns     number of columns to be exported. -1 means all columns.
	 *  @param wb                  the Workbook
	 *  @param sheet               the worksheet
	 *  @param startRow            the starting row. The first cell of the table will appear at this row index.
	 *  @param startColumn         the starting column. The first cell of the table will appear at this row index.
	 *  @param includeTableHeader  whether to include the table header.
	 *  @param cellValueConverter  the converter to convert cell value to the value that can be set to Excel cell.
	 *  @param columnNameConverter the converter to convert the column name.
	 */
	public static void exportToSheet(javax.swing.JTable table, int firstRow, int firstColumn, int numberOfRows, int numberOfColumns, Workbook wb, Sheet sheet, int startRow, int startColumn, boolean includeTableHeader, HssfTableUtils.CellValueConverter cellValueConverter, StringConverter columnNameConverter) {
	}

	/**
	 *  Exports the table to the specified location of an Excel sheet.
	 * 
	 *  @param table  the table to be exported.
	 *  @param wb     the Workbook
	 *  @param sheet  the worksheet
	 *  @param format HssfTableFormat instance which stores every single information needed for exporting to sheet
	 */
	public static void exportToSheet(javax.swing.JTable table, Workbook wb, Sheet sheet, HssfTableFormat format) {
	}

	/**
	 *  Exports a value to a particular cell in the sheet.
	 * 
	 *  @param sheet       the worksheet
	 *  @param rowIndex    the row index of the cell
	 *  @param columnIndex the column index of the cell
	 *  @param value       the value
	 */
	public static void exportToCell(Sheet sheet, int rowIndex, int columnIndex, Object value) {
	}

	/**
	 *  Converts the cell value in a table to the value that will be written to Excel cell.
	 */
	public static interface class CellValueConverter {


		/**
		 *  Converts the value to the value you want to set in the Excel.
		 *  <p/>
		 *  If you need to access the HSSFWorkbook instance used during this exporting process, you can get it using
		 *  table.getClientProperty("HssfTableUtils.HSSFWorkbook").
		 * 
		 *  @param table       the table
		 *  @param value       the value in the table
		 *  @param rowIndex    the row index of the value
		 *  @param columnIndex the column index of the value
		 *  @return the converted value.
		 */
		public Object convert(javax.swing.JTable table, Object value, int rowIndex, int columnIndex) {
		}

		/**
		 *  Gets the data format for the value. The formats are defined in POI's HSSF. Available formats are
		 *  <p/>
		 *  0, "General"<br> 1, "0"<br> 2, "0.00"<br> 3, "#,##0"<br> 4, "#,##0.00"<br> 5, "($#,##0_);($#,##0)"<br> 6,
		 *  "($#,##0_);[Red]($#,##0)"<br> 7, "($#,##0.00);($#,##0.00)"<br> 8, "($#,##0.00_);[Red]($#,##0.00)"<br> 9,
		 *  "0%"<br> 0xa, "0.00%"<br> 0xb, "0.00E+00"<br> 0xc, "# ?/?"<br> 0xd, "# ??/??"<br> 0xe, "m/d/yy"<br> 0xf,
		 *  "d-mmm-yy"<br> 0x10, "d-mmm"<br> 0x11, "mmm-yy"<br> 0x12, "h:mm AM/PM"<br> 0x13, "h:mm:ss AM/PM"<br> 0x14,
		 *  "h:mm"<br> 0x15, "h:mm:ss"<br> 0x16, "m/d/yy h:mm"<br>
		 *  <p/>
		 *  // 0x17 - 0x24 reserved for international and undocumented 0x25, "(#,##0_);(#,##0)"<P> 0x26,
		 *  "(#,##0_);[Red](#,##0)"<P> 0x27, "(#,##0.00_);(#,##0.00)"<P> 0x28, "(#,##0.00_);[Red](#,##0.00)"<P> 0x29,
		 *  "_(*#,##0_);_(*(#,##0);_(* \"-\"_);_(@_)"<P> 0x2a, "_($*#,##0_);_($*(#,##0);_($* \"-\"_);_(@_)"<P> 0x2b,
		 *  "_(*#,##0.00_);_(*(#,##0.00);_(*\"-\"??_);_(@_)"<P> 0x2c, "_($*#,##0.00_);_($*(#,##0.00);_($*\"-\"??_);_(@_)"<P>
		 *  0x2d, "mm:ss"<P> 0x2e, "[h]:mm:ss"<P> 0x2f, "mm:ss.0"<P> 0x30, "##0.0E+0"<P> 0x31, "@" - This is text
		 *  format.<P> 0x31  "text" - Alias for "@"<P>
		 *  <p/>
		 *  If you need to access the HSSFWorkbook instance used during this exporting process, you can get it using
		 *  table.getClientProperty("HssfTableUtils.HSSFWorkbook").
		 * 
		 *  @param table       the table
		 *  @param value       the value in the table
		 *  @param rowIndex    the row index of the value
		 *  @param columnIndex the column index of the value
		 *  @return the data format as defined above. -1 if you don't care and use the default format.
		 */
		public int getDataFormat(javax.swing.JTable table, Object value, int rowIndex, int columnIndex) {
		}
	}

	/**
	 *  Converts the cell value in a table to the value that will be written to Excel cell.
	 */
	public static class DefaultCellValueConverter {


		public HssfTableUtils.DefaultCellValueConverter() {
		}

		public Object convert(javax.swing.JTable table, Object value, int rowIndex, int columnIndex) {
		}

		public int getDataFormat(javax.swing.JTable table, Object value, int rowIndex, int columnIndex) {
		}
	}

	/**
	 *  Converts the cell value in a table to the value that will be written to Excel cell. The benefit of this converter
	 *  is that you would get almost the same visible contents in Excel as you run your application. However, the side
	 *  effect is that everything in Excel at the start point would be String instead of its original type. In this case,
	 *  the return value of getDataFormat does not take effect.
	 */
	public static class ContextSensitiveCellValueConverter {


		public HssfTableUtils.ContextSensitiveCellValueConverter() {
		}

		public Object convert(javax.swing.JTable table, Object value, int rowIndex, int columnIndex) {
		}

		public int getDataFormat(javax.swing.JTable table, Object value, int rowIndex, int columnIndex) {
		}
	}
}
