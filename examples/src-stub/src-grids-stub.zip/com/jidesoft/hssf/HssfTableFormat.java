/**
 *  The package contains Microsoft Excel(TM) exporting related classes using POI HSSF for JIDE Grids product.
 */
package com.jidesoft.hssf;


/**
 *  HssfTableFormat is a class to store the export properties to a excel sheet.
 */
public class HssfTableFormat implements Cloneable {
 {

	/**
	 *  Copy Constructor
	 * 
	 *  @param hssfTableFormat a <code>HssfTableFormat</code> object
	 */
	public HssfTableFormat(HssfTableFormat hssfTableFormat) {
	}

	/**
	 *  Default Constructor.
	 */
	public HssfTableFormat() {
	}

	@java.lang.Override
	protected Object clone() {
	}

	/**
	 *  Get top border style.
	 * 
	 *  @return the top border style.
	 */
	public short getTopBorder() {
	}

	/**
	 *  Set top border style.
	 * 
	 *  @param topBorder the top border style
	 */
	public void setTopBorder(short topBorder) {
	}

	/**
	 *  Get bottom border style.
	 * 
	 *  @return the bottom border style.
	 */
	public short getBottomBorder() {
	}

	/**
	 *  Set bottom border style.
	 * 
	 *  @param bottomBorder the bottom border style
	 */
	public void setBottomBorder(short bottomBorder) {
	}

	/**
	 *  Get left border style.
	 * 
	 *  @return the left border style.
	 */
	public short getLeftBorder() {
	}

	/**
	 *  Set left border style.
	 * 
	 *  @param leftBorder the left border style
	 */
	public void setLeftBorder(short leftBorder) {
	}

	/**
	 *  Get right border style.
	 * 
	 *  @return the right border style.
	 */
	public short getRightBorder() {
	}

	/**
	 *  Set right border style.
	 * 
	 *  @param rightBorder the right border style
	 */
	public void setRightBorder(short rightBorder) {
	}

	/**
	 *  Get the flag indicating if we should auto resize column width during exporting.
	 * 
	 *  @return true if need auto resize. Otherwise false.
	 */
	public boolean isAutoSizeColumns() {
	}

	/**
	 *  Set the flag indicating if we should auto resize column width during exporting.
	 * 
	 *  @param autoSizeColumns the flag
	 */
	public void setAutoSizeColumns(boolean autoSizeColumns) {
	}

	/**
	 *  Get the first row in JTable to be exported to excel sheet.
	 * 
	 *  @return the first row.
	 */
	public int getFirstRow() {
	}

	/**
	 *  Set the first row in JTable to be exported to excel sheet.
	 * 
	 *  @param firstRow the first row
	 */
	public void setFirstRow(int firstRow) {
	}

	/**
	 *  Get the first column in JTable to be exported to excel sheet.
	 * 
	 *  @return the first column.
	 */
	public int getFirstColumn() {
	}

	/**
	 *  Set the first column in JTable to be exported to excel sheet.
	 * 
	 *  @param firstColumn the first column
	 */
	public void setFirstColumn(int firstColumn) {
	}

	/**
	 *  Get the number of rows in JTable to be exported to excel sheet.
	 * 
	 *  @return the number of rows.
	 */
	public int getNumberOfRows() {
	}

	/**
	 *  Set the number of rows in JTable to be exported to excel sheet.
	 * 
	 *  @param numberOfRows the number of rows
	 */
	public void setNumberOfRows(int numberOfRows) {
	}

	/**
	 *  Get the number of columns in JTable to be exported to excel sheet.
	 * 
	 *  @return the number of columns.
	 */
	public int getNumberOfColumns() {
	}

	/**
	 *  Set the number of columns in JTable to be exported to excel sheet.
	 * 
	 *  @param numberOfColumns the number of columns
	 */
	public void setNumberOfColumns(int numberOfColumns) {
	}

	/**
	 *  Get the start row in the excel sheet to be exported to.
	 * 
	 *  @return the start row.
	 */
	public int getStartRow() {
	}

	/**
	 *  Set the start row in the excel sheet to be exported to.
	 * 
	 *  @param startRow the start row
	 */
	public void setStartRow(int startRow) {
	}

	/**
	 *  Get the start column in the excel sheet to be exported to.
	 * 
	 *  @return the start column.
	 */
	public int getStartColumn() {
	}

	/**
	 *  Set the start column in the excel sheet to be exported to.
	 * 
	 *  @param startColumn the start column
	 */
	public void setStartColumn(int startColumn) {
	}

	/**
	 *  Get the flag indicating if we should export the table header to excel sheet as well.
	 * 
	 *  @return true if need export the table header. Otherwise false.
	 */
	public boolean isIncludeTableHeader() {
	}

	/**
	 *  Set the flag indicating if we should export the table header to excel sheet as well.
	 * 
	 *  @param includeTableHeader the flag
	 */
	public void setIncludeTableHeader(boolean includeTableHeader) {
	}

	/**
	 *  Get the cell value converter to convert the value to string displayed in the target excel sheet.
	 * 
	 *  @return the cell value converter.
	 */
	public HssfTableUtils.CellValueConverter getCellValueConverter() {
	}

	/**
	 *  Set the cell value converter to convert the value to string displayed in the target excel sheet.
	 * 
	 *  @param cellValueConverter the cell value converter
	 */
	public void setCellValueConverter(HssfTableUtils.CellValueConverter cellValueConverter) {
	}

	/**
	 *  Get the column name converter to convert the value to string displayed in the target excel sheet.
	 * 
	 *  @return the column name converter.
	 */
	public StringConverter getColumnNameConverter() {
	}

	/**
	 *  Set the column name converter to convert the value to string displayed in the target excel sheet.
	 * 
	 *  @param columnNameConverter the column name converter
	 */
	public void setColumnNameConverter(StringConverter columnNameConverter) {
	}

	/**
	 *  Get the flag indicating whether to print in landscape.
	 * 
	 *  @return true if need print in landscape. Otherwise false.
	 */
	public boolean isPrintLandscape() {
	}

	/**
	 *  Set the flag indicating whether to print in landscape.
	 * 
	 *  @param printLandscape the flag
	 */
	public void setPrintLandscape(boolean printLandscape) {
	}

	/**
	 *  Get the flag indicating whether to include page number in the excel sheet.
	 * 
	 *  @return true if need include page number. Otherwise false.
	 */
	public boolean isIncludePageNumbers() {
	}

	/**
	 *  Set the flag indicating whether to include page number in the excel sheet.
	 * 
	 *  @param includePageNumbers the flag
	 */
	public void setIncludePageNumbers(boolean includePageNumbers) {
	}

	/**
	 *  Get the flag indicating whether to set print fit to the page.
	 * 
	 *  @return true if need set print fit to the page. Otherwise false.
	 */
	public boolean isPrintFitToPage() {
	}

	/**
	 *  Set the flag indicating whether to set print fit to the page.
	 * 
	 *  @param printFitToPage the flag
	 */
	public void setPrintFitToPage(boolean printFitToPage) {
	}

	/**
	 *  Get the flag indicating whether to set freeze pane in the target excel sheet for header tables.
	 * 
	 *  @return true if need set freeze pane for header tables. Otherwise false.
	 */
	public boolean isFreezePanes() {
	}

	/**
	 *  Set the flag indicating whether to set freeze pane in the target excel sheet for header tables.
	 * 
	 *  @param freezePanes the flag
	 */
	public void setFreezePanes(boolean freezePanes) {
	}

	/**
	 *  Get the header in the excel sheet.
	 * 
	 *  @return the header.
	 */
	public String getHeader() {
	}

	/**
	 *  Set the header in the excel sheet.
	 * 
	 *  @param header the header.
	 */
	public void setHeader(String header) {
	}

	/**
	 *  Get the flag if the rows should be grouped if there is expandable row in the table.
	 * 
	 *  @return true if group required. Otherwise false.
	 *  @see #setGroupExpandable(boolean)
	 */
	public boolean isGroupExpandable() {
	}

	/**
	 *  Set the flag if the rows should be grouped if there is expandable row in the table.
	 *  <p/>
	 *  The default value is true.
	 * 
	 *  @param groupExpandable the flag
	 */
	public void setGroupExpandable(boolean groupExpandable) {
	}

	/**
	 *  Constructs a <code>String</code> with all attributes in name = value format.
	 * 
	 *  @return a <code>String</code> representation of this object.
	 */
	public String toString() {
	}
}
