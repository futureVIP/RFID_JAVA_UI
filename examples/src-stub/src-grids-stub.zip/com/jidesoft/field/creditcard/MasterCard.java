package com.jidesoft.field.creditcard;


/**
 *  MasterCard credit card Issuer.
 */
public class MasterCard implements CardIssuer {
 {

	/**
	 *  Issuer Name
	 */
	public static final String NAME = "MasterCard";

	/**
	 *  Code to be returned when card number is not start with 51 to 55
	 */
	public static final int VAILDATE_ERROR_NOT_START_WITH_51_TO_55 = 200;

	public MasterCard() {
	}

	/**
	 *  Card number length should be 16, Issuer Identifier should be 51xxxx-55xxxx.
	 * 
	 *  @param cardNumber number to be checked
	 *  @return 0-the number is valid, other-invalid
	 */
	public int isCardNumberValid(String cardNumber) {
	}

	/**
	 *  Get card issuer's name
	 * 
	 *  @return card issuer's name
	 */
	public String getName() {
	}

	/**
	 *  Get card issuer's icon
	 * 
	 *  @return card issuer's icon
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  set card issuer's icon
	 * 
	 *  @param icon card issuer's icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}
}
