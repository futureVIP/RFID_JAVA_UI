package com.jidesoft.field.creditcard;


/**
 *  An interface to mask a credit card number.
 */
public interface CreditCardMask {

	/**
	 *  Masks the credit card number.
	 * 
	 *  @param cardNumber credit card number to be masked
	 *  @return masked credit card number
	 */
	public String mask(String cardNumber);
}
