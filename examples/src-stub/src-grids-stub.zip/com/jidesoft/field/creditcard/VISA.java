package com.jidesoft.field.creditcard;


/**
 *  VISA credit card Issuer.
 */
public class VISA implements CardIssuer {
 {

	/**
	 *  Issuer Name
	 */
	public static final String NAME = "VISA";

	/**
	 *  Code to be returned when card number is not start with 4
	 */
	public static final int VALIDATE_ERROR_NOT_START_WITH_4 = 100;

	public VISA() {
	}

	/**
	 *  Card number length should be 13 or 16, Issuer Identifier should be "4xxxxx".
	 * 
	 *  @param cardNumber number to be checked
	 *  @return 0-the number is valid, other-invalid
	 */
	public int isCardNumberValid(String cardNumber) {
	}

	/**
	 *  Get card issuer's name
	 * 
	 *  @return card issuer's name
	 */
	public String getName() {
	}

	/**
	 *  Get card issuer's icon
	 * 
	 *  @return card issuer's icon
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  set card issuer's icon
	 * 
	 *  @param icon card issuer's icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}
}
