package com.jidesoft.field.creditcard;


/**
 *  Discover credit card Issuer.
 */
public class Discover implements CardIssuer {
 {

	/**
	 *  Issuer Name
	 */
	public static final String NAME = "Discover";

	/**
	 *  Code to be returned when card number is not start with 6011
	 */
	public static final int VAILDATE_ERROR_NOT_START_WITH_6011 = 400;

	public Discover() {
	}

	/**
	 *  Card number length should be 16, Issuer Identifier should be "6011xx"".
	 * 
	 *  @param cardNumber number to be checked
	 *  @return 0-the number is valid, other-invalid
	 */
	public int isCardNumberValid(String cardNumber) {
	}

	/**
	 *  Get card issuer's name
	 * 
	 *  @return card issuer's name
	 */
	public String getName() {
	}

	/**
	 *  Get card issuer's icon
	 * 
	 *  @return card issuer's icon
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  set card issuer's icon
	 * 
	 *  @param icon card issuer's icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}
}
