/**
 *  The package contains classes related to Lucene for JIDE Grids product.
 */
package com.jidesoft.lucene;


/**
 *  <code>LuceneFilterableListModel</code> is a special FilterableListModel which uses Lucene mechanism to speed up the
 *  search.
 */
public class LuceneFilterableListModel extends com.jidesoft.list.FilterableListModel implements LuceneDocumentProvider {
 {

	public static final String LIST_FIELD_NAME = "list";

	public LuceneFilterableListModel() {
	}

	/**
	 *  Creates a FilterableListModel from any list model.
	 * 
	 *  @param model list model
	 */
	public LuceneFilterableListModel(javax.swing.ListModel model) {
	}

	@java.lang.Override
	public void intervalAdded(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void intervalRemoved(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	public void contentsChanged(javax.swing.event.ListDataEvent e) {
	}

	@java.lang.Override
	protected void filter() {
	}

	@java.lang.Override
	public void fireFilterChanged(com.jidesoft.list.FilterableListModelEvent e) {
	}

	/**
	 *  Convert Filter to Query text.
	 *  <p/>
	 *  So far we only converted FieldFilter to Query instances. You
	 *  can convert your desired filter to query as you wish. If you think you cannot convert the filter you encounter,
	 *  you'd better return null. Otherwise, you probably will lose some effect from the lost filter.
	 * 
	 *  @param filter      the filter
	 *  @return null if you think this filter is not able to converted to query text in some cases. "" if you want to
	 *          ignore the filter. Otherwise return a valid string.
	 */
	protected String convertFilterToLuceneQueryText(com.jidesoft.filter.Filter filter) {
	}

	/**
	 *  Convert the element in the list model to string.
	 *  <p/>
	 *  This method will be invoked by {@link #getDocument} so that LuceneSupport will have right string to do indexing.
	 *  @param element the value on the list model
	 *  @return the string to be searched on.
	 */
	protected String convertElementToString(Object element) {
	}

	public Document getDocument(int rowIndex) {
	}

	public int getDocumentCount() {
	}

	public void notifyIndexCreated() {
	}
}
