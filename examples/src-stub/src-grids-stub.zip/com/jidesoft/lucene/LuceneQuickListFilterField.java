/**
 *  The package contains classes related to Lucene for JIDE Grids product.
 */
package com.jidesoft.lucene;


/**
 *  <code>LuceneQuickListFilterField</code> works along with <code>LuceneFilterableListModel</code> to provide high performance searching feature.
 *  @see com.jidesoft.list.QuickListFilterField
 */
public class LuceneQuickListFilterField extends com.jidesoft.list.QuickListFilterField implements LuceneFilterField {
 {

	/**
	 *  Creates an empty <code>LuceneQuickListFilterField</code>. This method is useless since <code>LuceneQuickListFilterField</code>
	 *  has to have a table model in order to work correctly. So we have this method in place mainly to make it JavaBean
	 *  compatible. You must call {@link #setListModel(javax.swing.ListModel)} after you create
	 *  <code>LuceneQuickListFilterField</code> using this constructor.
	 */
	public LuceneQuickListFilterField() {
	}

	/**
	 *  Creates a <code>LuceneQuickListFilterField</code> using the specified listModel.
	 * 
	 *  @param listModel the ListModel
	 */
	public LuceneQuickListFilterField(javax.swing.ListModel listModel) {
	}

	/**
	 *  Sets the table model used by this component. It could be any table model, not necessarily be a
	 *  FilterableListModel.
	 * 
	 *  @param listModel the ListModel
	 */
	@java.lang.Override
	public void setListModel(javax.swing.ListModel listModel) {
	}

	/**
	 *  Create a filtering wrapper list model for LuceneQuickListFilterField.
	 *  <p/>
	 *  In this method, we will create a LuceneFilterableListModel instance by default.
	 *  @param listModel the list model
	 *  @return a FilterableListModel instance.
	 */
	protected com.jidesoft.list.FilterableListModel createDisplayListModel(javax.swing.ListModel listModel) {
	}

	/**
	 *  Get the popup menu for the instance of LuceneQuickTableFilterField
	 *  <p/>
	 *  Please see {@link com.jidesoft.lucene.LuceneQuickTableFilterField} for details of the menu items.
	 *  @return the popup menu.
	 */
	@java.lang.Override
	protected JidePopupMenu createContextMenu() {
	}

	public LuceneDocumentProvider getLuceneDocumentProvider() {
	}

	@java.lang.Override
	protected void prepareQuery(String text) {
	}

	/**
	 *  Get the flag if current input mode for JTextField is lucene input mode.
	 *  @return the flag.
	 */
	public boolean isLuceneInputMode() {
	}

	/**
	 *  Set the flag if current input mode for JTextField is lucene input mode.
	 *  @param luceneInputMode the flag
	 */
	public void setLuceneInputMode(boolean luceneInputMode) {
	}
}
