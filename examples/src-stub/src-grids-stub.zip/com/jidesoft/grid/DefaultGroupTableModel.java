/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public class DefaultGroupTableModel extends AbstractGroupTableModel implements ColumnIdentifierTableModel, SpanModel, RowTableModelWrapper, ColumnTableModelWrapper {
 {

	public static final int SORT_GROUP_COLUMN_NO_SORT = 0;

	public static final int SORT_GROUP_COLUMN_ASCENDING = 1;

	public static final int SORT_GROUP_COLUMN_DESCENDING = -1;

	public DefaultGroupTableModel(javax.swing.table.TableModel tableModel) {
	}

	public void groupAndRefresh() {
	}

	protected DefaultGroupRow createGroupRow() {
	}

	protected ReferenceRow createReferenceRow(javax.swing.table.TableModel tableModel, int row) {
	}

	public boolean isKeepColumnOrder() {
	}

	public void setKeepColumnOrder(boolean keepColumnOrder) {
	}

	public DefaultGroupRow addGroupRow(Expandable parentRow, DefaultGroupRow groupRow) {
	}

	public DefaultGroupRow findParentGroupRow(Expandable parent, GroupCondition condition) {
	}

	protected void ensureGroupColumnsCreated() {
	}

	@java.lang.Override
	public boolean isGroupEnabled() {
	}

	/**
	 *  Is the column grouped.
	 * 
	 *  @param columnIndex the column index. It is the column index as in the model.l
	 *  @return true if the column is grouped. Otherwise false.
	 */
	public boolean isColumnGrouped(int columnIndex) {
	}

	/**
	 *  Checks if it has grouped columns.
	 * 
	 *  @return true if it has grouped columns. Otherwise false.
	 */
	public boolean hasGroupColumns() {
	}

	/**
	 *  Gets the total count of group columns. You can use this method to get the count then use {@link
	 *  #getGroupColumnAt(int)} method to find out each group column index.
	 * 
	 *  @return the total count of group columns.
	 */
	public int getGroupColumnCount() {
	}

	/**
	 *  Gets the group column index.
	 * 
	 *  @param index the column index.
	 *  @return the group column index.
	 */
	public int getGroupColumnAt(int index) {
	}

	/**
	 *  Gets the group column order
	 * 
	 *  @param index the column index
	 *  @return the order.
	 */
	public int getGroupColumnOrder(int index) {
	}

	public void addGroupColumn(int columnIndex) {
	}

	public void addGroupColumn(int columnIndex, int sorting) {
	}

	public void removeGroupColumn(int columnIndex) {
	}

	public void setGroupColumns(int[] columnIndices) {
	}

	public void setGroupColumns(int[] columnIndices, int[] columnSorting) {
	}

	public void clearGroupColumns() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public Object getColumnIdentifier(int column) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	public boolean isSingleLevelGrouping() {
	}

	public void setSingleLevelGrouping(boolean singleLevelGrouping) {
	}

	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public DefaultGroupRow findGroupRow(Expandable parent, javax.swing.table.TableModel tableModel, int rowIndex) {
	}

	public DefaultGroupRow findGroupRow(Row row, int columnIndex) {
	}

	@java.lang.Override
	public Row getRowAt(int rowIndex) {
	}

	@java.lang.Override
	public int getRowIndex(Row row) {
	}

	public ReferenceRow getReferenceRow(int rowIndex) {
	}

	public boolean isCellSpanOn() {
	}

	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	protected void updateReference(int index, int inc) {
	}

	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	protected void tableStructureChanged() {
	}

	protected void tableDataChanged() {
	}

	public int[] getColumnMapping() {
	}

	public javax.swing.table.TableModel getActualModel() {
	}

	public int getActualRowAt(int visualRow) {
	}

	public int getVisualRowAt(int actualRow) {
	}

	public int getActualColumnAt(int column) {
	}

	public int getVisualColumnAt(int actualColumn) {
	}

	/**
	 *  Get the flag indicating if the GroupTable should display group columns.
	 *  <p/>
	 *  By default, the value is false to not show the group columns.
	 * 
	 *  @return true if the GroupTable should display group columns. Otherwise false.
	 */
	public boolean isDisplayGroupColumns() {
	}

	/**
	 *  Set the flag indicating if the GroupTable should display group columns.
	 * 
	 *  @param displayGroupColumns the flag
	 *  @see #isDisplayGroupColumns()
	 */
	public void setDisplayGroupColumns(boolean displayGroupColumns) {
	}

	/**
	 *  Get the flag indicating if a separate group column should be created to represent the grouped columns.
	 *  <p/>
	 *  By default, the value is false to not show the separate group column. This flag only takes effect while {@link
	 *  #isDisplayGroupColumns()} returns false and {@link #isKeepColumnOrder()} returns false.
	 * 
	 *  @return true if a separate group column is displayed. Otherwise false.
	 * 
	 *  @see #setDisplayGroupColumns(boolean)
	 *  @see #setKeepColumnOrder(boolean)
	 */
	public boolean isDisplaySeparateGroupColumn() {
	}

	/**
	 *  Set the flag indicating if a separate group column should be created to represent the grouped columns.
	 * 
	 *  @param displaySeparateGroupColumn the flag
	 *  @see #isDisplaySeparateGroupColumn()
	 */
	public void setDisplaySeparateGroupColumn(boolean displaySeparateGroupColumn) {
	}

	protected String getSeparateGroupColumnName() {
	}

	/**
	 *  Get the flag indicating if a separate count column should be created to represent the count.
	 *  <p/>
	 *  By default, the value is false to not show the separate count column. This flag only takes effect while {@link
	 *  #isDisplayGroupColumns()} returns true.
	 * 
	 *  @return true if a separate count column is displayed. Otherwise false.
	 * 
	 *  @see #setDisplayGroupColumns(boolean)
	 */
	public boolean isDisplayCountColumn() {
	}

	/**
	 *  Set the flag indicating if a separate count column should be created to represent the count.
	 * 
	 *  @param displayCountColumn the flag
	 *  @see #isDisplayCountColumn()
	 */
	public void setDisplayCountColumn(boolean displayCountColumn) {
	}

	@java.lang.Override
	public void expandRow(ExpandableRow row, boolean expanded) {
	}

	@java.lang.Override
	public void expandAll() {
	}

	/**
	 *  Expand all rows.
	 * 
	 *  @param fireDataChangedEvent the flag to indicating if a data changed event should be fired after expanding all.
	 */
	protected void expandAll(boolean fireDataChangedEvent) {
	}

	@java.lang.Override
	public void expandFirstLevel() {
	}

	@java.lang.Override
	public void collapseAll() {
	}

	@java.lang.Override
	public void collapseFirstLevel() {
	}

	/**
	 *  Sorts the rows.
	 *  <p/>
	 *  Subclass can override this method to implement their own algorithm to sort. When doing comparison in the
	 *  algorithm, use the compare(int, int) method defined in this class.
	 * 
	 *  @param from an int array of row indices to be sorted
	 *  @param to   an int array of row indices to store the result after sorting
	 *  @param low  the start index of the row in the array to be sorted
	 *  @param high the end index of the row in the array to be sorted
	 */
	protected void sort(int[] from, int[] to, int low, int high) {
	}

	protected int compare(int row1, int row2) {
	}

	protected int compare(Object o1, Object o2, int column) {
	}

	/**
	 *  For performance, all comparators for each column should be cached first.
	 */
	protected void cacheComparators() {
	}

	/**
	 *  Gets the column comparator. Subclass can override it to return a comparator for a particular column. By default,
	 *  SortableTableModel will look up for a comparator from ObjectComparatorManager based on getColumnClass return
	 *  value and getColumnComparatorContext return value. Please note, for the performance reason, if both objects are
	 *  Comparable of the same type, we will use Comparable#compareTo method to compare the two objects. Then we will use
	 *  the Comparator. If you want to always use Comparator to compare, you can call {@link
	 *  #setAlwaysUseComparators(boolean)} and set it to true.
	 * 
	 *  @param columnIndex the column index in the actual table model. It's NOT the column index in the group table
	 *                     model.
	 *  @return the comparator for the specified column.
	 */
	protected java.util.Comparator getComparator(int columnIndex) {
	}

	/**
	 *  Gets the column comparator context. Subclass can override it to return a comparator context. By default it will
	 *  return null. It should only be used when the column class for two columns are the same but you want to compare
	 *  them differently. First you need to register two different comparators using {@link ObjectComparatorManager}
	 *  using different comparator context in {@link ObjectComparatorManager#registerComparator(Class,java.util.Comparator,com.jidesoft.comparator.ComparatorContext)}
	 *  method. Then return the corresponding context when overriding this method.
	 *  <p/>
	 *  We also add a setter for this. You can call {@link #setColumnComparatorContextProvider(com.jidesoft.grid.DefaultGroupTableModel.ColumnComparatorContextProvider)}
	 *  to provide a ColumnComparatorContextProvider. This provider will return a ComparatorContext for each column. This
	 *  will be helpful when it's hard to override SortableTableModel.
	 * 
	 *  @param column the column index in the actual table model. It's NOT the column index in the group table model.
	 *  @return the comparator context for the column.
	 */
	protected ComparatorContext getColumnComparatorContext(int column) {
	}

	/**
	 *  Get the flag indicating if the row will be moved to upper level if the last grouper values are null.
	 * 
	 *  @return true if the row will be moved to upper level. Otherwise false.
	 * 
	 *  @see #setRemoveNullGrouper(boolean)
	 */
	public boolean isRemoveNullGrouper() {
	}

	/**
	 *  Set the flag indicating if the row will be moved to upper level if the last grouper values are null.
	 *  <p/>
	 *  The default value is false to keep original behavior.
	 * 
	 *  @param removeNullGrouper the flag
	 */
	public void setRemoveNullGrouper(boolean removeNullGrouper) {
	}

	/**
	 *  Gets the ColumnComparatorContextProvider.
	 * 
	 *  @return the ColumnComparatorContextProvider.
	 */
	public DefaultGroupTableModel.ColumnComparatorContextProvider getColumnComparatorContextProvider() {
	}

	/**
	 *  Sets the <code>ColumnComparatorContextProvider</code>. This provider will provide a
	 *  <code>ComparatorContext</code> for each column. If this table model has several columns that have the same types
	 *  in getColumnClass method but you want to use different comparators to compare and sort them, you would need to
	 *  register several comparators on <code>ObjectComparatorManager</code> using different
	 *  <code>ComparatorContext</code>. Then you can this provider to return different contexts so that
	 *  <code>SortableTableModel</code> can find the correct comparator registered on
	 *  <code>ObjectComparatorManager</code>. If you call this method with a non-null provider, we will automatically
	 *  call {@link #setAlwaysUseComparators(boolean)} and set it to true.
	 * 
	 *  @param columnComparatorContextProvider
	 *          the columnComparatorContextProvider
	 */
	public void setColumnComparatorContextProvider(DefaultGroupTableModel.ColumnComparatorContextProvider columnComparatorContextProvider) {
	}

	/**
	 *  Checks if the alwaysUseComparators flag value.
	 * 
	 *  @return true if alwaysUseComparators is true. Otherwise false.
	 */
	public boolean isAlwaysUseComparators() {
	}

	/**
	 *  Sets the alwaysUseComparators flag. By default, we will check if the two values are Comparable. If they both are,
	 *  we will use {@link Comparable#compareTo(Object)} to compare. This is the default preferred way because this gives
	 *  developer a finer control of the comparison result. People also sometimes forgot to implement getColumnClass and
	 *  getColumnComparatorContext. If so, a wrong comparator could be used. If this flag is set to true, we will always
	 *  use Comparators to compare which you means you must implement getColumnClass and optionally implement
	 *  getColumnComparatorContext or use {@link #setColumnComparatorContextProvider(com.jidesoft.grid.DefaultGroupTableModel.ColumnComparatorContextProvider)}
	 *  so that the correct comparator will be used for each column.
	 * 
	 *  @param alwaysUseComparators true or false.
	 */
	public void setAlwaysUseComparators(boolean alwaysUseComparators) {
	}

	@java.lang.Override
	public java.util.Map getExpansionState() {
	}

	@java.lang.Override
	public void setExpansionState(java.util.Map state) {
	}

	/**
	 *  While grouping, the rows are sorted first according the grouping columns. You could use this method to get
	 *  current sorting direction.
	 * 
	 *  @return true if the sorting is ascending, false if the sorting is descending.
	 * 
	 *  @deprecated replaced by {@link #addGroupColumn(int, int)}, sorting is the second parameter.
	 */
	@java.lang.Deprecated
	public boolean isAscendingGroupOrder() {
	}

	/**
	 *  While grouping, the rows are sorted first according the grouping columns. You could use this method to set
	 *  current sorting direction.
	 * 
	 *  @param order true to make later sorting ascending, false to make later sorting descending.
	 *  @deprecated replaced by {@link #addGroupColumn(int, int)}, sorting is the second parameter.
	 */
	@java.lang.Deprecated
	public void setAscendingGroupOrder(boolean order) {
	}

	/**
	 *  Gets the flag indicating if the previous expand status should be kept on data changing, adding/removing group columns.
	 * 
	 *  @see #setKeepPreviousExpandStatus(boolean)
	 *  @return true if previous expand status should be kept. Otherwise false.
	 */
	public boolean isKeepPreviousExpandStatus() {
	}

	/**
	 *  Sets the flag indicating if the previous expand status should be kept on data changing, adding/removing group columns.
	 *  <p/>
	 *  This flag has higher priority of {@link #setAutoExpand(boolean)}, which means if the new group row could be found in
	 *  previous status, it will take the expand status from auto expanding.
	 *  <p/>
	 *  By default, the flag is true. You could set it to false to return to original behavior.
	 * 
	 *  @param keepPreviousExpandStatus the flag
	 */
	public void setKeepPreviousExpandStatus(boolean keepPreviousExpandStatus) {
	}

	/**
	 *  Gets the flag indicating if previous grouping columns should be kept on receiving table structure changed event.
	 * 
	 *  @see #setKeepGroupingOnStructureChange(boolean)
	 *  @return true if previous grouping should be kept. Otherwise false.
	 */
	public boolean isKeepGroupingOnStructureChange() {
	}

	/**
	 *  Sets the flag indicating if previous grouping columns should be kept on receiving table structure changed event.
	 *  <p/>
	 *  By default, the flag is false. You could set it to true to return to original behavior.
	 * 
	 *  @param keepGroupingOnStructureChange the flag
	 */
	public void setKeepGroupingOnStructureChange(boolean keepGroupingOnStructureChange) {
	}

	/**
	 *  An interface used by {@link SortableTableModel#setColumnComparatorContextProvider(com.jidesoft.grid.SortableTableModel.ColumnComparatorContextProvider)}.
	 */
	public static interface class ColumnComparatorContextProvider {


		public ComparatorContext getColumnComparatorContext(javax.swing.table.TableModel tableModel, int column) {
		}
	}
}
