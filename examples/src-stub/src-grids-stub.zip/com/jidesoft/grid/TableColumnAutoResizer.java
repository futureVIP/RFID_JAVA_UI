/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Allows table column automatically resize to fit in all the contents in the cells when user mouse double clicks on the
 *  grid line of table header or table depending on the parameter you use to construct this class. To use it, you simply
 *  call
 *  <code><pre>
 *  new TableColumnAutoResizer(table);
 *  </pre></code>
 *  or
 *  <code><pre>
 *  new TableColumnAutoResizer(table, false);
 *  </pre></code>
 *  If you use any of the tables provided by JIDE Grids, you can simply call {@link
 *  JideTable#setColumnAutoResizable(boolean)} to make columns auto-resizable. *
 * 
 *  @author Jan Reidemeister
 *  @author JIDE Software, Inc.
 */
public class TableColumnAutoResizer extends TableResizer {

	protected static final String KEY = "columnAutoResizer";

	/**
	 *  Constructor. The default value for onTableHeader is true, meaning that the auto resize is effective on the table
	 *  header.
	 * 
	 *  @param table the table to enable column auto resize
	 */
	public TableColumnAutoResizer(javax.swing.JTable table) {
	}

	/**
	 *  Constructor.
	 * 
	 *  @param table         the table to enable column auto resize
	 *  @param onTableHeader if the auto resize feature is going to be effective on table header or table cells.
	 */
	public TableColumnAutoResizer(javax.swing.JTable table, boolean onTableHeader) {
	}

	@java.lang.Override
	public javax.swing.event.MouseInputListener createMouseInputListener() {
	}

	/**
	 *  The action to resize the column. In some cases like PivotTablePane, you need consider the synchronization between
	 *  different tables.
	 * 
	 *  @param resizingColumn the column to be resized.
	 */
	protected void resizeColumn(javax.swing.table.TableColumn resizingColumn) {
	}
}
