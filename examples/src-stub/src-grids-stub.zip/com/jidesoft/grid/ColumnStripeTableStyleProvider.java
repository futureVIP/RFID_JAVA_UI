/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellStyleProvider</code> for column stripes.
 */
public class ColumnStripeTableStyleProvider implements TableStyleProvider {
 {

	protected static final java.awt.Color DEFAULT_COLUMN_STRIPE_COLOR;

	/**
	 *  Creates a <code>ColumnStripeCellStyleProvider</code>. It uses WHITE and a very light yellow color as two
	 *  alternative column colors.
	 */
	public ColumnStripeTableStyleProvider() {
	}

	/**
	 *  Creates a <code>ColumnStripeCellStyleProvider</code>. You can define the alternative colors here.
	 * 
	 *  @param alternativeBackground the alternative column background colors. The length of the array should be greater
	 *                               than or equal to 2. You could use an array that the length is 1 but it will not have
	 *                               a stripe effect but the same background for all columns.
	 */
	public ColumnStripeTableStyleProvider(java.awt.Color[] alternativeBackground) {
	}

	/**
	 *  Creates a <code>ColumnStripeCellStyleProvider</code>. You can define the alternative colors here.
	 * 
	 *  @param alternativeBackground the alternative column background colors. The length of the array should be greater
	 *                               than or equal to 2. You could use an array that the length is 1 but it will not have
	 *                               a stripe effect but the same background for all columns.
	 *  @param alternativeForeground the alternative column foreground colors. The length of the array should be greater
	 *                               than or equal to 2. You could use an array that the length is 1 but it will not have
	 *                               a stripe effect but the same foreground for all columns.
	 */
	public ColumnStripeTableStyleProvider(java.awt.Color[] alternativeBackground, java.awt.Color[] alternativeForeground) {
	}

	public CellStyle getCellStyleAt(javax.swing.JTable table, int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the alternative background colors.
	 * 
	 *  @return the alternative background colors.
	 */
	public java.awt.Color[] getAlternativeBackgroundColors() {
	}

	/**
	 *  Sets alternative background colors for the columns.
	 * 
	 *  @param alternativeBackgroundColors alternative colors.
	 */
	public void setAlternativeBackgroundColors(java.awt.Color[] alternativeBackgroundColors) {
	}

	/**
	 *  Gets the alternative foreground colors.
	 * 
	 *  @return the alternative foreground colors.
	 */
	public java.awt.Color[] getAlternativeForegroundColors() {
	}

	/**
	 *  Sets alternative Foreground colors for the columns.
	 * 
	 *  @param alternativeForegroundColors alternative colors.
	 */
	public void setAlternativeForegroundColors(java.awt.Color[] alternativeForegroundColors) {
	}
}
