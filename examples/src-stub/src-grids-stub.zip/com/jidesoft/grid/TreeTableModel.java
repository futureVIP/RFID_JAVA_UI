/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TreeTableModel</code> is the table model used by {@link TreeTable}.
 *  <p/>
 *  The most information thing about a <code>TreeTableModel</code> has to have a list of rows. We called it original
 *  rows. You can either specify it by using constructor {@link #TreeTableModel(java.util.List)} or call {@link
 *  #setOriginalRows(java.util.List)}. The items in this list should be an instance of {@link Row}.
 *  <p/>
 *  Once you create the list of Rows and set it to TreeTableModel, you can set the model to {@link TreeTable}. That's
 *  pretty much all you need to do if you just want to view it.
 *  <p/>
 *  There are also a few methods for changing the table data. {@link #addRow(Row)} will add a new Row to the end. {@link
 *  #addRow(int,Row)} will add the Row after the specified index. Or {@link #addRow(int,Row,boolean)} will give you a
 *  chance to add before or after a certain index. In addition, {@link #addRow(Row,Row)} adds a row to the specified
 *  parent row. There are two remove methods. {@link #removeRow(Row)} can remove any Row from the table model, no matter
 *  if it is in nested children. {@link #removeRow(int)} will remove the Row as long as it's visible because the index
 *  passed in has to be a valid index on the table.
 *  <p/>
 *  You can also move up and move down the row within its current level using {@link #moveUpRow(Row)} and {@link
 *  #moveDownRow(Row)} respectively.
 *  <p/>
 *  If those modification methods above still can't get what you want, you can always change the original rows. After you
 *  are done with the change, call {@link #refresh()} method once to refresh the table.
 */
public abstract class TreeTableModel extends javax.swing.table.AbstractTableModel implements ContextSensitiveTableModel, MultiTableModel, ITreeTableModel, IndexChangeEventGenerator {
 {

	/**
	 *  A flag to turn on/off filters. {@link #setFiltersApplied(boolean)} with true will turn it on and {@link
	 *  #setFiltersApplied(boolean)} with false will turn it off.
	 */
	protected boolean _filtersApplied;

	/**
	 *  Creates an empty TreeTableModel.
	 */
	public TreeTableModel() {
	}

	/**
	 *  Creates TreeTableModel from a list of rows.
	 * 
	 *  @param rows list of rows
	 */
	public TreeTableModel(java.util.List rows) {
	}

	/**
	 *  Sets the original row list. The elements in the list should be instance of {@link Row}. Otherwise
	 *  IllegalArgumentException will be thrown.
	 * 
	 *  @param rows a list of <code>Row</code>s
	 *  @throws IllegalArgumentException if any element in the list is not an instance of Row.
	 */
	public void setOriginalRows(java.util.List rows) {
	}

	/**
	 *  Rebuilds the displayed rows from the original rows.
	 * 
	 *  @param rows the original rows.
	 *  @return the rows to be displayed.
	 */
	protected java.util.List buildRows(java.util.List rows) {
	}

	/**
	 *  Creates the List to contain the rows.
	 * 
	 *  @return a List of Rows.
	 */
	protected java.util.List createRows() {
	}

	/**
	 *  Rebuilds the displayed rows from the original rows and fire table data changed event.
	 */
	public void refresh() {
	}

	protected boolean shouldBeFiltered(Row row) {
	}

	/**
	 *  Changes a row's children.
	 * 
	 *  @param parentRow the parent row.
	 *  @param children  the children
	 */
	public void setChildren(Row parentRow, java.util.List children) {
	}

	/**
	 *  Adds row to the parentRow. The parentRow has to be an instance of ExpandableRow. Otherwise, there is no effect.
	 * 
	 *  @param parentRow the parent row.
	 *  @param row       the row to be added.
	 */
	public void addRow(Row parentRow, Row row) {
	}

	/**
	 *  Adds row to the parentRow. The parentRow has to be an instance of ExpandableRow. Otherwise, there is no effect.
	 * 
	 *  @param parentRow the parent row.
	 *  @param position  the insert position relative to the parent row.
	 *  @param row       the row to be added.
	 */
	public void addRow(Row parentRow, int position, Row row) {
	}

	/**
	 *  Adds a row to the root level of the table model.
	 * 
	 *  @param row row to be added.
	 */
	public void addRow(Row row) {
	}

	/**
	 *  Adds a row at the specified index. It can add a row to any position in the table model except the first position.
	 *  If you want to insert the row at the first position, you should use {@link #addRow(int,Row,boolean)} and set the
	 *  last boolean to true. The new row will be at the same level as the row at the index.
	 * 
	 *  @param index the row index where the row will be added.
	 *  @param row   the row to be added.
	 */
	public void addRow(int index, Row row) {
	}

	/**
	 *  Adds a row at the specified index. You can also use the last boolean parameter to control if it is added before
	 *  the index or after the index. The new row will be at the same level as the row at the index.
	 * 
	 *  @param index  the row index. The index can be -1. If it is -1 and before == false, it will be append at the end.
	 *                If it is -1 or 0, and before == true, it will insert at the first position.
	 *  @param row    row to be added.
	 *  @param before if it should be added before index or after index.
	 */
	public void addRow(int index, Row row, boolean before) {
	}

	/**
	 *  Adds row to the parentRow. The parentRow has to be an instance of ExpandableRow. Otherwise, there is no effect.
	 * 
	 *  @param parentRow the parent row.
	 *  @param rows      the row to be added.
	 */
	public void addRows(Row parentRow, java.util.List rows) {
	}

	/**
	 *  Adds row to the parentRow. The parentRow has to be an instance of ExpandableRow. Otherwise, there is no effect.
	 * 
	 *  @param parentRow the parent row.
	 *  @param position  the insert position relative to the parent row.
	 *  @param rows      the rows to be added.
	 */
	public void addRows(Row parentRow, int position, java.util.List rows) {
	}

	/**
	 *  Adds a row to the root level of the table model.
	 * 
	 *  @param rows row to be added.
	 */
	public void addRows(java.util.List rows) {
	}

	/**
	 *  Adds a row at the specified index. It can add a row to any position in the table model except the first position.
	 *  If you want to insert the row at the first position, you should use {@link #addRows(int,java.util.List,boolean)}
	 *  and set the last boolean to false. The new row will be at the same level as the row at the index.
	 * 
	 *  @param index the row index where the row will be added.
	 *  @param rows  the row to be added.
	 */
	public void addRows(int index, java.util.List rows) {
	}

	/**
	 *  Adds a row at the specified index. You can also use the last boolean parameter to control if it is added before
	 *  the index or after the index. The new row will be at the same level as the row at the index.
	 * 
	 *  @param index  the row index. The index can be -1. If it is -1 and before == false, it will be append at the end.
	 *                If before == true, it will insert at the first position.
	 *  @param rows   row to be added.
	 *  @param before if it should be added before index or after index.
	 */
	public void addRows(int index, java.util.List rows, boolean before) {
	}

	/**
	 *  Removes the row from tree table model. The row could be at any child level of this tree table model.
	 * 
	 *  @param row the row to be removed
	 */
	public void removeRow(Row row) {
	}

	/**
	 *  Removes the row at the row index. No matter which level the row is, it will be removed. If the row has child
	 *  rows, all of them will be removed.
	 * 
	 *  @param rowIndex the row index of the row to be removed
	 */
	public void removeRow(int rowIndex) {
	}

	/**
	 *  Moves up the row within its same level. If the row has children, all of them will be moved up.
	 * 
	 *  @param row the row to be moved up.
	 */
	public void moveUpRow(Row row) {
	}

	/**
	 *  Moves down the row within its same level. If the row has children, all of them will be moved down.
	 * 
	 *  @param row the row to be moved down.
	 */
	public void moveDownRow(Row row) {
	}

	/**
	 *  Gets a flatten list of all the rows that is currently displayed in the table.
	 * 
	 *  @return the list of rows
	 */
	public java.util.List getRows() {
	}

	/**
	 *  Checks if setOriginalRows is called.
	 * 
	 *  @return true if setOriginalRows was called. Otherwise false.
	 */
	public boolean isInitialized() {
	}

	/**
	 *  Gets the list of rows used by the table model. Different from {@link #getRows()}, this method returns the
	 *  original rows that is passed to constructor or {@link #setOriginalRows(java.util.List)}.
	 * 
	 *  @return the list of properties as it is passed in constructor
	 */
	public java.util.List getOriginalRows() {
	}

	/**
	 *  Sets the value the underlying row of that cell.
	 * 
	 *  @param aValue      value to assign to cell
	 *  @param rowIndex    row of cell
	 *  @param columnIndex column of cell
	 */
	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	/**
	 *  Returns false if column is 0 and return the isEditable of the row if column is 1.
	 * 
	 *  @param rowIndex    the row being queried
	 *  @param columnIndex the column being queried
	 *  @return false
	 */
	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	/**
	 *  Returns the number of rows in the model. A <code>JTable</code> uses this method to determine how many rows it
	 *  should display.  This method should be quick, as it is called frequently during rendering.
	 * 
	 *  @return the number of rows in the model
	 * 
	 *  @see #getColumnCount
	 */
	public int getRowCount() {
	}

	/**
	 *  Gets the total count of the rows in the tree table model, including all the children.
	 * 
	 *  @param includeChildren true to include collapsed children as part of the count. Otherwise getRowCount() will be returned.
	 *  @return the count of all rows including children if includeChildren flag is true. Otherwise, it will return the visible row count.
	 */
	public int getRowCount(boolean includeChildren) {
	}

	/**
	 *  Returns the value for the cell at <code>columnIndex</code> and <code>rowIndex</code>.
	 * 
	 *  @param rowIndex    the row whose value is to be queried
	 *  @param columnIndex the column whose value is to be queried
	 *  @return the value Object at the specified cell
	 */
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Returns the row at row specified by <code>row</code>.
	 * 
	 *  @param rowIndex the row whose row is to be queried
	 *  @return the row at the specified row index
	 */
	public Row getRowAt(int rowIndex) {
	}

	/**
	 *  Gets the index of the row.
	 * 
	 *  @param row row
	 *  @return the index of the row. If the row is displayed in the table, it will return the index. Otherwise, it will
	 *          return -1. So -1 could mean two things - the row is not displayed or the row is not in the tree hierarchy
	 *          at all.
	 */
	public int getRowIndex(Row row) {
	}

	/**
	 *  Expands all the rows contained in the tree path
	 * 
	 *  @param path the tree path
	 */
	public void expandTreePath(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Expands or collapses the row.
	 * 
	 *  @param row      the row to be expanded or collapsed
	 *  @param expanded true to expand, false to collapse.
	 */
	public void expandRow(ExpandableRow row, boolean expanded) {
	}

	@java.lang.Override
	public void fireTableRowsUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  Expands all rows which have children.
	 */
	public void expandAll() {
	}

	/**
	 *  Expands all root level rows.
	 */
	public void expandFirstLevel() {
	}

	/**
	 *  Expands one more level of rows.
	 */
	public void expandNextLevel() {
	}

	/**
	 *  Expand the rows in the list.
	 * 
	 *  @param rows    the target rows to be expanded.
	 *  @param digIn   if the expand will be extended to the leaf level or just this level
	 */
	public void expandRows(java.util.List rows, boolean digIn) {
	}

	/**
	 *  Collapse all rows which have children.
	 */
	public void collapseAll() {
	}

	/**
	 *  Collapses all top level rows only. The children level rows are still expanded if they were. But they can't be
	 *  seen anymore as the root rows are collapsed. If you expand the root rows after this call, you will see the
	 *  children rows remain expanded.
	 */
	public void collapseFirstLevel() {
	}

	/**
	 *  Collapses all top level rows only. The children level rows are still expanded if they were. But they can't be
	 *  seen anymore as the root rows are collapsed. If you expand the root rows after this call, you will see the
	 *  children rows remain expanded.
	 */
	public void collapseLastLevel() {
	}

	/**
	 *  Collapse the rows in the list.
	 * 
	 *  @param rows    the target rows to be expanded.
	 *  @param digIn   if the expand will be extended to the leaf level or just this level
	 */
	public void collapseRows(java.util.List rows, boolean digIn) {
	}

	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the root expandable row which has the original rows as children.
	 * 
	 *  @return the root expandable row.
	 */
	public Object getRoot() {
	}

	/**
	 *  Creates <code>ExpandableRow</code> which will be used as the root row.
	 * 
	 *  @return an instance of <code>RootExpandableRow</code>.
	 */
	protected ExpandableRow createRoot() {
	}

	/**
	 *  Returns the child of <code>parent</code> at index <code>index</code> in the parent's child array.
	 *  <code>parent</code> must be a node previously obtained from this data source. This should not return
	 *  <code>null</code> if <code>index</code> is a valid index for <code>parent</code> (that is <code>index >= 0 &&
	 *  index < getChildCount(parent</code>)).
	 * 
	 *  @param parent a node in the tree, obtained from this data source
	 *  @param index  the index of the child
	 *  @return the child of <code>parent</code> at index <code>index</code>
	 */
	public Object getChild(Object parent, int index) {
	}

	/**
	 *  Returns the number of children of <code>parent</code>. Returns 0 if it has no children.
	 * 
	 *  @param parent a node in the tree model
	 *  @return the number of children of the node <code>parent</code>
	 */
	public int getChildCount(Object parent) {
	}

	/**
	 *  Returns the index of child in parent.  If either <code>parent</code> or <code>child</code> is <code>null</code>,
	 *  returns -1. If either <code>parent</code> or <code>child</code> don't belong to this tree model, returns -1.
	 * 
	 *  @param parent a node in the tree
	 *  @param child  the node we are interested in
	 *  @return the index of the child in the parent, or -1 if either <code>child</code> or <code>parent</code> are
	 *          <code>null</code> or don't belong to this tree table model
	 */
	public int getIndexOfChild(Object parent, Object child) {
	}

	/**
	 *  Returns <code>true</code> if <code>node</code> is a leaf. As long as the node is not an instance of Expandable,
	 *  it is a leaf. It is possible for this method to return <code>false</code> even if <code>node</code> has no
	 *  children. A directory in a filesystem, for example, may contain no files; the node representing the directory is
	 *  not a leaf, but it also has no children.
	 * 
	 *  @param node a node in the tree table model
	 *  @return true if <code>node</code> is a leaf
	 */
	public boolean isLeaf(Object node) {
	}

	public boolean isFilterParent() {
	}

	public void setFilterParent(boolean filterParent) {
	}

	/**
	 *  Applies or unapplies the filters. By default, the filters are not applied. So after user adds several filters,
	 *  this method should be called to make filters taking effect. When new filter is added or existing is removed, this
	 *  method should be called as well.
	 * 
	 *  @param apply true to apply the filters.
	 */
	public void setFiltersApplied(boolean apply) {
	}

	/**
	 *  Checks if the filters are in effect.
	 * 
	 *  @return true if filters are in effect.
	 */
	public boolean isFiltersApplied() {
	}

	/**
	 *  Check if the parent will expand automatically when a child is added to it.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutoExpand() {
	}

	/**
	 *  Sets the autoExpand flag. By default, the flag is true meaning the parent will expand automatically when a child
	 *  is added to it.
	 * 
	 *  @param autoExpand true or false.
	 */
	public void setAutoExpand(boolean autoExpand) {
	}

	public int getColumnType(int columnIndex) {
	}

	public int getTableIndex(int columnIndex) {
	}

	/**
	 *  Gets the list of rows used by the table model. The order is as displayed.
	 * 
	 *  @param includeChildren true to include collapsed children as part of the list. Otherwise getRows() will be returned.
	 *  @return the list of rows
	 */
	public java.util.List getRows(boolean includeChildren) {
	}

	public boolean isAdjusting() {
	}

	public void setAdjusting(boolean adjusting) {
	}

	/**
	 *  Gets the expansion state of all expansion state of tree table model. You can use this method along with {@link
	 *  #setExpansionState(java.util.Map)} to restore the tree table expansion state after the TreeTableModel is
	 *  recreated.
	 * 
	 *  @return a map contains the expansion state of all rows. To save memory, we only save the expanded tree path so
	 *          far.
	 */
	public java.util.Map getExpansionState() {
	}

	/**
	 *  Restores the expansion state of all rows in tree table model. You can use this method to restore the expansion
	 *  state after the TreeTableModel is created but rows remain. For newly added rows, this method will not change
	 *  their expansion state.
	 * 
	 *  @param state a map of the expansion state.
	 */
	public void setExpansionState(java.util.Map state) {
	}

	public void addIndexChangeListener(IndexChangeListener l) {
	}

	public void removeIndexChangeListener(IndexChangeListener l) {
	}
}
