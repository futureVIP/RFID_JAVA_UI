/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>RowTableModelWrapper</code> is a wrapper around table model which is referred
 *  as the actual table model or underlying table model. It can be used to provide a
 *  different row mapping to create a different view to the actual model. A typical use case is SortableTableModel.
 *  <p/>
 *  Just so you know, there are several useful methods at {@link TableModelWrapperUtils} which allows
 *  you to do the row index conversion from view index to model index and vice versa.
 * 
 *  @see TableModelWrapperUtils
 */
public interface RowTableModelWrapper extends TableModelWrapper {
 {

	/**
	 *  Gets the actual row index in the underlying table that
	 *  corresponds the specified row index.
	 * 
	 *  @param visualRow the visual row index.
	 *  @return the actual row. If the actual row doesn't exist, return -1.
	 */
	public int getActualRowAt(int visualRow);

	/**
	 *  Gets the visual row index representing the specified actual row.
	 * 
	 *  @param actualRow the actual row index.
	 *  @return the visual row index. -1 if there is no visual row representing it.
	 */
	public int getVisualRowAt(int actualRow);
}
