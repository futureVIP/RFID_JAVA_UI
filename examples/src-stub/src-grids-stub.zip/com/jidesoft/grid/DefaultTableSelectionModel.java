/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableSelectionModel</code> is a table selection model that can support non-contiguous selection. It is used by
 *  JideTable when {@link JideTable#setNonContiguousCellSelection(boolean)} is set to true.
 */
public class DefaultTableSelectionModel implements javax.swing.event.ListSelectionListener, TableSelectionModel {
 {

	/**
	 *  List of Listeners which will be notified when the selection value changes
	 */
	protected javax.swing.event.EventListenerList listenerList;

	/**
	 *  contains a ListSelectionModel for each column
	 */
	protected java.util.Vector _listSelectionModels;

	protected boolean _withinOneSelection;

	protected int _anchorRowIndex;

	protected int _anchorColumnIndex;

	protected int _leadRowIndex;

	protected int _leadColumnIndex;

	protected int _minRowIndex;

	protected int _minColumnIndex;

	protected int _maxRowIndex;

	protected int _maxColumnIndex;

	protected boolean _isValueAdjusting;

	public DefaultTableSelectionModel() {
	}

	public boolean isValueAdjusting() {
	}

	public void setValueAdjusting(boolean valueAdjusting) {
	}

	public void markAsDirty(int firstRow, int lastRow, int firstColumn, int lastColumn) {
	}

	/**
	 *  Adds the cell specified by row and column to the selection.
	 */
	public void addSelection(int row, int column) {
	}

	/**
	 *  Removes the cell specified by row and column from the selection.
	 */
	public void removeSelection(int row, int column) {
	}

	/**
	 *  Adds the cell specified by row and column to the selection. It will clear out other selections in the same
	 *  column.
	 */
	public void setSelection(int row, int column) {
	}

	/**
	 *  Adds the cells of the specified column between row1 and row2 to the selection. It will clear out other selections
	 *  in the same column.
	 */
	public void setSelectionInterval(int row1, int row2, int column) {
	}

	/**
	 *  Sets the anchor selection at the cell specified by row and column. This call will clear out the lead selection.
	 */
	public void setAnchorSelection(int row, int column) {
	}

	/**
	 *  Sets the lead selection at the cell specified by row and column. All cells in the range of anchor cell and lead
	 *  cell will be selected after this call.
	 * 
	 *  @param row    the new lead selection row index
	 *  @param column the new lead selection column index
	 */
	public void setLeadSelection(int row, int column) {
	}

	/**
	 *  Moves the lead selection at the cell specified by row and column and leaving all selection values unchanged.
	 * 
	 *  @param row    the new lead selection row index
	 *  @param column the new lead selection column index
	 */
	public void moveLeadSelection(int row, int column) {
	}

	/**
	 *  Clears all the selections.
	 */
	public void clearSelection() {
	}

	/**
	 *  Selects all the cells.
	 */
	public void selectAll(int rowCount, int columnCount) {
	}

	/**
	 *  Checks if the specified cell is selected.
	 * 
	 *  @return true if the specified cell is selected. Otherwise false.
	 */
	public boolean isSelected(int row, int column) {
	}

	/**
	 *  Returns the ListSelectionModel at the specified column.
	 * 
	 *  @param columnIndex the column
	 *  @return the ListSelectionModel for the column
	 */
	public javax.swing.ListSelectionModel getListSelectionModelAt(int columnIndex) {
	}

	/**
	 *  Set the number of columns.
	 * 
	 *  @param count the number of columns
	 */
	public void setColumns(int count) {
	}

	/**
	 *  Adds a column to the end of the model.
	 */
	protected void addColumn() {
	}

	/**
	 *  Inserts a column at the specified index of the model.
	 * 
	 *  @param index the column index.
	 */
	protected void insertColumn(int index) {
	}

	/**
	 *  Removes last column from model.
	 */
	protected void removeColumn() {
	}

	/**
	 *  When the TableModel changes, the TableSelectionModel has to adapt to the new Model. This method is called if a
	 *  new TableModel is set to the JTable.
	 */
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Add a listener to the list that's notified each time a change to the selection occurs.
	 */
	public void addTableSelectionListener(TableSelectionListener l) {
	}

	/**
	 *  Remove a listener from the list that's notified each time a change to the selection occurs.
	 */
	public void removeTableSelectionListener(TableSelectionListener l) {
	}

	/**
	 *  Is called when the TableModel changes. If the number of columns had changed this class will adapt to it.
	 */
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Is called when the selection of a ListSelectionModel of a column has changed.
	 */
	public void valueChanged(javax.swing.event.ListSelectionEvent e) {
	}

	/**
	 *  Notifies listeners that we have ended a series of adjustments.
	 * 
	 *  @param isAdjusting true or false.
	 */
	protected void fireValueChanged(boolean isAdjusting) {
	}

	/**
	 *  Notify listeners that we have ended a series of adjustments.
	 * 
	 *  @param source
	 *  @param firstIndex
	 *  @param lastIndex
	 *  @param columnIndex
	 *  @param isAdjusting
	 */
	protected void fireValueChanged(Object source, int firstIndex, int lastIndex, int columnIndex, boolean isAdjusting) {
	}

	protected void fireValueChanged() {
	}

	/**
	 *  Notify listeners that we have ended a series of adjustments.
	 * 
	 *  @param source
	 *  @param firstIndex
	 *  @param lastIndex
	 *  @param firstColumnIndex
	 *  @param lastColumnIndex
	 *  @param isAdjusting
	 */
	protected void fireValueChanged(Object source, int firstIndex, int lastIndex, int firstColumnIndex, int lastColumnIndex, boolean isAdjusting) {
	}

	@java.lang.Override
	public String toString() {
	}

	/**
	 *  Gets the anchor row index.
	 * 
	 *  @return the anchor row index.
	 */
	public int getAnchorRowIndex() {
	}

	/**
	 *  Gets the anchor column index.
	 * 
	 *  @return the anchor column index.
	 */
	public int getAnchorColumnIndex() {
	}

	/**
	 *  Gets the lead row index.
	 * 
	 *  @return the lead row index.
	 */
	public int getLeadRowIndex() {
	}

	/**
	 *  Gets the lead column index.
	 * 
	 *  @return the lead column index.
	 */
	public int getLeadColumnIndex() {
	}

	/**
	 *  Checks if there is any selection in the selection model.
	 * 
	 *  @return true if there is no selection. Otherwise false.
	 */
	public boolean isSelectionEmpty() {
	}

	public int[] getSelectedColumns() {
	}

	public int getSelectedColumnCount() {
	}

	public int[] getSelectedRows() {
	}

	public int getSelectedRowCount() {
	}

	public boolean isRowSelected(int rowIndex) {
	}

	public boolean isColumnSelected(int columnIndex) {
	}

	public int getMinSelectedRowIndex() {
	}

	public int getMaxSelectedRowIndex() {
	}

	public int getMinSelectedColumnIndex() {
	}

	public int getMaxSelectedColumnIndex() {
	}

	public void columnAdded(int columnIndex) {
	}

	public void columnRemoved(int columnIndex) {
	}

	public void columnMoved(int fromColumnIndex, int toColumnIndex) {
	}
}
