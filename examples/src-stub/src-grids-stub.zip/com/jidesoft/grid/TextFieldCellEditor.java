/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editors that need to use JTextField. You need to let it know what's the type of the value
 *  so that it knows to use ConverterContext to converter it to/from string so that the value can be displayed in
 *  JTextField.
 */
public class TextFieldCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor, java.awt.event.ActionListener {
 {

	protected javax.swing.JTextField _textField;

	/**
	 *  Creates a CellEditor using JTextField.
	 * 
	 *  @param clazz the type of the value
	 */
	public TextFieldCellEditor(Class clazz) {
	}

	/**
	 *  Customizes the text field.
	 */
	protected void customizeTextField() {
	}

	/**
	 *  Creates a text field used by the cell editor. Subclass can override it to return other type of text field. By
	 *  default, we will override the processKeyBinding to respect isPassEnterKeyToTable() property.
	 *  <code><pre>
	 *  return new JTextField() {
	 *      protected boolean processKeyBinding(KeyStroke ks, KeyEvent e, int condition, boolean
	 *  pressed) {
	 *          Container parent = null;
	 *          if (e.getSource() != parent && isPassEnterKeyToTable() && e.getKeyCode() ==
	 *  KeyEvent.VK_ENTER) {
	 *              parent = SwingUtilities.getAncestorOfClass(JideTable.class, this);
	 *          }
	 *          boolean processed = super.processKeyBinding(ks, e, condition, pressed); // stop cell
	 *  editing
	 *          if (e.getSource() != parent && parent instanceof JideTable) {
	 *              ((JideTable) parent).processKeyBinding(ks, e, JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT,
	 *  pressed);
	 *          }
	 *          return processed;
	 *      }
	 *  };
	 *  </pre></code>
	 * 
	 *  @return a text field.
	 */
	protected javax.swing.JTextField createTextField() {
	}

	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	/**
	 *  Gets the text field that is used as the editor.
	 * 
	 *  @return the text field.
	 */
	public javax.swing.JTextField getTextField() {
	}

	public void actionPerformed(java.awt.event.ActionEvent e) {
	}

	@java.lang.Override
	public boolean isEditorStyleSupported(int editorStyle) {
	}
}
