/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A renderer to display an icon.
 */
public class IconCellRenderer extends ContextSensitiveCellRenderer {

	public IconCellRenderer() {
	}

	@java.lang.Override
	public void setValue(Object value) {
	}
}
