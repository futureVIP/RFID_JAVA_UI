/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An editor for cell styles.
 */
public class CellStyleEditor extends javax.swing.JPanel {

	protected javax.swing.JRadioButton _fontStyleRadioButton;

	protected javax.swing.JRadioButton _fontRadioButton;

	public CellStyleEditor() {
	}

	protected void installComponents() {
	}

	public void loadData() {
	}

	public void saveData() {
	}

	public CellStyle getStyle() {
	}

	public void setStyle(CellStyle style) {
	}

	protected String getResourceString(String key) {
	}

	public static void main(String[] args) {
	}
}
