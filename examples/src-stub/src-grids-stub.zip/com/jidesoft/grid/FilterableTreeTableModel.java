/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A filterable TreeTableModel used by TreeTable.
 */
public class FilterableTreeTableModel extends FilterableTableModel implements ITreeTableModel {
 {

	public FilterableTreeTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  This is an option to keep all children rows if their parent row is not filtered away. In the other word, if a
	 *  parent row returns false in the Filter's isValueFiltered method, we will keep all it children even though the
	 *  children don't satisfy the filter condition.
	 * 
	 *  @return true or false.
	 */
	public boolean isKeepAllChildren() {
	}

	/**
	 *  This is an option to keep all children rows if their parent row is not filtered away. In the other word, if a
	 *  parent row returns false in the Filter's isValueFiltered method, we will keep all it children even though the
	 *  children don't satisfy the filter condition.
	 * 
	 *  @param keepAllChildren true or false.
	 */
	public void setKeepAllChildren(boolean keepAllChildren) {
	}

	/**
	 *  This is an option to keep the row is one of its children rows is not filtered away. In TreeTableModel, if you
	 *  want to keep the children, you have to keep the parent. So this option is true by default. The only case you want
	 *  to set it to false is you want the parent row has complete control over its children.
	 *  <p/>
	 *  If you set this option to false, the {@link #isKeepAllChildren()} will automatically set to false. Otherwise
	 *  nothing will be filtered.
	 * 
	 *  @return true or false.
	 */
	public boolean isKeepParentNode() {
	}

	/**
	 *  This is an option to keep the row is one of its children rows is not filtered away. In TreeTableModel, if you
	 *  want to keep the children, you have to keep the parent. So this option is true by default. The only case you want
	 *  to set it to false is you want the parent row has complete control over its children.
	 *  <p/>
	 *  If you set this option to false, the {@link #isKeepAllChildren()} will automatically set to false. Otherwise
	 *  nothing will be filtered.
	 * 
	 *  @param keepParentNode true or false.
	 */
	public void setKeepParentNode(boolean keepParentNode) {
	}

	@java.lang.Override
	protected void invalidateFilterCache() {
	}

	protected void invalidateFilterCache(Object parent) {
	}

	protected void invalidateFilterCache(Object parent, boolean remove) {
	}

	@java.lang.Override
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	@java.lang.Override
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  Returns the row at row specified by <code>row</code>.
	 * 
	 *  @param rowIndex the row whose row is to be queried
	 *  @return the row at the specified row index
	 */
	public Row getRowAt(int rowIndex) {
	}

	/**
	 *  Gets the index of the row.
	 * 
	 *  @param row row
	 *  @return the index of the row. If the row is displayed in the table, it will return the index. Otherwise, it will
	 *          return -1. So -1 could mean two things - the row is not displayed or the row is not in the tree hierarchy
	 *          at all.
	 */
	public int getRowIndex(Row row) {
	}

	public Object getRoot() {
	}

	@java.lang.Override
	protected java.util.List shouldNotBeFiltered(ValueProvider valueProvider, java.util.List filteringRowList, com.jidesoft.filter.Filter filter, int filteringColumn) {
	}

	/**
	 *  The method contains the algorithm to filter the specified row. If you want to filter the row, return true.
	 *  Otherwise, return false. The default algorithm will filter the row whose if any of columns filters return true.
	 *  Subclass can override this method to do a different way. In the method, if you need to consider each column
	 *  filters or all column filters. Use getFilters(int col) to get filter list for a particular column. Use
	 *  getFilters(ALL_COLUMNS) to get the filter for all columns. You should always check for isFiltersApplied(). If
	 *  it's false, always return false. You should also check for each filter to see if it's enabled
	 *  (filter.isEnabled()). If enabled return false, you should skip the filter.
	 *  <p/>
	 *  Please be noted that, by default, this method is not being invoked. Instead, {@link #shouldNotBeFiltered(ValueProvider, java.util.List, com.jidesoft.filter.Filter, int)}
	 *  is the method you may want to override instead.
	 * 
	 *  @param valueProvider     an interface where we can retrieve value.
	 *  @param row               the row index
	 *  @param allColumnFilters  The list of filters on ALL_COLUMN
	 *  @param anyColumnFilters  The list of filters on ANY_COLUMN
	 *  @param eachColumnFilters The array of list of filters on each column
	 *  @return true if the row should be filtered. Otherwise, false.
	 */
	@java.lang.Override
	protected boolean shouldBeFiltered(ValueProvider valueProvider, int row, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}

	/**
	 *  This method will store the result of filtering in cache. This is helpful for the TreeTableModel because sometimes
	 *  it has to check parents and children to figure out if a row is filtered. So caching it will be helpful to improve
	 *  the performance.
	 * 
	 *  @param valueProvider     the ValueProvider
	 *  @param rowIndex          the row index.
	 *  @param allColumnFilters  The list of filters on ALL_COLUMN
	 *  @param anyColumnFilters  The list of filters on ANY_COLUMN
	 *  @param eachColumnFilters The array of list of filters on each column
	 *  @return true if the row is filtered. Otherwise false.
	 */
	protected boolean shouldBeFilteredCached(ValueProvider valueProvider, int rowIndex, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}

	protected boolean filtering(ValueProvider valueProvider, int rowIndex, java.util.List allColumnFilters, java.util.List anyColumnFilters, java.util.List[] eachColumnFilters) {
	}
}
