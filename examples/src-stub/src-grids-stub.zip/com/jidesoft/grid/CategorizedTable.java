/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CategorizedTable is a table that has category rows. Category rows are those special rows which usually have a
 *  different foreground and background and allow expand/collapse.
 */
public class CategorizedTable extends CellSpanTable {

	public static final javax.swing.ImageIcon DEFAULT_ASCENDING_ICON;

	public static final javax.swing.ImageIcon DEFAULT_DESCENDING_ICON;

	public static final String PROPERTY_EXPAND_ICON_VISIBLE = "EXPAND_ICON_VISIBLE";

	public CategorizedTable() {
	}

	public CategorizedTable(javax.swing.table.TableModel dm) {
	}

	public CategorizedTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public CategorizedTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	public CategorizedTable(int numRows, int numColumns) {
	}

	public CategorizedTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public CategorizedTable(Object[][] rowData, Object[] columnNames) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Gets the disabled cell background.
	 * 
	 *  @return the disabled cell background
	 */
	public java.awt.Color getDisabledBackground() {
	}

	/**
	 *  Sets the disabled cell background.
	 * 
	 *  @param disabledBackground the disabled background
	 */
	public void setDisabledBackground(java.awt.Color disabledBackground) {
	}

	/**
	 *  Gets the disabled cell foreground.
	 * 
	 *  @return the disabled cell foreground
	 */
	public java.awt.Color getDisabledForeground() {
	}

	/**
	 *  Sets the disabled cell foreground.
	 * 
	 *  @param disabledForeground the disabled background
	 */
	public void setDisabledForeground(java.awt.Color disabledForeground) {
	}

	/**
	 *  Gets the expanded icon. If you never set it before, this method will return the icon of
	 *  UIManagerLookup.getIcon("Tree.expandedIcon").
	 * 
	 *  @return the expanded icon
	 */
	public javax.swing.Icon getCategoryExpandedIcon() {
	}

	/**
	 *  Sets the expanded icon. If you didn't set your own icon, by default we get the icon from
	 *  UIManagerLookup.getIcon("Tree.expandedIcon").
	 * 
	 *  @param expandedIcon expanded icon
	 */
	public void setCategoryExpandedIcon(javax.swing.Icon expandedIcon) {
	}

	/**
	 *  Gets the collapsed icon. If you never set it before, this method will return the icon of
	 *  UIManagerLookup.getIcon("Tree.collapsedIcon").
	 * 
	 *  @return the collapsed icon
	 */
	public javax.swing.Icon getCategoryCollapsedIcon() {
	}

	/**
	 *  Sets the collapsed icon. If you didn't set your own icon, by default we get the icon from
	 *  UIManagerLookup.getIcon("Tree.collapsedIcon").
	 * 
	 *  @param collapsedIcon collapsed icon
	 */
	public void setCategoryCollapsedIcon(javax.swing.Icon collapsedIcon) {
	}

	/**
	 *  Gets the expanded icon. If you never set it before, this method will return the icon of
	 *  UIManagerLookup.getIcon("Tree.expandedIcon").
	 * 
	 *  @return the expanded icon
	 */
	public javax.swing.Icon getExpandedIcon() {
	}

	/**
	 *  Get the expanded icon by row.
	 *  <p/>
	 *  By default, it will invoke {@link #getExpandedIcon()}. You could override this method to supply different icon for
	 *  different row.
	 * 
	 *  @see #getExpandedIcon()
	 *  @param row the row index in the table
	 *  @return the expanded icon.
	 */
	public javax.swing.Icon getExpandedIcon(int row) {
	}

	/**
	 *  Get the collapsed icon by row.
	 *  <p/>
	 *  By default, it will invoke {@link #getCollapsedIcon()}. You could override this method to supply different icon for
	 *  different row.
	 * 
	 *  @see #getCollapsedIcon()
	 *  @param row the row index in the table
	 *  @return the collapsed icon.
	 */
	public javax.swing.Icon getCollapsedIcon(int row) {
	}

	/**
	 *  Sets the expanded icon. If you didn't set your own icon, by default we get the icon from
	 *  UIManagerLookup.getIcon("Tree.expandedIcon").
	 * 
	 *  @param expandedIcon expanded icon
	 */
	public void setExpandedIcon(javax.swing.Icon expandedIcon) {
	}

	/**
	 *  Gets the collapsed icon. If you never set it before, this method will return the icon of
	 *  UIManagerLookup.getIcon("Tree.collapsedIcon").
	 * 
	 *  @return the collapsed icon
	 */
	public javax.swing.Icon getCollapsedIcon() {
	}

	/**
	 *  Sets the collapsed icon. If you didn't set your own icon, by default we get the icon from
	 *  UIManagerLookup.getIcon("Tree.collapsedIcon").
	 * 
	 *  @param collapsedIcon collapsed icon
	 */
	public void setCollapsedIcon(javax.swing.Icon collapsedIcon) {
	}

	/**
	 *  Gets the ascending icon used by sortable table header. If it has never be set, it will use the default ascending
	 *  icon which is a triangle pointing northward.
	 * 
	 *  @return the ascending icon
	 */
	public javax.swing.Icon getAscendingIcon() {
	}

	/**
	 *  Sets the ascending icon used by sortable table header.
	 * 
	 *  @param ascendingIcon the icon
	 */
	public void setAscendingIcon(javax.swing.Icon ascendingIcon) {
	}

	/**
	 *  Gets the descending icon used by sortable table header. If it has never be set, it will use the default
	 *  descending icon which is a triangle pointing southward.
	 * 
	 *  @return the descending icon
	 */
	public javax.swing.Icon getDescendingIcon() {
	}

	/**
	 *  Sets the descending icon used by sortable table header.
	 * 
	 *  @param descendingIcon the icon
	 */
	public void setDescendingIcon(javax.swing.Icon descendingIcon) {
	}

	/**
	 *  A flag to decide if the category row should use the regular table cell renderer. Default is false which means
	 *  category row will be rendered in its own. You can set it to true so that you can customize the renderer of
	 *  category row using regular table cell renderer.
	 * 
	 *  @return true to use table cell renderer. Otherwise, false.
	 */
	public boolean isUseTableRendererForCategoryRow() {
	}

	/**
	 *  Set the flag if the category row should use the regular table cell renderer. Default is false which means
	 *  category row will be rendered in its own. You can set it to true so that you can customize the renderer of
	 *  category row using regular table cell renderer.
	 * 
	 *  @param useTableRendererForCategoryRow true to use table cell renderer. Otherwise, false.
	 */
	public void setUseTableRendererForCategoryRow(boolean useTableRendererForCategoryRow) {
	}

	/**
	 *  Checks if paints the margin background.
	 * 
	 *  @return true if margin background will be painted.
	 */
	public boolean isPaintMarginBackground() {
	}

	/**
	 *  @param paintMarginBackground the background
	 */
	public void setPaintMarginBackground(boolean paintMarginBackground) {
	}

	/**
	 *  Gets the background color that is used to paint the margin.
	 * 
	 *  @return the background color of margin.
	 */
	public java.awt.Color getMarginBackground() {
	}

	/**
	 *  Sets the background color that is used to paint the margin.
	 * 
	 *  @param marginBackground the background
	 */
	public void setMarginBackground(java.awt.Color marginBackground) {
	}

	/**
	 *  Get the flag indicating if the expandable icon is visible.
	 *  <p/>
	 *  By default, the value is true so that in TreeTable the +/- icon is visible. You could set it to false if you want
	 *  to hide the icons.
	 * 
	 *  @return true if the expand icon is visible. Otherwise false.
	 */
	public boolean isExpandIconVisible() {
	}

	/**
	 *  set the flag indicating if the expandable icon is visible.
	 * 
	 *  @see #isExpandIconVisible()
	 *  @param expandIconVisible the flag
	 */
	public void setExpandIconVisible(boolean expandIconVisible) {
	}

	/**
	 *  Get the flag indicating if SortableTable will use look and feel default sort icon as its default sort icon.
	 *  <p/>
	 *  By default, the flag is true so that we can have the same look and feel with other swing components. If your JDK
	 *  version is earlier than JDK6, even you set this flag to true, we will still use our triangle sort icon as default
	 *  since those JDK versions does not have any default look and feel sort icon.
	 * 
	 *  @return the flag.
	 */
	public boolean isUseLnfDefaultSortIcon() {
	}

	/**
	 *  Set the flag indicating if SortableTable will use JDK default sort icon as its default sort icon.
	 * 
	 *  @param useLnfDefaultSortIcon the flag
	 */
	public void setUseLnfDefaultSortIcon(boolean useLnfDefaultSortIcon) {
	}
}
