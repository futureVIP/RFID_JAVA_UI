/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>MultiTableModel</code> is a special table model which it can use one table model to
 *  represent multiple table models.
 *  <p/>
 *  There are two ways of using this table model.
 *  <p/>
 *  First, <code>MultiTableModel</code>
 *  Please notes the terms we used. They are a little confusing.
 *  ColumnHeader == header row; ColumnFooter == footer row; RowHeader == header column; RowFooter == footer column.
 *  <p/>
 *  <code>MultiTableModel</code> will make it possible. So in a unified table mode, you can define which columns are headers
 *  which will appear at the left side of the table, which columns are footer which will appears at the right side of the table.
 *  Once you defined this table model, {@link TableScrollPane} will take it and display it correctly.
 *  <p/>
 *  The header columns and footer columns are not necessarily at the same cluster. They can be anywhere inside the table model.
 *  TableScrollPane will find all those special columns and put them at the right place.
 * 
 *  @see TableScrollPane
 */
public interface MultiTableModel extends ContextSensitiveTableModel {
 {

	public static final int REGULAR_COLUMN = 0;

	public static final int HEADER_COLUMN = 1;

	public static final int FOOTER_COLUMN = 2;

	/**
	 *  Checks if the column at the columnIndex is a header column or footer column
	 *  or just regular column. Header columns will be displayed at the left side
	 *  of the table. Footer columns will be on the right side. Regular columns
	 *  will in the middle and will have horizontal scroll bar if there are a
	 *  lot of columns.
	 * 
	 *  @param columnIndex the column index
	 *  @return column type. The possible values are REGULAR_COLUMN, HEADER_COLUMN, or FOOTER_COLUMN.
	 */
	public int getColumnType(int columnIndex);

	/**
	 *  Gets the table index that this column belongs to. As convention, the table
	 *  index starts from 0. So all columns that return 0 in this method will be grouped
	 *  into the first table. Those return 1 will be on the second table, and so on.
	 * 
	 *  @param columnIndex the column index
	 *  @return the table index.
	 */
	public int getTableIndex(int columnIndex);
}
