/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The SortTableHeaderRenderer will consider \n in headings and display them on multiple lines. <BR> 'Date of\nbirth'
 *  will be displayed on two lines. 'Date of' on the first, birth on the second. <BR> 'Date of birth' will be displayed
 *  on one lines,
 *  <p/>
 *  In addition to multiple line feature, it will also show the sort order and sort direction if there is a sort model
 *  defined for the table and the column is in that model.
 */
public class SortTableHeaderRenderer implements javax.swing.table.TableCellRenderer, javax.swing.plaf.UIResource {
 {

	protected javax.swing.JPanel _headerPanel;

	protected javax.swing.JPanel _titlePanel;

	protected SortTableHeaderRenderer.SortPanel _sortPanel;

	public SortTableHeaderRenderer() {
	}

	public SortTableHeaderRenderer(int alignment) {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Get an approximation of the width of the title based on the width in characters. This is much faster than
	 *  getTitleSize() which instantiates the actual components and then gets the preferred size of those components. It
	 *  doesn't matter too much that this is an approximation because table views should define a width explicitly if
	 *  it's important. Also, basing the default width on the header label takes no account of whether data in the column
	 *  will fit.
	 * 
	 *  @param title the title.
	 *  @return the header width.
	 */
	public int getDefaultHeaderWidth(String title) {
	}

	/**
	 *  Creation of the header panel.
	 */
	protected void initComponents() {
	}

	protected javax.swing.JLabel createLabel(javax.swing.Icon icon) {
	}

	protected javax.swing.JLabel createLabel(String text) {
	}

	/**
	 *  Update the sort parameters for this component. This will result in the component changing its columns number and
	 *  direction if necessary.
	 * 
	 *  @param table  the table
	 *  @param column The column as display (0 leftmost)
	 */
	public void updateSortPanel(javax.swing.JTable table, int column) {
	}

	/**
	 *  Get the flag indicating if the sort arrow is visible in the renderer while sorting.
	 *  <p/>
	 *  By default, the flag is true. You could set it to false if you don't want to show the sort arrow up.
	 * 
	 *  @return true if the sort arrow is visible. Otherwise false.
	 */
	public boolean isSortArrowVisible() {
	}

	/**
	 *  Set the flag indicating if the sort arrow is visible in the renderer while sorting.
	 * 
	 *  @see #isSortArrowVisible()
	 *  @param sortArrowVisible the flag
	 */
	public void setSortArrowVisible(boolean sortArrowVisible) {
	}

	/**
	 *  Get the alignment of the header renderer.
	 *  <p/>
	 *  By default the value is <code>javax.swing.SwingConstants.CENTER</code>. You could set it to other alignments if
	 *  you want.
	 * 
	 *  @return the alignment.
	 */
	public int getAlignment() {
	}

	/**
	 *  Set the alignment of the header renderer.
	 * 
	 *  @see #getAlignment()
	 *  @param alignment the alignment
	 */
	public void setAlignment(int alignment) {
	}

	/**
	 *  Creates the component to display the sort arrow. Subclass can implement SortArrow and create their own component.
	 *  However it must be a JComponent.
	 * 
	 *  @return SortArrow
	 */
	protected SortTableHeaderRenderer.SortArrow createSortArrow() {
	}

	/**
	 *  An interface for SortArrow, the arrow which is used to display on the table header to indicate sort direction and
	 *  sort index.
	 */
	public static interface class SortArrow {


		public void setDirection(javax.swing.JTable table, boolean ascending) {
		}

		public void setText(String text) {
		}
	}
}
