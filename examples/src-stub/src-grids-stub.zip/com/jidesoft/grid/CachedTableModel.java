/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <tt>CachedTableModel</tt> is a table model that can cache the table data. If you use <tt>DefaultTableModel</tt>,
 *  there is no need to cache the data because the data are actually in the data list. However if you are using
 *  <tt>AbstractTableModel</tt> and getValueAt() gets the data on fly, you will suffer from performance issue if
 *  getValueAt() is complex. <tt>CachedTableModel</tt> can solve this issue by caching the value. So each getValueAt()
 *  will be called only once. When data changes, as long as the underlying table model fires the correct table model
 *  event, the cache will update automatically to fetch the new value. If you want to invalidate the cache yourself, you
 *  can always use methods such as {@link #invalidateCache()}, {@link #invalidateCache(int)} or {@link
 *  #invalidateCache(int,int)} to invalidate all the cache or portions of it.
 *  <p/>
 *  At any time, you can call {@link #setCacheEnabled(boolean)} to disable the caching. Or you can call {@link
 *  #setCachedColumns(int[])} to specify which columns you want to cache. For example, if the cell value in a column is a
 *  direct value without calculation, you can disable the cache on that column to save memory.
 *  <p/>
 */
public class CachedTableModel extends TableModelWrapperImpl implements java.io.Serializable {
 {

	/**
	 *  The <code>List</code> of <code>Lists</code> of <code>Object</code> values.
	 */
	protected java.util.List _cachedValueList;

	protected int[] _cachedColumns;

	protected int[] _conversionIndex;

	/**
	 *  Constructs a default <code>DefaultTableModel</code> which is a table of zero columns and zero rows.
	 * 
	 *  @param model the table model.
	 */
	public CachedTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Checks if cache is enabled. Usually you want the cache to be enabled since you are using CacheTableModel. However
	 *  you still can disable it temporarily if you want the data to be retrieved directly from the underlying table
	 *  model.
	 * 
	 *  @return true if cache is enabled. Otherwise false.
	 */
	public boolean isCacheEnabled() {
	}

	/**
	 *  Enables or disables the cache. If cache is enabled, it will create cache to cache all values retrieved from
	 *  getValueAt method. Next time when the getValueAt is called on the same cell, the value from the cache will be
	 *  returned instead asking the table model again.
	 *  <p/>
	 *  By default, the cache is enabled. If this method is called, the whole cache will be invalidated.
	 * 
	 *  @param cacheEnabled true or false.
	 */
	public void setCacheEnabled(boolean cacheEnabled) {
	}

	/**
	 *  Overrides the method in DefaultTableModelWrapper to update the cache when underlying table model is changed.
	 * 
	 *  @param firstRow the index of the first row that was inserted
	 *  @param lastRow  the index of the last row that was inserted
	 */
	@java.lang.Override
	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	/**
	 *  Overrides the method in DefaultTableModelWrapper to update the cache when underlying table model is changed.
	 * 
	 *  @param firstRow the index of the first row that was deleted
	 *  @param lastRow  the index of the last row that was deleted
	 */
	@java.lang.Override
	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	/**
	 *  Overrides the method in DefaultTableModelWrapper to update the cache when underlying table model is changed.
	 * 
	 *  @param firstRow the index of the first row that was updated
	 *  @param lastRow  the index of the last row that was updated
	 */
	@java.lang.Override
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  Overrides the method in DefaultTableModelWrapper to update the cache when underlying table model is changed.
	 * 
	 *  @param column   the index of the column that was updated
	 *  @param firstRow the index of the first row in the above <code> column</code> that was updated
	 *  @param lastRow  the index of the last row in the above <code> column</code> that was updated
	 */
	@java.lang.Override
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  Overrides the method in DefaultTableModelWrapper to update the cache when underlying table model is changed.
	 */
	@java.lang.Override
	protected void tableDataChanged() {
	}

	/**
	 *  Overrides the method in DefaultTableModelWrapper to update the cache when underlying table model is changed.
	 */
	@java.lang.Override
	protected void tableStructureChanged() {
	}

	/**
	 *  Returns the number of rows in this data table.
	 * 
	 *  @return the number of rows in the model
	 */
	@java.lang.Override
	public synchronized int getRowCount() {
	}

	/**
	 *  Checks if the cached value at the specified row and column is valid.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return true if it is valid. Otherwise false.
	 */
	protected boolean isCachedValueValid(int row, int column) {
	}

	/**
	 *  Invalidate the whole cache.
	 */
	public synchronized void invalidateCache() {
	}

	/**
	 *  Invalidate the cache at the specified row index.
	 * 
	 *  @param row the row index.
	 */
	public synchronized void invalidateCache(int row) {
	}

	/**
	 *  Invalidate the cache at the specified row and column.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 */
	public synchronized void invalidateCache(int row, int column) {
	}

	/**
	 *  Removes the cached row data at the specified rowIndex.
	 * 
	 *  @param rowIndex the row index
	 */
	protected synchronized void removeCache(int rowIndex) {
	}

	/**
	 *  Inserts a new row data at the specified rowIndex.
	 * 
	 *  @param rowIndex the row index
	 */
	protected void insertCache(int rowIndex) {
	}

	/**
	 *  Updates the cache at the specified row and column with a new value.
	 * 
	 *  @param value  the new value
	 *  @param row    the row index
	 *  @param column the column index
	 */
	protected void updateCachedValue(Object value, int row, int column) {
	}

	/**
	 *  Returns an attribute value for the cell at <code>row</code> and <code>column</code>. If the cached is enabled, it
	 *  will get the data from the cache first. If the data is not in cache or it is not valid, it will then get the data
	 *  from the actual table model and update the cache.
	 * 
	 *  @param row    the row whose value is to be queried
	 *  @param column the column whose value is to be queried
	 *  @return the value Object at the specified cell
	 * 
	 *  @throws ArrayIndexOutOfBoundsException if an invalid row or column was given
	 */
	@java.lang.Override
	public synchronized Object getValueAt(int row, int column) {
	}

	@java.lang.Override
	public Class getCellClassAt(int row, int column) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int row, int column) {
	}

	/**
	 *  Gets the cached rows.
	 * 
	 *  @return the cached rows.
	 */
	protected synchronized java.util.List getCachedRows() {
	}

	/**
	 *  Cached all the values.
	 */
	public void cacheIt() {
	}

	public int[] getCachedColumns() {
	}

	/**
	 *  Sets the columns you want to cache.
	 * 
	 *  @param cachedColumns the column index array. Null means all columns will be cached.
	 */
	public void setCachedColumns(int[] cachedColumns) {
	}

	/**
	 *  Checks if the column is cached.
	 * 
	 *  @param column the column index
	 *  @return true if the column is cached.
	 */
	public boolean isColumnCached(int column) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int row, int column) {
	}
}
