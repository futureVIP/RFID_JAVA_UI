/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>DefaultNavigableTableModel</code> adds <code>NavigableModel</code> support to <code>DefaultTableModel</code>.
 *  You can use it as replacement for <code>DefaultTableModel</code>. Instead of returning if a cell is navigable
 *  programmatically like in {@link AbstractNavigableTableModel}, you can use {@link #setNavigableAt(int,int,boolean)}
 *  control if a cell should be navigable.
 */
public class DefaultNavigableTableModel extends javax.swing.table.DefaultTableModel implements NavigableTableModel {
 {

	public DefaultNavigableTableModel() {
	}

	public DefaultNavigableTableModel(int rowCount, int columnCount) {
	}

	public DefaultNavigableTableModel(java.util.Vector columnNames, int rowCount) {
	}

	public DefaultNavigableTableModel(Object[] columnNames, int rowCount) {
	}

	public DefaultNavigableTableModel(java.util.Vector data, java.util.Vector columnNames) {
	}

	public DefaultNavigableTableModel(Object[][] data, Object[] columnNames) {
	}

	/**
	 *  Gets if a cell should be navigable at the specified row and column index.
	 * 
	 *  @param rowIndex
	 *  @param columnIndex
	 *  @return true or false to indicate if a cell should be navigable at the specified row and column index.
	 */
	public boolean isNavigableAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Makes a cell navigable or not navigable. TableCellUpdated event will be fired in this case.
	 * 
	 *  @param rowIndex    the row index of the cell.
	 *  @param columnIndex the column index of the cell.
	 *  @param navigable   true or false. True to make the cell navigable. Otherwise false.
	 */
	public void setNavigableAt(int rowIndex, int columnIndex, boolean navigable) {
	}

	/**
	 *  Makes all cells navigable. This method will fire TableDataChanged event.
	 *  <p/>
	 *  Note: If you want to turn off the navigation temporarily, you should use <code>setNavigableOn(false)</code>.
	 */
	public void setNavigableAll() {
	}

	public boolean isNavigationOn() {
	}

	public void setNavigationOn(boolean navigableOn) {
	}
}
