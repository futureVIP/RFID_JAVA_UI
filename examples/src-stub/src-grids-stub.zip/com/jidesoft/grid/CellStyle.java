/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellStyle</code> defines the styles of a table cell. Those styles include the background (include the selection
 *  background), the foreground (include the selection foreground), the font, the horizontal alignment, the vertical
 *  alignment, the text, the toolTipText, the icon and the border. <code>CellStyleTable</code> and its subclasses will
 *  use the styles defined in <code>CellStyle</code> and set to cell renderer component. Obviously, not all styles apply
 *  to all types of cell renderer components.
 *  <p/>
 *  <code>CellStyle</code> works with <code>StyleModel</code> which can be used as an interface for TableModel. You can
 *  refer to {@link StyleModel} to see how to use it.
 *  <p/>
 *  In additional to all the styles that you can set to CellStyle, you can assign a priority to it. This is useful where
 *  there are multiple cell styles for the same cell. Please read javadoc of {@link #getPriority()} for more
 *  information.
 */
public class CellStyle implements javax.swing.SwingConstants {
 {

	/**
	 *  An empty icon instance. If you ever setIcon on a cell style, you should set this EMPTY_ICON to those cell styles
	 *  that don't have an icon.
	 */
	public static final javax.swing.Icon EMPTY_ICON;

	public static final java.awt.Color EMPTY_COLOR;

	public static final java.awt.Font EMPTY_FONT;

	public static final javax.swing.border.Border EMPTY_BORDER;

	public static final String EMPTY_STRING = "AN_EMPTY_STRING";

	public CellStyle() {
	}

	/**
	 *  Create a copy of the CellStyle;
	 * 
	 *  @param style the existing cell style.
	 */
	public CellStyle(CellStyle style) {
	}

	public javax.swing.border.Border getBorder() {
	}

	public void setBorder(javax.swing.border.Border border) {
	}

	public java.awt.Color getBackground() {
	}

	public void setBackground(java.awt.Color background) {
	}

	public java.awt.Color getForeground() {
	}

	public void setForeground(java.awt.Color foreground) {
	}

	public java.awt.Color getSelectionBackground() {
	}

	public void setSelectionBackground(java.awt.Color selectionBackground) {
	}

	public java.awt.Color getSelectionForeground() {
	}

	public void setSelectionForeground(java.awt.Color selectionForeground) {
	}

	public java.awt.Font getFont() {
	}

	/**
	 *  Sets the font. If you set the font, we will ignore the value in setFontStyle.
	 * 
	 *  @param font the font in the CellStyle.
	 */
	public void setFont(java.awt.Font font) {
	}

	public int getFontStyle() {
	}

	/**
	 *  Sets the font style which could be Font.PLAIN, Font.BOLD or Font.ITALIC. If you set the font, we will ignore the value in setFontStyle.
	 * 
	 *  @param fontStyle the font style in the CellStyle.
	 */
	public void setFontStyle(int fontStyle) {
	}

	public javax.swing.Icon getIcon() {
	}

	public void setIcon(javax.swing.Icon icon) {
	}

	public int getVerticalAlignment() {
	}

	public void setVerticalAlignment(int verticalAlignment) {
	}

	public int getHorizontalAlignment() {
	}

	public void setHorizontalAlignment(int horizontalAlignment) {
	}

	public int getVerticalTextPosition() {
	}

	public void setVerticalTextPosition(int verticalTextPosition) {
	}

	public int getHorizontalTextPosition() {
	}

	public void setHorizontalTextPosition(int horizontalTextPosition) {
	}

	public String getText() {
	}

	public void setText(String text) {
	}

	public String getToolTipText() {
	}

	public void setToolTipText(String toolTipText) {
	}

	public javax.swing.border.Border getOverlayBorder() {
	}

	public void setOverlayBorder(javax.swing.border.Border overlayBorder) {
	}

	/**
	 *  Gets the priority of the cell style. This has nothing to do with the styles for a cell but the priority of this
	 *  particular cell style when there are multiple cell styles for the same cells.
	 *  <p/>
	 *  In JIDE Grids, we used <code>TableModelWrapper</code> which can wrap another table model. So you can end up with
	 *  a pipe of <code>TableModelWrapper</code>s. Any of the table models can implement <code>StyleModel</code> and each
	 *  one can return a different cell style. <code>CellStyleTable</code> will look at those <code>CellStyle</code>s and
	 *  sort them by the priority. The cell style that has the higher priority will win over any cell styles that have a
	 *  lower priority when there are style conflicts (meaning the same style is used in different cell styles).
	 *  <p/>
	 *  For example, you have one cell style that implements the row stripes and another cell style that implements cell
	 *  update indication. Both use cell background style. Obviously you want the cell update indication has a higher
	 *  priority than row stripes. So you just set a higher priority in cell update indication cell style.
	 *  <p/>
	 *  If the cell styles have the same priority, the one from inner style table model has a higher priority.
	 * 
	 *  @return the priority.
	 */
	public int getPriority() {
	}

	/**
	 *  Sets the priority of the cell style.
	 * 
	 *  @param priority the new priority
	 */
	public void setPriority(int priority) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
