/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellStyleProvider is an interface to allow user to customize the CellStyle for any table model.
 */
public interface CellStyleProvider {

	/**
	 *  Gets the cell style at the specified cell.
	 * 
	 *  @param model       the model. This is the model from table.getModel().
	 *  @param rowIndex    the row index as in the model
	 *  @param columnIndex the column index as in the model
	 * 
	 *  @return the cell style at the specified cell.
	 */
	public CellStyle getCellStyleAt(javax.swing.table.TableModel model, int rowIndex, int columnIndex);
}
