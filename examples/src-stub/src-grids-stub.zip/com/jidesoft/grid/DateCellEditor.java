/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Date or Calendar. It uses DateComboBox to provide an editor for Date or Calendar. You can override
 *  {@link #createDateComboBox()} method to provide your own DateComboBox.
 */
public class DateCellEditor extends AbstractComboBoxCellEditor {

	public static final EditorContext DATETIME_CONTEXT;

	public static final int TYPE_UTIL_CALENDAR = 0;

	public static final int TYPE_UTIL_DATE = 1;

	public static final int TYPE_SQL_DATE = 2;

	public static final int TYPE_SQL_TIME = 3;

	/**
	 *  Creates a DateCellEditor.
	 */
	public DateCellEditor() {
	}

	/**
	 *  Creates a DateCellEditor.
	 * 
	 *  @param useDate true or false. If useDate is true, getCellEditorValue() will return an instance of Date. Otherwise
	 *                 it will return an instance of Calendar. Default is false.
	 */
	public DateCellEditor(boolean useDate) {
	}

	/**
	 *  Creates a DateCellEditor with a date model.
	 * 
	 *  @param dateModel the new DateModel.
	 */
	public DateCellEditor(com.jidesoft.combobox.DateModel dateModel) {
	}

	/**
	 *  Creates a DateCellEditor with a date model.
	 * 
	 *  @param dateModel the new DateModel.
	 *  @param useDate   true or false. If useDate is true, getCellEditorValue() will return an instance of Date.
	 *                   Otherwise it will return an instance of Calendar. Default is false.
	 */
	public DateCellEditor(com.jidesoft.combobox.DateModel dateModel, boolean useDate) {
	}

	/**
	 *  Creates the date combobox used by this cell editor.
	 * 
	 *  @return the date combobox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	protected com.jidesoft.combobox.DateComboBox createDateComboBox() {
	}

	/**
	 *  Gets the date type. The type could be one of the followings: {@link #TYPE_UTIL_DATE}, {@link
	 *  #TYPE_UTIL_CALENDAR}, {@link #TYPE_SQL_DATE} and {@link #TYPE_SQL_TIME}. They are corresponding to
	 *  java.util.Date, java.util.Calendar, java.sql.Date and java.sql.Time respectively. The getCellEditorValue will
	 *  return the data type as specified.
	 * 
	 *  @return the data type.
	 */
	public int getDataType() {
	}

	/**
	 *  Sets the date type. The type could be one of the followings: {@link #TYPE_UTIL_DATE}, {@link
	 *  #TYPE_UTIL_CALENDAR}, {@link #TYPE_SQL_DATE} and {@link #TYPE_SQL_TIME}. They are corresponding to
	 *  java.util.Date, java.util.Calendar, java.sql.Date and java.sql.Time respectively. The getCellEditorValue will
	 *  return the data type as specified.
	 * 
	 *  @param dataType the data type.
	 */
	public void setDataType(int dataType) {
	}

	/**
	 *  Gets the value of the cell editor.
	 * 
	 *  @return the value of the cell editor
	 */
	@java.lang.Override
	public Object getCellEditorValue() {
	}

	@java.lang.Override
	public void setCellEditorValue(Object value) {
	}

	/**
	 *  Validates date using DateModel.
	 * 
	 *  @param oldValue the old value.
	 *  @param newValue the new value.
	 *  @return validation result.
	 */
	@java.lang.Override
	public ValidationResult validate(Object oldValue, Object newValue) {
	}

	/**
	 *  Checks if the time is displayed.
	 * 
	 *  @return true or false.
	 */
	public boolean isTimeDisplayed() {
	}

	/**
	 *  Sets the timeDisplayed property. If this property is true, the <code>DateChooserPanel</code> will show a time
	 *  spinner so that user can change time.
	 * 
	 *  @param timeDisplayed true or false.
	 */
	public void setTimeDisplayed(boolean timeDisplayed) {
	}
}
