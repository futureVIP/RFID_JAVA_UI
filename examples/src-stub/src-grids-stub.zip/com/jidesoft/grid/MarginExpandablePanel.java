/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The component used by PropertyTableCellRenderer and HierarchicalTableCellRenderer which has a "+/-" button.
 */
public class MarginExpandablePanel extends TreeExpandablePanel {

	public MarginExpandablePanel(javax.swing.JTable table) {
	}

	/**
	 *  Creates an ExpandablePanel.
	 * 
	 *  @param table the table
	 *  @param expandedIcon the expanded icon
	 *  @param collapsedIcon the collapsed icon
	 *  @param disabledBackground the disabled background
	 *  @param disabledForeground the disabled foreground
	 *  @deprecated use {@link #MarginExpandablePanel(javax.swing.JTable)} instead
	 */
	public MarginExpandablePanel(javax.swing.JTable table, javax.swing.Icon expandedIcon, javax.swing.Icon collapsedIcon, java.awt.Color disabledBackground, java.awt.Color disabledForeground) {
	}

	@java.lang.Override
	protected void initComponents() {
	}

	/**
	 *  Calls the UI delegate's paint method, if the UI delegate is non-<code>null</code>.  We pass the delegate a copy
	 *  of the <code>Graphics</code> object to protect the rest of the paint code from irrevocable changes (for example,
	 *  <code>Graphics.translate</code>).
	 *  <p/>
	 *  If you override this in a subclass you should not make permanent changes to the passed in <code>Graphics</code>.
	 *  For example, you should not alter the clip <code>Rectangle</code> or modify the transform. If you need to do
	 *  these operations you may find it easier to create a new <code>Graphics</code> from the passed in
	 *  <code>Graphics</code> and manipulate it. Further, if you do not invoker super's implementation you must honor the
	 *  opaque property, that is if this component is opaque, you must completely fill in the background in a non-opaque
	 *  color. If you do not honor the opaque property you will likely see visual artifacts.
	 * 
	 *  @param g the <code>Graphics</code> object to protect
	 *  @see #paint
	 *  @see ComponentUI
	 */
	@java.lang.Override
	public void paint(java.awt.Graphics g) {
	}

	/**
	 *  Checks if the margin should be shown.
	 * 
	 *  @param property the property
	 *  @return true if the margin
	 */
	protected boolean shouldShowMargin(ExpandableCell property) {
	}

	@java.lang.Override
	protected void paintBackground(java.awt.Graphics g) {
	}

	/**
	 *  Gets the margin background color..
	 * 
	 *  @return the margin background color.
	 */
	public java.awt.Color getMarginBackground() {
	}

	/**
	 *  Sets the margin background.
	 * 
	 *  @param marginBackground the margin background
	 */
	public void setMarginBackground(java.awt.Color marginBackground) {
	}

	/**
	 *  Checks if the margin background should be painted.
	 * 
	 *  @return true if the margin background should be painted.
	 */
	public boolean isPaintMarginBackground() {
	}

	/**
	 *  Sets the attribute which controls if margin background should be painted.
	 * 
	 *  @param paintMarginBackground the attribute
	 */
	public void setPaintMarginBackground(boolean paintMarginBackground) {
	}
}
