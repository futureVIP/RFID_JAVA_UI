/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The editor context is used by CellRendererManager and CellEditorManager so that for the same type, different
 *  editor/renderer can be registered since the EditorContext is different.
 */
public class EditorContext extends AbstractContext {

	/**
	 *  Default editor context with empty name and no user object.
	 */
	public static EditorContext DEFAULT_CONTEXT;

	/**
	 *  Default dynamic value editor to work with {@link com.jidesoft.grid.CellEditorValueProvider} and {@link com.jidesoft.converter.ConverterContext#DEFAULT_CONTEXT_DYNAMIC_VALUE}.
	 */
	@java.lang.Deprecated
	public static EditorContext DEFAULT_CONTEXT_DYNAMIC_VALUE;

	/**
	 *  Creates an editor context with a name.
	 * 
	 *  @param name the name of the editor context
	 */
	public EditorContext(String name) {
	}

	/**
	 *  Creates an editor context with a name and an object.
	 * 
	 *  @param name the name of the editor context
	 *  @param object the user object. It can be used as any object to pass information along.
	 */
	public EditorContext(String name, Object object) {
	}
}
