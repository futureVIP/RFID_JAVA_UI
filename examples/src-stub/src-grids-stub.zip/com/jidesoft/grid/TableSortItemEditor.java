/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableSortItemEditor</code> is an editor for a list of SortItems and ColumnComparatorContextProvider.
 */
public class TableSortItemEditor extends AbstractDialogPage {

	public TableSortItemEditor(javax.swing.table.TableModel tableModel) {
	}

	public void lazyInitialize() {
	}

	protected void initComponents() {
	}

	protected java.awt.Component createSortItemEditor(String title) {
	}

	public ISortableTableModel.SortItem[] getSortItems() {
	}

	public SortableTableModel.ColumnComparatorContextProvider getColumnComparatorContextProvider() {
	}

	public void getColumnComparatorContextProvider(SortableTableModel.ColumnComparatorContextProvider provider) {
	}

	public void setSortItems(ISortableTableModel.SortItem[] sortItems) {
	}

	protected java.util.ResourceBundle getResourceBundle() {
	}
}
