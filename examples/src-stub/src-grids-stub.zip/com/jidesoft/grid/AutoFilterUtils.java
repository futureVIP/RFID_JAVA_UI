/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a help class to install additional auto filter table row in a JideScrollPane for a JideTable to implement
 *  auto filtering feature.
 *  <p/>
 *  This feature can be used together with NestedTableHeader so that you can have filtering and nest table header feature
 *  in one table, which is a supplement of AutoFilterTableHeader. However, this class cannot work together with
 *  TableScrollPane, while AutoFilterTableHeader can.
 */
public class AutoFilterUtils {

	/**
	 *  Main table in this class.
	 */
	protected JideTable _mainTable;

	/**
	 *  Filter table, where the customer can input filtering criteria for each column.
	 */
	protected JideTable _filterTable;

	/**
	 *  FilterableTableModel created for filtering purpose.
	 */
	protected IFilterableTableModel _filterableTableModel;

	/**
	 *  Default Constructor.
	 */
	public AutoFilterUtils() {
	}

	/**
	 *  Install the filtering row above the JideTable.
	 * 
	 *  @param table the target JideTable
	 *  @return the JideScrollPane which contains the table and the new-added filtering row
	 */
	public JideScrollPane install(JideTable table) {
	}

	/**
	 *  Uninstall the filtering row above the JideTable.
	 * 
	 *  @param table the target JideTable
	 */
	public void uninstall(JideTable table) {
	}

	/**
	 *  Creates the <code>FilterableTableModel</code> to be used by {@link AutoFilterTableHeader}. It returns null by
	 *  default. You can override it to create your own <code>FilterableTableModel</code>.
	 * 
	 *  @param model the table model.
	 *  @return the <code>FilterableTableModel</code>.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected IFilterableTableModel createFilterableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Creates the <code>FilterableTableModel</code>.
	 * 
	 *  @param model the table model.
	 *  @return the <code>FilterableTableModel</code>.
	 */
	protected IFilterableTableModel createDefaultFilterableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Create a table model for FilterTable. You can override this method to create your customized table model. For
	 *  example, if you only need exact value match, you can create a table model exactly from the main table so that
	 *  it's renderer and editor looks consistent with the main table.
	 * 
	 *  @return the table model.
	 */
	protected javax.swing.table.TableModel createAutoFilterRowTableModel() {
	}

	/**
	 *  Create the FilterTable.
	 * 
	 *  @param model the table model of the FilterTable
	 *  @return the filter table.
	 */
	protected JideTable createAutoFilterRowTable(javax.swing.table.TableModel model) {
	}

	/**
	 *  Converts the element from object to string.
	 * 
	 *  @param columnIndex the column index
	 *  @param item        the item
	 *  @return the string.
	 */
	protected String convertElementToString(int columnIndex, Object item) {
	}

	/**
	 *  Create filter with the input searching text.
	 * 
	 *  @param searchingText the searching text
	 *  @return the filter.
	 */
	protected TableFilter createFilter(String searchingText) {
	}

	/**
	 *  Checks if the ObjectConverter will be used to convert element to string so that it can be compared with the
	 *  searching text.
	 * 
	 *  @return true or false.
	 */
	public boolean isObjectConverterManagerEnabled() {
	}

	/**
	 *  Sets the flag if the <code>ObjectConveter</code> will be used to convert the element to String. Default is false.
	 *  If true,  <code>convertElementToString</code> method will use ObjectConverterManager to convert the element to
	 *  String if underlying table model is <code>ContextSensitiveTableModel</code>.
	 * 
	 *  @param objectConverterManagerEnabled new value for the objectConverterManagerEnabled flag.
	 */
	public void setObjectConverterManagerEnabled(boolean objectConverterManagerEnabled) {
	}

	/**
	 *  Converts the element from Object to string. It will use ObjectConverterManager to do the conversion if the
	 *  underlying table model is ContextSensitiveTableModel. Otherwise, we will call super convertElementToString
	 *  method.
	 *  <p/>
	 *  You can subclass and override this method to do your own conversion if needed.
	 * 
	 *  @param element     the element to be converted to string.
	 *  @param rowIndex    the row index of the value
	 *  @param columnIndex the column index of the value
	 *  @return the string representation of the element. "" if the element is null. Otherwise it will call toString to
	 *          do the conversion.
	 */
	protected String convertElementToString(Object element, int rowIndex, int columnIndex) {
	}

	/**
	 *  Converts the element from Object to string. By default it will use toString to do the conversion if the element
	 *  is not null. If it's null, it will return empty string.
	 *  <p/>
	 *  You can subclass and override this method to do your own conversion if needed.
	 * 
	 *  @param element the element to be converted to string.
	 *  @return the string representation of the element. "" if the element is null. Otherwise it will call toString to
	 *          do the conversion.
	 */
	protected String convertElementToString(Object element) {
	}

	/**
	 *  Get the filterable column identifiers.
	 *  <p/>
	 *  By default the value is null, which means every column is filterable. If the customer set a set, the columns not
	 *  contained in the array will not be able to filter.
	 * 
	 *  @return the filterable column identifier list.
	 */
	public Object[] getFilterableColumnIdentifiers() {
	}

	/**
	 *  Set the filterable column identifiers.
	 * 
	 *  @see #getFilterableColumnIdentifiers()
	 *  @param filterableColumnIdentifiers the filterable column identifier list
	 */
	public void setFilterableColumnIdentifiers(Object[] filterableColumnIdentifiers) {
	}

	/**
	 *  Get the flag indicating if auto completion should be triggered while input searching text.
	 *  <p/>
	 *  By default the value is true.
	 * 
	 *  @return true if auto completion should be triggered while input searching text. Otherwise false.
	 */
	public boolean isIntelliHintsEnabled() {
	}

	/**
	 *  Set the flag indicating if auto completion should be triggered while input searching text.
	 * 
	 *  @param intelliHintsEnabled the flag
	 *  @see #isIntelliHintsEnabled()
	 */
	public void setIntelliHintsEnabled(boolean intelliHintsEnabled) {
	}

	/**
	 *  If it returns a positive number, it will wait for that many ms before doing the search. When the searching is
	 *  complex, this flag will be useful to make the searching efficient. In the other words, if user types in several
	 *  keys very quickly, there will be only one search. If it returns 0, each key will generate a search. If it returns
	 *  -1 or a negative number, it will never automatically generate a search unless ENTER key is pressed.
	 * 
	 *  @return the number of ms delay before searching starts.
	 */
	public int getSearchingDelay() {
	}

	/**
	 *  If this flag is set to a positive number, it will wait for that many ms before doing the search. When the
	 *  searching is complex, this flag will be useful to make the searching efficient. In the other words, if user types
	 *  in several keys very quickly, there will be only one search. If this flag is set to 0, each key will generate a
	 *  search with no delay. You can also set it to a negative number such as -1. If so, it will never generate a search
	 *  unless user presses the ENTER key.
	 * 
	 *  @param searchingDelay the number of ms delay before searching start.
	 */
	public void setSearchingDelay(int searchingDelay) {
	}

	/**
	 *  Get the background of the filter row.
	 * 
	 *  @return the background color.
	 */
	public java.awt.Color getFilterRowBackground() {
	}

	/**
	 *  Set the background of the filter row.
	 * 
	 *  @param filterRowBackground the background color
	 */
	public void setFilterRowBackground(java.awt.Color filterRowBackground) {
	}

	/**
	 *  The table model for the FilterRowTable. It subclasses DefaultTableModel.
	 */
	protected class AutoFilterRowTableModel {


		protected AutoFilterUtils.AutoFilterRowTableModel() {
		}

		@java.lang.Override
		public int getRowCount() {
		}

		@java.lang.Override
		public int getColumnCount() {
		}

		@java.lang.Override
		public String getColumnName(int column) {
		}

		public Object getColumnIdentifier(int columnIndex) {
		}

		@java.lang.Override
		public boolean isCellEditable(int row, int column) {
		}

		public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
		}

		public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
		}

		public Class getCellClassAt(int rowIndex, int columnIndex) {
		}

		public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
		}

		public boolean isCellStyleOn() {
		}
	}

	/**
	 *  The table to contain the new-added filter row. It subclasses JideTable.
	 */
	protected class AutoFilterRowTable {


		public AutoFilterUtils.AutoFilterRowTable(javax.swing.table.TableModel dm) {
		}

		@java.lang.Override
		public void setValueAt(Object aValue, int row, int column) {
		}

		@java.lang.Override
		public javax.swing.table.TableCellEditor getCellEditor(int row, int column) {
		}

		@java.lang.Override
		public java.awt.Component prepareRenderer(javax.swing.table.TableCellRenderer renderer, int row, int column) {
		}

		@java.lang.Override
		public java.awt.Component prepareEditor(javax.swing.table.TableCellEditor editor, int row, int column) {
		}
	}

	/**
	 *  The filter used to filtering the table. It subclasses WildcardFilter
	 */
	protected class TableWildcardFilter {


		protected int _rowIndex;

		protected int _columnIndex;

		public AutoFilterUtils.TableWildcardFilter(String pattern) {
		}

		public void setColumnIndex(int columnIndex) {
		}

		public void setRowIndex(int rowIndex) {
		}

		public int getColumnIndex() {
		}

		public int getRowIndex() {
		}

		@java.lang.Override
		protected String convertElementToString(Object value) {
		}
	}
}
