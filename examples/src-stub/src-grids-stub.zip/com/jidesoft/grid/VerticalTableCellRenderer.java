/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is copied from JDK DefaultTableCellRenderer except using JideLabel to support vertical text.
 */
public class VerticalTableCellRenderer extends JideLabel implements javax.swing.table.TableCellRenderer, java.io.Serializable {
 {

	protected static javax.swing.border.Border noFocusBorder;

	/**
	 *  Creates a default table cell renderer.
	 */
	public VerticalTableCellRenderer() {
	}

	/**
	 *  Overrides <code>JComponent.setForeground</code> to assign
	 *  the unselected-foreground color to the specified color.
	 * 
	 *  @param c set the foreground color to this value
	 */
	public void setForeground(java.awt.Color c) {
	}

	/**
	 *  Overrides <code>JComponent.setBackground</code> to assign
	 *  the unselected-background color to the specified color.
	 * 
	 *  @param c set the background color to this value
	 */
	public void setBackground(java.awt.Color c) {
	}

	/**
	 *  Notification from the <code>UIManager</code> that the look and feel
	 *  [L&F] has changed.
	 *  Replaces the current UI object with the latest version from the
	 *  <code>UIManager</code>.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	public void updateUI() {
	}

	/**
	 *  Returns the default table cell renderer.
	 *  <p>
	 *  During a printing operation, this method will be called with
	 *  <code>isSelected</code> and <code>hasFocus</code> values of
	 *  <code>false</code> to prevent selection and focus from appearing
	 *  in the printed output. To do other customization based on whether
	 *  or not the table is being printed, check the return value from
	 *  {@link javax.swing.JComponent#isPaintingForPrint()}.
	 * 
	 *  @param table      the <code>JTable</code>
	 *  @param value      the value to assign to the cell at
	 *                    <code>[row, column]</code>
	 *  @param isSelected true if cell is selected
	 *  @param hasFocus   true if cell has focus
	 *  @param row        the row of the cell to render
	 *  @param column     the column of the cell to render
	 *  @return the default table cell renderer
	 *  @see javax.swing.JComponent#isPaintingForPrint()
	 */
	@java.lang.SuppressWarnings("Since15")
	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public boolean isOpaque() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 * 
	 *  @since 1.5
	 */
	public void invalidate() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void validate() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void revalidate() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void repaint(long tm, int x, int y, int width, int height) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void repaint(java.awt.Rectangle r) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 * 
	 *  @since 1.5
	 */
	public void repaint() {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Overridden for performance reasons.
	 *  See the <a href="#override">Implementation Note</a>
	 *  for more information.
	 */
	public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Sets the <code>String</code> object for the cell being rendered to
	 *  <code>value</code>.
	 * 
	 *  @param value the string value for this cell; if value is
	 *               <code>null</code> it sets the text value to an empty string
	 *  @see javax.swing.JLabel#setText
	 */
	protected void setValue(Object value) {
	}

	/**
	 *  A subclass of <code>DefaultTableCellRenderer</code> that
	 *  implements <code>UIResource</code>.
	 *  <code>DefaultTableCellRenderer</code> doesn't implement
	 *  <code>UIResource</code>
	 *  directly so that applications can safely override the
	 *  <code>cellRenderer</code> property with
	 *  <code>DefaultTableCellRenderer</code> subclasses.
	 *  <p>
	 *  <strong>Warning:</strong>
	 *  Serialized objects of this class will not be compatible with
	 *  future Swing releases. The current serialization support is
	 *  appropriate for short term storage or RMI between applications running
	 *  the same version of Swing.  As of 1.4, support for long term storage
	 *  of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package.
	 *  Please see {@link java.beans.XMLEncoder}.
	 */
	public static class UIResource {


		public VerticalTableCellRenderer.UIResource() {
		}
	}
}
