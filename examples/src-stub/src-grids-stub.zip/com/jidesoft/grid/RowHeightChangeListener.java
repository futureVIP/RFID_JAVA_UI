/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  RowHeightChangeListener defines the interface for an object that listens to changes in a <code>RowHeights</code>.
 * 
 *  @see RowHeightChangeEvent
 *  @see RowHeights
 */
public interface RowHeightChangeListener extends java.util.EventListener {
 {

	/**
	 *  This fine grain notification tells listeners the exact range of cells, rows, or columns that changed.
	 * 
	 *  @param e the RowHeightChangeEvent.
	 */
	public void rowHeightChanged(RowHeightChangeEvent e);
}
