/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An abstract implementation of <code>Expandable</code>.
 */
public abstract class AbstractExpandable extends AbstractNode implements Expandable {
 {

	/**
	 *  Used internally to keep track of if the property is expanded.
	 */
	protected boolean _expanded;

	protected boolean _expandable;

	public static final String PROPERTY_EXPANDED = "expanded";

	public static final String PROPERTY_EXPANDABLE = "expandable";

	/**
	 *  Constructs an AbstractExpandable.
	 */
	public AbstractExpandable() {
	}

	/**
	 *  Is this expandable expanded.
	 * 
	 *  @return expanded
	 */
	public boolean isExpanded() {
	}

	/**
	 *  Makes the children expanded.
	 *  <p/>
	 *  Please note this method will not notify the TreeTableModel. So it'd better to use {@link
	 *  com.jidesoft.grid.TreeTableModel#expandRow(ExpandableRow,boolean)} method to expand a row than using this
	 *  method.
	 * 
	 *  @param expanded true to expand the node. False to collapse it.
	 */
	public void setExpanded(boolean expanded) {
	}

	public boolean isExpandable() {
	}

	public void setExpandable(boolean expandable) {
	}

	/**
	 *  Returns true if this expandable has any children.
	 * 
	 *  @return true if this expandable has any children
	 */
	public boolean hasChildren() {
	}

	/**
	 *  Removes all children from this expandable.
	 */
	public void removeAllChildren() {
	}

	/**
	 *  Gets the number of visible descendants of this expandable. The number is actually include itself. So if this
	 *  expandable has no child, it will return 1.
	 * 
	 *  @return number of visible expandable.
	 */
	public int getNumberOfVisibleExpandable() {
	}

	/**
	 *  Gets the number of visible immediate children of this expandable. The number doesn't include itself. If it has no
	 *  visible children, it will return 0.
	 * 
	 *  @return the number of visible immediate children.
	 */
	public int getNumberOfVisibleChildren() {
	}

	/**
	 *  Gets the number of visible immediate children of this expandable. The number doesn't include itself. If it has no
	 *  visible children, it will return 0.
	 * 
	 *  @return the number of visible immediate children.
	 */
	public boolean hasVisibleChildren() {
	}

	/**
	 *  Gets children count.
	 * 
	 *  @return the children count
	 */
	public int getChildrenCount() {
	}

	/**
	 *  Gets children count after filtering.
	 * 
	 *  @return the children count after filtering
	 * 
	 *  @deprecated please use TableModelWrapperUtils.getVisibleChildrenCount(TableModel, ROW) instead to get visible
	 *              children count
	 */
	@java.lang.Deprecated
	public int getAllVisibleChildrenCount() {
	}

	/**
	 *  Gets all children count. It will include all its children, grand-children etc. You can use this method to get the
	 *  number of children of the parent so that you can display it somewhere in the UI. Of course, you need to be
	 *  careful when using this method. If there are unlimited number of children due to recursively definition, you
	 *  should never call this method.
	 * 
	 *  @param leafOnly if true, the children count will only includes the leaf node. Otherwise, all nodes will be
	 *                  included in the count.
	 *  @return the children count
	 */
	public int getAllChildrenCount(boolean leafOnly) {
	}

	/**
	 *  Adds a child.
	 * 
	 *  @param child the child to be added.
	 *  @return the child just added.
	 */
	public Object addChild(Object child) {
	}

	/**
	 *  Adds a child.
	 * 
	 *  @param index the index where the child to be inserted.
	 *  @param child the child to be added.
	 *  @return the child just added.
	 */
	public Object addChild(int index, Object child) {
	}

	/**
	 *  Adds a list of children.
	 * 
	 *  @param index    the index where the children to be inserted.
	 *  @param children the children to be added.
	 */
	public void addChildren(int index, java.util.List children) {
	}

	/**
	 *  Removes a child.
	 * 
	 *  @param child child to be removed.
	 *  @return true if child is removed successfully. If the child doesn't exist in the children list, return false.
	 */
	public boolean removeChild(Object child) {
	}

	public boolean removeChildren(java.util.List children) {
	}

	/**
	 *  Gets the child at the specified index.
	 * 
	 *  @param index the index.
	 *  @return the child at the specified index. Null if the index is out of bounds.
	 */
	public Object getChildAt(int index) {
	}

	/**
	 *  Gets the child at the specified index.
	 * 
	 *  @param child the child.
	 *  @return the index of the child if it exists. Otherwise, return -1.
	 */
	public int getChildIndex(Object child) {
	}

	/**
	 *  Moves up the child in the children list.
	 * 
	 *  @param child the child to be moved up.
	 *  @return true if the child is moved up. Otherwise false.
	 */
	public boolean moveUpChild(Object child) {
	}

	/**
	 *  Moves down the child in the children list.
	 * 
	 *  @param child the child to be moved down.
	 *  @return true if the child is moved down. Otherwise false.
	 */
	public boolean moveDownChild(Object child) {
	}

	public void notifyChildInserted(Object child, int childIndex) {
	}

	public void notifyChildrenInserted(java.util.List children, int firstIndex) {
	}

	public void notifyChildDeleted(Object child) {
	}

	public void notifyChildrenDeleted(java.util.List children) {
	}

	public void notifyChildUpdated(Object child) {
	}

	public void notifyChildrenUpdated(java.util.List children) {
	}

	public TreeTableModel getTreeTableModel() {
	}

	public boolean isAdjusting() {
	}

	public void setAdjusting(boolean adjusting) {
	}
}
