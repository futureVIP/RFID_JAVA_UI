/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A <code>TableModelValueProvider</code> is a <code>ValueProvider</code> which retrieves a value from a table model.
 */
public class TableModelValueProvider implements ValueProvider {
 {

	public TableModelValueProvider(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the value from the designated rowIndex and columnIndex in the _model.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return the value at the columnIndex of a Row.
	 */
	public Object getValueAt(int row, int column) {
	}
}
