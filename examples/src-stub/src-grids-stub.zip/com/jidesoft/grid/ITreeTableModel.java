/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public interface ITreeTableModel {

	/**
	 *  Returns the row at row specified by <code>row</code>.
	 * 
	 *  @param rowIndex the row whose row is to be queried
	 *  @return the row at the specified row index
	 */
	public Row getRowAt(int rowIndex);

	/**
	 *  Gets the index of the row.
	 * 
	 *  @param row row
	 *  @return the index of the row. If the row is displayed in the table, it will return the index. Otherwise, it will
	 *          return -1. So -1 could mean two things - the row is not displayed or the row is not in the tree hierarchy
	 *          at all.
	 */
	public int getRowIndex(Row row);

	/**
	 *  Gets the root expandable row which has the original rows as children.
	 * 
	 *  @return the root expandable row.
	 */
	public Object getRoot();
}
