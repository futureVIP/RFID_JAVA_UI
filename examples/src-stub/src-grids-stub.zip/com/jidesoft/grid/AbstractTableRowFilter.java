/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>AbstractTableRowFilter</code> is an abstract implementation of {@link com.jidesoft.grid.TableRowFilter}.
 *  <p/>
 *  Please note, this class extends com.jidesoft.grid.AbstractFilter for backward compatible reason. It will change to
 *  extend com.jidesoft.filter.AbstractFilter after a few releases.
 */
public abstract class AbstractTableRowFilter extends AbstractFilter implements TableRowFilter {
 {

	public AbstractTableRowFilter() {
	}
}
