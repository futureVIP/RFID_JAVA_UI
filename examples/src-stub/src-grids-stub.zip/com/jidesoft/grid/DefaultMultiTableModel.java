/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Default implementation of MultiTableModel based on DefaultTableModel.
 *  <p/>
 *  By default none of the columns are header or footer. The table index returned from getTableIndex() is always 0.
 */
public class DefaultMultiTableModel extends javax.swing.table.DefaultTableModel implements MultiTableModel {
 {

	public DefaultMultiTableModel() {
	}

	public int getColumnType(int column) {
	}

	public int getTableIndex(int columnIndex) {
	}

	public ConverterContext getConverterContextAt(int row, int column) {
	}

	public EditorContext getEditorContextAt(int row, int column) {
	}

	public Class getCellClassAt(int row, int column) {
	}
}
