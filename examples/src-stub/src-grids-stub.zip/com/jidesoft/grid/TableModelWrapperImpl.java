/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The default implementation of TableModelWrapper.
 *  <p/>
 *  Note: This class should be named as DefaultTableModelWrapper but the name was taken and is too much trouble to
 *  change.
 */
public class TableModelWrapperImpl extends javax.swing.table.AbstractTableModel implements ColumnIdentifierTableModel, TableModelWrapper, ContextSensitiveTableModel, StyleModel, SpanModel, NavigableModel, MultiTableModel, javax.swing.event.TableModelListener, IndexChangeEventGenerator, EditorStyleTableModel {
 {

	protected javax.swing.table.TableModel _model;

	/**
	 *  Creates a DefaultTableModelWrapper from any table model.
	 * 
	 *  @param model the actual table model.
	 */
	public TableModelWrapperImpl(javax.swing.table.TableModel model) {
	}

	public void addIndexChangeListener(IndexChangeListener l) {
	}

	public void removeIndexChangeListener(IndexChangeListener l) {
	}

	/**
	 *  Returns an array of all the <code>IndexChangeListener</code>s added to this <code>TableModelWrapper</code> with
	 *  <code>addIndexChangeListener</code>.
	 * 
	 *  @return all of the <code>IndexChangeListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addIndexChangeListener
	 */
	public IndexChangeListener[] getIndexChangeListeners() {
	}

	/**
	 *  Tells the TableModeWrapper that indexes is going to be changed. It will basically fire an INDEX_CHANGING_EVENT
	 *  event.
	 * 
	 *  @return the event serial number for this call, to be used in its partner fireIndexChanged
	 */
	protected int fireIndexChanging() {
	}

	/**
	 *  Tells the TableModeWrapper that indexes is changed. It will basically fire an INDEX_CHANGED_EVENT event.
	 * 
	 *  @param eventSerialNumber the serial number indicating where this method is invoked, to be pair with
	 *                           fireIndexChanging
	 */
	protected void fireIndexChanged(int eventSerialNumber) {
	}

	/**
	 *  Gets the actual table model. Since TableModelWrapper is just a wrapper around another table model, this method
	 *  will return you the actual table model.
	 * 
	 *  @return the actual table model.
	 */
	public javax.swing.table.TableModel getActualModel() {
	}

	public Object getValueAt(int row, int column) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int row, int column) {
	}

	public synchronized int getRowCount() {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public Object getColumnIdentifier(int column) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	@java.lang.Override
	public boolean isCellEditable(int row, int column) {
	}

	/**
	 *  Gets the converter context of the underlying table model. This will return a valid value only if underlying table
	 *  model is instance of <code>ContextSensitiveTableModel</code>. If not, it will return null.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return converter context of the underlying table model.
	 */
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	/**
	 *  Gets the editor context of the underlying table model. This will return a valid value only if underlying table
	 *  model is instance of <code>ContextSensitiveTableModel</code>. If not, it will return null.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return editor context of the underlying table model.
	 */
	public EditorContext getEditorContextAt(int row, int column) {
	}

	/**
	 *  Gets the cell class of the underlying table model. This will return a valid value only if underlying table model
	 *  is instance of <code>ContextSensitiveTableModel</code>. If not, it will return underlying model's
	 *  getColumnClass(column).
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return cell class of the underlying table model.
	 */
	public Class getCellClassAt(int row, int column) {
	}

	/**
	 *  Returns null all the time unless you override this method to return a cell style.
	 * 
	 *  @param row    the row index.
	 *  @param column the column index.
	 *  @return null.
	 */
	public CellStyle getCellStyleAt(int row, int column) {
	}

	/**
	 *  Returns false all the time unless you override this method to return true. The reason is CellStyleTable will look
	 *  into the underlying model to see if it defined style. \ Thus no need we delegate to the underlying table model
	 *  here.
	 * 
	 *  @return false.
	 */
	public boolean isCellStyleOn() {
	}

	/**
	 *  it return true by default.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return true.
	 */
	public boolean isNavigableAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  It returns false.
	 * 
	 *  @return false.
	 */
	public boolean isNavigationOn() {
	}

	/**
	 *  Gets cell span of the underlying table model.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index.
	 *  @return cell span of the underlying table model.
	 */
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Delegates to underlying table model for cell span information.
	 * 
	 *  @return the isCellSpaneOn value of underlying table model.
	 */
	public boolean isCellSpanOn() {
	}

	/**
	 *  Implementation of the <code>TableChangeListener</code> interface. Depending on the type of the
	 *  <code>TableModelEvent</code>, this method delegates to one of the following methods based on the contract of the
	 *  <code>TableModelEvent</code> object: <ul> <li>{@link #tableRowsInserted(int,int)} <li>{@link
	 *  #tableRowsDeleted(int,int)} <li>{@link #tableStructureChanged()} <li>{@link #tableDataChanged()} <li>{@link
	 *  #tableRowsUpdated(int,int)} <li>{@link #tableCellsUpdated(int,int,int)} <ul> The default implementations of the
	 *  above methods simply rebroadcast a <code>TableModelEvent</code> to the listeners on this model. Most Subclasses
	 *  will override one or more of the above protected methods to provide custom behavior for particular events.
	 *  However, some implementations may wish to override this method instead. Obviously, if this method is overridden,
	 *  the above protected methods will not be called unless the overridden implementation does so explicitly.
	 * 
	 *  @param e the <code>TableModelEvent</code> representing the change
	 */
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	/**
	 *  Called each time one or more contiguous rows are inserted into the underlying <code>TableModel</code>. This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was inserted
	 *  @param lastRow  the index of the last row that was inserted
	 */
	protected void tableRowsInserted(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time one or more contiguous rows are deleted from the underlying <code>TableModel</code>. This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was deleted
	 *  @param lastRow  the index of the last row that was deleted
	 */
	protected void tableRowsDeleted(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time one or more contiguous rows are updated in the underlying <code>TableModel</code>. simply fires
	 *  a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 * 
	 *  @param firstRow the index of the first row that was updated
	 *  @param lastRow  the index of the last row that was updated
	 */
	protected void tableRowsUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  Called each time the cells in <code>column</code> in the range [<code>firstRow</code>, <code>lastRow</code>] are
	 *  updated. This default implementation simply fires a corresponding <code> TableModelEvent</code> to the listeners
	 *  on this model.
	 * 
	 *  @param firstRow the index of the first row in the above <code> column</code> that was updated
	 *  @param lastRow  the index of the last row in the above <code> column</code> that was updated
	 *  @param column   the index of the column that was updated
	 */
	public void fireTableCellsUpdated(int firstRow, int lastRow, int column) {
	}

	/**
	 *  Called each time the cells in <code>column</code> in the range [<code>firstRow</code>, <code>lastRow</code>] are
	 *  updated. This default implementation simply fires a corresponding <code> TableModelEvent</code> to the listeners
	 *  on this model.
	 * 
	 *  @param column   the index of the column that was updated
	 *  @param firstRow the index of the first row in the above <code> column</code> that was updated
	 *  @param lastRow  the index of the last row in the above <code> column</code> that was updated
	 */
	protected void tableCellsUpdated(int column, int firstRow, int lastRow) {
	}

	/**
	 *  Called each time all of the data (i.e. all rows) is changed in the underlying<code>TableModel</code>.  This
	 *  default implementation simply fires a corresponding <code>TableModelEvent</code> to the listeners on this model.
	 */
	protected void tableDataChanged() {
	}

	/**
	 *  Called each time the structure (<code>TableColumn</code>s, etc) of the underlying <code>TableModel</code>
	 *  changes. This default implementation simply fires a corresponding <code>TableModelEvent </code> to the listeners
	 *  on this model.
	 */
	protected void tableStructureChanged() {
	}

	public int getColumnType(int columnIndex) {
	}

	public int getTableIndex(int columnIndex) {
	}

	@java.lang.Override
	public int getEditorStyleAt(int rowIndex, int columnIndex) {
	}
}
