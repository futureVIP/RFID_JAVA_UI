/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The cell renderer for the expandable column of <code>TreeTable</code> where there is a +/- icon.
 */
public class TreeTableCellRenderer extends javax.swing.table.DefaultTableCellRenderer {

	protected TreeExpandablePanel _cellRenderer;

	protected javax.swing.table.TableCellRenderer _actualCellRenderer;

	public TreeTableCellRenderer() {
	}

	/**
	 *  Returns the component used for drawing the cell.  This method is used to configure the renderer appropriately
	 *  before drawing.
	 * 
	 *  @param table       the <code>JTable</code> that is asking the renderer to draw; can be <code>null</code>
	 *  @param value       the value of the cell to be rendered.  It is up to the specific renderer to interpret and draw
	 *                     the value.  For example, if <code>value</code> is the string "true", it could be rendered as a
	 *                     string or it could be rendered as a check box that is checked.  <code>null</code> is a valid
	 *                     value
	 *  @param isSelected  true if the cell is to be rendered with the selection highlighted; otherwise false
	 *  @param hasFocus    if true, render cell appropriately.  For example, put a special border on the cell, if the
	 *                     cell can be edited, render in the color used to indicate editing
	 *  @param rowIndex    the row index of the cell being drawn.  When drawing the header, the value of <code>row</code>
	 *                     is -1
	 *  @param columnIndex the column index of the cell being drawn
	 *  @return the table cell renderer component
	 */
	@java.lang.Override
	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int rowIndex, int columnIndex) {
	}

	/**
	 *  Creates the TreeExpandablePanel. The panel will be used to paint +/- icon as well as the actual cell renderer.
	 * 
	 *  @param treeTable
	 *  @return a new instance of TreeExpandablePanel.
	 */
	protected TreeExpandablePanel createTreeExpandablePanel(TreeTable treeTable) {
	}

	/**
	 *  Customizes the PropertyTableCellRenderer style. By default, it will use bold font for property whose
	 *  isPreferred() is true.
	 * 
	 *  @param row
	 *  @param ret
	 */
	protected void customizeCellRenderer(Row row, java.awt.Component ret) {
	}

	/**
	 *  Gets the actual cell renderer.
	 * 
	 *  @return the actual cell renderer.
	 */
	public javax.swing.table.TableCellRenderer getActualCellRenderer() {
	}

	/**
	 *  Sets the actual cell renderer.
	 * 
	 *  @param actualCellRenderer
	 */
	public void setActualCellRenderer(javax.swing.table.TableCellRenderer actualCellRenderer) {
	}

	public void releaseCellRenderer() {
	}
}
