/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for Color. It uses ColorComboBox to provide an editor for Color. You can override {@link
 *  #createColorComboBox()} method to provide your own ColorComboBox.
 */
public class ColorCellEditor extends AbstractComboBoxCellEditor {

	/**
	 *  Creates a ColorCellEditor.
	 */
	public ColorCellEditor() {
	}

	/**
	 *  Creates the color combobox used by this cell editor.
	 * 
	 *  @return the color combobox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates the color combobox used by this cell editor.
	 * 
	 *  @return the color combobox.
	 */
	protected com.jidesoft.combobox.ColorComboBox createColorComboBox() {
	}

	@java.lang.Override
	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}
}
