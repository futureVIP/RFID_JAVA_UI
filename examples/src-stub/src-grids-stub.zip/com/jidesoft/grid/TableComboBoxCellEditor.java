/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is for any cell editor where one needs to choose value from a table. It used TableComboBox as the editor.
 */
public class TableComboBoxCellEditor extends AbstractComboBoxCellEditor {

	/**
	 *  Creates a <code>TableComboBoxCellEditor</code>.
	 * 
	 *  @param model the TableModel
	 */
	public TableComboBoxCellEditor(javax.swing.table.TableModel model) {
	}

	/**
	 *  Creates a <code>TableComboBoxCellEditor</code> .
	 * 
	 *  @param model the <code>TableModel</code>
	 *  @param type  the element type.
	 */
	public TableComboBoxCellEditor(javax.swing.table.TableModel model, Class type) {
	}

	/**
	 *  Gets the table model.
	 * 
	 *  @return the table model.
	 */
	public javax.swing.table.TableModel getTableModel() {
	}

	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox(javax.swing.ComboBoxModel model, Class type) {
	}

	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	@java.lang.Override
	public void itemStateChanged(java.awt.event.ItemEvent e) {
	}

	@java.lang.Override
	public void popupMenuWillBecomeInvisible(javax.swing.event.PopupMenuEvent e) {
	}

	/**
	 *  Creates the TableComboBox.
	 * 
	 *  @return the TableComboBox instance.
	 */
	protected com.jidesoft.combobox.TableComboBox createTableComboBox() {
	}

	/**
	 *  Creates the TableComboBox.
	 * 
	 *  @param model the <code>TableModel</code>.
	 *  @param type  the element type.
	 *  @return the TableComboBox.
	 *  @deprecated please use {@link #createTableComboBox()} instead.
	 */
	@java.lang.Deprecated
	protected com.jidesoft.combobox.TableComboBox createTableComboBox(javax.swing.table.TableModel model, Class type) {
	}
}
