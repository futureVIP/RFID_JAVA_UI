/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>BeanTableModel</code> provides the same features as {@link com.jidesoft.grid.BasicTableModel} after we
 *  introduced the BasicTableModel. BeanTableModel is just an empty place holder for backward compatible reason.
 */
public class BeanTableModel extends BasicTableModel {

	public BeanTableModel() {
	}

	public BeanTableModel(java.util.List objects, Class type) {
	}

	public BeanTableModel(java.util.List objects, Class type, com.jidesoft.introspector.IntrospectorContext context) {
	}

	public BeanTableModel(java.util.List objects, Class type, String[] propertyNames) {
	}

	public BeanTableModel(java.util.List objects, com.jidesoft.introspector.Introspector introspector) {
	}
}
