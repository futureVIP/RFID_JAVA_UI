/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  TableWrapperUtilsis a utility class that contains several useful methods for TableModelWrapper.
 */
public class TableModelWrapperUtils {

	public TableModelWrapperUtils() {
	}

	/**
	 *  Gets the inner table model whose class is an instance of the innerModelClass.
	 * 
	 *  @param outerModel      the outermost TableModel
	 *  @param innerModelClass the class for the inner model.
	 *  @return the table model whose class is innerModelClass.
	 */
	public static javax.swing.table.TableModel getActualTableModel(javax.swing.table.TableModel outerModel, Class innerModelClass) {
	}

	/**
	 *  Gets the inner most table model.
	 * 
	 *  @param outerModel the outer TableModel
	 *  @return the inner most table model. It is the first inner model that is not an instance of TableModelWrapper.
	 */
	public static javax.swing.table.TableModel getActualTableModel(javax.swing.table.TableModel outerModel) {
	}

	/**
	 *  Gets next inner table model.
	 * 
	 *  @param outerModel the outer TableModel
	 *  @return the next inner table model.
	 */
	public static javax.swing.table.TableModel getNextInnerTableModel(javax.swing.table.TableModel outerModel) {
	}

	/**
	 *  Gets the actual row index at an innerModel whose class is innerModelClass.
	 * 
	 *  @param outerModel      the outer TableModel.
	 *  @param rowIndex        the row on the outer TableModel
	 *  @param innerModelClass the class of the inner TableModel
	 *  @return the row index of inner TableModel. If it can't find it, -1 will be returned.
	 */
	public static int getActualRowAt(javax.swing.table.TableModel outerModel, int rowIndex, Class innerModelClass) {
	}

	/**
	 *  Gets the actual row index at an outerModel whose class is innerModelClass.
	 * 
	 *  @param outerModel the outer TableModel.
	 *  @param rowIndex   the row of outer TableModel
	 *  @param innerModel the inner TableModel
	 *  @return the row index of inner TableModel. If it can't find it, -1 will be returned.
	 */
	public static int getActualRowAt(javax.swing.table.TableModel outerModel, int rowIndex, javax.swing.table.TableModel innerModel) {
	}

	/**
	 *  Gets the actual row index at the outerModel.
	 * 
	 *  @param outerModel the outer TableModel.
	 *  @param rowIndex   the row of outer TableModel
	 *  @return the row index of nested model which is not a table wrapper. If it can't find it, -1 will be returned.
	 */
	public static int getActualRowAt(javax.swing.table.TableModel outerModel, int rowIndex) {
	}

	/**
	 *  Gets the innermost table model row count.
	 * 
	 *  @param outerModel the outer TableModel
	 *  @return the row count at the innermost model.
	 */
	public static int getActualRowCount(javax.swing.table.TableModel outerModel) {
	}

	/**
	 *  Gets the row at the outer model knowing the row index on an inner model
	 * 
	 *  @param outerModel      the outer TableModel
	 *  @param innerModel      the inner TableModel
	 *  @param rowInInnerModel the row index on the inner TableModel
	 *  @return the row at the outer model. If it can't find it, -1 will be returned.
	 */
	public static int getRowAt(javax.swing.table.TableModel outerModel, javax.swing.table.TableModel innerModel, int rowInInnerModel) {
	}

	/**
	 *  Gets the row at the outer model knowing the row index on an inner most model
	 * 
	 *  @param outerModel      the outer TableModel
	 *  @param rowInInnerModel the row index on the inner TableModel
	 *  @return the row at the outer model. If it can't find it, -1 will be returned.
	 */
	public static int getRowAt(javax.swing.table.TableModel outerModel, int rowInInnerModel) {
	}

	/**
	 *  Gets the actual column index at an outerModel whose class is innerModelClass.
	 * 
	 *  @param outerModel      the outer TableModel.
	 *  @param column          the column of outer TableModel
	 *  @param innerModelClass the class of the inner TableModel
	 *  @return the column index of inner TableModel. If it can't find it, -1 will be returned.
	 */
	public static int getActualColumnAt(javax.swing.table.TableModel outerModel, int column, Class innerModelClass) {
	}

	/**
	 *  Gets the actual column index at an outerModel whose class is innerModelClass.
	 * 
	 *  @param outerModel the outer TableModel.
	 *  @param column     the column of outer TableModel
	 *  @param innerModel the inner TableModel
	 *  @return the column index of inner TableModel. If it can't find it, -1 will be returned.
	 */
	public static int getActualColumnAt(javax.swing.table.TableModel outerModel, int column, javax.swing.table.TableModel innerModel) {
	}

	/**
	 *  Gets the actual column index at an outerModel.
	 * 
	 *  @param outerModel the outer TableModel.
	 *  @param column     the column of outer TableModel
	 *  @return the column index of nested model which is not a table wrapper. If it can't find it, -1 will be returned.
	 */
	public static int getActualColumnAt(javax.swing.table.TableModel outerModel, int column) {
	}

	/**
	 *  Gets the innermost table model column count.
	 * 
	 *  @param outerModel the outer TableModel
	 *  @return the column count at the innermost model.
	 */
	public static int getActualColumnCount(javax.swing.table.TableModel outerModel) {
	}

	/**
	 *  Gets the column at the outer model knowing the column index on an inner model
	 * 
	 *  @param outerModel         the outer TableModel
	 *  @param innerModel         the inner model
	 *  @param columnInInnerModel the column index on the inner model.
	 *  @return the column at the outer model. If it can't find it, -1 will be returned.
	 */
	public static int getColumnAt(javax.swing.table.TableModel outerModel, javax.swing.table.TableModel innerModel, int columnInInnerModel) {
	}

	/**
	 *  Gets the column at the outer model knowing the column index on the innermost model
	 * 
	 *  @param outerModel         the outer TableModel
	 *  @param columnInInnerModel the column index on the innermost model
	 *  @return the column at the outer model. If it can't find it, -1 will be returned.
	 */
	public static int getColumnAt(javax.swing.table.TableModel outerModel, int columnInInnerModel) {
	}

	/**
	 *  Gets the actual rows in the inner most table model based on the row indices of the outer TableModel. This method can be used in combination
	 *  with table.getSelectedRows() which returns an int array to find out the actual row indices in the actual table
	 *  model.
	 * 
	 *  @param outerModel the outer TableModel.
	 *  @param rowIndices the row index array of the outer TableModel
	 *  @param sort       true to sort the returned row indices. If false, the order will be the same as the order of the
	 *                    rowIndices parameter.
	 *  @return the row index array of nested model which is not a table wrapper. If it can't find any row, -1 will be placed on the index of the array.
	 */
	public static int[] getActualRowsAt(javax.swing.table.TableModel outerModel, int[] rowIndices, boolean sort) {
	}

	/**
	 *  Gets the actual columns in the inner most table model based on the column indices of the outer TableModel. This method can be used in
	 *  combination with table.getSelectedColumns() which returns an int array to find out the actual column indices in
	 *  the actual table model.
	 * 
	 *  @param outerModel    the outer TableModel.
	 *  @param columnIndices the column index array of the outer TableModel
	 *  @param sort          true to sort the returned column indices. If false, the order will be the same as the order
	 *                       of the columnIndices parameter.
	 *  @return the column index array of nested model which is not a table wrapper. If it can't find any row, -1 will be placed on the index of the array.
	 */
	public static int[] getActualColumnsAt(javax.swing.table.TableModel outerModel, int[] columnIndices, boolean sort) {
	}

	/**
	 *  Gets the visual rows in outerModel based on the row indices of the innermost TableModel. This method can be used in combination
	 *  with table.getSelectedRows() which returns an int array to find out the row indices in the outerModel.
	 * 
	 *  @param outerModel the outer TableModel.
	 *  @param rowIndices the row index array of innermost TableModel
	 *  @param sort       true to sort the returned row indices. If false, the order will be the same as the order of the
	 *                    rowIndices parameter.
	 *  @return the row index array of the outer model. If it can't find any row, -1 will be placed on the index of the array.
	 */
	public static int[] getRowsAt(javax.swing.table.TableModel outerModel, int[] rowIndices, boolean sort) {
	}

	/**
	 *  Gets the visual columns based on the column indices of the inner TableModel.
	 * 
	 *  @param outerModel    the outer TableModel.
	 *  @param columnIndices the column index array of the innermost TableModel
	 *  @param sort          true to sort the returned column indices. If false, the order will be the same as the order
	 *                       of the columnIndices parameter.
	 *  @return the column index array of the outer model. If it can't find any row, -1 will be placed on the index of the array.
	 */
	public static int[] getColumnsAt(javax.swing.table.TableModel outerModel, int[] columnIndices, boolean sort) {
	}

	/**
	 *  The method can only be used for any table model who has one inner model as {@link
	 *  com.jidesoft.grid.TreeTableModel} to find the current visible children count. It has two options, leaf only or
	 *  count collapsed nodes.
	 *  <p/>
	 *  It could hit performance since we have to expand all to count the actual leaf nodes then set the original expansion
	 *  state back.
	 * 
	 *  @param model  the outer table model
	 *  @param parent the Row to be queried
	 *  @param leafOnly the count will only include leaf children or not
	 *  @param countCollapsedNodes if the collapsed nodes need to be counted
	 *  @return the visible children count in the outer table model
	 *  @deprecated replaced by {@link com.jidesoft.grid.TreeTableUtils#getDescendantCount(javax.swing.table.TableModel, Row, boolean, boolean)}
	 */
	@java.lang.Deprecated
	public static int getVisibleChildrenCount(javax.swing.table.TableModel model, Row parent, boolean leafOnly, boolean countCollapsedNodes) {
	}

	/**
	 *  The method can only be used for any table model who has one inner model as {@link
	 *  com.jidesoft.grid.TreeTableModel} to find the current visible children count.
	 * 
	 *  @param model  the outer table model
	 *  @param parent the Row to be queried
	 *  @return the visible children count in the outer table model
	 *  @deprecated replaced by {@link com.jidesoft.grid.TreeTableUtils#getDescendantCount(javax.swing.table.TableModel, Row, boolean, boolean)}
	 */
	@java.lang.Deprecated
	public static int getVisibleChildrenCount(javax.swing.table.TableModel model, Row parent) {
	}
}
