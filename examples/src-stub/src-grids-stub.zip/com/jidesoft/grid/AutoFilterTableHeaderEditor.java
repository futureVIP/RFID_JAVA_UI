/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Header cell editor for <code>AutoFilterTableHeader</code>.
 */
public class AutoFilterTableHeaderEditor extends javax.swing.AbstractCellEditor implements javax.swing.table.TableCellEditor, javax.swing.SwingConstants {
 {

	protected AutoFilterBox _box;

	public AutoFilterTableHeaderEditor() {
	}

	/**
	 *  Creates the <code>AutoFilterBox</code>.
	 * 
	 *  @return the <code>AutoFilterBox</code>.
	 */
	protected AutoFilterBox createAutoFilterBox() {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	}

	/**
	 *  Gets the editor value. It will return the text.
	 * 
	 *  @return the text.
	 */
	public Object getCellEditorValue() {
	}

	/**
	 *  Returns the vertical alignment of the text and icon.
	 * 
	 *  @return the <code>verticalAlignment</code> property, one of the following values: <ul> <li>{@code
	 *          SwingConstants.CENTER} (the default) <li>{@code SwingConstants.TOP} <li>{@code SwingConstants.BOTTOM}
	 *          </ul>
	 */
	public int getVerticalAlignment() {
	}

	/**
	 *  Sets the vertical alignment of the icon and text.
	 * 
	 *  @param alignment one of the following values: <ul> <li>{@code SwingConstants.CENTER} (the default) <li>{@code
	 *                   SwingConstants.TOP} <li>{@code SwingConstants.BOTTOM} </ul>
	 *  @throws IllegalArgumentException if the alignment is not one of the legal values listed above
	 */
	public void setVerticalAlignment(int alignment) {
	}

	/**
	 *  Returns the horizontal alignment of the icon and text. {@code AbstractButton}'s default is {@code
	 *  SwingConstants.CENTER}, but subclasses such as {@code JCheckBox} may use a different default.
	 * 
	 *  @return the <code>horizontalAlignment</code> property, one of the following values: <ul> <li>{@code
	 *          SwingConstants.RIGHT} <li>{@code SwingConstants.LEFT} <li>{@code SwingConstants.CENTER} <li>{@code
	 *          SwingConstants.LEADING} <li>{@code SwingConstants.TRAILING} </ul>
	 */
	public int getHorizontalAlignment() {
	}

	/**
	 *  Sets the horizontal alignment of the icon and text. {@code AbstractButton}'s default is {@code
	 *  SwingConstants.CENTER}, but subclasses such as {@code JCheckBox} may use a different default.
	 * 
	 *  @param alignment the alignment value, one of the following values: <ul> <li>{@code SwingConstants.RIGHT}
	 *                   <li>{@code SwingConstants.LEFT} <li>{@code SwingConstants.CENTER} <li>{@code
	 *                   SwingConstants.LEADING} <li>{@code SwingConstants.TRAILING} </ul>
	 *  @throws IllegalArgumentException if the alignment is not one of the valid values
	 */
	public void setHorizontalAlignment(int alignment) {
	}

	/**
	 *  Verify that the {@code key} argument is a legal value for the {@code horizontalAlignment} and {@code
	 *  horizontalTextPosition} properties. Valid values are: <ul> <li>{@code SwingConstants.RIGHT} <li>{@code
	 *  SwingConstants.LEFT} <li>{@code SwingConstants.CENTER} <li>{@code SwingConstants.LEADING} <li>{@code
	 *  SwingConstants.TRAILING} </ul>
	 * 
	 *  @param key       the property value to check
	 *  @param exception the message to use in the {@code IllegalArgumentException} that is thrown for an invalid value
	 *  @throws IllegalArgumentException if key is not one of the legal values listed above
	 *  @see #setHorizontalAlignment
	 */
	protected int checkHorizontalKey(int key, String exception) {
	}

	/**
	 *  Verify that the {@code key} argument is a legal value for the vertical properties. Valid values are: <ul>
	 *  <li>{@code SwingConstants.CENTER} <li>{@code SwingConstants.TOP} <li>{@code SwingConstants.BOTTOM} </ul>
	 * 
	 *  @param key       the property value to check
	 *  @param exception the message to use in the {@code IllegalArgumentException} that is thrown for an invalid value
	 *  @throws IllegalArgumentException if key is not one of the legal values listed above
	 */
	protected int checkVerticalKey(int key, String exception) {
	}
}
