/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An <code>AWTEvent</code> that adds support for
 *  <code>SortableTableModel</code> objects as the event source.
 */
public class SortEvent extends java.util.EventObject {

	/**
	 *  Constructs an <code>SortableTableModelEvent</code> object.
	 * 
	 *  @param source the <code>SortableTableModel</code> object that originated the event
	 */
	public SortEvent(Object source) {
	}
}
