/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>GroupTable</code> is a special <code>TreeTable</code> that can group rows who has the same value in certain
 *  column into a group. It is an implementation that is very similar to the table used in Microsoft Outlook Inbox
 *  table.
 */
public class GroupTable extends TreeTable {

	public GroupTable() {
	}

	public GroupTable(int numRows, int numColumns) {
	}

	public GroupTable(javax.swing.table.TableModel dm) {
	}

	public GroupTable(Object[][] rowData, Object[] columnNames) {
	}

	public GroupTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public GroupTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public GroupTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	@java.lang.Override
	public javax.swing.table.TableCellRenderer getCellRenderer(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	protected void handleMouseEvent(java.awt.event.MouseEvent e) {
	}
}
