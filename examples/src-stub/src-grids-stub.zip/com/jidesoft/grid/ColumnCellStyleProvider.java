/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>CellStyleProvider</code> for column stripes.
 */
public class ColumnCellStyleProvider implements CellStyleProvider {
 {

	/**
	 *  Creates a <code>ColumnStripeCellStyleProvider</code>. It uses WHITE and a very light yellow color as two
	 *  alternative column colors.
	 * 
	 *  @param tableModel the table model
	 */
	public ColumnCellStyleProvider(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Gets the cell style at the specified cell.
	 * 
	 *  @param model       the model. This is the model from table.getModel().
	 *  @param rowIndex    the column index as in the model
	 *  @param columnIndex the column index as in the model
	 *  @return the cell style at the specified cell.
	 */
	public CellStyle getCellStyleAt(javax.swing.table.TableModel model, int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the cell styles.
	 * 
	 *  @return the cell styles.
	 */
	public CellStyle[] getCellStyles() {
	}

	/**
	 *  Gets the cell styles.
	 * 
	 *  @param cellStyles the new cell styles.
	 */
	public void setCellStyles(CellStyle[] cellStyles) {
	}

	/**
	 *  Sets the cell style for the column.
	 * 
	 *  @param columnIndex the column index
	 *  @param style       the CellStyle for the column
	 */
	public void setCellStyleAt(int columnIndex, CellStyle style) {
	}

	/**
	 *  Sets the cell style for the column.
	 * 
	 *  @param columnIndex the column index
	 *  @return the CellStyle for the column
	 */
	public CellStyle getCellStyleAt(int columnIndex) {
	}
}
