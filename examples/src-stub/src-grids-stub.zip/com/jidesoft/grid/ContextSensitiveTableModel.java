/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This interface should be used along with TableModel class.
 *  Combining with TableModel, it will be able to get converter
 *  context, editor context and type of each cell.
 *  <p/>
 *  The cellClassAt and the converterContextAt will provide the key to look up for
 *  the <code>ObjectConverter</code> from <code>ObjectConverterManager</code>.
 *  The cellClassAt and the editorContextAt will provide the key to look up for
 *  the <code>TableCellRenderer</code> and <code>TableCellEditor</code>from
 *  <code>CellRendererManager</code> and <code>CellEditorManager</code> respectively.
 */
public interface ContextSensitiveTableModel extends javax.swing.table.TableModel {
 {

	/**
	 *  Gets the converter context at cell (row, column).
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return converter context
	 */
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex);

	/**
	 *  Gets the editor context at cell (row, column).
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return editor context
	 */
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex);

	/**
	 *  Gets the type at cell (row, column).
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return type
	 */
	public Class getCellClassAt(int rowIndex, int columnIndex);
}
