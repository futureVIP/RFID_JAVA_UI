/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  RowHeightChangeEvent is used to notify listeners that a table's row height has changed. Depending on the parameters
 *  used in the constructors, the RowHeightChangeEvent can be used to specify the following types of changes: <p>
 *  <p/>
 *  <pre>
 *  RowHeightChangeEvent(source);              //  The data, i.e. all rows height changed
 *  RowHeightChangeEvent(source, 1);           //  Row 1 height changed
 *  RowHeightChangeEvent(source, 3, 6);        //  Rows 3 to 6 inclusive changed
 *  RowHeightChangeEvent(source, 3, 6, INSERT); // Rows (3, 6) were inserted
 *  RowHeightChangeEvent(source, 3, 6, DELETE); // Rows (3, 6) were deleted
 *  </pre>
 */
public class RowHeightChangeEvent extends java.util.EventObject {

	/**
	 *  Identifies the addition of new rows.
	 */
	public static final int INSERT = 1;

	/**
	 *  Identifies a change to existing data.
	 */
	public static final int UPDATE = 0;

	/**
	 *  Identifies the removal of rows.
	 */
	public static final int DELETE = -1;

	protected int type;

	protected int firstRow;

	protected int lastRow;

	/**
	 *  All row data in the table has changed, listeners should discard any state that was based on the rows and re-query
	 *  the <code>RowHeights</code> to get the new row count and all the appropriate values. The <code>JTable</code> will
	 *  repaint the entire visible region on receiving this event, querying the model for the cell values that are
	 *  visible. The structure of the table, i.e. the column names, types and order have not changed.
	 * 
	 *  @param source the source for the event.
	 */
	public RowHeightChangeEvent(RowHeights source) {
	}

	/**
	 *  This row of data has been updated. To denote the arrival of a completely new table with a different structure use
	 *  <code>HEADER_ROW</code> as the value for the <code>row</code>. When the <code>JTable</code> receives this event
	 *  and its <code>autoCreateColumnsFromModel</code> flag is set it discards any TableColumns that it had and
	 *  reallocates default ones in the order they appear in the model. This is the same as calling
	 *  <code>setModel(RowHeights)</code> on the <code>JTable</code>.
	 * 
	 *  @param source the source for the event.
	 *  @param row    the row index.
	 */
	public RowHeightChangeEvent(RowHeights source, int row) {
	}

	/**
	 *  The data in rows [<I>firstRow</I>, <I>lastRow</I>] have been updated.
	 * 
	 *  @param source   the source for the event.
	 *  @param firstRow the first row index.
	 *  @param lastRow  the last row index.
	 */
	public RowHeightChangeEvent(RowHeights source, int firstRow, int lastRow) {
	}

	/**
	 *  The cells from (firstRow, column) to (lastRow, column) have been changed. The <I>column</I> refers to the column
	 *  index of the cell in the model's co-ordinate system. When <I>column</I> is ALL_COLUMNS, all cells in the
	 *  specified range of rows are considered changed.
	 *  <p/>
	 *  The <I>type</I> should be one of: INSERT, UPDATE and DELETE.
	 * 
	 *  @param source   the source for the event.
	 *  @param firstRow the first row index.
	 *  @param lastRow  the last row index.
	 *  @param type     the event type.
	 */
	public RowHeightChangeEvent(RowHeights source, int firstRow, int lastRow, int type) {
	}

	/**
	 *  Returns the first row that is changed.  HEADER_ROW means the meta data, ie. names, types and order of the
	 *  columns.
	 * 
	 *  @return the first row that is changed.
	 */
	public int getFirstRow() {
	}

	/**
	 *  Returns the last row that changed.
	 * 
	 *  @return the last row that is changed.
	 */
	public int getLastRow() {
	}

	/**
	 *  Returns the type of event - one of: INSERT, UPDATE and DELETE.
	 * 
	 *  @return the event type.
	 */
	public int getType() {
	}

	@java.lang.Override
	public String toString() {
	}
}
