/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>StyleTableModel</code> interface combines <code>TableModel</code> and <code>StyleModel</code>.
 */
public interface StyleTableModel extends javax.swing.table.TableModel, StyleModel {
 {
}
