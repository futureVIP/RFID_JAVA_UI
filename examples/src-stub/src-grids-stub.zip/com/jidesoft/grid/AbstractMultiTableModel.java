/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  An abstract implementation of MultiTableModel based on AbstractTableModel.
 */
public abstract class AbstractMultiTableModel extends javax.swing.table.AbstractTableModel implements MultiTableModel {
 {

	public AbstractMultiTableModel() {
	}

	public Class getCellClassAt(int row, int column) {
	}

	public EditorContext getEditorContextAt(int row, int column) {
	}

	public ConverterContext getConverterContextAt(int row, int column) {
	}
}
