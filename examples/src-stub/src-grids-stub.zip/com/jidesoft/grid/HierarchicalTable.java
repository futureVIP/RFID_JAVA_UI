/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>HierarchicalTable</code> is a special <code>JTable</code> which can show any components inside the table in a hierarchical fashion. Each row can have a child component. Usually the child
 *  component is not visible. However if <code>expandRow()</code> is called on a row, the child component will be shown either under that row or replace that row. Since the child component itself could
 *  be another <code>HierarchicalTable</code> which can have child components, as a result, it forms a hierarchy. This is why we called it HierarchicalTable.
 *  <p/>
 *  In fact, in addition to show in as hierarchy, <code>HierarchicalTable</code> can also be used to display master-detail relation. When there are a lot of details of each row but can't be shown
 *  because of the column count limitation, child component can be used to display the details of each row.
 *  <p/>
 *  <code>HierarchicalTable</code> has one special column called expandable column. If a column is an expandable column, there will be an expand/collapse button on the left side of any cells in that
 *  column. Clicking on that button will expand/collapse. By default, the first column is the expandable column. Usually if you choose a column to be expandable column, the cells in that column should
 *  be read only. If you want to control when to expand/collapse all by yourself, you can call <code>setHierarchicalColumn(-1)</code>. You can then add mouse listener or key listener to expand or
 *  collapse.
 *  <p/>
 *  There is another attribute called <code>singleExpansion</code>. Typical when user expand a row, then expand another row, they want both rows to be expanded. However there are case user wants one
 *  row to be expanded at a time. <code>singleExpansion</code> can be used in this case. <code>singleExpansion</code> is true means only one row can expanded at a time. Default is false.
 *  <p/>
 *  We used the same +/- icons used in JTree so it will change based on different LookAndFeels. You can also define your own icons by calling {@link #setCategoryExpandedIcon(javax.swing.Icon)} and
 *  {@link #setCategoryCollapsedIcon(javax.swing.Icon)}.
 *  <p/>
 *  <code>HierarchicalTable</code> is a {@link SortableTable}, so you can sort the table even with some rows are expanded. If you don't want the sorting feature, simple call
 *  <code>setSortable(false)</code>.
 *  <p/>
 *  This class is part of HierarchicalTable component. If you used the beta version of HierarchicalTable component before, please note you need to change your code as the interface changed. The main
 *  reason for this change is to break the model from view. Please refer to {@link HierarchicalTableModel} for details.
 */
public class HierarchicalTable extends SortableTable implements HierarchicalTableSupport {
 {

	public static final String PROPERTY_SINGLE_EXPANSION = "singleExpansion";

	public static final String PROPERTY_MOUSE_ENABLED = "mouseEnabled";

	public static final String PROPERTY_HIERARCHICAL_COLUMN = "hierarchicalColumn";

	public static final String PROPERTY_SELECT_ROW_WHEN_TOGGLING = "selectRowWhenToggling";

	public static final String PROPERTY_DOUBLE_CLICK_ENABLED = "doubleClickEnabled";

	protected HierarchicalTableCellRenderer _hierarchicalTableCellRenderer;

	/**
	 *  Constructs a default <code>HierarchicalTable</code> that is initialized with a default data model, a default column model, and a default selection model.
	 *  <p/>
	 *  Since <code>HierarchicalTable</code> expects an instance of HierarchicalTableModel ex data model, this constructor creates nothing but a regular JTable if there is no subsequent call to
	 *  setModel() to pass in a <code>HierarchicalTableModel</code>.
	 */
	public HierarchicalTable() {
	}

	/**
	 *  Constructs a <code>HierarchicalTable</code> that is initialized with <code>dm</code> as the data model, a default column model, and a default selection model.
	 * 
	 *  @param dm the data model for the table. It should be an instance of <code>HierarchicalTableModel</code>.
	 */
	public HierarchicalTable(javax.swing.table.TableModel dm) {
	}

	/**
	 *  Constructs a <code>HierarchicalTable</code> that is initialized with <code>dm</code> as the data model, <code>cm</code> as the column model, and a default selection model.
	 * 
	 *  @param dm the data model for the table. It should be an instance of <code>HierarchicalTableModel</code>.
	 *  @param cm the column model for the table
	 */
	public HierarchicalTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	/**
	 *  Constructs a <code>JTable</code> that is initialized with <code>dm</code> as the data model, <code>cm</code> as the column model, and <code>sm</code> as the selection model. If any of the
	 *  parameters are <code>null</code> this method will initialize the table with the corresponding default model. The <code>autoCreateColumnsFromModel</code> flag is set to false if <code>cm</code>
	 *  is non-null, otherwise it is set to true and the column model is populated with suitable <code>TableColumns</code> for the columns in <code>dm</code>.
	 * 
	 *  @param dm the data model for the table. It should be an instance of <code>HierarchicalTableModel</code>.
	 *  @param cm the column model for the table
	 *  @param sm the row selection model for the table
	 */
	public HierarchicalTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	/**
	 *  Constructs a <code>JTable</code> with <code>numRows</code> and <code>numColumns</code> of empty cells using <code>DefaultTableModel</code>.  The columns will have names of the form "A", "B",
	 *  "C", etc.
	 *  <p/>
	 *  Since <code>HierarchicalTable</code> expects an instance of HierarchicalTableModel ex data model, this constructor creates nothing but a regular JTable if there is no subsequent call to
	 *  setModel() to pass in a <code>HierarchicalTableModel</code>.
	 * 
	 *  @param numRows    the number of rows the table holds
	 *  @param numColumns the number of columns the table holds
	 *  @see javax.swing.table.DefaultTableModel
	 */
	public HierarchicalTable(int numRows, int numColumns) {
	}

	/**
	 *  Constructs a <code>JTable</code> to display the values in the <code>Vector</code> of <code>Vectors</code>, <code>rowData</code>, with column names, <code>columnNames</code>.  The
	 *  <code>Vectors</code> contained in <code>rowData</code> should contain the values for that row. In other words, the value of the cell at row 1, column 5 can be obtained with the following code:
	 *  <p/>
	 *  <pre>((Vector)rowData.elementAt(1)).elementAt(5);</pre>
	 *  <p/>
	 *  Since <code>HierarchicalTable</code> expects an instance of HierarchicalTableModel ex data model, this constructor creates nothing but a regular JTable if there is no subsequent call to
	 *  setModel() to pass in a <code>HierarchicalTableModel</code>.
	 * 
	 *  @param rowData     the data for the new table
	 *  @param columnNames names of each column
	 */
	public HierarchicalTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	/**
	 *  Constructs a <code>JTable</code> to display the values in the two dimensional array, <code>rowData</code>, with column names, <code>columnNames</code>. <code>rowData</code> is an array of rows,
	 *  so the value of the cell at row 1, column 5 can be obtained with the following code:
	 *  <p/>
	 *  <pre> rowData[1][5]; </pre>
	 *  <p/>
	 *  All rows must be of the same length as <code>columnNames</code>.
	 *  <p/>
	 *  Since <code>HierarchicalTable</code> expects an instance of HierarchicalTableModel ex data model, this constructor creates nothing but a regular JTable if there is no subsequent call to
	 *  setModel() to pass in a <code>HierarchicalTableModel</code>.
	 * 
	 *  @param rowData     the data for the new table
	 *  @param columnNames names of each column
	 */
	public HierarchicalTable(Object[][] rowData, Object[] columnNames) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns a string that specifies the name of the L&F class that renders this component.
	 * 
	 *  @return the string "BasicHiTableUI"
	 * 
	 *  @see JComponent#getUIClassID
	 *  @see UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  There are too many ways to control when to expand and when to collapse. By default, the expand/collapse button will do the job if expandable column is a valid column index. If the expandable
	 *  column is -1, double clicking on the column will expand/collapse the row. However you can always decide which way you want. You can either overwrite this method to implement another mouse event
	 *  based handler or simply overwrite with an empty method then implement your own way.
	 * 
	 *  @param e the mouse event
	 */
	protected void handleMouseEvent(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Return true if the row is expanded.
	 * 
	 *  @param actualRow the actual row index
	 *  @return true if the row is expanded
	 */
	public boolean isActualRowExpanded(int actualRow) {
	}

	/**
	 *  Return true if the row is expanded. The row is the visual row.
	 * 
	 *  @param row the row index
	 *  @return true if the row is expanded
	 */
	public boolean isExpanded(int row) {
	}

	/**
	 *  Return true if any row is expanded.
	 * 
	 *  @return true if any row is expanded
	 */
	public boolean isAnyExpanded() {
	}

	/**
	 *  Gets the expandable column view index. Different from {@link #getHierarchicalColumn()}  convert the index from model index to index. There is no setter for this method, you have to set it
	 *  through {@link #setHierarchicalColumn(int)}. If you never called setHierarchicalColumn, this method will always return 0 meaning the first visible column will be used to display the +/- icon.
	 * 
	 *  @return the expandable column view index.
	 */
	public int getHierarchicalColumnViewIndex() {
	}

	/**
	 *  Gets the hierarchical column. Hierarchical column is the column which has an expand/collapse button. Clicking on that button will show/hide the child component associated with that row.
	 * 
	 *  @return the hierarchical column.
	 */
	public int getHierarchicalColumn() {
	}

	/**
	 *  Sets the hierarchical column. Please note, this column index is the model column index. In the other word, when user rearranges the columns, the +/- icon will go with the column. If you prefer
	 *  the +/- icon remains on the same view column index, you can override {@link #getHierarchicalColumnViewIndex()} to return a view column index. For example, if you return 0, the +/- icon will
	 *  always be at the first column no matter how you rearrange the columns.
	 * 
	 *  @param hierarchicalColumn new hierarchical column. It should be a value between 0 and getColumnCount() - 1. Or -1 if you don't want to show any column to be hierarchical. Default value is 0.
	 */
	public void setHierarchicalColumn(int hierarchicalColumn) {
	}

	@java.lang.Override
	public javax.swing.table.TableCellRenderer getCellRenderer(int row, int column) {
	}

	/**
	 *  Expands the specified row if it's not expanded or collapse the row if it's expanded already.
	 * 
	 *  @param row the row index to be toggled.
	 */
	public void toggleRow(int row) {
	}

	/**
	 *  Expands the row if the row has child component. Please note each expanded child component is considered as a row if <code>isHierarchical()</code> in <code>HierarhicalTableModel</code> returns
	 *  true. So the value passed in as row parameter could be different from the row in <code>getChildComponent(int row)</code>.
	 * 
	 *  @param row the row index
	 */
	public void expandRow(int row) {
	}

	/**
	 *  Collapse the row.
	 * 
	 *  @param row the row index
	 */
	public void collapseRow(int row) {
	}

	/**
	 *  Refresh the row. If the row is expanded, refreshRow method will destroy current child component and recreate it. Since the expansion state doesn't change, there is no expand/collapse event
	 *  fired in this case.
	 * 
	 *  @param row the row index
	 */
	public void refreshRow(int row) {
	}

	/**
	 *  Collapse all rows.
	 */
	public void collapseAllRows() {
	}

	/**
	 *  Expands all rows as long as they are expandable.
	 */
	public void expandAllRows() {
	}

	@java.lang.Override
	public void doLayout() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize() {
	}

	/**
	 *  Gets the child component at the specified row index. If the row is not expanded, it will return null.
	 * 
	 *  @param row the row index.
	 *  @return the child component. Null if the specified row is not expanded.
	 */
	public java.awt.Component getChildComponentAt(int row) {
	}

	/**
	 *  Get the flag indicating if HierarchicalTable should paint the grids inside the MarginExpandablePanel to the color get from {@link #getMarginBackground()}.
	 *  <p/>
	 *  By default, the flag is false to keep the original behavior. However, if you set the margin background differently with the grid color, you may need set this flag to true.
	 * 
	 *  @return true if the margin grid should be painted the same color with margin background. Otherwise false.
	 * 
	 *  @see #getMarginBackground()
	 *  @see #getGridColor()
	 *  @see #getGridColor(int)
	 */
	public boolean isPaintMarginGridMarginBackground() {
	}

	/**
	 *  Set the flag indicating if HierarchicalTable should paint the grids inside the MarginExpandablePanel to the color get from {@link #getMarginBackground()}.
	 * 
	 *  @param paintMarginGridMarginBackground
	 *          the flag
	 *  @see #isPaintMarginGridMarginBackground()
	 */
	public void setPaintMarginGridMarginBackground(boolean paintMarginGridMarginBackground) {
	}

	/**
	 *  The action to take while child component is resized.
	 *  <p/>
	 *  By default, it will invoke doLayout(). However, if you have any concern about the performance, you could override
	 *  this method to invoke invalidate() only.
	 */
	protected void childComponentResized() {
	}

	/**
	 *  Checks if refreshRow() is called when row updated event is fired.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutoRefreshOnRowUpdate() {
	}

	/**
	 *  Sets the flag autoRefreshOnRowUpdate. If the flag is true, refreshRow method will be called when table model fireTableRowsUpdated. Otherwise, you will have to call refreshRow if the child
	 *  component of that row is changed. Default is true.
	 * 
	 *  @param autoRefreshOnRowUpdate true or false
	 */
	public void setAutoRefreshOnRowUpdate(boolean autoRefreshOnRowUpdate) {
	}

	/**
	 *  Returns true if only one row can be expanded at a time.
	 * 
	 *  @return true if only one row can be expanded at a time.
	 */
	public boolean isSingleExpansion() {
	}

	/**
	 *  Sets the singleExpansion attribute. If singleExpansion is true, only one row can be expanded at a time.
	 * 
	 *  @param singleExpansion true or false.
	 */
	public void setSingleExpansion(boolean singleExpansion) {
	}

	/**
	 *  Returns true if default mouse listener is installed to expand/collapse rows.
	 * 
	 *  @return true if only one row can be expanded at a time.
	 */
	public boolean isMouseEnabled() {
	}

	/**
	 *  Sets the mouseEnabled attribute. If mouseEnabled is true, mouse clicks on +/- button will expand or collapse the row if {@link #getHierarchicalColumnViewIndex()}  {@link
	 *  #getHierarchicalColumnViewIndex()} == -1, double clicking will expand/collapse the row. However if mouseEnabled is false, no mouse listener will be added. You need to add your own mouse
	 *  listener or some other ways to expand or collapse the row.
	 * 
	 *  @param mouseEnabled true or false
	 */
	public void setMouseEnabled(boolean mouseEnabled) {
	}

	/**
	 *  Gets the component factory that will create the child component of HierarchicalTable.
	 * 
	 *  @return the component factory.
	 */
	public HierarchicalTableComponentFactory getComponentFactory() {
	}

	/**
	 *  Sets the component factory that will create the child component of HierarchicalTable.
	 * 
	 *  @param factory the new component factory.
	 */
	public void setComponentFactory(HierarchicalTableComponentFactory factory) {
	}

	@java.lang.Override
	protected RowHeights createRowHeights() {
	}

	@java.lang.Override
	protected boolean isRowHeightChanged(int row, int newHeight) {
	}

	/**
	 *  As we overridden getRowModel(), {@link #getRowHeight(int)} will now return the row height considering the child component height. So this method will give you a way to get the actual row height
	 *  without the child component.
	 * 
	 *  @param row the row index
	 *  @return the actual row height without the child component.
	 */
	public int getActualRowHeight(int row) {
	}

	/**
	 *  Sets the actual row height without the child component.
	 * 
	 *  @param row       the row index.
	 *  @param rowHeight new actual row height.
	 */
	public void setActualRowHeight(int row, int rowHeight) {
	}

	@java.lang.Override
	protected void muteDefaultKeyStroke() {
	}

	@java.lang.Override
	protected javax.swing.Action createDelegateAction(javax.swing.Action action, javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Creates the mouse listener used to handle mouse click on +/- icon.
	 *  <p/>
	 *  Please override this method if you are NOT in JDK 1.6. Otherwise, please use {@link #createExpandMouseInputListener(javax.swing.event.MouseInputListener)} instead.
	 * 
	 *  @return a mouse listener.
	 * 
	 *  @see #createExpandMouseInputListener(javax.swing.event.MouseInputListener)
	 */
	protected javax.swing.event.MouseInputListener createExpandMouseListener() {
	}

	/**
	 *  Creates the mouse listener used to handle mouse click on +/- icon.
	 *  <p/>
	 *  Please override this method if you are in JDK 1.6. In other JDK releases, please use {@link #createExpandMouseListener()} instead.
	 * 
	 *  @param listener the MouseInputListener
	 *  @return a mouse listener.
	 * 
	 *  @see #createExpandMouseListener()
	 */
	protected javax.swing.event.MouseInputListener createExpandMouseInputListener(javax.swing.event.MouseInputListener listener) {
	}

	/**
	 *  Adds a listener for <code>TreeExpansion</code> events. We reused the listener and event class for JTree to avoid duplicate code. However since there is not TreeNode concept in HierarchicalTable
	 *  and there is one level deep, the TreePath object in the {@link TreeExpansionEvent} only has one element which is the row index.
	 * 
	 *  @param tel a TreeExpansionListener that will be notified when a tree node is expanded or collapsed (a "negative expansion")
	 */
	public void addTreeExpansionListener(javax.swing.event.TreeExpansionListener tel) {
	}

	/**
	 *  Removes a listener for <code>TreeExpansion</code> events.
	 * 
	 *  @param tel the <code>TreeExpansionListener</code> to remove
	 */
	public void removeTreeExpansionListener(javax.swing.event.TreeExpansionListener tel) {
	}

	/**
	 *  Returns an array of all the <code>TreeExpansionListener</code>s added to this JTree with addTreeExpansionListener().
	 * 
	 *  @return all of the <code>TreeExpansionListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @since 1.4
	 */
	public javax.swing.event.TreeExpansionListener[] getTreeExpansionListeners() {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was expanded
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTreeExpanded(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was collapsed
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTreeCollapsed(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Adds a listener for <code>TreeWillExpand</code> events.
	 * 
	 *  @param tel a <code>TreeWillExpandListener</code> that will be notified when a tree node will be expanded or collapsed (a "negative expansion")
	 */
	public void addTreeWillExpandListener(javax.swing.event.TreeWillExpandListener tel) {
	}

	/**
	 *  Removes a listener for <code>TreeWillExpand</code> events.
	 * 
	 *  @param tel the <code>TreeWillExpandListener</code> to remove
	 */
	public void removeTreeWillExpandListener(javax.swing.event.TreeWillExpandListener tel) {
	}

	/**
	 *  Returns an array of all the <code>TreeWillExpandListener</code>s added to this JTree with addTreeWillExpandListener().
	 * 
	 *  @return all of the <code>TreeWillExpandListener</code>s added or an empty array if no listeners have been added
	 */
	public javax.swing.event.TreeWillExpandListener[] getTreeWillExpandListeners() {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type.  The event instance is lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was expanded
	 *  @throws javax.swing.tree.ExpandVetoException
	 *           if the tree node is not allowed to be expanded
	 *  @see EventListenerList
	 */
	public void fireTreeWillExpand(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type.  The event instance is lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was expanded
	 *  @throws javax.swing.tree.ExpandVetoException
	 *           if the tree node is not allowed to be collapsed
	 *  @see EventListenerList
	 */
	public void fireTreeWillCollapse(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Overrides to make sure the editor is set the correct height when there is expanded row.
	 * 
	 *  @param row    the row to be edited
	 *  @param column the column to be edited
	 *  @param e      event to pass into <code>shouldSelectCell</code>; note that as of Java 2 platform v1.2, the call to <code>shouldSelectCell</code> is no longer made
	 *  @return false if for any reason the cell cannot be edited
	 */
	@java.lang.Override
	public boolean editCellAt(int row, int column, java.util.EventObject e) {
	}

	@java.lang.Override
	public java.awt.Rectangle getCellRect(int rowIndex, int columnIndex, boolean includeSpacing) {
	}

	@java.lang.Override
	public java.awt.Rectangle getEditorCellRect(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void changeSelection(int rowIndex, int columnIndex, boolean toggle, boolean extend) {
	}

	@java.lang.Override
	public boolean isVariousRowHeights() {
	}

	/**
	 *  Get the child component listener.
	 * 
	 *  @return the child component listener.
	 */
	protected java.awt.event.ComponentListener getChildComponentResizeListener() {
	}

	/**
	 *  Gets the horizontal leg y position. It is also the +/- icon y center position. By default, it will use half the size of cellHeight. You can override this method to return another value in case
	 *  your cell is not center aligned vertically.
	 * 
	 *  @param cellHeight the new cell height
	 *  @return the horizontal leg y position.
	 */
	public int getHorizontalLegPosition(int cellHeight) {
	}

	/**
	 *  Gets the value of selectRowWhenToggling property. If true, the row will be selected when when a row is expanded or collapsed. If false, the old selection will be kept when a row is expanded or
	 *  collapsed.
	 * 
	 *  @return true or false.
	 */
	public boolean isSelectRowWhenToggling() {
	}

	/**
	 *  Sets the selectRowWhenToggling flag.
	 * 
	 *  @param selectRowWhenToggling true or false. If true, the row will be selected when when a row is expanded or collapsed. If false, the old selection will be kept when a row is expanded or
	 *                               collapsed.
	 */
	public void setSelectRowWhenToggling(boolean selectRowWhenToggling) {
	}

	/**
	 *  A boolean flag to determine if the rect should always be calculated when painting the grid line and cells. If false, it will calculate the rect for the first column once and then add the column
	 *  width to determine the next column cell rect. It returns false in JideTable but subclass can return true (such as in TreeTable and HierarchicalTable case).
	 * 
	 *  @return true by default. Since we will calculate the rect differently for the cell that has expand/collapse icon, we will have to calculate the rect size for each cell.
	 */
	@java.lang.Override
	public boolean alwaysCalculateCellRect() {
	}

	/**
	 *  Checks if the double click is enabled. If it is enabled, double clicking anywhere on the row (except the +/- icon area) will expand/collapse the row. If the cells are editable, it is recommend
	 *  you set it to false. Otherwise it will conflict with cell editing. Default is true.
	 * 
	 *  @return true if double click on the row is enabled.
	 */
	public boolean isDoubleClickEnabled() {
	}

	/**
	 *  Enables double click on the row to expand/collapse the row. Property change event on {@link #PROPERTY_DOUBLE_CLICK_ENABLED} be fired when value changes.
	 * 
	 *  @param doubleClickEnabled true to enable double click to expand/collapse a row
	 */
	public void setDoubleClickEnabled(boolean doubleClickEnabled) {
	}

	protected class ExpandMouseListener {


		protected HierarchicalTable.ExpandMouseListener() {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}
	}

	protected class DelegateExpandMouseInputListener {


		public HierarchicalTable.DelegateExpandMouseInputListener(javax.swing.event.MouseInputListener listener) {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseMoved(java.awt.event.MouseEvent e) {
		}
	}

	protected static class HierarchicalTableAction {


		public HierarchicalTable.HierarchicalTableAction(javax.swing.Action action, javax.swing.KeyStroke keyStroke) {
		}

		@java.lang.Override
		public void actionPerformed(java.awt.event.ActionEvent e) {
		}
	}
}
