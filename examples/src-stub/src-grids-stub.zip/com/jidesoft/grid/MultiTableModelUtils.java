/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <tt>MultiTableModelUtils</tt> contains methods useful for MultiTableModel.
 */
public class MultiTableModelUtils {

	public MultiTableModelUtils() {
	}

	/**
	 *  Removes extra columns from table.
	 * 
	 *  @param table      The table which has a MultiTableModel as its model. If the model is not an instance of
	 *                    MultiTableModel, this method will do nothing.
	 *  @param columnType which column type to keep. If {@link MultiTableModel#getColumnType(int)} returns a value
	 *                    different from the specified column type in parameter, the column will be removed.
	 *  @param tableIndex which table index to keep If {@link MultiTableModel#getTableIndex(int)}} returns a value
	 *                    different from the specified table index in parameter, the column will be removed.
	 */
	public static void removeExtraColumns(javax.swing.JTable table, int columnType, int tableIndex) {
	}

	/**
	 *  Removes extra columns from table.
	 * 
	 *  @param table                 The table which has a MultiTableModel as its model. If the model is not an instance
	 *                               of MultiTableModel, this method will do nothing.
	 *  @param columnType            which column type to keep. If {@link MultiTableModel#getColumnType(int)} returns a
	 *                               value different from the specified column type in parameter, the column will be
	 *                               removed.
	 *  @param tableIndex            which table index to keep If {@link MultiTableModel#getTableIndex(int)}} returns a
	 *                               value different from the specified table index in parameter, the column will be
	 *                               removed.
	 *  @param newlyAddedColumnIndex the newly added column index.
	 */
	public static void removeExtraColumns(javax.swing.JTable table, int columnType, int tableIndex, int newlyAddedColumnIndex) {
	}

	/**
	 *  Adds/removes columns from each table to match the getColumnType in the MultiTableModel.
	 * 
	 *  @param tables     The sub-tables which have the same MultiTableModel as their table model. If the model is not an
	 *                    instance of MultiTableModel, this method will do nothing.
	 *  @param tableIndex which table index to keep If {@link MultiTableModel#getTableIndex(int)}} returns a value
	 *                    different from the specified table index in parameter, the column will be removed.
	 *  @return true if the table is refreshed correctly. Otherwise false.
	 */
	public static boolean refreshColumns(javax.swing.JTable[] tables, int tableIndex) {
	}

	public static boolean containsColumn(javax.swing.table.TableColumnModel model, String columnName) {
	}

	/**
	 *  Gets the column count that matches with the specified columnType and tableIndex.
	 * 
	 *  @param model      the table model. It should be an instance of MultiTableModel.
	 *  @param columnType the column type as defined MultiTableModel.
	 *  @param tableIndex the table index.
	 *  @return the column count.
	 */
	public static int getColumnCount(javax.swing.table.TableModel model, int columnType, int tableIndex) {
	}
}
