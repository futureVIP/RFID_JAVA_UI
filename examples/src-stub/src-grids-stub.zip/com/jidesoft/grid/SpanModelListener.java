/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


public interface SpanModelListener extends java.util.EventListener {
 {

	/**
	 *  This fine grain notification tells listeners the exact range of cells, rows, or columns that changed.
	 * 
	 *  @param e the SpanModelEvent
	 */
	public void spanChanged(SpanModelEvent e);
}
