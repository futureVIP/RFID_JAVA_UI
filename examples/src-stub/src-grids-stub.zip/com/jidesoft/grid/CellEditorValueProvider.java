/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  @deprecated replaced by {@link com.jidesoft.grid.ListComboBoxCellEditor} or {@link com.jidesoft.grid.CheckBoxListComboBoxCellEditor}
 *              which know how to use userObject of ConverterContext to configure the possible values dynamically.
 */
@java.lang.Deprecated
public interface CellEditorValueProvider {

	public Object[] getPossibleValues(int rowIndex, int columnIndex);

	public ObjectConverter getConverter(int rowIndex, int columnIndex);
}
