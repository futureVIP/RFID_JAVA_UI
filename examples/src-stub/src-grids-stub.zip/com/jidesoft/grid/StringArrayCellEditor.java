/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A String array cell editor.
 */
public class StringArrayCellEditor extends AbstractComboBoxCellEditor {

	/**
	 *  Creates a StringArrayCellEditor.
	 */
	public StringArrayCellEditor() {
	}

	/**
	 *  Creates StringArrayComboBox used by this cell editor.
	 * 
	 *  @return a StringArrayComboBox.
	 */
	@java.lang.Override
	public com.jidesoft.combobox.AbstractComboBox createAbstractComboBox() {
	}

	/**
	 *  Creates StringArrayComboBox used by this cell editor.
	 * 
	 *  @return a StringArrayComboBox.
	 */
	protected com.jidesoft.combobox.StringArrayComboBox createStringArrayComboBox() {
	}
}
