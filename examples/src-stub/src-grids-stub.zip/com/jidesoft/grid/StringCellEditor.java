/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  CellEditor for String.
 */
public class StringCellEditor extends TextFieldCellEditor {

	public StringCellEditor() {
	}
}
