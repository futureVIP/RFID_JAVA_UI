/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a table model to change the orientation of the table. With this model's help, you could transpose the original table
 *  model's row to column while the column to be row.
 *  <p/>
 *  To have the functionality, please simply wrap your original table model with this class. You could then invoke {@link #setTransposed(boolean)}
 *  to change the orientation as you wish. If {@link #isTransposed()} returns false, it should behaves exactly the same as if
 *  there is only the original table model in the place.
 *  <p/>
 *  After transposed, the default column name would be the first column values in the original table model. The default column
 *  class would be Object.class. You could either override {@link #getDefaultTransposedColumnClass(int)} or invoke {@link #setTransposedColumnClasses(Class[])}
 *  to change the column classes.
 */
public class TransposeTableModel extends javax.swing.table.AbstractTableModel implements ContextSensitiveTableModel, StyleModel, SpanModel, NavigableModel, MultiTableModel, CategorizedTableModel, ColumnIdentifierTableModel, ColumnWidthTableModel, EditableColumnTableModel, GroupableTableModel, HierarchicalTableModel, RowModel, TableModelWrapper {
 {

	public TransposeTableModel(javax.swing.table.TableModel model) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public int getRowCount() {
	}

	@java.lang.Override
	public int getColumnCount() {
	}

	protected String getDefaultTransposedColumnIdentifier(int columnIndex) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected Class getDefaultTransposedColumnClass(int columnIndex) {
	}

	@java.lang.Override
	public String getColumnName(int columnIndex) {
	}

	@java.lang.Override
	public Class getColumnClass(int columnIndex) {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public boolean isCellSpanOn() {
	}

	@java.lang.Override
	public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public boolean isCellStyleOn() {
	}

	@java.lang.Override
	public GrouperContext getGrouperContext(int columnIndex) {
	}

	@java.lang.Override
	public boolean isCategoryRow(int rowIndex) {
	}

	@java.lang.Override
	public Row getRowAt(int rowIndex) {
	}

	@java.lang.Override
	public int getRowIndex(Row row) {
	}

	@java.lang.Override
	public boolean isNavigableAt(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public boolean isNavigationOn() {
	}

	@java.lang.Override
	public int getMinimumWidth(int column) {
	}

	@java.lang.Override
	public int getPreferredWidth(int column) {
	}

	@java.lang.Override
	public int getMaximumWidth(int column) {
	}

	@java.lang.Override
	public boolean isColumnHeaderEditable(int columnIndex) {
	}

	@java.lang.Override
	public javax.swing.table.TableCellEditor getColumnHeaderCellEditor(int columnIndex) {
	}

	@java.lang.Override
	public Object getColumnIdentifier(int columnIndex) {
	}

	@java.lang.Override
	public int getColumnType(int columnIndex) {
	}

	@java.lang.Override
	public int getTableIndex(int columnIndex) {
	}

	@java.lang.Override
	public boolean hasChild(int row) {
	}

	@java.lang.Override
	public boolean isHierarchical(int row) {
	}

	@java.lang.Override
	public Object getChildValueAt(int row) {
	}

	@java.lang.Override
	public boolean isExpandable(int row) {
	}

	@java.lang.Override
	public javax.swing.table.TableModel getActualModel() {
	}

	/**
	 *  Get the flag indicating if the table model is transposed.
	 * 
	 *  @see #setTransposed(boolean)
	 *  @return true if the table model is turned. Otherwise false.
	 */
	public boolean isTransposed() {
	}

	/**
	 *  Set the flag indicating if the table model is transposed.
	 *  <p/>
	 *  By default, this flag is false to keep the same behavior with the original table model.
	 * 
	 *  @param transposed the flag
	 */
	public void setTransposed(boolean transposed) {
	}

	/**
	 *  Get the column classes to be displayed after transposed.
	 * 
	 *  @see #setTransposedColumnClasses(Class[])
	 *  @return the column classes after transposed.
	 */
	public Class[] getTransposedColumnClasses() {
	}

	/**
	 *  Set the column classes to be displayed after transposed.
	 *  <p/>
	 *  If this is not configured, {@link #getDefaultTransposedColumnClass(int)} will be invoked to feed the column classes on transposed.
	 * 
	 *  @param transposedColumnClasses the column classes array
	 */
	public void setTransposedColumnClasses(Class[] transposedColumnClasses) {
	}

	/**
	 *  Get the first column name after transposed.
	 * 
	 *  @see #setTransposedColumnName(String)
	 *  @return the column name
	 */
	public String getTransposedColumnName() {
	}

	/**
	 *  Set the first column name after transposed.
	 *  <p/>
	 *  By default, it's null. Then we will display an empty string for the column.
	 * 
	 *  @param transposedColumnName the column name
	 */
	public void setTransposedColumnName(String transposedColumnName) {
	}
}
