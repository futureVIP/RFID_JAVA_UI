/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  TableCellRenderer which can accept ConverterContext. All TableCellRenderers we built extends this class.
 */
public class VerticalContextSensitiveCellRenderer extends VerticalTableCellRenderer implements EditorContextSupport, javax.swing.SwingConstants {
 {

	public static EditorContext CONTEXT;

	/**
	 *  An empty <code>Border</code>. This field might not be used. To change the <code>Border</code> used by this
	 *  renderer override the <code>getTableCellRendererComponent</code> method and set the border of the returned
	 *  component directly.
	 */
	protected static javax.swing.border.Border noFocusBorder;

	protected static final javax.swing.border.Border SAFE_NO_FOCUS_BORDER;

	/**
	 *  Creates a context sensitive cell renderer.
	 */
	public VerticalContextSensitiveCellRenderer() {
	}

	/**
	 *  Creates a context sensitive cell renderer for a specified type.
	 * 
	 *  @param clazz type
	 */
	public VerticalContextSensitiveCellRenderer(Class clazz) {
	}

	/**
	 *  Creates a context sensitive cell renderer using the converter context.
	 * 
	 *  @param context converter context
	 */
	public VerticalContextSensitiveCellRenderer(ConverterContext context) {
	}

	/**
	 *  Creates a context sensitive cell renderer using specified type and the converter context.
	 * 
	 *  @param clazz   type
	 *  @param context converter context
	 */
	public VerticalContextSensitiveCellRenderer(Class clazz, ConverterContext context) {
	}

	public Class getType() {
	}

	public void setType(Class clazz) {
	}

	@java.lang.Override
	protected void setValue(Object value) {
	}

	/**
	 *  Sets the converter context.
	 * 
	 *  @param context converter context
	 */
	public void setConverterContext(ConverterContext context) {
	}

	/**
	 *  Gets the converter context.
	 * 
	 *  @return converter context
	 */
	public ConverterContext getConverterContext() {
	}

	/**
	 *  Gets the editor context.
	 * 
	 *  @return editor context
	 */
	public EditorContext getEditorContext() {
	}

	/**
	 *  Sets the editor context.
	 * 
	 *  @param context editor context
	 */
	public void setEditorContext(EditorContext context) {
	}

	public static javax.swing.border.Border getNoFocusBorder() {
	}

	public static void installColorFontAndBorder(javax.swing.JTable table, java.awt.Component component, boolean isSelected, boolean hasFocus, int row, int column) {
	}
}
