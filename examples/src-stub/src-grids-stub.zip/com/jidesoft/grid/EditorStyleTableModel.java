/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This is a table model to define the editor style. It will only take effect if <code>TableModel#isCellEditable(int, int)</code>
 *  returns true and your table is an instance of ContextSensitiveTable.
 *  <p/>
 *  If you have defined your own cell editor, you need check if your cell editor implemented {@link com.jidesoft.grid.EditorStyleSupport}
 *  already to make sure the settings would take effect.
 */
public interface EditorStyleTableModel {

	/**
	 *  In this case, JIDE will not touch the existing setting of the cell editor and just use the editor default settings.
	 */
	public static final int EDITOR_STYLE_NORMAL = 0;

	/**
	 *  For combo box/spinner/slider based cell editors, the text field is not editable however the customer could select
	 *  from the popup to change the value of the cell.
	 */
	public static final int EDITOR_STYLE_SELECT_ONLY = 1;

	/**
	 *  Although the cell is editable defined in <code>TableModel#isCellEditable(int, int)</code>, the cell is read only.
	 *  However, the customer would be able to select the content inside the cell and copy it out.
	 */
	public static final int EDITOR_STYLE_READ_ONLY = 2;

	/**
	 *  Force the cell editor to be editable.
	 */
	public static final int EDITOR_STYLE_EDITABLE = 3;

	/**
	 *  Gets editor style at the cell.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return the editor style.
	 */
	public int getEditorStyleAt(int rowIndex, int columnIndex);
}
