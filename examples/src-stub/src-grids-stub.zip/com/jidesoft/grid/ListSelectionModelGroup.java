/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  This class is used to create a multiple-exclusion scope for a set of ListSelectionModel so that one
 *  ListSelectionModel can have selected index at a time.
 */
public class ListSelectionModelGroup extends <any> implements java.io.Serializable {
 {

	/**
	 *  Creates a new <code>ListSelectionModelGroup</code>.
	 */
	public ListSelectionModelGroup() {
	}

	@java.lang.Override
	protected javax.swing.event.ListSelectionListener createSelectionListener() {
	}

	@java.lang.Override
	protected void addSelectionListener(javax.swing.ListSelectionModel model, javax.swing.event.ListSelectionListener listener) {
	}

	@java.lang.Override
	protected void removeSelectionListener(javax.swing.ListSelectionModel model, javax.swing.event.ListSelectionListener listener) {
	}

	/**
	 *  Returns all the ListSelectionModel that are participating in this group.
	 * 
	 *  @return an array of all ListSelectionModels
	 */
	public javax.swing.ListSelectionModel[] getListModels() {
	}
}
