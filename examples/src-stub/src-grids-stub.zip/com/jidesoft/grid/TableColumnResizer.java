/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Allows table columns to be resized not only on table header but also on any places along the vertical grid line. To
 *  use it, you simply call
 *  <code><pre>
 *  new TableColumnResizer(table);
 *  </pre></code>
 *  If you use any of the tables provided by JIDE Grids, you can simply call {@link
 *  JideTable#setColumnResizable(boolean)} to make columns resizable.
 * 
 *  @author Santhosh Kumar T
 *  @author JIDE Software, Inc.
 */
public class TableColumnResizer extends TableResizer {

	public static java.awt.Cursor _resizeCursor;

	public static final int OFFSET = 3;

	public TableColumnResizer(javax.swing.JTable table) {
	}

	@java.lang.Override
	public javax.swing.event.MouseInputListener createMouseInputListener() {
	}

	public boolean isResizing() {
	}
}
