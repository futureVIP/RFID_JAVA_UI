/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  MultipleEnumCellEditor is a cell editor based on CheckBoxListComboBoxCellEditor using MultipleEnumConverter.
 */
public class MultipleEnumCellEditor extends CheckBoxListComboBoxCellEditor {

	public MultipleEnumCellEditor() {
	}

	public MultipleEnumCellEditor(MultipleEnumConverter enumConverter) {
	}

	public MultipleEnumConverter getEnumConverter() {
	}

	public void setEnumConverter(MultipleEnumConverter multiEnumConverter) {
	}

	public EditorContext getContext() {
	}

	@java.lang.Override
	public void setCellEditorValue(Object object) {
	}

	@java.lang.Override
	public Object getCellEditorValue() {
	}
}
