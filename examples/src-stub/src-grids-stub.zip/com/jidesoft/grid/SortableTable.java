/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>SortableTable</code> is a table which uses <code>SortableTableModel</code> so that multiple columns can be
 *  sorted. If user presses mouse key on the table column header, the corresponding table column will be sorted. The
 *  first click will sort ascendingly, the second click to sort descendingly, and the third click to reset back to
 *  unsorted mode.
 *  <p/>
 *  Difference from other implementation of SortableTable, it can do multiple column sorting. Just press CTRL key (or
 *  Command key on Mac OS X) and hold, click several column headers will sort by all of them. The column header will show
 *  a small number to indicate which one is first sort-by column, second sort-by column etc.
 *  <p/>
 *  <code>SortableTable</code> can accept any table model as input. However it doesn't change anything in the table model
 *  whens sorting. A new instance of SortableTableModel is created when setModel is called to wrap around the actual
 *  table model.
 *  <pre><code>
 *  new SortableTableModel(model)
 *  </code></pre>
 *  If you call sortableTableModel.getModel(), this SortableTableModel instance will be returned if the table is
 *  sortable. If you want to get the actual table model you created, call ((TableModelWrapper)
 *  getModel()).getActualModel(). If you use several levels of TableModelWrappers, you may want to use {@link
 *  TableModelWrapperUtils#getActualTableModel(javax.swing.table.TableModel,Class)} to find the inner most table model.
 *  <p/>
 *  Since SortableTableModel wraps the actual table model, whenever you want to change the data that is displayed, you
 *  should always go to the actual table model and change it. Please make sure you fire the right table model event so
 *  that the SortableTableModel is aware of any change and handles it correctly. This is especially important if you are
 *  not using DefaultTableModel but using AbstractTableModel or TableModel interface directly, where you are responsible
 *  in firing the table model events.
 *  <p/>
 *  Please note, SortableTable and all other JIDE tables that extend {@link ContextSensitiveTable} uses a JComboBox for
 *  boolean data type, which is different from JTable which uses JCheckBox. This can be solved by returning an
 *  EditorContext in ContextSensitiveTableModel. Please refer to the javadoc of {@link BooleanCheckBoxCellRenderer} for
 *  more information.
 */
public class SortableTable extends CategorizedTable implements SortListener {
 {

	/**
	 *  Property name for SORTABLE.
	 */
	public static final String SORTABLE_PROPERTY = "sortable";

	/**
	 *  Property name for showSortOrderNumber.
	 */
	public static final String PROPERTY_SHOW_SORT_ORDER_NUMBER = "showSortOrderNumber";

	/**
	 *  Property name for MULTICOLUMN_SORTABLE.
	 */
	public static final String MULTICOLUMN_SORTABLE_PROPERTY = "multicolumn_sortable";

	/**
	 *  Create a SortableTable which is not sortable. If you want to make it sortable, call setSortable(true).
	 */
	public SortableTable() {
	}

	/**
	 *  Create a SortableTable. You can pass in any table model. If it is not an instance of SortableTableModel, we will
	 *  create a SortableTableModel and wrap around it. If it is an instance of SortTableModel, it will be used
	 *  directly.
	 * 
	 *  @param model any table model.
	 */
	public SortableTable(javax.swing.table.TableModel model) {
	}

	public SortableTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public SortableTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	public SortableTable(int numRows, int numColumns) {
	}

	public SortableTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public SortableTable(Object[][] rowData, Object[] columnNames) {
	}

	protected SortableTableHeaderMouseListener createSortableTableHeaderMouseListener() {
	}

	/**
	 *  Does this table allow sort by multiple columns.
	 * 
	 *  @return true if this table allows sort by multiple columns
	 */
	public boolean isMultiColumnSortable() {
	}

	/**
	 *  Set the value if this table allows sort by multiple columns. Please note, we simply call {@link
	 *  SortableTableModel#setMultiColumnSortable(boolean)} in this case. So if you change the model, you need to call it
	 *  again to set the value.
	 * 
	 *  @param multiColumnSortable pass in true if this you want this table allows sort by multiple columns
	 */
	public void setMultiColumnSortable(boolean multiColumnSortable) {
	}

	/**
	 *  Checks if the table is sortable.
	 * 
	 *  @return true if the table is sortable.
	 */
	public boolean isSortable() {
	}

	/**
	 *  Sets if the table is sortable. This method will reset table model. If sortable is true, it will set current table
	 *  to SortableTableMode. If false, it will use actual table model which is usually not a SortableTableModel.
	 * 
	 *  @param sortable true or false.
	 */
	public void setSortable(boolean sortable) {
	}

	/**
	 *  Checks if the table is showing sort order number. If this flag is false, the sort number will only be displayed
	 *  when there are multiple columns are sorted. If there is only one column that is sorted, there will be no sort
	 *  number.
	 * 
	 *  @return true if the table is sortable.
	 */
	public boolean isShowSortOrderNumber() {
	}

	/**
	 *  Sets if the table shows the sort number in table header when there is only column is sorted.
	 * 
	 *  @param showSortOrderNumber true or false
	 */
	public void setShowSortOrderNumber(boolean showSortOrderNumber) {
	}

	/**
	 *  Creates a <code>SortableTableModel</code> that wraps around the actual model. Subclass can override it to create
	 *  your own <code>SortabletTableModel</code>. For example TreeTable overrides it to create a
	 *  <code>SortableTreeTableModel</code> for <code>TreeTableModel</code>.
	 * 
	 *  @param model the actual table model.
	 *  @return a SortableTableModel.
	 */
	protected ISortableTableModel createSortableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Listens to sortChanging event.
	 * 
	 *  @param event the sort event
	 */
	public void sortChanging(SortEvent event) {
	}

	/**
	 *  Listens to sortChanged event so that we can repaint the table header in case sort arrow changed. By default, we
	 *  will keep the selection after sorting changed. You can turn it off by setting {@link
	 *  #setPreserveSelectionsAfterSorting(boolean)} to false. Also by default, we will not scroll the selection visible
	 *  because it will cause flickering when the table data is updated too rapidly. However you can override this method
	 *  and call TableUtils.ensureRowSelectionVisible(this) to enable auto-scrolling. If user clicks on the table header
	 *  to sort the column, we will ensureRowSelectionVisible in the mouse listener so selection will be scrolled
	 *  visible.
	 * 
	 *  @param event the sort event
	 */
	public void sortChanged(SortEvent event) {
	}

	@java.lang.Override
	public void setModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Sort column specified by columnName.
	 * 
	 *  @param columnName name of column to be sorted.
	 */
	public void sortColumn(String columnName) {
	}

	/**
	 *  Sort column specified by columnName.
	 * 
	 *  @param columnName name of column to be sorted.
	 *  @param reset      whether reset the sort order of all other columns.
	 */
	public void sortColumn(String columnName, boolean reset) {
	}

	/**
	 *  Sort column specified by columnName.
	 * 
	 *  @param columnName name of column to be sorted.
	 *  @param reset      whether reset the sort order of all other columns.
	 *  @param ascending  whether the sort order is ascending or descending.
	 */
	public void sortColumn(String columnName, boolean reset, boolean ascending) {
	}

	/**
	 *  Unsorts any sorting columns.
	 */
	public void unsort() {
	}

	/**
	 *  Sort column specified by columnIndex.
	 * 
	 *  @param columnIndex index of column to be sorted.
	 */
	public void sortColumn(int columnIndex) {
	}

	/**
	 *  Sort column specified by columnIndex.
	 * 
	 *  @param columnIndex index of column to be sorted.
	 *  @param reset       whether reset the sort order of all other columns.
	 */
	public void sortColumn(int columnIndex, boolean reset) {
	}

	/**
	 *  Sort column specified by columnIndex.
	 * 
	 *  @param columnIndex index of column to be sorted.
	 *  @param reset       whether reset the sort order of all other columns.
	 *  @param ascending   whether the sort order is ascending or descending.
	 */
	public void sortColumn(int columnIndex, boolean reset, boolean ascending) {
	}

	/**
	 *  Gets the actual row.
	 *  <p/>
	 *  Please note, this method will only return the row index on the immediate table model that the SortableTableModel
	 *  wraps. If you need the actual row index at the inner most table model in case you have several levels of wrapped
	 *  table models, please use {@link TableModelWrapperUtils#getActualRowAt(javax.swing.table.TableModel,int,Class)} or
	 *  {@link TableModelWrapperUtils#getActualRowAt(javax.swing.table.TableModel,int)} method.
	 * 
	 *  @param row the row on the UI.
	 *  @return the actual row in the actual model. It will throw IllegalArgumentException if the row is out of range.
	 */
	public int getActualRowAt(int row) {
	}

	/**
	 *  Gets the row number after sorting.
	 *  <p/>
	 *  Please note, this method will treat the row index as it is on the immediate table model that the
	 *  SortableTableModel wraps. If the actual row index is on the inner most table model in case you have several
	 *  levels of wrapped table models, please use {@link TableModelWrapperUtils#getRowAt(javax.swing.table.TableModel,int)}
	 *  method.
	 * 
	 *  @param actualRow the actual row in actual model.
	 *  @return the row on UI. -1 if cannot find the row.
	 */
	public int getSortedRowAt(int actualRow) {
	}

	/**
	 *  Gets any table model which is sortable table model.
	 * 
	 *  @return sortable table model
	 */
	protected ISortableTableModel getSortableTableModel() {
	}

	/**
	 *  Checks if the optimized flag is true.
	 * 
	 *  @return the optimized flag.
	 */
	public boolean isOptimized() {
	}

	/**
	 *  If optimized flag is true and the table is already sorted, SortableTableModel will do incremental sorting when
	 *  data changes. If the flag is false, SortableTableModel will sort completely again when data changed. If your
	 *  table model does a lot of small updates - such as a cell update, a row update, a row insertion/deletion, you
	 *  should set this flag to true. On the other hand, if your table always does big updates such as
	 *  adding/deleting/updating many rows and just fire one fire one event after that, it will be better if you set the
	 *  flag to false. You can change this flag on fly. So if you know you will do a big update, set it to false. After
	 *  the big data change is done, set it back to true. </p/> Default is false. It probably should be true by default
	 *  but we have to keep it this way for backward compatible reason as initially we don't have such a flag and the
	 *  behavior is acting like the flag is false.
	 * 
	 *  @param optimized true or false.
	 */
	public void setOptimized(boolean optimized) {
	}

	/**
	 *  Checks if the table is automatically resort when data changes.
	 * 
	 *  @return true if autoResort. Otherwise false.
	 */
	public boolean isAutoResort() {
	}

	/**
	 *  AutoResort is a feature that automatically resort the table when table value changes. This is the default
	 *  behavior and useful in most cases. However there are cases when the data changes frequently, resort will make it
	 *  very hard for user to read the value. So in these cases, you can set autoResort to false. Then you will need to
	 *  provide a button to call {@link #resort} to resort the table.
	 *  <p/>
	 *  Note: this flag is only used when optimized flag is true. If optimized is false, autoResort is always true.
	 * 
	 *  @param autoResort true or false.
	 */
	public void setAutoResort(boolean autoResort) {
	}

	/**
	 *  Resort the table. When autoResort is false, the table will be out of order after data changes. The method will
	 *  resort the table while keeping the sorting columns.
	 */
	public void resort() {
	}

	@java.lang.Override
	protected javax.swing.table.JTableHeader createDefaultTableHeader() {
	}

	/**
	 *  Gets the sort arrow color.
	 * 
	 *  @return the sort arrow color.
	 */
	public java.awt.Color getSortArrowForeground() {
	}

	/**
	 *  Sets the sort arrow color.
	 * 
	 *  @param sortArrowForeground the sort arrow color
	 */
	public void setSortArrowForeground(java.awt.Color sortArrowForeground) {
	}

	/**
	 *  Gets the sort order number foreground color.
	 * 
	 *  @return the sort order number foreground color.
	 */
	public java.awt.Color getSortOrderForeground() {
	}

	/**
	 *  Sets the sort order number foreground color.
	 * 
	 *  @param sortOrderForeground the text color of the sort order number
	 */
	public void setSortOrderForeground(java.awt.Color sortOrderForeground) {
	}

	/**
	 *  Checks if user sorting is enabled.
	 * 
	 *  @return true or false.
	 */
	public boolean isSortingEnabled() {
	}

	/**
	 *  Sets sorting enabled or disabled. If sorting is disabled, user cannot press table column header to sort it.
	 *  However you as developer can still call API to sort the tables. By default sorting is enabled.
	 * 
	 *  @param sortingEnabled true or false.
	 */
	public void setSortingEnabled(boolean sortingEnabled) {
	}

	/**
	 *  Checks if SortableTable will preserve the selections after sort order changes. If true, we will use saveSelection
	 *  and loadSelections methods in TableUtils to preserve the selections. If false, the selections will be gone after
	 *  sort. We give this option in case you have your own way to preserve the selections.
	 * 
	 *  @return true or false. Default is true.
	 * 
	 *  @deprecated this flag will not take effection, since we will preserve selection anyway after sorting right now.
	 */
	@java.lang.Deprecated
	public boolean isPreserveSelectionsAfterSorting() {
	}

	/**
	 *  Sets the flag of preserveSelectionsAfterSorting. If true, we will use saveSelection and loadSelections methods in
	 *  TableUtils to preserve the selections. If false, the selections will be gone after sorting. We give this option
	 *  in case you have your own way to preserve the selections.
	 * 
	 *  @param preserveSelectionsAfterSorting true or false.
	 *  @deprecated this flag will not take effection, since we will preserve selection anyway after sorting right now.
	 */
	@java.lang.Deprecated
	public void setPreserveSelectionsAfterSorting(boolean preserveSelectionsAfterSorting) {
	}

	/**
	 *  Create the sort arrow icon. Subclass can override it to create your own sort arrow. Although the name is
	 *  createSortIcon, you could cache the icon internally and don't create it every time when this method is called.
	 * 
	 *  @param ascending true or false. True is ascending.
	 *  @return the sort arrow icon.
	 */
	public javax.swing.Icon createSortIcon(boolean ascending) {
	}

	/**
	 *  Gets the flag indicating if JScrollPane should scroll to make the selected rows visible while clicking the table header to sort.
	 * 
	 *  @see #setEnsureSelectedRowVisibleOnTogglingSort(boolean)
	 *  @return true if should scroll on toggling sort. Otherwise false.
	 */
	public boolean isEnsureSelectedRowVisibleOnTogglingSort() {
	}

	/**
	 *  Sets the flag indicating if JScrollPane should scroll to make the selected rows visible while clicking the table header to sort.
	 *  <p/>
	 *  The default value is true to keep previous behavior.
	 * 
	 *  @param ensureSelectedRowVisibleOnTogglingSort the flag
	 */
	public void setEnsureSelectedRowVisibleOnTogglingSort(boolean ensureSelectedRowVisibleOnTogglingSort) {
	}
}
