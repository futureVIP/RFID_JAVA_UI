/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  AbstractJideCellEditor adds the validation support to AbstractCellEditor.
 */
public abstract class AbstractJideCellEditor extends javax.swing.AbstractCellEditor implements JideCellEditor {
 {

	/**
	 *  An integer specifying the number of clicks needed to start editing. Even if
	 *  <code>clickCountToStart</code> is defined as zero, it will not initiate until a click
	 *  occurs.
	 */
	protected int _clickCountToStart;

	public AbstractJideCellEditor() {
	}

	@java.lang.Override
	public boolean isCellEditable(java.util.EventObject anEvent) {
	}

	/**
	 *  Specifies the number of clicks needed to start editing.
	 * 
	 *  @param count an int specifying the number of clicks needed to start editing
	 * 
	 *  @see #getClickCountToStart
	 */
	public void setClickCountToStart(int count) {
	}

	/**
	 *  Returns the number of clicks needed to start editing.
	 * 
	 *  @return the number of clicks needed to start editing
	 */
	public int getClickCountToStart() {
	}

	/**
	 *  Adds a <code>Validator</code> to the listener list.
	 * 
	 *  @param l the new listener to be added
	 */
	public void addValidationListener(Validator l) {
	}

	/**
	 *  Removes a <code>Validator</code> from the listener list.
	 * 
	 *  @param l the listener to be removed
	 */
	public void removeValidationListener(Validator l) {
	}

	/**
	 *  Returns an array of all the <code>Validator</code>s added to this AbstractCellEditor with
	 *  addValidationListener().
	 * 
	 *  @return all of the <code>Validator</code>s added or an empty array if no listeners have been
	 *          added
	 * 
	 *  @since 1.4
	 */
	public Validator[] getValidationListeners() {
	}

	/**
	 *  Returns the state after validation.
	 * 
	 *  @param oldValue the old value
	 *  @param newValue the new value
	 * 
	 *  @return ValidateState. If it's null, it means validation passed. Only when the validation
	 *          fails, it returns ValidationState.
	 */
	public ValidationResult validate(Object oldValue, Object newValue) {
	}

	/**
	 *  Gets the default validation error behavior. The valid values are {@link
	 *  ValidationResult#FAIL_BEHAVIOR_PERSIST}, {@link ValidationResult#FAIL_BEHAVIOR_RESET}, and
	 *  {@link ValidationResult#FAIL_BEHAVIOR_REVERT}. For example, in DateCellEditor, this is used
	 *  when the date entered by user is out of the range of valid dates as defined in DateModel.
	 * 
	 *  @return the default validation error behavior.
	 */
	public int getDefaultErrorBehavior() {
	}

	/**
	 *  Sets the default validation error behavior. The valid values are {@link
	 *  ValidationResult#FAIL_BEHAVIOR_PERSIST}, {@link ValidationResult#FAIL_BEHAVIOR_RESET}, and
	 *  {@link ValidationResult#FAIL_BEHAVIOR_REVERT}. For example, in DateCellEditor, this is used
	 *  when the date entered by user is out of the range of valid dates as defined in DateModel. By
	 *  default, the valid is ValidationResult.ERROR_BEHAVIOR_REVERT.
	 * 
	 *  @param defaultErrorBehavior the default error behavior.
	 */
	public void setDefaultErrorBehavior(int defaultErrorBehavior) {
	}

	/**
	 *  Checks if the cell editor will stop editing when value is changed. Default is true.
	 * 
	 *  @return true if the cell editor will stop editing. Otherwise false.
	 */
	public boolean isAutoStopCellEditing() {
	}

	/**
	 *  Sets the flag if the cell editor will stop editing when value is changed.
	 * 
	 *  @param autoStopCellEditing true or false.
	 */
	public void setAutoStopCellEditing(boolean autoStopCellEditing) {
	}

	/**
	 *  Checks if the ENTER key should be delegated to the table.
	 * 
	 *  @return true or false.
	 */
	public boolean isPassEnterKeyToTable() {
	}

	/**
	 *  If this flag is set to true, the editor should pass the ENTER key to the table after it is
	 *  processed. The reason for this is to save one ENTER key. Otherwise user has to press ENTER to
	 *  stop cell editing first, then press ENTER key again to go to the next cell in the same column
	 *  (such as in PropertyTable case).
	 * 
	 *  @param passEnterKeyToTable true or false.
	 */
	public void setPassEnterKeyToTable(boolean passEnterKeyToTable) {
	}
}
