/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TableCustomFilterEditor</code> adds additional controls to create a list of FilterItems and they can be added to <code>FilterableTableModel</code>. To get the list of
 *  <code>FilterItem</code>s, you can call {@link #getFilterItems()} method.
 *  <p/>
 *  It has two different ways to configure the filters. The first way is what we called filter list way (using setStyle(STYLE_FILTER_LIST)). In this way, you define the filter, add the filter to the
 *  list below it. Then define another filter, add it to the list and so on. The second way is to use inline editor to define filter (using setStyle(STYLE_INLINE_EDITOR)). You can use setStyle method
 *  to change the style. Note calling this method will clear the filters that are already defined.
 */
@java.lang.SuppressWarnings("ALL")
public class TableCustomFilterEditor extends AbstractDialogPage {

	/**
	 *  The CustomFilterEditor, which contains a column selection JComboBox, a condition JComboBox and the ValueEditors.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected com.jidesoft.filter.CustomFilterEditor _editor;

	/**
	 *  The existing filter list, which contains a list of current existing filters.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JList _list;

	/**
	 *  The label displayed on the left and above the {@link #_list}.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JLabel _filtersLabel;

	/**
	 *  The button displayed on the left of {@link #_addButton}.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JButton _replaceButton;

	/**
	 *  The button displayed on the left of {@link #_clearButton}
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JButton _removeButton;

	/**
	 *  The button displayed on the right and below the {@link #_list}.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JButton _applyButton;

	/**
	 *  The button displayed on the right and above the {@link #_list}.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JButton _addButton;

	/**
	 *  The button displayed on the left of {@link #_applyButton}
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JButton _clearButton;

	protected int _style;

	public static final int STYLE_FILTER_LIST = 0;

	public static final int STYLE_INLINE_EDITOR = 1;

	/**
	 *  The FilterPanel list currently visible.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_INLINE_EDITOR}.
	 */
	protected java.util.List _filterPanels;

	/**
	 *  The label displayed on the left and below the {@link #_list}.
	 *  It is only used if {@link #getStyle()} returns {@link #STYLE_FILTER_LIST}.
	 */
	protected javax.swing.JToggleButton _andButton;

	public final String PROPERTY_COLLAPSIBLE = "collapsible";

	public final String PROPERTY_COLLAPSED = "collapsed";

	public TableCustomFilterEditor(javax.swing.table.TableModel tableModel) {
	}

	public void lazyInitialize() {
	}

	protected void initComponents() {
	}

	/**
	 *  Creates the FilterableTableModel. Subclass can override to return an existing FilterableTableModel if the table model
	 *  wrapper chain already has a FilterableTableModel.
	 * 
	 *  @param tableModel the table model.
	 *  @return a FilterableTableModel.
	 */
	protected IFilterableTableModel createFilterableTableModel(javax.swing.table.TableModel tableModel) {
	}

	public boolean isCollapsible() {
	}

	/**
	 *  Sets the collapsible property. This property is only used when the style is {@link #STYLE_INLINE_EDITOR}.
	 * 
	 *  @param collapsible true or false.
	 */
	public void setCollapsible(boolean collapsible) {
	}

	public boolean isCollapsed() {
	}

	/**
	 *  Sets the filter editor into collapsed mode so that only the first filter editor is visible. This flag is only used when the style is {@link #STYLE_INLINE_EDITOR}.
	 * 
	 *  @param collapsed true or false.
	 */
	public void setCollapsed(boolean collapsed) {
	}

	public void saveFilterItems() {
	}

	protected javax.swing.JComboBox createColumnComboBox(String[] columnNames) {
	}

	/**
	 *  Creates the FilterFactoryManager used by this TableCustomFilterEditor. Subclass can override it to provide your own instance of FilterFactoryManager or customize it before returning the one
	 *  created by super.createFilterFactoryManager.
	 * 
	 *  @return an new instance of FilterFactoryManager.
	 */
	protected com.jidesoft.filter.FilterFactoryManager createFilterFactoryManager() {
	}

	/**
	 *  Gets the table column name.
	 * 
	 *  @param tableModel  the table model.
	 *  @param columnIndex the column index.
	 *  @return the name of the column at the specified index.
	 */
	protected String getColumnName(javax.swing.table.TableModel tableModel, int columnIndex) {
	}

	/**
	 *  Creates a CustomFilterEditor.
	 * 
	 *  @param filterFactoryManager the FilterFactoryManager.
	 *  @param type                 the type.
	 *  @param converterContext     the ConverterContext.
	 *  @param possibleValues       the possible values.
	 *  @return a new instance of CustomFilterEditor.
	 */
	protected com.jidesoft.filter.CustomFilterEditor createCustomFilterEditor(com.jidesoft.filter.FilterFactoryManager filterFactoryManager, Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	/**
	 *  Creates the ValueEditor.
	 * 
	 *  @param type             the type.
	 *  @param converterContext the ConverterContext.
	 *  @param possibleValues   the possible values.
	 *  @return a new instance of the ValueEditor.
	 */
	protected com.jidesoft.filter.ValueEditor createValueEditor(Class type, ConverterContext converterContext, Object[] possibleValues) {
	}

	protected java.awt.Component createListPanel() {
	}

	/**
	 *  Gets the FilterItems defined in this <code>TableCustomFilterEditor</code>.
	 * 
	 *  @return the FilterItems defined in this <code>TableCustomFilterEditor</code>.
	 */
	public IFilterableTableModel.FilterItem[] getFilterItems() {
	}

	/**
	 *  Sets the FilterItems. It will remove all existing FilterItems defined in the editor and replace them with the new ones.
	 * 
	 *  @param filterItems the FilterItems defined this <code>TableCustomFilterEditor</code>.
	 */
	public void setFilterItems(IFilterableTableModel.FilterItem[] filterItems) {
	}

	/**
	 *  Gets the filterable table model.
	 * 
	 *  @return the filterable table model.
	 */
	public IFilterableTableModel getFilterableTableModel() {
	}

	/**
	 *  Gets the FilterFactoryManager used by this <code>TableCustomFilterEditor</code>.
	 * 
	 *  @return the FilterFactoryManager instance.
	 */
	public com.jidesoft.filter.FilterFactoryManager getFilterFactoryManager() {
	}

	protected String getResourceString(String key) {
	}

	public int getStyle() {
	}

	/**
	 *  Changes the way how the filters are defined. Valid values are {#link #STYLE_FILTER_LIST} and {@link #STYLE_INLINE_EDITOR}. Please note, calling this method will clear the filters that are
	 *  already defined.
	 * 
	 *  @param style the new style;.
	 */
	public void setStyle(int style) {
	}

	/**
	 *  Gets the action listener to apply the filters defined by this editor to a FilterableTableModel.
	 * 
	 *  @return the action listener.
	 */
	public java.awt.event.ActionListener getApplyFilterActionListener() {
	}

	/**
	 *  Sets the action listener that applies the filters defined by this editor to a FilterableTableModel.
	 * 
	 *  @param applyFilterActionListener a new listener.
	 */
	public void setApplyFilterActionListener(java.awt.event.ActionListener applyFilterActionListener) {
	}

	/**
	 *  Gets the action listener to clear the filters defined by this editor to a FilterableTableModel.
	 * 
	 *  @return the action listener.
	 */
	public java.awt.event.ActionListener getClearFilterActionListener() {
	}

	/**
	 *  Sets the action listener that clears the filters defined by this editor to a FilterableTableModel.
	 * 
	 *  @param clearFilterActionListener a new listener.
	 */
	public void setClearFilterActionListener(java.awt.event.ActionListener clearFilterActionListener) {
	}

	/**
	 *  Gets the relation of the filters when there are multiple filters. It could be either AND or OR relation. It will apply to all the filters. In a single query, you can't have a mixsure of AND and
	 *  OR among filters.
	 * 
	 *  @return true or false.
	 */
	public boolean isAnd() {
	}

	/**
	 *  Sets the relation of the filters when there are multiple filters. The relation could be either AND or OR relation. It will apply to all the filters. In a single query, you can't have a mixsure
	 *  of AND and OR among filters.
	 * 
	 *  @param and true or false. True means AND and false means OR.
	 */
	public void setAnd(boolean and) {
	}

	/**
	 *  It's one line of FilterPanel contains several components.
	 */
	public class FilterPanel {


		public javax.swing.JComboBox _comboBox;

		/**
		 *  The CustomFilterEditor on the right of {@link #_andButton} or {@link #_filterLabel}, which contains a column selection JComboBox, a condition JComboBox and the ValueEditors.
		 */
		public com.jidesoft.filter.CustomFilterEditor _editor;

		/**
		 *  The index of this FilterPanel in the panels.
		 */
		public int _index;

		/**
		 *  The count of all visible FilterPanels.
		 */
		public int _total;

		/**
		 *  Current filter item represented by this FilterPanel.
		 */
		public IFilterableTableModel.FilterItem _item;

		/**
		 *  The clear button on the right of {@link #_addButton}. It only displays on the last FilterPanel.
		 */
		public javax.swing.JButton _goButton;

		/**
		 *  The clear button on the right of {@link #_goButton}. It only displays on the last FilterPanel.
		 */
		public javax.swing.JButton _clearButton;

		/**
		 *  The clear button on the right of {@link #_editor}.
		 */
		public javax.swing.JButton _removeButton;

		/**
		 *  The add button on the right of {@link #_removeButton}.
		 */
		public javax.swing.JButton _addButton;

		/**
		 *  The collapse button on the left most of a FilterPanel. It only displays on the first Filterpanel.
		 */
		public JideButton _collapseButton;

		/**
		 *  The and/or JComboBox on the left most of a FilterPanel. It displays on the Filterpanels except the first one.
		 */
		public javax.swing.JComboBox _andButton;

		/**
		 *  The filter label on the right of {@link #_collapseButton}. It only displays on the first Filterpanel.
		 */
		public javax.swing.JLabel _filterLabel;

		public TableCustomFilterEditor.FilterPanel(IFilterableTableModel.FilterItem item, int index, int total) {
		}

		public void updateAndButton() {
		}

		public void updateIndex(int index, int total) {
		}

		public void updateCollapseButton() {
		}
	}
}
