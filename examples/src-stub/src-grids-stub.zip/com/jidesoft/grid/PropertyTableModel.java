/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  The table model is used by PropertyTable.
 */
public class PropertyTableModel extends TreeTableModel implements SpanModel, CategorizedTableModel, java.beans.PropertyChangeListener, EditorStyleTableModel {
 {

	/**
	 *  Constant used by setOrder().
	 */
	public static final int CATEGORIZED = 0;

	/**
	 *  Constant used by setOrder().
	 */
	public static final int SORTED = 1;

	/**
	 *  Constant used by setOrder().
	 */
	public static final int UNSORTED = 2;

	protected boolean _indentNonCategoryRow;

	/**
	 *  Creates an empty PropertyTableModel.
	 */
	public PropertyTableModel() {
	}

	/**
	 *  Creates PropertyTableModel from a list of properties.
	 * 
	 *  @param properties list of properties
	 */
	public PropertyTableModel(java.util.List properties) {
	}

	/**
	 *  Creates PropertyTableModel from a list of properties.
	 * 
	 *  @param properties list of properties
	 *  @param categories the categories
	 */
	public PropertyTableModel(java.util.List properties, String[] categories) {
	}

	/**
	 *  Creates PropertyTableModel from a list of properties.
	 * 
	 *  @param properties    the list of properties
	 *  @param categoryOrder the order of category. 0 means unsorted, 1 means ascending and -1 means descending.
	 */
	public PropertyTableModel(java.util.List properties, int categoryOrder) {
	}

	/**
	 *  Sets the original property list.
	 * 
	 *  @param properties the list of properties
	 */
	public void setOriginalProperties(java.util.List properties) {
	}

	/**
	 *  Gets the comparator that is used to sort properties when the property table is in SORTED display mode.
	 * 
	 *  @return comparator. If it's null, the default comparator will be used to sort by the property name
	 */
	public java.util.Comparator getComparator() {
	}

	/**
	 *  Sets the comparator which will be used to sort properties when the table is in SORTED display mode.
	 * 
	 *  @param comparator the comparator to sort the properties.
	 */
	public void setComparator(java.util.Comparator comparator) {
	}

	/**
	 *  This method will convert from the original properties to the list that can be displayed as in TreeTableModel.
	 * 
	 *  @param properties the original properties list.
	 *  @return the list that will be used for TreeTableModel.
	 */
	protected java.util.List buildProperties(java.util.List properties) {
	}

	/**
	 *  Creates the Category type. Please note, if you subclass Property to use the generic feature provided by
	 *  PropertyTableModel, make sure you create your own subclass of Property here. Make sure you call {@link
	 *  Property#setCategoryRow(boolean)} and set it to true.
	 * 
	 *  @param category the category name.
	 *  @return the Property which is used for the category rows.
	 */
	protected Property createCategory(String category) {
	}

	/**
	 *  Filter the property. If it returns true, PropertyTable will not show that property. By default, it will return
	 *  true when Property isHidden() is true, or Property isExpert() is true and PropertyTableModel isShowExpert() is
	 *  false. Subclass can override this method to customize the behavior.
	 * 
	 *  @param property the property to be checked if it should be filtered.
	 *  @return true or false. If it is true, PropertyTable will not show that property.
	 */
	protected boolean filterProperty(Property property) {
	}

	@java.lang.Override
	protected boolean shouldBeFiltered(Property row) {
	}

	/**
	 *  Gets the order. It could be one of the three values - CATEGORIZED, SORTED or UNSORTED.
	 * 
	 *  @return the order.
	 */
	public int getOrder() {
	}

	/**
	 *  Sets the order. It could be one of the three values - CATEGORIZED, SORTED or UNSORTED.
	 * 
	 *  @param order the order.
	 */
	public void setOrder(int order) {
	}

	/**
	 *  Gets the list of properties used by the table model. If it is in CATEGORIZED order, this method will return a
	 *  list of categories. If it is in SORTED or UNSORTED order, it will return a list of properties. The order of the
	 *  properties is as displayed.
	 * 
	 *  @return the list of properties
	 */
	public java.util.List getProperties() {
	}

	/**
	 *  Gets the list of properties used by the table model. The order is as displayed.
	 * 
	 *  @param includeChildren whether to include all the children when asking for the list of properties.
	 *  @return the list of properties
	 */
	public java.util.List getProperties(boolean includeChildren) {
	}

	/**
	 *  Gets the list of properties used by the table mode. The order is as it is passed in constructor.
	 * 
	 *  @return the list of properties as it is passed in constructor
	 */
	public java.util.List getOriginalProperties() {
	}

	/**
	 *  Gets the list of properties used by the table mode. The order is as it is passed in constructor.
	 * 
	 *  @param includeChildren true to include the children of all the properties.
	 *  @return the list of properties as it is passed in constructor
	 */
	public java.util.List getOriginalProperties(boolean includeChildren) {
	}

	/**
	 *  If you changed the properties list directly, you need to call this method to refresh the internal data
	 *  structure.
	 */
	public void reloadProperties() {
	}

	/**
	 *  Override the method in TreeTableModel. If you want to change the original properties list of PropertyTableModel,
	 *  you should always use {@link #setOriginalProperties(java.util.List)}. For backward compatible reason, we made
	 *  this method do the same thing as setOriginalProperties.
	 * 
	 *  @param rows the original properties list.
	 */
	@java.lang.Override
	public void setOriginalRows(java.util.List rows) {
	}

	/**
	 *  Refreshes the table model when the original properties changed.
	 */
	@java.lang.Override
	public void refresh() {
	}

	/**
	 *  Sets the value the underlying property of that cell.
	 * 
	 *  @param aValue      value to assign to cell
	 *  @param rowIndex    row of cell
	 *  @param columnIndex column of cell
	 */
	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	/**
	 *  Returns false if column is 0 and return the isEditable of the property if column is 1.
	 * 
	 *  @param rowIndex    the row being queried
	 *  @param columnIndex the column being queried
	 *  @return false
	 */
	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	/**
	 *  Returns "Name" is column is 0 and "Value" is column is 1.
	 * 
	 *  @param column the column being queried
	 *  @return a string containing the default name of <code>column</code>
	 */
	@java.lang.Override
	public String getColumnName(int column) {
	}

	/**
	 *  Returns the number of columns in the model. A <code>JTable</code> uses this method to determine how many columns
	 *  it should create and display by default.
	 * 
	 *  @return the number of columns in the model
	 * 
	 *  @see #getRowCount
	 */
	public int getColumnCount() {
	}

	/**
	 *  Returns the Property at row specified by <code>row</code>.
	 * 
	 *  @param row the row whose Property is to be queried
	 *  @return the Property at the specified row
	 */
	public Property getPropertyAt(int row) {
	}

	/**
	 *  Gets the index of the property.
	 * 
	 *  @param property property
	 *  @return the index of the property
	 */
	public int getPropertyIndex(Property property) {
	}

	/**
	 *  @param fullName the full name of the property
	 *  @return the property.
	 * 
	 *  @deprecated If you want to find property that is visible, use {@link #getVisibleProperty(String)}. If you want to
	 *              find property either is either visible or invisible, use {@link #getProperty(String)}.
	 */
	@java.lang.Deprecated
	public Property findProperty(String fullName) {
	}

	/**
	 *  Gets Property whose full name is specified in parameter fullName. Please note, this method will only find the
	 *  property that is visible. If its parent is collapsed, this method will not find the property.
	 * 
	 *  @param fullName property full name
	 *  @return the index of the property
	 * 
	 *  @see #findProperty(String).
	 */
	public Property getVisibleProperty(String fullName) {
	}

	/**
	 *  Gets Property whose full name is specified in parameter fullName.
	 * 
	 *  @param fullName property full name
	 *  @return the index of the property
	 */
	public Property getProperty(String fullName) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int row, int column) {
	}

	@java.lang.Override
	public Class getCellClassAt(int row, int column) {
	}

	public boolean isCategoryRow(int rowIndex) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method should be used to remove
	 *  PropertyChangeListeners that were registered for all bound properties of this class.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners registered on this component.
	 * 
	 *  @return all of this component's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the PropertyChangeListener to be added
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public synchronized void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list for a specific property. This method should be used to
	 *  remove PropertyChangeListeners that were registered for a specific bound property.
	 *  <p/>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public synchronized void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param propertyName the property name
	 *  @return all of the <code>PropertyChangeListeners</code> associated with the named property or an empty array if
	 *          no listeners have been added
	 * 
	 *  @see #addPropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 *  @since 1.4
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected synchronized void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	/**
	 *  Support for reporting bound property changes for boolean properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, boolean oldValue, boolean newValue) {
	}

	/**
	 *  Support for reporting bound property changes for integer properties. This method can be called when a bound
	 *  property has changed and it will send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, int oldValue, int newValue) {
	}

	/**
	 *  Checks if the non-category row should indent. By default there is no indent of first level non-category row.
	 * 
	 *  @return true if non category row should indent.
	 */
	public boolean isIndentNonCategoryRow() {
	}

	/**
	 *  Sets if first level non-category row indent from category row. By default the first level non-category row has
	 *  the same indent as category row. We do this because we want to save the space.
	 * 
	 *  @param indent true or false.
	 *  @deprecated the indention is now controlled by each Property. Please use {@link Property#setIndentNonCategoryRow(boolean)}.
	 */
	@java.lang.Deprecated
	public void setIndentNonCategoryRow(boolean indent) {
	}

	/**
	 *  Gets misc category name. Misc category is for property which doesn't specify a category.
	 * 
	 *  @return misc category name. If it has never been set before, it will use the string from a resource bundle in
	 *          com.jidesoft.grid. In English, it will be "Misc".
	 */
	public String getMiscCategoryName() {
	}

	/**
	 *  Sets the misc category name.
	 * 
	 *  @param miscCategoryName the name for misc category.
	 */
	public void setMiscCategoryName(String miscCategoryName) {
	}

	/**
	 *  Changes the category name.
	 * 
	 *  @param currentCategory the current category name
	 *  @param newCategory     the new category name
	 */
	public void renameCategory(String currentCategory, String newCategory) {
	}

	/**
	 *  Sets the category list. After calling this method, you should call reloadProperties() for it to take effect. We
	 *  have this method so that you can specify the order of categories using the string array.
	 * 
	 *  @param categories an array of categories
	 */
	public void setCategories(String[] categories) {
	}

	/**
	 *  Get all the category row instances. You don't have to invoke setCategories() to make it work. As long as you defined
	 *  category for every single property, you would be able to retrieve the category row instances.
	 * 
	 *  @return the category row array.
	 */
	public Property[] getCategories() {
	}

	/**
	 *  Gets the category sort order.
	 * 
	 *  @return 0 means unsorted, 1 means ascending and -1 means descending.
	 */
	public int getCategoryOrder() {
	}

	/**
	 *  Sets category sort order.
	 * 
	 *  @param categoryOrder the order of category. 0 means unsorted, 1 means ascending and -1 means descending.
	 */
	public void setCategoryOrder(int categoryOrder) {
	}

	/**
	 *  If the expert properties should be shown.
	 * 
	 *  @return true if expert properties should be shown.
	 */
	public boolean isShowExpert() {
	}

	/**
	 *  Sets to true if the expert properties should be shown. Otherwise set it to false. By default it's true. By
	 *  default, all properties are shown in PropertyTableModel, including export properties. However if you call
	 *  PropertyTableModel#setShowExpert(false), export properties will be hidden. You can use this if you don't want
	 *  non-expert users to touch some of the properties which are considered as for experts only.
	 * 
	 *  @param showExpert true or false.
	 */
	public void setShowExpert(boolean showExpert) {
	}

	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public boolean isCellSpanOn() {
	}

	/**
	 *  Overrides the method in TreeTableModel to always throw IllegalStateException. Since PropertyTableModel has its
	 *  own way to manage the order of properties, it'd better to call {@link #getOriginalProperties()} to get the
	 *  original property list and add a new property to the list, then call {@link #refresh()} to update the view.
	 * 
	 *  @param index  the row index. The index can be -1. If it is -1 and before == false, it will be append at the end.
	 *                If before == true, it will insert at the first position.
	 *  @param row    row to be added.
	 *  @param before if it should be added before index or after index.
	 */
	@java.lang.Override
	public void addRow(int index, Property row, boolean before) {
	}

	/**
	 *  /** Overrides the method in TreeTableModel to always throw IllegalStateException. Since PropertyTableModel has
	 *  its own way to manage the order of properties, it'd better to call {@link #getOriginalProperties()} to get the
	 *  original property list and remove a property from the list, then call {@link #refresh()} to update the view.
	 * 
	 *  @param rowIndex the row index of the row to be removed
	 */
	@java.lang.Override
	public void removeRow(int rowIndex) {
	}

	/**
	 *  Binds an object with the <code>PropertyTableModel</code>. This is used if the <code>PropertyTableModel</code> is
	 *  created from {@link com.jidesoft.introspector.BeanIntrospector#createPropertyTableModel(Object)} method. If the
	 *  table model is changed, it will set the value on the object. But if the object is modified outside the table
	 *  model, the table model is not aware of the change, thus it will not update automatically to show the change. This
	 *  bind method will call <code>addPropertyChangeListener</code> method on the object to listen to the property
	 *  change event so that it knows when the object's property is changed.
	 * 
	 *  @param beanObject the object
	 *  @throws Exception if the object doesn't have addPropertyChangeListener method.
	 */
	public void bind(Object beanObject) {
	}

	/**
	 *  Unbinds an object with the <code>PropertyTableModel</code> which is previously bounded using {@link
	 *  #bind(Object)}.
	 * 
	 *  @param beanObject the object
	 *  @throws Exception if the object doesn't have removePropertyChangeListener method.
	 */
	public void unbind(Object beanObject) {
	}

	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}

	/**
	 *  Gets the expansion state of all properties. You can use this method along with {@link
	 *  #setExpansionState(java.util.Map)} to restore the property expansion state after the PropertyTableModel is
	 *  recreated.
	 * 
	 *  @return a map contains the expansion state of all properties.
	 */
	public java.util.Map getExpansionState() {
	}

	/**
	 *  Restores the expansion state of all properties. You can use this method to restore the expansion state after the
	 *  PropertyTableModel is created but property names remain. For newly added property, this method will not change
	 *  its expansion state.
	 * 
	 *  @param state a map of the expansion state.
	 */
	public void setExpansionState(java.util.Map state) {
	}

	/**
	 *  Gets editor style at the cell.
	 *  <p/>
	 *  By default, it will try to get the editor style from the property if column index is 1. Otherwise it returns
	 *  {@link com.jidesoft.grid.EditorStyleTableModel#EDITOR_STYLE_NORMAL} by default
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return the editor style
	 */
	@java.lang.Override
	public int getEditorStyleAt(int rowIndex, int columnIndex) {
	}
}
