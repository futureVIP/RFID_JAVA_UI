/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>TreeTable</code> is a combination of a tree and a table -- a component capable of both expanding and
 *  contracting rows, as well as showing multiple columns of data. Tree and table work on different data structure. The
 *  former is used to display hierarchical data. The latter is used to disable a flat tabular data. So in order to make
 *  the data works in TreeTable, we need to hierarchize the flat tabular data. To make the design simple, we make the
 *  following assumption <p><b> If the data can be used in TreeTable, it must be row-oriented, meaning each row in the
 *  table can be represented as one data structure. </b> Based on this assumption, we introduce several concepts (they
 *  are all Interfaces) to make TreeTable possible. <ul> <li>{@link Node}: represent a node in tree data structure
 *  <li>{@link Expandable}: represent something can be expanded such as tree node with children. <li>{@link Row}:
 *  represent a row in table data structure. <li>{@link ExpandableRow}: represent a row which can have children rows.
 *  </ul>
 *  <p/>
 *  It will be simple to understand this using an example. A typical TreeTable example is the file system. In file
 *  system, there are files and folders. Using the concepts above, each file will be a Row; each folder will be an
 *  ExpandableRow. Folder (ExpandableRow) can have children which can be either files (Row) or other folders
 *  (ExpandableRow).
 *  <p/>
 *  The table model used by <code>TreeTable</code> is {@link TreeTableModel}. It extends AbstractTableModel. However it's
 *  essentially a list of ExpandableRows or Rows. <code>TreeTableModel</code> is an abstract class. The only method you
 *  has to implement is {@link TreeTableModel#getColumnCount()}. You might want to override {@link
 *  TreeTableModel#getColumnName(int)}. Otherwise, it will use "A", "B" etc as default names. You also need to make the
 *  columns match with the value you returned in {@link Row#getValueAt(int)}. Once we create a java.util.List of the
 *  Rows, you call
 *  <code><pre>
 *  TreeTableModel model = new MyTreeTableModel(list);
 *  TreeTable table = new TreeTable(model);
 *  </pre></code>
 *  Now you get a TreeTable instance.
 *  <p/>
 *  <code>TreeTable</code> uses a special cell renderer on the first column to paint +/- icon as well as tree line. If
 *  the row is expandable, you will see +/- icon. Clicking on it will expand the row. Clicking again will collapse it.
 *  You can also use keyboard to expand/collapse a row. Right arrow key will expand the selected row and left arrow key
 *  will collapse it. If the selected row doesn't have children or it is collapsed already, it will change the selection
 *  to its parent. If you try it, you will find it is very convenient to navigate in the tree table using arrow keys.
 *  <p/>
 *  Since the first columns are used to paint +/- icon and tree lines, it'd better you make the first column of the table
 *  not editable. There should be workaround for this limitation, such as using dialog to edit the first cell or
 *  rearranging the table columns to use a non-editable column as the first one.
 *  <p/>
 *  We used the same +/- icons used in JTree so it will change based on different LookAndFeels. You can also define your
 *  own icons by calling {@link #setExpandedIcon(javax.swing.Icon)} and {@link #setCollapsedIcon(javax.swing.Icon)}. The
 *  tree lines can be turn on or off using {@link #setShowTreeLines(boolean)}. The line color can be set by {@link
 *  #setTreeLineColor(java.awt.Color)}. By default, it will use the JTree's tree line color which is
 *  <code>UIManagerLookup.getColor("Tree.hash")</code>.
 *  <p/>
 *  There are several keystrokes you can use to expand or collapse rows. If the current cell is the first cell, you can
 *  use right or left arrow keys to expand or collapse the selected row respectively. You can also use "+", "-", "*", "/"
 *  key on Numpad to expand, collapse, expand all, collapse all respectively. So if your tree table has a huge number or
 *  unlimited number of children nodes, you should disable expand all operation because it will never end. This is
 *  important because Numpad "*" will trigger expand all. If you didn't disable expand all, user might press Numpad "*"
 *  key by mistake and freeze the GUI.
 */
public class TreeTable extends SortableTable {

	public static final String PROPERTY_SHOW_TREE_LINES = "showTreeLines";

	public static final String PROPERTY_SHOW_LEAF_NODE_TREE_LINES = "showLeafNodeTreeLines";

	public static final String PROPERTY_TREE_LINE_COLOR = "treeLineColor";

	public static final String PROPERTY_DOUBLE_CLICK_ENABLED = "doubleClickEnabled";

	public static final String PROPERTY_EXPANDABLE_COLUMN = "expandableColumn";

	public static final String PROPERTY_SELECT_ROW_WHEN_TOGGLING = "selectRowWhenToggling";

	public static final String CLIENT_PROPERTY_DO_NOT_PAINT_CELL_CONTENT_BACKGROUND = "TreeTable.doNotPaintCellContentBackground";

	public TreeTable() {
	}

	public TreeTable(int numRows, int numColumns) {
	}

	public TreeTable(javax.swing.table.TableModel dm) {
	}

	public TreeTable(Object[][] rowData, Object[] columnNames) {
	}

	public TreeTable(java.util.Vector rowData, java.util.Vector columnNames) {
	}

	public TreeTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm) {
	}

	public TreeTable(javax.swing.table.TableModel dm, javax.swing.table.TableColumnModel cm, javax.swing.ListSelectionModel sm) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Returns a string that specifies the name of the L&F class that renders this component.
	 * 
	 *  @return the string "TreeTableUI"
	 * 
	 *  @see JComponent#getUIClassID
	 *  @see UIDefaults#getUI
	 */
	@java.lang.Override
	public String getUIClassID() {
	}

	/**
	 *  Creates the special cell renderer for the first column which paints +/- icon and tree line.
	 * 
	 *  @return an instance of TreeTableCellRenderer. The same instance will be used to paint the cell of all rows in
	 *          TreeTable.
	 */
	protected javax.swing.table.TableCellRenderer createCellRenderer() {
	}

	@java.lang.Override
	protected void muteDefaultKeyStroke() {
	}

	/**
	 *  Sets the data model for this table to <code>newModel</code> and registers with it for listener notifications from
	 *  the new data model.
	 *  <p/>
	 *  If the table is in editing mode, it will stop cell editing first.
	 *  <p/>
	 *  <code>TreeTable</code> only supports <code>TreeTableModel</code>. If <code>newModel</code> is <code>null</code>
	 *  or tableModel is not an instance of <code>TreeTableModel</code>. An empty <code>TreeTableModel</code> will be
	 *  created and used.
	 * 
	 *  @param tableModel the new data source for this table. It must be an instance of TreeTableModel
	 *  @see #getModel
	 */
	@java.lang.Override
	public void setModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Handles the mouse event. It does two things. If single mouse clicks on the +/- icon will expand/collapse the row.
	 *  If {@link #isDoubleClickEnabled()} is true, double click on the row any place other than +/- icon will
	 *  expand/collapse the row as well.
	 *  <p/>
	 *  Please note, since 1.9.4.10 release, we change the signature of this method to return boolean. If you override
	 *  this method before, you will get a compile error. Simply change the overridden method to return boolean will fix
	 *  it.
	 * 
	 *  @param e the mouse event
	 */
	protected void handleMouseEvent(java.awt.event.MouseEvent e) {
	}

	protected boolean toggleRow(Row row) {
	}

	/**
	 *  Gets the Row from the underlying table model.
	 * 
	 *  @param rowIndex the row index
	 *  @return Row at the specified row index.
	 */
	public Row getRowAt(int rowIndex) {
	}

	public int getRowIndex(Row row) {
	}

	/**
	 *  Expands or collapses the row at the specified rowIndex.
	 * 
	 *  @param rowIndex rowIndex to be expanded.
	 *  @param expanded true to expand and false to collapse.
	 *  @return true if the row is expanded.
	 */
	public boolean expandRow(int rowIndex, boolean expanded) {
	}

	/**
	 *  Gets the value of selectRowWhenToggling property. If true, the row will be selected when when a row is expanded
	 *  or collapsed. If false, the old selection will be kept when a row is expanded or collapsed.
	 * 
	 *  @return true or false.
	 */
	public boolean isSelectRowWhenToggling() {
	}

	/**
	 *  Sets the selectRowWhenToggling flag.
	 * 
	 *  @param selectRowWhenToggling true or false. If true, the row will be selected when when a row is expanded or
	 *                               collapsed. If false, the old selection will be kept when a row is expanded or
	 *                               collapsed.
	 */
	public void setSelectRowWhenToggling(boolean selectRowWhenToggling) {
	}

	/**
	 *  Selects the specified <code>Row</code>. In TreeTable, a <code>Row</code> could be at any row index when
	 *  expand/collapse state changes. The old way to select a row using selection model won't work. This method will
	 *  make it easier to select a row by passing in the <code>Row</code> which you usually know.
	 *  <p/>
	 *  If the <code>Row</code> is not visible, it will expand its parents to make it visible.
	 * 
	 *  @param row the row
	 */
	public void setSelectedRow(Row row) {
	}

	/**
	 *  Adds the specified <code>Row</code>. In TreeTable, a <code>Row</code> could be at any row index when
	 *  expand/collapse state changes. The old way to select a row using selection model won't work. This method will
	 *  make it easier to select a row by passing in the <code>Row</code> which you usually know.
	 *  <p/>
	 *  If the <code>Row</code> is not visible, it will expand its parents to make it visible.
	 * 
	 *  @param row the row
	 */
	public void addSelectedRow(Row row) {
	}

	/**
	 *  Removes the selection on the specified <code>Row</code>. In TreeTable, a <code>Row</code> could be at any row index when
	 *  expand/collapse state changes. The old way to de-select a row using selection model won't work. This method will
	 *  make it easier to de-select a row by passing in the <code>Row</code> which you usually know.
	 * 
	 *  @param row the row
	 */
	public void removeSelectedRow(Row row) {
	}

	/**
	 *  Selects the specified <code>rows</code>. In TreeTable, a <code>Row</code> could be at any row index when
	 *  expand/collapse state changes. The old way to select rows using selection model won't work. This method will
	 *  make it easier to select rows by passing in the <code>rows</code> which you usually know.
	 *  <p/>
	 *  If the <code>rows</code> are not visible, it will expand their parents to make them visible.
	 * 
	 *  @param rows the rows
	 */
	public void setSelectedRows(Row[] rows) {
	}

	/**
	 *  Adds the specified <code>rows</code>. In TreeTable, a <code>Row</code> could be at any row index when
	 *  expand/collapse state changes. The old way to select rows using selection model won't work. This method will
	 *  make it easier to select rows by passing in the <code>rows</code> which you usually know.
	 *  <p/>
	 *  If the <code>rows</code> are not visible, it will expand their parents to make them visible.
	 * 
	 *  @param rows the rows
	 */
	public void addSelectedRows(Row[] rows) {
	}

	/**
	 *  Removes the specified <code>rows</code>. In TreeTable, a <code>Row</code> could be at any row index when
	 *  expand/collapse state changes. The old way to de-select rows using selection model won't work. This method will
	 *  make it easier to de-select rows by passing in the <code>rows</code> which you usually know.
	 * 
	 *  @param rows the rows
	 */
	public void removeSelectedRows(Row[] rows) {
	}

	/**
	 *  Expands all so that all rows are visible.
	 */
	public void expandAll() {
	}

	/**
	 *  Expands all top level rows.
	 */
	public void expandFirstLevel() {
	}

	/**
	 *  Expands one more level of rows.
	 */
	public void expandNextLevel() {
	}

	/**
	 *  Collapses all so that all non-top level rows are invisible.
	 */
	public void collapseAll() {
	}

	/**
	 *  Collapses all top level rows only. The children level rows are still expanded if they were. But they can't be
	 *  seen anymore as the root rows are collapsed. If you expand the root rows after this call, you will see the
	 *  children rows remain expanded.
	 */
	public void collapseFirstLevel() {
	}

	/**
	 *  Collapses all top level rows only. The children level rows are still expanded if they were. But they can't be
	 *  seen anymore as the root rows are collapsed. If you expand the root rows after this call, you will see the
	 *  children rows remain expanded.
	 */
	public void collapseLastLevel() {
	}

	/**
	 *  Gets the cell rect which contains point p.
	 * 
	 *  @param p the point
	 *  @return cell rectangle
	 */
	protected java.awt.Rectangle getCellRect(java.awt.Point p) {
	}

	protected java.awt.Point getCellAt(java.awt.Point p) {
	}

	public javax.swing.table.TableCellRenderer getActualCellRenderer(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	public void removeNotify() {
	}

	@java.lang.Override
	public javax.swing.table.TableCellRenderer getCellRenderer(int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	protected javax.swing.Action createDelegateAction(javax.swing.Action action, javax.swing.KeyStroke keyStroke) {
	}

	/**
	 *  Get the flag indicating if comparing with the current selection before loading selection.
	 * 
	 *  @return the flag.
	 * 
	 *  @see #setCompareCurrentSelection(boolean)
	 */
	public boolean isCompareCurrentSelection() {
	}

	/**
	 *  Set the flag indicating if comparing with the current selection before loading selection.
	 * 
	 *  @param compareCurrentSelection if current selection will be compared with the selection to load. By default, the
	 *                                 value is false for performance reason. You could turn this flag to true if you care
	 *                                 more about the selection events.
	 */
	public void setCompareCurrentSelection(boolean compareCurrentSelection) {
	}

	/**
	 *  Get the flag indicating if collapsed rows would be exported to excel while exporting.
	 *  <p/>
	 *  The default value of this flag is false. The reason is that we have to updateUI() to export the collapsed rows. You
	 *  could set it to true. However, you will have to consider put the exporting task to EDT, which could freeze the UI
	 *  in large amount of data.
	 * 
	 *  @return true if collapsed rows would be exported to excel. Otherwise false.
	 */
	public boolean isExportCollapsedRowsToExcel() {
	}

	/**
	 *  Set the flag indicating if collapsed rows would be exported to excel while exporting.
	 * 
	 *  @param exportCollapsedRowsToExcel the flag
	 *  @see #isExportCollapsedRowsToExcel()
	 */
	public void setExportCollapsedRowsToExcel(boolean exportCollapsedRowsToExcel) {
	}

	/**
	 *  Get the indent specificall for this row in the TreeTable. By default, we will just invoke {@link #getIndent()} to
	 *  return. If you want to customize the indent behavior for specific rows, please override this method.
	 * 
	 *  @param row the row
	 *  @return the indent for the row comparing its parent row.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected int getIndent(Row row) {
	}

	/**
	 *  Get the delay time while dragging to expand a row.
	 *  <p/>
	 *  The default value of the delay time is 200ms. Since the drag functionality was introduced since JDK 1.6, this
	 *  method will only take effect since JDK 1.6 as well.
	 * 
	 *  @return the delay time in milliseconds.
	 * 
	 *  @see JTable#setDragEnabled(boolean)
	 *  @see JTable#setDropMode(javax.swing.DropMode)
	 *  @see JTable#setTransferHandler(javax.swing.TransferHandler)
	 */
	@java.lang.SuppressWarnings("Since15")
	public int getDragExpandDelay() {
	}

	/**
	 *  Set the delay time while dragging to expand a row.
	 * 
	 *  @param dragExpandDelay the delay time in milliseconds
	 *  @see #getDragExpandDelay()
	 */
	public void setDragExpandDelay(int dragExpandDelay) {
	}

	/**
	 *  Creates the mouse listener used to handle mouse click on +/- icon.
	 *  <p/>
	 *  Please override this method if you are NOT in JDK 1.6. Otherwise, please use {@link #createExpandMouseInputListener(javax.swing.event.MouseInputListener)}
	 *  instead.
	 * 
	 *  @return a mouse listener.
	 * 
	 *  @see #createExpandMouseInputListener(javax.swing.event.MouseInputListener)
	 */
	protected javax.swing.event.MouseInputListener createExpandMouseListener() {
	}

	/**
	 *  Creates the mouse listener used to handle mouse click on +/- icon.
	 *  <p/>
	 *  Please override this method if you are in JDK 1.6. In other JDK releases, please use {@link #createExpandMouseListener()}
	 *  instead.
	 * 
	 *  @param listener the MouseInputListener
	 *  @return a mouse listener.
	 * 
	 *  @see #createExpandMouseListener()
	 */
	protected javax.swing.event.MouseInputListener createExpandMouseInputListener(javax.swing.event.MouseInputListener listener) {
	}

	/**
	 *  Adds a listener for <code>TreeExpansion</code> events.
	 *  <p/>
	 *  Please note, methods such as {@link #expandAll()}, {@link #expandFirstLevel()}, {@link #expandNextLevel()},
	 *  {@link #collapseAll()}, {@link #collapseFirstLevel()} and {@link #collapseLastLevel()} will not fire this event.
	 * 
	 *  @param tel a TreeExpansionListener that will be notified when a row is expanded or collapsed (a "negative
	 *             expansion")
	 */
	public void addTreeExpansionListener(javax.swing.event.TreeExpansionListener tel) {
	}

	/**
	 *  Removes a listener for <code>TreeExpansion</code> events.
	 * 
	 *  @param tel the <code>TreeExpansionListener</code> to remove
	 */
	public void removeTreeExpansionListener(javax.swing.event.TreeExpansionListener tel) {
	}

	/**
	 *  Returns an array of all the <code>TreeExpansionListener</code>s added to this TreeTable with
	 *  addTreeExpansionListener().
	 * 
	 *  @return all of the <code>TreeExpansionListener</code>s added or an empty array if no listeners have been added
	 */
	public javax.swing.event.TreeExpansionListener[] getTreeExpansionListeners() {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is
	 *  lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was expanded
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTreeExpanded(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type. The event instance is
	 *  lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was collapsed
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireTreeCollapsed(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Adds a listener for <code>TreeWillExpand</code> events.
	 *  <p/>
	 *  Please note, methods such as {@link #expandAll()}, {@link #expandFirstLevel()}, {@link #expandNextLevel()},
	 *  {@link #collapseAll()}, {@link #collapseFirstLevel()} and {@link #collapseLastLevel()} will not fire this event.
	 * 
	 *  @param tel a <code>TreeWillExpandListener</code> that will be notified when a tree node will be expanded or
	 *             collapsed (a "negative expansion")
	 */
	public void addTreeWillExpandListener(javax.swing.event.TreeWillExpandListener tel) {
	}

	/**
	 *  Removes a listener for <code>TreeWillExpand</code> events.
	 * 
	 *  @param tel the <code>TreeWillExpandListener</code> to remove
	 */
	public void removeTreeWillExpandListener(javax.swing.event.TreeWillExpandListener tel) {
	}

	/**
	 *  Returns an array of all the <code>TreeWillExpandListener</code>s added to this JTree with
	 *  addTreeWillExpandListener().
	 * 
	 *  @return all of the <code>TreeWillExpandListener</code>s added or an empty array if no listeners have been added
	 */
	public javax.swing.event.TreeWillExpandListener[] getTreeWillExpandListeners() {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type.  The event instance is
	 *  lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was expanded
	 *  @throws javax.swing.tree.ExpandVetoException
	 *           if the tree node is not allowed to be expanded
	 *  @see EventListenerList
	 */
	public void fireTreeWillExpand(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Notifies all listeners that have registered interest for notification on this event type.  The event instance is
	 *  lazily created using the <code>path</code> parameter.
	 * 
	 *  @param path the <code>TreePath</code> indicating the node that was expanded
	 *  @throws javax.swing.tree.ExpandVetoException
	 *           if the tree node is not allowed to be collapsed
	 *  @see EventListenerList
	 */
	public void fireTreeWillCollapse(javax.swing.tree.TreePath path) {
	}

	/**
	 *  Checks if the tree lines are visible.
	 * 
	 *  @return true if tree lines is visible.
	 */
	public boolean isShowTreeLines() {
	}

	/**
	 *  Sets the tree lines visible or not. Property change event on {@link #PROPERTY_SHOW_TREE_LINES} be fired when
	 *  value changes.
	 * 
	 *  @param showTreeLines true to show the tree lines. Otherwise false.
	 */
	public void setShowTreeLines(boolean showTreeLines) {
	}

	/**
	 *  Checks if the tree lines are visible.
	 * 
	 *  @return true if tree lines is visible.
	 */
	public boolean isShowLeafNodeTreeLines() {
	}

	/**
	 *  Sets the tree lines visible or not. Property change event on {@link #PROPERTY_SHOW_LEAF_NODE_TREE_LINES} be fired
	 *  when value changes.
	 * 
	 *  @param showLeafNodeTreeLines true to show leaf node's tree lines
	 */
	public void setShowLeafNodeTreeLines(boolean showLeafNodeTreeLines) {
	}

	/**
	 *  Checks if the double click is enabled. If it is enabled, double clicking anywhere on the row (except the +/- icon
	 *  area) will expand/collapse the row. If the cells are editable, it is recommend you set it to false. Otherwise it
	 *  will conflict with cell editing. Default is true.
	 * 
	 *  @return true if double click on the row is enabled.
	 */
	public boolean isDoubleClickEnabled() {
	}

	/**
	 *  Enables double click on the row to expand/collapse the row. Property change event on {@link
	 *  #PROPERTY_DOUBLE_CLICK_ENABLED} be fired when value changes.
	 * 
	 *  @param doubleClickEnabled true to enable double click to expand/collapse a row
	 */
	public void setDoubleClickEnabled(boolean doubleClickEnabled) {
	}

	/**
	 *  Gets the line color used to pain the tree line.
	 * 
	 *  @return the tree line color.
	 */
	public java.awt.Color getTreeLineColor() {
	}

	/**
	 *  Sets the tree line color. Property change event on {@link #PROPERTY_TREE_LINE_COLOR} be fired when value
	 *  changes.
	 * 
	 *  @param treeLineColor the new tree line color
	 */
	public void setTreeLineColor(java.awt.Color treeLineColor) {
	}

	protected javax.swing.table.TableModel getTreeTableModel() {
	}

	/**
	 *  Override the method in SortableTable to create a special sortable table model for TreeTable.
	 * 
	 *  @param model the table model.
	 *  @return a SortableTableModel.
	 */
	@java.lang.Override
	protected ISortableTableModel createSortableTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the indent of child level, in pixels.
	 * 
	 *  @return the indent.
	 */
	public int getIndent() {
	}

	/**
	 *  Sets the indent of child level, in pixels. Default value is 16.
	 * 
	 *  @param indent the new indent
	 */
	public void setIndent(int indent) {
	}

	/**
	 *  Gets the left margin of first level, in pixels.
	 * 
	 *  @return the indent.
	 * 
	 *  @see #setLeftMargin(int)
	 */
	public int getLeftMargin() {
	}

	/**
	 *  Sets the left margin of first level, in pixels.
	 *  <p/>
	 *  By default, the value is 16.
	 * 
	 *  @param leftMargin the left margin
	 */
	public void setLeftMargin(int leftMargin) {
	}

	/**
	 *  Sets the value of the <code>showsRootHandles</code> property, which specifies whether the node handles should be
	 *  displayed. The default value of this property depends on the constructor used to create the
	 *  <code>TreeTable</code>. Some look and feels might not support handles; they will ignore this property.
	 * 
	 *  @param showRootHandles <code>true</code> if root handles should be displayed; otherwise, <code>false</code>
	 *                         description: Whether the node handles are to be displayed.
	 *  @see #_showsRootHandles
	 *  @see #getShowsRootHandles
	 */
	public void setShowsRootHandles(boolean showRootHandles) {
	}

	/**
	 *  Returns the value of the <code>showsRootHandles</code> property.
	 * 
	 *  @return the value of the <code>showsRootHandles</code> property
	 * 
	 *  @see #_showsRootHandles
	 */
	public boolean getShowsRootHandles() {
	}

	/**
	 *  Is expand all or collapse all operations are allowed.
	 * 
	 *  @return if expand all operation is allowed.
	 */
	public boolean isExpandAllAllowed() {
	}

	/**
	 *  Sets if expand all or collapse all are allowed. Expand all will recursively go through all tree nodes and expand
	 *  all of them. So if your tree table has a huge number or unlimited number of children nodes, you should disable
	 *  expand all operation because it will never end. This is important because Numpad "*" will trigger expand all. If
	 *  you didn't disable expand all, user might press Numpad "*" key by mistake and freeze the GUI.
	 * 
	 *  @param expandAllAllowed true to enable expand all
	 */
	public void setExpandAllAllowed(boolean expandAllAllowed) {
	}

	/**
	 *  Whether allowing the rows to be expanded and collapsed by the users. Developers can still expand/collapse rows
	 *  using the API.
	 * 
	 *  @return true or false.
	 */
	public boolean isExpandable() {
	}

	/**
	 *  Sets the flag if the rows are allowed to be expanded and collapsed by the users. Default is true.
	 * 
	 *  @param expandable true to allow the rows to be expanded and collapsed by the users.
	 */
	public void setExpandable(boolean expandable) {
	}

	/**
	 *  Gets the expandable column view index. Different from {@link #getExpandableColumn()}, this one will convert the
	 *  index from model index to index. There is no setter for this method, you have to set it through {@link
	 *  #setExpandableColumn(int)}. If you never called setExpandableColumn, this method will always return 0 meaning the
	 *  first visible column will be used to display the +/- icon.
	 * 
	 *  @return the expandable column view index.
	 */
	public int getExpandableColumnViewIndex() {
	}

	/**
	 *  Check if TreeTable should paint the horizontal leg for the row.
	 *  <p>
	 *  The default implementation of this method is to check the isShowLeafNodeTreeLines method.
	 *  <code><pre>
	 *       Row row = getRowAt(rowIndex);
	 *       if (row == null) {
	 *           return false;
	 *       }
	 *       Expandable parent = row.getParent();
	 *       if (row instanceof Expandable && !((Expandable) row).hasChildren() && !isShowLeafNodeTreeLines() && parent instanceof Row) {
	 *           int lastChildIndex = getRowIndex((Row) parent) + TableModelWrapperUtils.getVisibleChildrenCount(getModel(), (Row) parent);
	 *           if (rowIndex != lastChildIndex) {
	 *               return false;
	 *           }
	 *       }
	 *       return true;
	 *  </pre></code>
	 * 
	 *  @param rowIndex the index of the row
	 *  @return true if the horizontal leg should be painted. Otherwise false.
	 * 
	 *  @see #isShowLeafNodeTreeLines()
	 */
	public boolean shouldPaintHorizontalLeg(int rowIndex) {
	}

	/**
	 *  Gets the expandable column.
	 *  <p/>
	 *  Expandable column is the column which has an expand/collapse button and tree lines if needed. Clicking on that
	 *  button will show/hide the child component associated with that row. Due to the limitation of the implementation,
	 *  all cells in that column should be not editable.
	 *  <p/>
	 *  It should be a value between -1 and getColumnCount() - 1. A value as -1 means that you don't want to designate any
	 *  column to be expandable. In this case, the first visible column would always be painted with expand/collapse button
	 *  and tree lines. Any value between 0 and getColumnCount() - 1 means that the visible column with the model index as
	 *  the value will be painted with expand/collapse button and tree lines.
	 *  <p/>
	 *  The default value is -1.
	 * 
	 *  @return the expandable column.
	 */
	public int getExpandableColumn() {
	}

	/**
	 *  Sets the expandable column.
	 * 
	 *  @param expandableColumn new expandable column.
	 *  @see #getExpandableColumn()
	 */
	public void setExpandableColumn(int expandableColumn) {
	}

	/**
	 *  Gets the horizontal leg y position. It is also the +/- icon y center position. By default, it will use half the
	 *  size of cellHeight. You can override this method to return another value in case your cell is not center aligned
	 *  vertically.
	 * 
	 *  @param cellHeight the new cell height
	 *  @return the horizontal leg y position.
	 */
	public int getHorizontalLegPosition(int cellHeight) {
	}

	/**
	 *  Gets the vertical line start position. By default, it will start from the next row of the parent row. You can
	 *  override this method to return another value in case you want to cover the empty space when your row height is
	 *  big.
	 * 
	 *  @param cellHeight the cell height
	 *  @return vertical line start position.
	 */
	public int getVerticalLineStartPosition(int cellHeight) {
	}

	/**
	 *  If the point falls into the expand icon (+/- icon), this method will return the Row. Otherwise, it will return
	 *  null.
	 * 
	 *  @param p the point
	 *  @return the Row that has the +/- icon or null.
	 */
	public Row expandableRowAtPoint(java.awt.Point p) {
	}

	@java.lang.Override
	public java.awt.Rectangle getEditorCellRect(int rowIndex, int columnIndex) {
	}

	/**
	 *  A boolean flag to determine if the rect should always be calculated when painting the grid line and cells. If
	 *  false, it will calculate the rect for the first column once and then add the column width to determine the next
	 *  column cell rect. It returns false in JideTable but subclass can return true (such as in TreeTable and
	 *  HierarchicalTable case).
	 * 
	 *  @return true by default. Since we will calculate the rect differently for the cell that has expand/collapse icon,
	 *          we will have to calculate the rect size for each cell.
	 */
	@java.lang.Override
	public boolean alwaysCalculateCellRect() {
	}

	/**
	 *  Gets the flag if the renderer's preferred height is respected.
	 * 
	 *  @return true or false.
	 */
	public boolean isRespectRenderPreferredHeight() {
	}

	/**
	 *  Sets the flag if the renderer's preferred height is respected. By default, the tree table's first column adds +/-
	 *  icon before the actual renderer. The renderer is painted to cover the whole height of the cell. If this flag is
	 *  set to false, we will use the actual renderer height when painting the renderer.
	 * 
	 *  @param respectRenderPreferredHeight true or false.
	 */
	public void setRespectRenderPreferredHeight(boolean respectRenderPreferredHeight) {
	}

	protected static class TreeTableAction {


		public TreeTable.TreeTableAction(javax.swing.Action action, javax.swing.KeyStroke keyStroke) {
		}

		@java.lang.Override
		public void actionPerformed(java.awt.event.ActionEvent e) {
		}

		protected void expandAll(TreeTable table) {
		}

		protected void collapseAll(TreeTable table) {
		}

		protected boolean expandSelectedRow(TreeTable table, boolean expanded, boolean firstColumnOnly) {
		}

		protected boolean stopEditing(TreeTable table) {
		}

		protected boolean cancelEditing(TreeTable table) {
		}
	}

	protected class ExpandMouseListener {


		protected TreeTable.ExpandMouseListener() {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}
	}

	protected class DelegateExpandMouseInputListener {


		public TreeTable.DelegateExpandMouseInputListener(javax.swing.event.MouseInputListener listener) {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseMoved(java.awt.event.MouseEvent e) {
		}
	}
}
