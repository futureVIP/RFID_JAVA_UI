/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  Header cell renderer for <code>AutoFilterTableHeader</code>.
 */
public class AutoFilterTableHeaderRenderer extends AutoFilterBox implements javax.swing.table.TableCellRenderer {
 {

	public AutoFilterTableHeaderRenderer() {
	}

	public java.awt.Component getTableCellRendererComponent(javax.swing.JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
	}

	protected void customizeAutoFilterBox(AutoFilterBox autoFilterBox) {
	}
}
