/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  <code>JoinTableModel</code> joints several table models horizontally. Although all the table models can have
 *  different row counts, it makes more sense if they have. <code>JoinTableModel</code> will take care of the table
 *  events fired from those models and translate them to the correct table model event for JoinTableModel. It supports
 *  <code>SpanModel</code>, <code>StyleModel</code> and <code>ContextSensitiveTableModel</code> as well. It supports
 *  <code>MultiTableModel</code> too. The first table model will be the header table model, the second model to be the
 *  main table model and the third table model will be the footer table model. All models after the first three models
 *  will be ignored in this case.
 */
public class JoinTableModel extends javax.swing.table.AbstractTableModel implements ColumnIdentifierTableModel, ContextSensitiveTableModel, SpanModel, StyleModel, NavigableModel, MultiTableModel, TableModelsWrapper {
 {

	protected java.util.List _models;

	/**
	 *  Creates an empty <code>JoinTableModel</code>.
	 */
	public JoinTableModel() {
	}

	/**
	 *  Creates an <code>JoinTableModel</code> that joins the table models in the array.
	 * 
	 *  @param models an array of table models to be joined.
	 */
	public JoinTableModel(javax.swing.table.TableModel[] models) {
	}

	/**
	 *  Adds a table model at the end of the <code>JoinTableModel</code>.
	 * 
	 *  @param model the model to be added.
	 */
	public synchronized void addTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Inserts a table model at the specified index of the <code>JoinTableModel</code>.
	 * 
	 *  @param model the model to be added.
	 *  @param index the index where the model will be inserted.
	 */
	public synchronized void addTableModel(javax.swing.table.TableModel model, int index) {
	}

	/**
	 *  Removes a table model from the <code>JoinTableModel</code>.
	 * 
	 *  @param model the model to be removed.
	 */
	public synchronized void removeTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Removes all table models.
	 */
	public synchronized void removeAllTableModels() {
	}

	/**
	 *  Gets the number of table models in the <code>JoinTableModel</code>.
	 * 
	 *  @return the number of table models in the <code>JoinTableModel</code>.
	 */
	public synchronized int getTableModelCount() {
	}

	/**
	 *  Gets the table model at the specific index. The index matches with the order when the table model is added. For
	 *  example, the first added table model index is 0. getTableModel(0) will return that index. Of course, the order
	 *  could change if {@link #addTableModel(javax.swing.table.TableModel,int)} is used.
	 * 
	 *  @param index the index.
	 *  @return the table model at the index.
	 */
	public synchronized javax.swing.table.TableModel getTableModel(int index) {
	}

	public Object getColumnIdentifier(int columnIndex) {
	}

	/**
	 *  Overrides to return the getColumnClass from the underlying table models.
	 * 
	 *  @param columnIndex the column index.
	 *  @return the column class for the column.
	 */
	@java.lang.Override
	public synchronized Class getColumnClass(int columnIndex) {
	}

	/**
	 *  Overrides to return the getColumnName from the underlying table models.
	 * 
	 *  @param columnIndex the column index.
	 *  @return the column name for the column.
	 */
	@java.lang.Override
	public synchronized String getColumnName(int columnIndex) {
	}

	/**
	 *  Overrides to return the isCellEditable from the underlying table models.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return true or false.
	 */
	@java.lang.Override
	public final boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the total number of column count. It is the sum of all table models' column count.
	 * 
	 *  @return the total number of column count.
	 */
	public synchronized int getColumnCount() {
	}

	/**
	 *  Gets the total number of row count. It is the max of all table models' row count.
	 * 
	 *  @return the total number of row count.
	 */
	public synchronized int getRowCount() {
	}

	/**
	 *  Overrides to return the getValueAt from the underlying table models.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the value at the specified row and column index.
	 */
	public synchronized Object getValueAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to call setValueAt of the underlying table models to set the value.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @param aValue      the new value at the specified row and column index.
	 */
	@java.lang.Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex) {
	}

	/**
	 *  Gets the table model which contains the specific column index. For example, if we have three table models that
	 *  have 4, 3, 5 columns respectively. getTableModelForColumn(0 to 3) will return the first model.
	 *  getTableModelForColumn(4 to 6) will return the second model. getTableModelForColumn(7 to 11) will return the
	 *  second model. If the column index is less than 0 or greater than 11, null will be returned.
	 * 
	 *  @param columnIndex the column index
	 *  @return the table model which contains the specific column index.
	 */
	public javax.swing.table.TableModel getActualModel(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to return the getConverterContextAt from the underlying table models, of course, only when the
	 *  underlying table model is ContextSensitiveTableModel. Otherwise null will be returned.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the ConverterContext at the specified row and column index.
	 */
	public ConverterContext getConverterContextAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to return the getEditorContextAt from the underlying table models, of course, only when the underlying
	 *  table model is ContextSensitiveTableModel. Otherwise null will be returned.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the EditorContext at the specified row and column index.
	 */
	public EditorContext getEditorContextAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to return the getCellClassAt from the underlying table models, of course, only when the underlying
	 *  table model is ContextSensitiveTableModel. Otherwise null will be returned.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the CellClass at the specified row and column index.
	 */
	public Class getCellClassAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to return the CellSpan from the underlying table models, of course, only when the underlying table
	 *  model is SpanModel and isCellSpanOn is true. Otherwise null will be returned.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the CellSpan at the specified row and column index.
	 */
	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to return true if any of the underlying table models is SpanModel and the isCellSpanOn is true.
	 * 
	 *  @return return true if any of the underlying table models is SpanModel and the isCellSpanOn is true. Otherwise
	 *          false.
	 */
	public boolean isCellSpanOn() {
	}

	/**
	 *  Overrides to return the CellStyle from the underlying table models, of course, only when the underlying table
	 *  model is StyleModel and isCellStyleOn is true. Otherwise null will be returned.
	 * 
	 *  @param rowIndex    the row index.
	 *  @param columnIndex the column index.
	 *  @return the CellStyle at the specified row and column index.
	 */
	public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to return true if any of the underlying table models is StyleModel and the isCellStyleOn is true.
	 * 
	 *  @return return true if any of the underlying table models is StyleModel and the isCellStyleOn is true. Otherwise
	 *          false.
	 */
	public boolean isCellStyleOn() {
	}

	/**
	 *  Overrides to return true or false depending on the child table models.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return if the cell is navigable.
	 */
	public boolean isNavigableAt(int rowIndex, int columnIndex) {
	}

	/**
	 *  Overrides to return true if any of the underlying table models is StyleModel and the isNavigableOn is true.
	 * 
	 *  @return return true if any of the underlying table models is StyleModel and the isNavigableOn is true. Otherwise
	 *          false.
	 */
	public boolean isNavigationOn() {
	}

	/**
	 *  Gets the column type in MultiTableModel. The returned value is limited to the first three table model. If you
	 *  need something different, you would need to override it to return something else.
	 * 
	 *  @param columnIndex the column index.
	 *  @return HEADER_COLUMN if the column index is part of the first table model, REGULAR_COLUMN if the column index is
	 *          part of the second table model and FOOTER_COLUMN if the column index is part of the third table model.
	 */
	public int getColumnType(int columnIndex) {
	}

	/**
	 *  Get the table index. This is a method MultiTableModel index. It always return 0. If you need something different,
	 *  you would need to override it to return something else.
	 * 
	 *  @param columnIndex the column index.
	 *  @return always 0.
	 */
	public int getTableIndex(int columnIndex) {
	}
}
