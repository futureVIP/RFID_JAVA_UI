/**
 *  The package contains all kinds of components and classes based on JTable for JIDE Grids product.
 */
package com.jidesoft.grid;


/**
 *  A cell editor uss JTextArea as the editor component.
 */
public class MultilineTableCellEditor extends ContextSensitiveCellEditor implements javax.swing.table.TableCellEditor {
 {

	public static EditorContext CONTEXT;

	protected javax.swing.JTextArea _textArea;

	protected javax.swing.JScrollPane _scrollPane;

	/**
	 *  Creates a CellEditor using JTextArea.
	 */
	public MultilineTableCellEditor() {
	}

	protected javax.swing.JScrollPane createScrollPane(javax.swing.JComponent component) {
	}

	/**
	 *  Customizes the text area.
	 */
	protected void customizeTextArea() {
	}

	/**
	 *  Creates a JTextArea used by the cell editor. Subclass can override it to return other type of JTextArea or
	 *  further customize the JTextArea before returning it.
	 * 
	 *  @return a text area field.
	 */
	protected javax.swing.JTextArea createTextArea() {
	}

	public Object getCellEditorValue() {
	}

	public void setCellEditorValue(Object value) {
	}

	public java.awt.Component getTableCellEditorComponent(javax.swing.JTable table, Object value, boolean isSelected, int row, int column) {
	}

	/**
	 *  Gets the text area that is used as the cell editor.
	 * 
	 *  @return the text area.
	 */
	public javax.swing.JTextArea getTextArea() {
	}

	@java.lang.Override
	public boolean isEditorStyleSupported(int editorStyle) {
	}
}
