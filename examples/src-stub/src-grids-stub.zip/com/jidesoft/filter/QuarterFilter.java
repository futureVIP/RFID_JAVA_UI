/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns false in {@link #isValueFiltered(Object)} only if the input value is within in the
 *  quarter as specified. It will return false if the Calendar or the Date in that quarter, regardless the year.
 */
public class QuarterFilter extends DateOrCalendarFilter {

	/**
	 *  Creates a QuarterFilter. The quarter will be set later using setQuarter method.
	 */
	public QuarterFilter() {
	}

	/**
	 *  Creates a QuarterFilter for a particular quarter.
	 * 
	 *  @param quarter the quarter, starting from 1 for the first quarter (including January, February, and March).
	 */
	public QuarterFilter(int quarter) {
	}

	public int getQuarter() {
	}

	public void setQuarter(int quarter) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if the quarter of the two filters are same. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
