/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


public class FilterResource {

	public FilterResource() {
	}

	public static java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	}
}
