/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> that always returns true in {@link #isValueFiltered(Object)} no matter what the input value
 *  is.
 */
public class NoneFilter extends AbstractFilter {

	/**
	 *  Creates a NoneFilter.
	 */
	public NoneFilter() {
	}

	/**
	 *  Checks if the value is allowed.
	 * 
	 *  @param value the value to check.
	 *  @return always true
	 */
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Check if this filter is stricter than the input filter. This method always returns true as NoneFilter is stricter
	 *  than or the same strict as any other filters.
	 * 
	 *  @param inputFilter the input filter
	 *  @return always true
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
