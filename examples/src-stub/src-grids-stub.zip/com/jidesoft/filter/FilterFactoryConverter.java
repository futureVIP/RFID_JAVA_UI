/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  Converters to convert the FilterFactory to String. It only supports toString. The fromString is not supported in this
 *  converter.
 */
public class FilterFactoryConverter {

	public FilterFactoryConverter(java.util.Locale locale) {
	}

	/**
	 *  Call {@link com.jidesoft.filter.FilterFactory#getConditionString(java.util.Locale)}.
	 * 
	 *  @param object  the FilterFactory.
	 *  @param context usually is null in this particular case.
	 *  @return the condition string of the FilterFactory.
	 */
	public String toString(Object object, ConverterContext context) {
	}

	public boolean supportToString(Object object, ConverterContext context) {
	}

	public Object fromString(String string, ConverterContext context) {
	}

	public boolean supportFromString(String string, ConverterContext context) {
	}
}
