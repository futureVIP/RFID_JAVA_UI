/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A filter implements filtering a string based the wildcards. It uses the following three chars as the wildcards.
 *  <pre>
 *  <ul>
 *  <li> '?' The question mark indicates there is exact one of missing element. For example, colo?r matches
 *  "colour" but not "color" or "colouur".
 *  <li>'*' The asterisk indicates there are zero or more of the missing elements. For example, ab*c matches
 *  "abc", "abbc", "abdbc", and so on.
 *  <li>'+' The plus sign indicates there are at least one of the missing elements. For example, ab+c matches
 *  "abbc", "abdbc", but not "abc".
 *  </ul>
 *  </pre>
 */
public class WildcardFilter extends RegexFilter {

	public WildcardFilter() {
	}

	public WildcardFilter(String pattern) {
	}

	@java.lang.Override
	public void setPattern(String pattern) {
	}

	/**
	 *  Converts the wildcards enabled pattern to the pattern used in Java Pattern class.
	 * 
	 *  @param pattern the input pattern.
	 *  @return the pattern string used by {@link java.util.regex.Pattern}.
	 */
	@java.lang.Override
	protected String convertFromPatternToRegex(String pattern) {
	}

	@java.lang.Override
	public boolean isValueFiltered(Object value) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
