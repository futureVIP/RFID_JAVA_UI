/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  A <code>Filter</code> returns opposite value in {@link #isValueFiltered(Object)} of {@link LikeFilter}.
 */
public class NotLikeFilter extends LikeFilter {

	public NotLikeFilter(String pattern) {
	}

	@java.lang.Override
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Gets the operator. It will return " NOT LIKE " by default.
	 * 
	 *  @return the operator.
	 */
	@java.lang.Override
	public String getOperator() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
