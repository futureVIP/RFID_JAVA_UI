/**
 *  The package contains filter related classes for JIDE Grids product.
 */
package com.jidesoft.filter;


/**
 *  An filter which filters a value if all of its filters filter away the value. In the other word, it is an OR logic.
 */
public class OrFilter extends MultipleFilters {

	public OrFilter() {
	}

	public OrFilter(Filter[] filters) {
	}

	/**
	 *  This method will call isValueFiltered from its filters. If one of the filters returns false, this method will
	 *  return false.
	 * 
	 *  @param value the value to be filtered
	 *  @return false if one of the filters returns false. Otherwise true.
	 */
	public boolean isValueFiltered(Object value) {
	}

	/**
	 *  Check if this filter is stricter than the input filter while the two filters are with the same class.
	 *  <p/>
	 *  Please be noted that it's a very loose comparison, we will compare the filters contained one by one only. Don't
	 *  expect it to be very concise.
	 * 
	 *  @param inputFilter the input filter
	 *  @return true if all the filters contained in this filter are stricter than the input filter AND the number of
	 *          filters are smaller or equal than the input filter. Otherwise false.
	 */
	@java.lang.Override
	public boolean stricterThan(Filter inputFilter) {
	}
}
