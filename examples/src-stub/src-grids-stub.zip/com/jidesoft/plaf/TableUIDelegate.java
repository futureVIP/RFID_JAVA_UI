package com.jidesoft.plaf;


public interface TableUIDelegate {
}
