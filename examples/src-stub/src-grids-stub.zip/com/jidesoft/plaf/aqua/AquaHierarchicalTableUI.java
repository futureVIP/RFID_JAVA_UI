package com.jidesoft.plaf.aqua;


public class AquaHierarchicalTableUI extends AquaCellSpanTableUI {

	public AquaHierarchicalTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected com.jidesoft.plaf.TableUIDelegate createUIDelegate() {
	}
}
