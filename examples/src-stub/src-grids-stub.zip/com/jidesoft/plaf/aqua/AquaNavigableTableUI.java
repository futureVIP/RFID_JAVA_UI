package com.jidesoft.plaf.aqua;


public class AquaNavigableTableUI extends AquaJideTableUI {

	public AquaNavigableTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected com.jidesoft.plaf.TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}
}
