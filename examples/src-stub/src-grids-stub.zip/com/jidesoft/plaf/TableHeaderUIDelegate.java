package com.jidesoft.plaf;


public class TableHeaderUIDelegate {

	public TableHeaderUIDelegate() {
	}
}
