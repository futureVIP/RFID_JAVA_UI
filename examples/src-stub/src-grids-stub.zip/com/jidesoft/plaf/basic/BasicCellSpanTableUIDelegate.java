package com.jidesoft.plaf.basic;


public class BasicCellSpanTableUIDelegate extends BasicNavigableTableUIDelegate {

	public BasicCellSpanTableUIDelegate(javax.swing.JTable table, javax.swing.CellRendererPane rendererPane) {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	protected void paintSpanDraggedArea(java.awt.Graphics g, int rMin, int rMax, javax.swing.table.TableColumn draggedColumn, int distance) {
	}
}
