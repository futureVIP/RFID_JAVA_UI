package com.jidesoft.plaf.basic;


public class BasicCellSpanTableUI extends BasicNavigableTableUI {

	public BasicCellSpanTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected com.jidesoft.plaf.TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
