package com.jidesoft.plaf.basic;


public class BasicNavigableTableUI extends BasicJideTableUI {

	public BasicNavigableTableUI() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	protected com.jidesoft.plaf.TableUIDelegate createUIDelegate() {
	}

	@java.lang.Override
	protected javax.swing.event.MouseInputListener createMouseInputListener() {
	}
}
