package com.jidesoft.plaf.basic;


public class BasicHierarchicalTableUIDelegate extends BasicCellSpanTableUIDelegate {

	public BasicHierarchicalTableUIDelegate(javax.swing.JTable table, javax.swing.CellRendererPane rendererPane) {
	}

	@java.lang.Override
	public void paintGrid(java.awt.Graphics g, int rMin, int rMax, int cMin, int cMax) {
	}

	@java.lang.Override
	public void paintDraggedArea(java.awt.Graphics g, int rMin, int rMax, javax.swing.table.TableColumn draggedColumn, int distance) {
	}

	@java.lang.Override
	public void paintCell(java.awt.Graphics g, java.awt.Rectangle cellRect, int row, int column) {
	}
}
