/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>AbstractGanttEntryRelationModel</code> is an abstract implementation of <code>GanttEntryRelationModel</code>.
 *  It implements all the methods related to <code>GanttEntryRelationModel</code> but leaves all other methods for
 *  subclass to implement.
 * 
 *  @param <S> The type of the GanttEntry in the model.
 */
public abstract class AbstractGanttEntryRelationModel implements GanttEntryRelationModel, java.io.Serializable {
 {

	/**
	 *  List of listeners
	 */
	protected javax.swing.event.EventListenerList listenerList;

	protected AbstractGanttEntryRelationModel() {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the gantt model occurs.
	 * 
	 *  @param l the GanttEntryRelationListener
	 */
	public void addGanttEntryRelationListener(GanttEntryRelationListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the data model occurs.
	 * 
	 *  @param l the GanttEntryRelationListener
	 */
	public void removeGanttEntryRelationListener(GanttEntryRelationListener l) {
	}

	/**
	 *  Returns an array of all the gantt model listeners registered on this model.
	 * 
	 *  @return all of this model's <code>GanttEntryRelationListener</code>s or an empty array if no gantt model
	 *          listeners are currently registered
	 * 
	 *  @see #addGanttEntryRelationListener
	 *  @see #removeGanttEntryRelationListener
	 */
	public GanttEntryRelationListener[] getGanttEntryRelationListeners() {
	}

	/**
	 *  Notifies all listeners that all Gantt entry relations may have changed. The number of relations may also have
	 *  changed and the <code>GanttChart</code> should redraw from scratch. The structure of the chart (as in the order
	 *  of the Gantt entries) is assumed to be the same.
	 * 
	 *  @see com.jidesoft.gantt.GanttModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireGanttEntryRelationChanged() {
	}

	/**
	 *  Notifies all listeners that a new relation is added.
	 * 
	 *  @param relation the related to be added.
	 */
	public void fireGanttEntryRelationAdded(GanttEntryRelation relation) {
	}

	/**
	 *  Notifies all listeners that an existing relation is removed.
	 * 
	 *  @param relation the relation to be removed
	 */
	public void fireGanttEntryRealtionRemoved(GanttEntryRelation relation) {
	}

	/**
	 *  Notifies all listeners that all relations are removed
	 */
	public void fireGanttEntryRelationCleared() {
	}

	/**
	 *  Forwards the given notification event to all <code>GanttEntryRelationListeners</code> that registered themselves
	 *  as listeners for this table model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addGanttEntryRelationListener
	 *  @see com.jidesoft.gantt.GanttModelEvent
	 *  @see javax.swing.event.EventListenerList
	 */
	public void fireGanttEntryRelationChanged(GanttEntryRelationEvent e) {
	}
}
