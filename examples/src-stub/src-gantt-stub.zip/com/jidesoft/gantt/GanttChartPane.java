/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>GanttChartPane</code> is a pane that contains both TreeTable and GanttChart.
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 *  @param <S> The type of the GanttEntries in the model.
 */
public class GanttChartPane extends JideSplitPane {

	public GanttChartPane(GanttModel ganttModel) {
	}

	public GanttModel getGanttModel() {
	}

	public void setGanttModel(GanttModel ganttModel) {
	}

	public void setRowHeight(int height) {
	}

	public GanttChart getGanttChart() {
	}

	public TreeTable getTreeTable() {
	}

	protected void initComponent() {
	}

	/**
	 *  Creates the scroll pane for the TreeTable and the GanttChart.
	 * 
	 *  @param component the component
	 *  @return the scroll pane.
	 */
	protected javax.swing.JScrollPane createScrollPane(java.awt.Component component) {
	}

	/**
	 *  Allows sub classes to customize or wrap the scroll pane of the TreeTable and GanttChart. For example to wrap them
	 *  in a JXLayer with MouseScrollableUI.
	 *  <p/>
	 *  By default, the scroll pane is just returned for the TreeTable. For the GanttChart, we will set a CornerScroller
	 *  to the lower right corner of the scroll pane.
	 * 
	 *  @param scrollPane the scroll pane for the table and the chart.
	 *  @return The (wrapper) scroll pane.
	 */
	protected java.awt.Component customizeScrollPane(javax.swing.JScrollPane scrollPane) {
	}

	/**
	 *  To customize the panel above the table header, override this method and add your custom component with the
	 *  BorderLayout.CENTER constraint for the best result.
	 * 
	 *  @return By default returns a JPanel with a south line border and a BorderLayout.
	 */
	protected javax.swing.JComponent createTableHeaderComponent() {
	}

	/**
	 *  By default, returns a TreeTable with setFillsViewPortHeight set to true and installs the table header component
	 *  with the actual table header in the enclosing scroll pane instance column header view.
	 *  <p/>
	 *  If the table model is not wrapped in a SortableTreeTableModel, sorting is disabled.
	 * 
	 *  @param model                The ITreeTableModel of the GanttModel (which should also implement TableModel) or
	 *                              null if the GanttModel is null.
	 *  @param tableHeaderComponent A JComponent which should be placed above the table header in case the gantt chart
	 *                              has multiple scale tiers.
	 *  @return Returns the TreeTable for GanttChartPane
	 */
	protected TreeTable createTreeTable(javax.swing.table.TableModel model, javax.swing.JComponent tableHeaderComponent) {
	}

	/**
	 *  By default, returns a GanttChart with a DefaultPeriodConverter.
	 * 
	 *  @param ganttModel The GanttModel (can be null);
	 *  @return Returns the GanttChart for the the GanttChartPane.
	 */
	protected GanttChart createGanttChart(GanttModel ganttModel) {
	}
}
