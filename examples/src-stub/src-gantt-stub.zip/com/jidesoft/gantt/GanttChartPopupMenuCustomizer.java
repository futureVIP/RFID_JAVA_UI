/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  An interface to allow user to customize for the GanttChartPopupMenuInstaller.
 */
public interface GanttChartPopupMenuCustomizer {

	/**
	 *  Customizes the popup menu.
	 * 
	 *  @param ganttChart  the GanttChart
	 *  @param popup       the popup menu to be displayed
	 *  @param clickingRow the row that is clicked
	 *  @param p           the clicked point
	 */
	public void customizePopupMenu(GanttChart ganttChart, javax.swing.JPopupMenu popup, int clickingRow, java.awt.Point p);
}
