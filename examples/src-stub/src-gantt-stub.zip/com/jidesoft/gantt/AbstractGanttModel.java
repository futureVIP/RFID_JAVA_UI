/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  This abstract class provides default implementations for most of the methods in the <code>GanttModel</code>
 *  interface. It takes care of the management of listeners and provides some conveniences for generating
 *  <code>GanttModelEvents</code> and dispatching them to the listeners. To create a concrete <code>GanttModel</code> as
 *  a subclass of <code>AbstractGanttModel</code> you need only provide implementations for the following four methods:
 *  <p/>
 *  <code><pre>
 *  public ITreeTableModel<S> getTreeTableModel();
 *  public Range<T> getRange();
 *  public ScaleModel<T> getScaleModel();
 *  public GanttEntryRelationModel<S> getGanttEntryRelationModel();
 *  </pre></code>
 *  <p/>
 * 
 *  @param <T> The type of the bases unit of the scale, for example Date or Integer.
 *  @param <S> The type of the GanttEntries in the model.
 */
public abstract class AbstractGanttModel implements GanttModel, java.io.Serializable {
 {

	/**
	 *  List of listeners
	 */
	protected javax.swing.event.EventListenerList listenerList;

	protected AbstractGanttModel() {
	}

	public int getEntryCount() {
	}

	@java.lang.SuppressWarnings("unchecked")
	public GanttEntry getEntryAt(int index) {
	}

	public int getIndexOf(GanttEntry entry) {
	}

	/**
	 *  Adds a listener to the list that's notified each time a change to the gantt model occurs.
	 * 
	 *  @param l the GanttModelListener
	 */
	public void addGanttModelListener(GanttModelListener l) {
	}

	/**
	 *  Removes a listener from the list that's notified each time a change to the data model occurs.
	 * 
	 *  @param l the GanttModelListener
	 */
	public void removeGanttModelListener(GanttModelListener l) {
	}

	/**
	 *  Returns an array of all the gantt model listeners registered on this model.
	 * 
	 *  @return all of this model's <code>GanttModelListener</code>s or an empty array if no gantt model listeners are
	 *          currently registered
	 * 
	 *  @see #addGanttModelListener
	 *  @see #removeGanttModelListener
	 */
	public GanttModelListener[] getGanttModelListeners() {
	}

	/**
	 *  Notifies all listeners that all gantt enties may have changed. The number of gantt enties may also have changed
	 *  and the <code>GanttChart</code> should redraw the chart from scratch.
	 * 
	 *  @see GanttModelEvent
	 *  @see EventListenerList
	 */
	public void fireGanttDataChanged() {
	}

	/**
	 *  Notifies all listeners that rows in the range <code>[firstRow, lastRow]</code>, inclusive, have been inserted.
	 * 
	 *  @param firstRow the first row
	 *  @param lastRow  the last row
	 *  @see GanttModelEvent
	 *  @see EventListenerList
	 */
	public void fireGanttEntriesInserted(int firstRow, int lastRow) {
	}

	/**
	 *  Notifies all listeners that rows in the range <code>[firstRow, lastRow]</code>, inclusive, have been updated.
	 * 
	 *  @param firstRow the first row
	 *  @param lastRow  the last row
	 *  @see GanttModelEvent
	 *  @see EventListenerList
	 */
	public void fireGanttEntriesUpdated(int firstRow, int lastRow) {
	}

	/**
	 *  Notifies all listeners that rows in the range <code>[firstRow, lastRow]</code>, inclusive, have been deleted.
	 * 
	 *  @param firstRow the first row
	 *  @param lastRow  the last row
	 *  @see GanttModelEvent
	 *  @see EventListenerList
	 */
	public void fireGanttEntriesDeleted(int firstRow, int lastRow) {
	}

	/**
	 *  Forwards the given notification event to all <code>GanttModelListeners</code> that registered themselves as
	 *  listeners for this gantt model.
	 * 
	 *  @param e the event to be forwarded
	 *  @see #addGanttModelListener
	 *  @see GanttModelEvent
	 *  @see EventListenerList
	 */
	public void fireGanttChanged(GanttModelEvent e) {
	}
}
