/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  <code>MutableGanttEntry</code> extends <code>GanttEntry</code> and adds setters for the range and the completion.
 * 
 *  @param <T> The type of the bases unit of the range, for example Date or Integer.
 */
public interface MutableGanttEntry extends GanttEntry {
 {

	/**
	 *  @param startInstant The new start instant for this GanttEntry.
	 *  @param endInstant   The new end instant for this GanttEntry.
	 *  @return Returns the new Range of this GanttEntry.
	 */
	public <any> setRange(Object startInstant, Object endInstant);

	/**
	 *  @return Return true to allow this entry's range to be modified by the user.
	 */
	public boolean isRangeEditable();

	/**
	 *  A double value between [0.0, 1.0] representing the completion of the entry.
	 * 
	 *  @param completion The new completion for the GanttEntry.
	 */
	public void setCompletion(double completion);

	/**
	 *  @return Return true to allow this entry's completion to be modified by the user.
	 */
	public boolean isCompletionEditable();
}
