/**
 *  The package contains classes related to JIDE Gantt Chart product.
 */
package com.jidesoft.gantt;


/**
 *  This is a TreeTableModel implementation for DefaultGanttModel. It will automatically return 4 columns with the corresponding
 *  column name. It will also try to listen to the table model event from sub entry changes then fire a customized table
 *  model event so that the {@link com.jidesoft.gantt.DefaultGanttModel} could fire correct {@link com.jidesoft.gantt.GanttModelEvent}
 *  with correct {@link com.jidesoft.gantt.SubEntryGanttEntry} information.
 */
public class DefaultGanttTreeTableModel extends TreeTableModel {

	/**
	 *  Default constructor.
	 */
	public DefaultGanttTreeTableModel() {
	}

	/**
	 *  Constructor.
	 * 
	 *  @param rows the gantt entries.
	 */
	public DefaultGanttTreeTableModel(java.util.List rows) {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	@java.lang.Override
	protected ExpandableRow createRoot() {
	}
}
