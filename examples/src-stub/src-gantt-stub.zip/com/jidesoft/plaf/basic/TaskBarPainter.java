package com.jidesoft.plaf.basic;


/**
 *  <code>TaskBarPainter</code> is an interface to paint the task bar.
 */
public interface TaskBarPainter {

	public void paintTask(java.awt.Graphics2D g2d, com.jidesoft.gantt.TaskBar taskBar, java.awt.Rectangle rect, java.awt.Insets insets, java.awt.Color color, java.awt.Color borderColor, java.awt.Color percentageColor);

	public void paintTaskGroup(java.awt.Graphics2D g2d, com.jidesoft.gantt.TaskBar taskBar, java.awt.Rectangle rect, java.awt.Insets insets, java.awt.Color color, java.awt.Color borderColor, java.awt.Color percentageColor);

	public void paintMilestone(java.awt.Graphics2D g2d, com.jidesoft.gantt.TaskBar taskBar, java.awt.Rectangle rect, java.awt.Insets insets, java.awt.Color color, java.awt.Color borderColor, java.awt.Color percentageColor);
}
