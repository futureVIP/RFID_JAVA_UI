package com.jidesoft.plaf;


public interface PeriodHeaderPainter {

	public void paintPeriodHeaders(com.jidesoft.scale.ScaleArea scaleArea, java.awt.Graphics graphics);
}
