package com.jidesoft.plaf;


public interface GanttEntryRelationPainter {

	public void paintRelation(java.awt.Graphics graphics, com.jidesoft.gantt.GanttChart ganttChart, com.jidesoft.gantt.GanttEntryRelation relation, boolean selected, boolean focused);
}
