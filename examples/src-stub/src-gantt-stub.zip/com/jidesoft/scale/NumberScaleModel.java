/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  A simple integer numbers scale that ranges from 0 to 100.
 */
public class NumberScaleModel extends AbstractScaleModel {

	public NumberScaleModel() {
	}

	public NumberScaleModel(int start, int end, NumberPeriod[] periods) {
	}

	public Integer getInstantAt(long position) {
	}

	public Integer getPeriodEnd(Period period, Integer instant) {
	}

	public Integer getPeriodStart(Period period, Integer instant) {
	}

	public long getPosition(Integer instant) {
	}
}
