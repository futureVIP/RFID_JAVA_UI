/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  A <code>PeriodConverter</code> is responsible for providing UI with the (tooltip) text of a specific period
 *  interval.
 * 
 *  @param <T> The base unit of the ScaleModel to render the periods for.
 */
public interface PeriodConverter {

	/**
	 *  Gets the period display name. The display name will be used in the places to represent the period.
	 * 
	 *  @return the display name for a particular period.
	 */
	public String getDisplayName();

	/**
	 *  Gets the short text representing the period. It can be used as the scale area header text.
	 * 
	 *  @param startInstant the start instance of the period
	 *  @param endInstant   the end instance of the period
	 *  @return the short text representing the period.
	 */
	public String getText(Object startInstant, Object endInstant);

	/**
	 *  Gets the long text representing the period. It can be used as the scale area header tooltip.
	 * 
	 *  @param startInstant the start instance of the period
	 *  @param endInstant   the end instance of the period
	 *  @return the long text representing the period.
	 */
	public String getDescription(Object startInstant, Object endInstant);

	/**
	 *  Getes the prototype value. The value represents the longest expected string length for the period for the getText
	 *  method.
	 * 
	 *  @return a value which represents the longest expected string length for the period to calculate the preferred
	 *          with.
	 */
	public Object getPrototypeDisplayValue();
}
