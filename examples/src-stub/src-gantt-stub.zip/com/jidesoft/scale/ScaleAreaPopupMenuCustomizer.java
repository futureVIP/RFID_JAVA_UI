/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  A popup menu customizer for the ScaleArea.
 * 
 *  @param <T> The base unit of the scale.
 */
public interface ScaleAreaPopupMenuCustomizer {

	public void customizePopup(javax.swing.JPopupMenu menu, ScaleArea scaleArea, Period clickedPeriod, Object clickedInstant);
}
