/**
 *  The package contains classes related to ScaleModel and ScaleArea in JIDE Gantt Chart product.
 */
package com.jidesoft.scale;


/**
 *  A tagging interface for objects which represents a period in a ScaleModel. The period is a range. It could be a range
 *  of date or a number range.
 */
public interface Period {
}
