package com.jidesoft.utils;


public class Q {

	public Q() {
	}

	public static boolean zz(int product) {
	}
}
