package com.jidesoft.swing;


/**
 *  A simple splash screen that allows to display company logo, product version information etc
 *  during application startup.
 *  <pre><code>
 *  SplashScreen.create(an ImageIcon);
 *  SplashScreen.show(); // to show it
 *  ...   // applicate starts up
 *  SplashScreen.hide(); // to hide it
 *  </code></pre>
 * 
 *  @deprecated We will not work on this component in the future. In JDK6, Sun introduced
 *              SplashScreen component which is much better because it will be shown as soon as JVM
 *              started. We suggest you to use that SplashScreen instead of this one. Hence we
 *              decided to deprecate this class.
 */
@java.lang.Deprecated
public class SplashScreen {

	public SplashScreen() {
	}

	/**
	 *  Create the splash with an image.
	 * 
	 *  @param icon
	 */
	public static void create(javax.swing.ImageIcon icon) {
	}

	/**
	 *  Show the splash screen.
	 */
	public static void show() {
	}

	/**
	 *  Hide the spash screen.
	 */
	public static void hide() {
	}
}
