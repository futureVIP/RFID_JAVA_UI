package com.jidesoft.swing;


/**
 *  <code>LayoutPersistenceManager</code> can manage multiple LayoutPersistences as one unit. Right now
 *  <code>DockingManager</code> and <code>DockableBarManager</code> are both LayoutPersistence. If user call saveLayout
 *  on both managers, you will end up with two layout files (or two entries in registry). If user didn't set profile key
 *  correctly, the two could even step on each other. That's why introduce <code>LayoutPersistenceManager</code>.
 *  <p/>
 *  If you use <code>DefaultDockableBarHolder</code> (for Action Framework only) or <code>DefaultDockableHolder</code>
 *  (for Docking Framework only) as your JFrame, there is no change to the way you load/save layout.
 *  <p/>
 *  If you are using <code>DefaultDockableBarDockableHolder</code>, you should call all layout related methods on
 *  getLayoutPersistence(). For example, <code>frame.getLayoutPersistence().saveLayoutData()</code>,
 *  <code>frame.getLayoutPersistence().setProfileKey()</code>
 *  <p/>
 *  If you are not using <code>DefaultDockableBarDockableHolder</code> for some reason, you need to add some code to make
 *  it happen.
 *  <p/>
 *  First, create a new field call LayoutPersistenceManager _layoutPersistence. After initiaization of DockingManager and
 *  DockableBarManager, call the code below.
 *  <pre><code>
 *   _layoutPersistence = new LayoutPersistenceManager();
 *   _layoutPersistence.addLayoutPersistence(getDockableBarManager());
 *   _layoutPersistence.addLayoutPersistence(getDockingManager());
 *  </code></pre>
 *  <br>Then add a new method. See below.
 *  <pre><code>
 *   public LayoutPersistence getLayoutPersistence() {
 *       return _layoutPersistence;
 *   }
 *  </code></pre>
 *  Now in your code to use layout, call those layout methods use getLayoutPersistence() you just added. For example,
 *  when you save layout, call getLayoutPersistence().saveLayoutData(). When loading layout, call
 *  getLayoutPersistence().loadLayoutData(). Or if you want to change profile key, call
 *  getLayoutPersistence().setProfileKey(newKey).
 *  <p/>
 *  A2. SampleVsnet example is such an example using <code>DefaultDockableBarDockableHolder</code>. You can always refer
 *  to its source code to find out how to use the class.
 */
public class LayoutPersistenceManager extends AbstractLayoutPersistence {

	public static final String NODE_DOCKING_MANAGER = "DockingManager";

	public static final String NODE_DOCKABLE_BAR_MANAGER = "DockableBarManager";

	public static final String NODE_DOCUMENT_PANE = "DocumentPane";

	public LayoutPersistenceManager() {
	}

	public void addLayoutPersistence(LayoutPersistence layoutPersistence) {
	}

	public void removeLayoutPersistence(LayoutPersistence layoutPersistence) {
	}

	public void clear() {
	}

	@java.lang.Override
	public boolean loadLayoutFrom(org.w3c.dom.Document document) {
	}

	/**
	 *  Load layout data from an InputStream that specified as <code>in</code> parameter. If any exception happens during
	 *  the read, it will call resetLayout() to use default layout.
	 * 
	 *  @param in the InputStream where the layout data will be read from.
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *          load the layout.)
	 */
	public boolean loadLayoutFrom(java.io.InputStream in) {
	}

	/**
	 *  Did the loadLayoutFrom(InputStream in) method load successfully from the input stream (false indicates that it
	 *  called resetToDefault to load the layout.) This method can be called immediately after the
	 *  loadLayoutFrom(InputStream in) call to determine if a specific LayoutPersistence was forced to call
	 *  resetToDefault.
	 * 
	 *  @return boolean did it load successfully from the input stream (false indicates that it called resetToDefault to
	 *          load the layout.)
	 */
	public boolean isLoadDataSuccessful() {
	}

	@java.lang.Override
	public void saveLayoutTo(org.w3c.dom.Document document) {
	}

	public void saveLayoutTo(java.io.OutputStream out) {
	}

	public void resetToDefault() {
	}

	public void beginLoadLayoutData() {
	}

	@java.lang.Override
	public void loadInitialLayout(String layoutFile) {
	}

	@java.lang.Override
	public void loadInitialLayout(java.io.InputStream layoutStream) {
	}

	public void loadInitialLayout(org.w3c.dom.Document layoutDocument) {
	}

	@java.lang.Override
	public void setUseFrameBounds(boolean useFrameBounds) {
	}

	@java.lang.Override
	public void setUseFrameState(boolean useFrameState) {
	}

	@java.lang.Override
	public void setLayoutDirectory(String layoutDirectory) {
	}

	@java.lang.Override
	public void setVersion(short version) {
	}

	@java.lang.Override
	public void setUsePref(boolean usePref) {
	}

	@java.lang.Override
	public void setProfileKey(String profileKey) {
	}

	@java.lang.Override
	public boolean isLast() {
	}

	@java.lang.Override
	public void setLast(boolean last) {
	}
}
