package com.jidesoft.grid;


/**
 *  <tt>CalculatedTableModel</tt> allows user to create a new table model based on an existing table model using column
 *  based conversion. For example, you can only expose some columns in the existing table model to the new table model by
 *  using {@link #addColumn(CalculatedColumn)} with {@link SingleColumn}.
 */
public class CalculatedTableModel extends DefaultColumnTableModelWrapper {

	/**
	 *  The constructor.
	 * 
	 *  @param model the original table model.
	 */
	public CalculatedTableModel(javax.swing.table.TableModel model) {
	}

	/**
	 *  Gets the CalculatedColumn instance at the column.
	 * 
	 *  @param columnIndex the column index
	 *  @return the CalculatedColumn instance.
	 */
	public CalculatedColumn getCalculatedColumnAt(int columnIndex) {
	}

	@java.lang.Override
	public int getActualColumnAt(int column) {
	}

	@java.lang.Override
	public final int getVisualColumnAt(int actualColumn) {
	}

	@java.lang.Override
	public Object getValueAt(int row, int column) {
	}

	@java.lang.Override
	public void setValueAt(Object value, int row, int column) {
	}

	@java.lang.Override
	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public Object getColumnIdentifier(int column) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	@java.lang.Override
	public boolean isCellEditable(int row, int column) {
	}

	@java.lang.Override
	public Class getCellClassAt(int row, int column) {
	}

	@java.lang.Override
	public EditorContext getEditorContextAt(int row, int column) {
	}

	@java.lang.Override
	public ConverterContext getConverterContextAt(int row, int column) {
	}

	@java.lang.Override
	public final int[] getIndexes() {
	}

	@java.lang.Override
	public final void setIndexes(int[] indexes) {
	}

	/**
	 *  Gets the depending columns of the column.
	 * 
	 *  @param column the column index
	 *  @return all columns directly depending on the column.
	 */
	protected int[] getDependingColumnsOf(int column) {
	}

	@java.lang.Override
	public void tableCellsUpdated(int columnIndex, int firstRow, int lastRow) {
	}

	/**
	 *  Adds all columns from the original table model.
	 *  <p/>
	 *  Since you could select part of the columns in the original table model, JIDE don't invoke this method by default
	 *  in the constructor. Please make sure you will invoke this method to include all existing columns in the original
	 *  table model.
	 */
	public void addAllColumns() {
	}

	/**
	 *  Adds a new CalculatedColumn.
	 * 
	 *  @see #addColumns(java.util.Collection)
	 *  @param column the new column
	 */
	public void addColumn(CalculatedColumn column) {
	}

	/**
	 *  Adds a set of new CalculatedColumns.
	 * 
	 *  @param columns the new columns
	 */
	public void addColumns(java.util.Collection columns) {
	}

	/**
	 *  Removes an existing CalculatedColumn.
	 * 
	 *  @see #removeColumns(java.util.Collection)
	 *  @param column the column
	 */
	public void removeColumn(CalculatedColumn column) {
	}

	/**
	 *  Removes a set of existing CalculatedColumns.
	 * 
	 *  @param columns the columns
	 */
	public void removeColumns(java.util.Collection columns) {
	}
}
