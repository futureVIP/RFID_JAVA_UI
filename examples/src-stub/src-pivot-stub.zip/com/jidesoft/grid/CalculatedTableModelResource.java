package com.jidesoft.grid;


public class CalculatedTableModelResource {

	public CalculatedTableModelResource() {
	}

	public static java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	}
}
