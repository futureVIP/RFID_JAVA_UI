/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public interface PostEventSupport {

	public PostEventAction[] getPostEventActions();

	public void addPostAction(PostEventAction action);

	public void removePostAction(PostEventAction action);

	public void clearPostActions();
}
