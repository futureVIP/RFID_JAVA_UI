/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  AggregateTableColumnChooserDialog is a dialog to allow user to select the columns to be displayed in a JTable using a
 *  CheckBoxList.
 */
public class AggregateTableColumnChooserDialog extends TableColumnChooserDialog {

	public AggregateTableColumnChooserDialog(java.awt.Dialog owner, String title, AggregateTable table) {
	}

	public AggregateTableColumnChooserDialog(java.awt.Frame owner, String title, AggregateTable table) {
	}

	protected String getName(int index) {
	}

	protected boolean isColumnVisible(int index) {
	}

	protected void showOrHideColumns(int[] selectedModelIndices) {
	}
}
