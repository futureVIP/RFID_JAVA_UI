/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  TableCellRenderer for HeaderTable.
 */
public class HeaderTableCellRenderer extends ExpandableTableCellRenderer {

	protected PivotTablePane _pivotTablePane;

	public HeaderTableCellRenderer() {
	}

	public HeaderTableCellRenderer(PivotTablePane pivotTablePane) {
	}

	@java.lang.Override
	protected void customizeCellRenderer(javax.swing.JTable table, Expandable expandable, java.awt.Component ret, int rowIndex, int columnIndex) {
	}

	@java.lang.Override
	protected ExpandablePanel createExpandablePanel(CategorizedTable table) {
	}

	@java.lang.Override
	protected Object prepareValue(Object value) {
	}
}
