/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  The default implementation for PivotEditingProvider. The assumption is the data source is TableModelPivotDataSource
 *  and the original table model is a DefaultTableModel.
 */
public class DefaultPivotEditingProvider extends AbstractPivotEditingProvider {

	public DefaultPivotEditingProvider() {
	}

	public int addRow(IPivotDataModel model) {
	}

	public void removeRow(IPivotDataModel model, int rowIndex) {
	}
}
