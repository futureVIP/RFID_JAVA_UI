/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class CornerTableModel extends javax.swing.table.AbstractTableModel {

	public CornerTableModel(IPivotDataModel pivotDataModel) {
	}

	public int getRowCount() {
	}

	public int getColumnCount() {
	}

	public Object getValueAt(int rowIndex, int columnIndex) {
	}

	public CellSpan getCellSpanAt(int rowIndex, int columnIndex) {
	}

	public boolean isCellSpanOn() {
	}

	/**
	 *  Gets the cell style at the specified cell. This method is final. Please use {@link
	 *  PivotDataModel#setCellStyleProvider(PivotCellStyleProvider)} to provide cell style for HeaderTable.
	 * 
	 *  @param rowIndex
	 *  @param columnIndex
	 *  @return the cell style at the specified cell.
	 */
	public final CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	public final boolean isCellStyleOn() {
	}

	/**
	 *  Gets the PivotDataModel.
	 * 
	 *  @return the PivotDataModel.
	 */
	public IPivotDataModel getPivotDataModel() {
	}

	/**
	 *  Gets the pivot field associated with the cell.
	 * 
	 *  @param rowIndex    the row index
	 *  @param columnIndex the column index
	 *  @return the pivot field associated with the cell. It could return null for certain cells when there are more than
	 *          one data fields.
	 */
	public PivotField getFieldAt(int rowIndex, int columnIndex) {
	}
}
