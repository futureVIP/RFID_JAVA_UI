/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class CalculatedPivotDataModel extends PivotDataModel implements IPivotDataModel, PivotValueProviderListener, javax.swing.event.TableModelListener {
 {

	public CalculatedPivotDataModel(javax.swing.table.TableModel tableModel) {
	}

	public CalculatedPivotDataModel(PivotDataSource dataSource) {
	}

	public CalculatedPivotDataModel(IPivotDataModel pivotDataModel) {
	}

	public CalculatedPivotDataModel(PivotValueProvider pivotValueProvider, javax.swing.table.TableModel tableModel) {
	}

	public void setPivotValueProvider(PivotValueProvider pivotValueProvider) {
	}

	public PivotValueProvider getPivotValueProvider() {
	}

	protected IPivotDataModel createPivotDataModel(javax.swing.table.TableModel tableModel) {
	}

	protected IPivotDataModel createPivotDataModel(PivotDataSource dataSource) {
	}

	public Object getPivotDataModel() {
	}

	public void setPivotDataModel(IPivotDataModel pivotDataModel) {
	}

	@java.lang.Override
	public void setOriginalTableModel(javax.swing.table.TableModel tableModel) {
	}

	@java.lang.Override
	public void initialize() {
	}

	protected PivotField createPivotField(javax.swing.table.TableModel tableModel, int columnIndex) {
	}

	/**
	 *  Handle the table model change event of the original table model.
	 *  <p/>
	 *  It will only be invoked in PivotValueProvider only scenario. In that scenario, CalculatedPivotDataModel only needs
	 *  to handle the table structure change event to recreate fields. Assume PivotValueProvider will get events from table
	 *  model itself.
	 *  <p/>
	 *  It will only handle the table structure change event to initialize PivotField and trigger calculation. The reason
	 *  is that, PivotValueProvider is supposed to handle the dynamic data change.
	 * 
	 *  @param e the table model event
	 */
	@java.lang.Override
	public void tableChanged(javax.swing.event.TableModelEvent e) {
	}

	@java.lang.Override
	protected void handleFieldPropertyEvent(java.beans.PropertyChangeEvent evt) {
	}

	@java.lang.Override
	public javax.swing.table.TableModel getTableModel() {
	}

	@java.lang.Override
	public void setDataSource(PivotDataSource dataSource) {
	}

	@java.lang.Override
	public PivotDataSource getDataSource() {
	}

	@java.lang.Override
	public int getStatisticsType(Values rowValues, Values columnValues, PivotField dataField) {
	}

	@java.lang.Override
	public PivotField getField(String name) {
	}

	@java.lang.Override
	public PivotField getField(int index) {
	}

	@java.lang.Override
	public PivotField[] getFields() {
	}

	@java.lang.Override
	public boolean isCalculating() {
	}

	@java.lang.Override
	public Object[] getPossibleValues(PivotField field) {
	}

	@java.lang.Override
	public PivotField[] getRowFields() {
	}

	@java.lang.Override
	public int[] getRowFieldIndices() {
	}

	@java.lang.Override
	public PivotField[] getColumnFields() {
	}

	@java.lang.Override
	public int[] getColumnFieldIndices() {
	}

	@java.lang.Override
	public PivotField[] getDataFields() {
	}

	@java.lang.Override
	public void resetDataFields() {
	}

	@java.lang.Override
	public int[] getDataFieldIndices() {
	}

	@java.lang.Override
	public PivotField[] getFilterFields() {
	}

	@java.lang.Override
	public int[] getFilterFieldIndices() {
	}

	@java.lang.Override
	public PivotField[] getUnassignedFields() {
	}

	@java.lang.Override
	public int[] getUnassignedFieldIndices() {
	}

	@java.lang.Override
	public boolean isAggregateMode() {
	}

	@java.lang.Override
	protected HeaderTableModel createRowHeaderTableModel(CompoundKey[] keys) {
	}

	@java.lang.Override
	protected HeaderTableModel createColumnHeaderTableModel(CompoundKey[] keys) {
	}

	@java.lang.Override
	public CompoundKey[] getRowKeys() {
	}

	@java.lang.Override
	public CompoundKey[] getColumnKeys() {
	}

	@java.lang.Override
	public void setRowMerger(PivotDataModel.RowMerger rowMerger) {
	}

	@java.lang.Override
	public PivotDataModel.RowMerger getRowMerger() {
	}

	@java.lang.Override
	public void setHideSingleDataField(boolean hideSingleDataField) {
	}

	@java.lang.Override
	public void setAlwaysRowDataFields(boolean alwaysRowDataFields) {
	}

	@java.lang.Override
	public boolean isAlwaysRowDataFields() {
	}

	@java.lang.Override
	public void setAlwaysColumnDataFields(boolean alwaysColumnDataFields) {
	}

	@java.lang.Override
	public boolean isAlwaysColumnDataFields() {
	}

	@java.lang.Override
	public void setSummaryCalculator(SummaryCalculator summaryCalculator) {
	}

	@java.lang.Override
	public SummaryCalculator getSummaryCalculator() {
	}

	@java.lang.Override
	public void setSummaryCalculatorFactory(SummaryCalculatorFactory summaryCalculatorFactory) {
	}

	@java.lang.Override
	public SummaryCalculatorFactory getSummaryCalculatorFactory() {
	}

	@java.lang.Override
	public void setSummaryLayer(boolean summaryLayer) {
	}

	@java.lang.Override
	public boolean isSummaryLayer() {
	}

	@java.lang.Override
	public void calculate() {
	}

	@java.lang.Override
	public boolean isAutoUpdate() {
	}

	@java.lang.Override
	public void setAutoUpdate(boolean autoUpdate) {
	}

	@java.lang.Override
	public boolean isRowDataFields() {
	}

	@java.lang.Override
	public boolean isColumnDataFields() {
	}

	@java.lang.Override
	public boolean isSingleValueMode() {
	}

	@java.lang.Override
	public void setSingleValueMode(boolean singleValueMode) {
	}

	@java.lang.Override
	public boolean verify() {
	}

	public boolean isCacheEnabled() {
	}

	public void setCacheEnabled(boolean cacheEnabled) {
	}

	public void pivotValueProviderEventHandler(PivotValueProviderEvent event) {
	}

	@java.lang.Override
	public java.util.List getDataAt(CompoundKey rowKey, CompoundKey columnKey) {
	}

	@java.lang.Override
	public boolean isAdjusting() {
	}

	@java.lang.Override
	public void setAdjusting(boolean adjusting) {
	}

	@java.lang.Override
	public boolean isSummaryMode() {
	}

	@java.lang.Override
	public void setSummaryMode(boolean summaryMode) {
	}

	@java.lang.Override
	public int getRowHeaderRowIndexAt(int rowIndex) {
	}

	@java.lang.Override
	public int getColumnHeaderColumnIndexAt(int rowIndex) {
	}

	protected Values[] collectChildrenValues(Values parentValues, boolean isRowValues, int summaryType) {
	}

	@java.lang.Override
	protected Object[] collectValuesForCell(PivotField field, Values rowKeys, Values columnKeys, int summaryType) {
	}

	@java.lang.Override
	public Object getValueAt(PivotField field, Values rowKeys, Values columnKeys) {
	}

	protected Object calculateStatistics(RunningSummary runningSummary, Object[] objects) {
	}

	/**
	 *  Set the flag indicating that if the PivotValueProviderEvent will contain the affected cells information on original
	 *  data model change scenario.
	 *  <p/>
	 *  By default, the flag is false. You could set it to true however it may hit the performance since we have to cache
	 *  the values before and after value changed to get the affected cells.
	 *  <p/>
	 *  This flag could only take effect when both isAutoUpdate() and isCacheEnabled() return true.
	 * 
	 *  @param computeAffectedCellOnUpdate the flag
	 */
	public void setComputeAffectedCellOnUpdate(boolean computeAffectedCellOnUpdate) {
	}
}
