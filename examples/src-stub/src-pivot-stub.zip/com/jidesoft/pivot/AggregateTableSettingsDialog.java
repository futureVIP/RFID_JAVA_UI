/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


/**
 *  This class is not ready for public usage yet.
 */
public class AggregateTableSettingsDialog extends StandardDialog {

	public AggregateTableSettingsDialog(java.awt.Frame owner, AggregateTable aggregateTable, String title) {
	}

	public AggregateTableSettingsDialog(java.awt.Dialog owner, AggregateTable aggregateTable, String title) {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	public AggregateTableSettingsPanel getAggregateTableSettingsPanel() {
	}
}
