/**
 *  The package contains classes for JIDE Pivot Grid product.
 */
package com.jidesoft.pivot;


public class TableModelPivotDataSource implements PivotDataSource {
 {

	protected javax.swing.table.TableModel _originalTableModel;

	protected IFilterableTableModel _filterTableModel;

	protected IFilterableTableModel _tableModel;

	public TableModelPivotDataSource(javax.swing.table.TableModel originalTableModel) {
	}

	public void setTableModel(javax.swing.table.TableModel tableModel) {
	}

	/**
	 *  Create inner filterable table model to support filtering feature in PivotTablePane.
	 *  <p/>
	 *  This method will be created twice every time <code>setTableModel</code> is invoked. The first time is to create a
	 *  FilterableTableModel for filter fields, the second time is to create a FilterablTableModel for row/column/data
	 *  fields.
	 *  <p/>
	 *  The default implementation is just <code>new FilterableTableModel(model)</code>.
	 *  
	 *  @param model the original table model
	 *  @return the wrapping FilterableTableModel instance.
	 */
	protected FilterableTableModel createFilterableTableModel(javax.swing.table.TableModel model) {
	}

	public javax.swing.table.TableModel getTableModel() {
	}

	public int getFieldCount() {
	}

	public String getFieldName(int fieldIndex) {
	}

	public Class getFieldType(int fieldIndex) {
	}

	public int getRowCount() {
	}

	public Object getValueAt(int rowIndex, int fieldIndex) {
	}

	public void setValueAt(Object value, int rowIndex, int fieldIndex) {
	}

	/**
	 *  Updates the possible value from the specified row index. If the field is a filter field, we will get the values
	 *  from the _originalTableModel. Otherwise, we will get it from _filterTableModel.
	 * 
	 *  @param values        the set of possible values.
	 *  @param fieldIndex    the field index
	 *  @param row           the row index as in the original table model
	 *  @param viewRow       the row index as in the filterable table model.
	 *  @param filterField   true if the field is a filter field. Otherwise false.
	 *  @param isNullAllowed true if we will add null to the possible values set. Otherwise do not add.
	 */
	protected void updatePossibleValues(java.util.Set values, int fieldIndex, int row, int viewRow, boolean filterField, boolean isNullAllowed) {
	}

	/**
	 *  Gets the possible values.
	 * 
	 *  @param fieldIndex  the field index
	 *  @param filterField If the field is a filter field. The difference is that a filter field will include values even
	 *                     though they are filtered by other filter fields, and a non-filter field will not.* @return
	 */
	public java.util.Set getPossibleValues(int fieldIndex, boolean filterField, boolean isNullAllowed) {
	}

	@java.lang.Override
	public boolean hasFilter() {
	}

	public void clearFilters() {
	}

	public void applyFilters() {
	}

	public void applyFilters(int[] rowFieldIndices, int[] columnFieldIndices, int[] dataFieldIndices, int[] filterFieldIndices) {
	}

	public void setFilter(Object[] values, int fieldIndex, boolean filterField) {
	}

	@java.lang.Override
	public void setExcludeFilter(Object[] values, int fieldIndex, boolean filterField) {
	}

	public void setFilter(Filter filter, int fieldIndex, boolean filterField) {
	}

	public int getFilteredRowIndex(int actualRowIndex) {
	}

	public int getActualRowIndex(int visualRowIndex) {
	}

	public void addTableModelListener(javax.swing.event.TableModelListener listener) {
	}

	public void removeTableModelListener(javax.swing.event.TableModelListener listener) {
	}
}
