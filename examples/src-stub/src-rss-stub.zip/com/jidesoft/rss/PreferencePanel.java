/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


/**
 *  The panel for preference. You can use this panel as part of your application's preference dialog.
 */
public class PreferencePanel extends javax.swing.JPanel {

	public PreferencePanel(FeedReader rss) {
	}

	protected void initComponents() {
	}

	public javax.swing.JComponent createSubscriptionPanel() {
	}

	public javax.swing.JComponent createBrowserPanel() {
	}

	public void load(FeedPreference preference) {
	}

	public void save(FeedPreference preference) {
	}
}
