/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


public interface Product {
}
