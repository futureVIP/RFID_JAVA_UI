/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


/**
 *  The table model that contains the feed items of a channel.
 */
public class FeedItemTableModel extends javax.swing.table.AbstractTableModel {

	public FeedItemTableModel() {
	}

	public FeedItemTableModel(int maxItems) {
	}

	public FeedItemTableModel(int maxItems, PersistenceManagerIF persistenceManager) {
	}

	public int getColumnCount() {
	}

	public int getRowCount() {
	}

	@java.lang.Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
	}

	public ConverterContext getConverterContextAt(int row, int column) {
	}

	public EditorContext getEditorContextAt(int row, int column) {
	}

	public long getItemID(int row) {
	}

	public ItemIF getItemAt(int row) {
	}

	public int getItemIndex(ItemIF item) {
	}

	public Class getCellClassAt(int row, int column) {
	}

	@java.lang.Override
	public Class getColumnClass(int column) {
	}

	public Object getValueAt(int row, int column) {
	}

	public void addItemAt(ItemIF aValue, int rowIndex) {
	}

	public void setItemReadStatus(int row, boolean unread) {
	}

	public void toggleItemReadStatus(int row) {
	}

	public void setAllItemReadStatus(boolean unread) {
	}

	public void removeAll() {
	}

	public CellStyle getCellStyleAt(int rowIndex, int columnIndex) {
	}

	public boolean isCellStyleOn() {
	}

	public void openChannel(ChannelIF channel) {
	}

	public void closeCurrentChannel() {
	}

	protected String getResourceString(String key) {
	}

	public java.util.ResourceBundle getResourceBundle() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public PersistenceManagerIF getPersistenceManager() {
	}

	public void setPersistenceManager(PersistenceManagerIF persistenceManager) {
	}

	public int getMaxItems() {
	}

	public void setMaxItems(int maxItems) {
	}

	public ChannelIF getChannel() {
	}

	public void setChannel(ChannelIF channel) {
	}
}
