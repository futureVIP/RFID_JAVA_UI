/**
 *  The package contains classes for JIDE Feed Reader product.
 */
package com.jidesoft.rss;


/**
 *  An event listener to listen to any <code>FeedEvent</code>s happened in <code>FeedReader</code>.
 */
public interface FeedEventListener extends java.util.EventListener {
 {

	/**
	 *  Indicates a <code>FeedEvent</code> happened.
	 * 
	 *  @param e the FeedEvent.
	 */
	public void eventHappened(FeedEvent e);
}
