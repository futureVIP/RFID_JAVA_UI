package com.jidesoft.plaf.basic;


/**
 *  Special icon for UI.
 */
public class SpecialIcon implements javax.swing.Icon {
 {

	public static final int BUTTON_CLOSE = 0;

	public static final int STATE_DEFAULT = 0;

	public static final int STATE_PRESSED = 1;

	public static final int STATE_ROLLOVER = 2;

	public static final int STATE_SELECTED = 3;

	public static final int STATE_DISABLE = 4;

	public static final int STATE_DISABLE_SELECTED = 5;

	public static final int STATE_DISABLED_ROLLOVER = 6;

	public SpecialIcon(int type) {
	}

	public SpecialIcon(int type, int state) {
	}

	public int getIconHeight() {
	}

	public int getIconWidth() {
	}

	public void paintIcon(java.awt.Component c, java.awt.Graphics g, int x, int y) {
	}
}
