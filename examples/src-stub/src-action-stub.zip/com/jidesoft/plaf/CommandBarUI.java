package com.jidesoft.plaf;


/**
 *  Pluggable look and feel interface for CommandBar.
 */
public abstract class CommandBarUI extends javax.swing.plaf.MenuBarUI {

	public CommandBarUI() {
	}

	public abstract java.awt.Component getGripper() {
	}

	public abstract java.awt.Component getTitleBar() {
	}
}
