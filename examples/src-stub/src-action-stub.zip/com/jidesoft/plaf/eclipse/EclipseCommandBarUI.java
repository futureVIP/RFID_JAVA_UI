package com.jidesoft.plaf.eclipse;


public class EclipseCommandBarUI extends com.jidesoft.plaf.basic.BasicCommandBarUI {

	public EclipseCommandBarUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}
}
