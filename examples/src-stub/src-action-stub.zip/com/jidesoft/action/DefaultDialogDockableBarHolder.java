/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  Default implementation of DockableBarHolder.
 *  <p/>
 *  If for some reason you can't use DefaultDockableBarHolder, you will need to override getJMenuBar() method in your JFrame.
 *  See the code below. If you don't override this method, nothing will break seriously except you won't be able to use
 *  ALT key to activate the menu bar on Windows OS.
 *  <code><pre>
 *      public JMenuBar getJMenuBar() {
 *        if (getDockableBarManager() != null) {
 *            Collection col = getDockableBarManager().getAllDockableBars();
 *            for (Iterator iterator = col.iterator(); iterator.hasNext();) {
 *                DockableBar bar = (DockableBar) iterator.next();
 *                if (bar instanceof CommandBar && ((CommandBar) bar).isMenuBar()) {
 *                    return bar;
 *                }
 *            }
 *        }
 *        return super.getJMenuBar();
 *    }
 *  </pre></code>
 */
public class DefaultDialogDockableBarHolder extends javax.swing.JDialog implements DockableBarHolder {
 {

	public DefaultDialogDockableBarHolder() {
	}

	public DefaultDialogDockableBarHolder(java.awt.Frame owner) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Frame owner, boolean modal) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Frame owner, String title) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Frame owner, String title, boolean modal) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Frame owner, String title, boolean modal, java.awt.GraphicsConfiguration gc) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Dialog owner) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Dialog owner, boolean modal) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Dialog owner, String title) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Dialog owner, String title, boolean modal) {
	}

	public DefaultDialogDockableBarHolder(java.awt.Dialog owner, String title, boolean modal, java.awt.GraphicsConfiguration gc) {
	}

	/**
	 *  Create a content container and add it to CENTER of JFrame content pane.
	 */
	protected void initFrame(java.awt.Container container) {
	}

	protected DockableBarManager createDockableBarManager(java.awt.Container contentContainer) {
	}

	protected com.jidesoft.swing.ContentContainer createContentContainer() {
	}

	/**
	 *  Gets the default dockable bar manager.
	 * 
	 *  @return dockable bar manager.
	 */
	public DockableBarManager getDockableBarManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableBarHolder,
	 *  it's the same value that is returned from getDockableBarManager().
	 * 
	 *  @return layout persistence.
	 */
	public LayoutPersistence getLayoutPersistence() {
	}

	/**
	 *  Override in DefaultDockableBarHolder to return the menu bar in DockableBarManager.
	 * 
	 *  @return the menubar for this frame
	 */
	@java.lang.Override
	public javax.swing.JMenuBar getJMenuBar() {
	}

	protected boolean isContentPaneCheckingEnabled() {
	}

	protected void setContentPaneCheckingEnabled(boolean contentPaneCheckingEnabled) {
	}
}
