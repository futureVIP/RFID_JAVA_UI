/**
 *  The package contains events and listeners for JIDE Action Framework product.
 */
package com.jidesoft.action.event;


/**
 *  Default implementation of <code>DockableBarListener</code>.
 * 
 *  @see DockableBarListener
 */
public class DockableBarAdapter implements DockableBarListener {
 {

	public DockableBarAdapter() {
	}

	/**
	 *  Invoked when a <code>DockableBar</code> has been added to DockingManager.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarAdded(DockableBarEvent e) {
	}

	/**
	 *  Invoked when a <code>DockableBar</code> has been removed from DockingManager.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarRemoved(DockableBarEvent e) {
	}

	/**
	 *  Invoked when a <code>DockableBar</code> has been set visible.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarShown(DockableBarEvent e) {
	}

	/**
	 *  Invoked when a <code>DockableBar</code> has been set invisible.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarHidden(DockableBarEvent e) {
	}

	/**
	 *  Invoked when a <code>DockableBar</code> has change from other state to docking state.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarHoriDocked(DockableBarEvent e) {
	}

	/**
	 *  Invoked when a <code>DockableBar</code> has change from other state to vertical docking state.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarVertDocked(DockableBarEvent e) {
	}

	/**
	 *  Invoked when a <code>DockableBar</code> has change from other state to floating state.
	 * 
	 *  @param e DockableBarEvent
	 */
	public void dockableBarFloating(DockableBarEvent e) {
	}
}
