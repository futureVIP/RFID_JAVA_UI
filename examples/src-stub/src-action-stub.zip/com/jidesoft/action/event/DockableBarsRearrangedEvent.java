/**
 *  The package contains events and listeners for JIDE Action Framework product.
 */
package com.jidesoft.action.event;


/**
 *  An <code>AWTEvent</code> that adds support for <code>DockableBarManager</code> objects as the event source.
 *  <p/>
 *  The event reflects that docked DockableBars have been rearranged. A DockableBar has:
 *  <p/>
 *  - changed from floating to docked - changed from docked to floating - been added in docked mode - been removed from
 *  docked mode - been hidden from docked mode - moved from one DockableContainer to another - moved to a different
 *  row/column within the same DockableContainer - moved to a different index within the same row/column in the same
 *  DockableContainer - resized in the same row/column in the same DockableContainer.
 *  <p/>
 *  The event indicates which component was moved and which of the above transitions happened to it.
 *  <p/>
 *  The event lists its previous and current mode, (docked or floating), DockableContainer, (NORTH, SOUTH, EAST, or
 *  WEST), row/column index, item index within the row, and size. (length or height, depending upon its orientation)
 *  <p/>
 *  When a DockableBar is rearranged, all of the DockableBars after it, in both its previous and current row/column, are
 *  also rearranged. Also, if the previous or current row/column contains no other DockableBars, a row/column must have
 *  been added or removed; so every DockableBar in every row/column after it is also rearranged.
 *  <p/>
 *  Therefore, the event also includes a list of all other DockableBars which were rearranged; and each item also lists
 *  which transition happened to it along with its previous and current state values.
 * 
 *  @see com.jidesoft.action.DockableBar
 *  @see DockableBarListener
 */
public class DockableBarsRearrangedEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>DockableBarsRearranged</code> events.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_FIRST = 5099;

	/**
	 *  The last number in the range of IDs used for <code>DockableBarsRearranged</code> events.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_LAST = 5107;

	/**
	 *  This event is delivered when the <code>DockableBar</code> is first added to DockableBarManager in docked mode.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_ADDED_DOCKED = 5099;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is removed from DockableBarManager.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_DOCKED_REMOVED = 5100;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is floated.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_DOCKED_FLOATED = 5101;

	/**
	 *  This event is delivered when the floating <code>DockableBar</code> is docked.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_FLOATING_DOCKED = 5102;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is hidden.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_HIDDEN = 5103;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is moved to a different DockableContainer.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_CHANGED_CONTAINER = 5104;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is moved to a different row within the same
	 *  DockableContainer.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_CHANGED_ROW_OR_COLUMN = 5105;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is moved to a different index within the same
	 *  row/column in the same DockableContainer.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_CHANGED_INDEX = 5106;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is resized at the same index within the same
	 *  row/column in the same DockableContainer.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_RESIZED = 5107;

	/**
	 *  This event is delivered when the docked <code>DockableBar</code> is moved when it is floating.
	 */
	public static final int DOCKABLE_BARS_REARRANGED_MOVED = 5108;

	protected DockableBarStateTransition _stateTransition;

	protected java.util.List _otherRearrangedBarsStateTransitions;

	/**
	 *  Constructs an <code>DockableBarEvent</code> object.
	 * 
	 *  @param source the <code>Component</code> object that originated the event (should be a <code>DockableBar</code>)
	 *  @param id     an integer indicating the type of event
	 */
	public DockableBarsRearrangedEvent(java.awt.Component source, int id) {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	@java.lang.Override
	public String paramString() {
	}

	/**
	 *  Returns the originator of the event.
	 * 
	 *  @return the <code>Component</code> (should be a <code>DockableBar</code>) object that originated the event
	 */
	public java.awt.Component getComponent() {
	}

	public void setComponent(java.awt.Component newValue) {
	}

	public void setId(int newValue) {
	}

	/**
	 *  Returns the state transition (ID and pre- and post-states) for the component that originated the event.
	 * 
	 *  @return the state transition for the component that originated the event
	 */
	public DockableBarStateTransition getStateTransition() {
	}

	public void setStateTransition(DockableBarStateTransition newValue) {
	}

	public void addOtherRearrangedBar(DockableBarStateTransition stateTransition) {
	}

	public java.util.List getOtherRearrangedBarsStateTransitions() {
	}

	public void clear() {
	}
}
