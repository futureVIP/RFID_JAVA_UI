/**
 *  The package contains events and listeners for JIDE Action Framework product.
 */
package com.jidesoft.action.event;


public class DockableBarState {

	public java.awt.Component _component;

	public int _dockableContainerID;

	public int _orientation;

	public int _mode;

	public int _rowOrCol;

	public int _start;

	public java.awt.Rectangle _bounds;

	public int _index;

	public DockableBarState() {
	}

	public void clear() {
	}
}
