/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  An implementation of JFrame which can support both DockableBars (of JIDE Action Framework) and DockableFrames (of
 *  JIDE Docking Framework).
 *  <p/>
 *  If for some reason you can't use DefaultDockableBarDockableHolder, you will need to override getJMenuBar() method in
 *  your JFrame. See the code below. If you don't override this method, nothing will break seriously except you won't be
 *  able to use ALT key to activate the menu bar on Windows OS.
 *  <code><pre>
 *      public JMenuBar getJMenuBar() {
 *        if (getDockableBarManager() != null) {
 *            Collection col = getDockableBarManager().getAllDockableBars();
 *            for (Iterator iterator = col.iterator(); iterator.hasNext();) {
 *                DockableBar bar = (DockableBar) iterator.next();
 *                if (bar instanceof CommandBar && ((CommandBar) bar).isMenuBar()) {
 *                    return bar;
 *                }
 *            }
 *        }
 *        return super.getJMenuBar();
 *    }
 *  </pre></code>
 */
public class DefaultDialogDockableBarDockableHolder extends DefaultDialogDockableHolder implements DockableBarDockableHolder {
 {

	public DefaultDialogDockableBarDockableHolder() {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Frame owner) {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Frame owner, boolean modal) {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Frame owner, String title) {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Frame owner, String title, boolean modal) {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Dialog owner) {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Dialog owner, boolean modal) {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Dialog owner, String title) {
	}

	public DefaultDialogDockableBarDockableHolder(java.awt.Dialog owner, String title, boolean modal) {
	}

	/**
	 *  Create a content container and add it to CENTER of JFrame content pane.
	 */
	@java.lang.Override
	protected void initFrame(java.awt.Container container) {
	}

	protected DockableBarManager createDockableBarManager(java.awt.Container contentContainer) {
	}

	protected com.jidesoft.swing.ContentContainer createContentContainer() {
	}

	/**
	 *  Gets the default dockable bar manager.
	 * 
	 *  @return dockable bar manager
	 */
	public DockableBarManager getDockableBarManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableBarDockableHolder, it's an instance of
	 *  LayoutPersistenceManager that manages both DockingManager and DockableBarManager.
	 * 
	 *  @return layout persistence.
	 */
	@java.lang.Override
	public LayoutPersistence getLayoutPersistence() {
	}

	/**
	 *  Override in DefaultDockableBarHolder to return the menu bar in DockableBarManager.
	 * 
	 *  @return the menubar for this frame
	 */
	@java.lang.Override
	public javax.swing.JMenuBar getJMenuBar() {
	}

	@java.lang.Override
	public void dispose() {
	}
}
