/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


public interface Product {
}
