/**
 *  The main package for JIDE Action Framework product.
 */
package com.jidesoft.action;


/**
 *  A JPanel which can be used as DockableBarHolder and DockableHolder
 */
public class DockableBarDockableHolderPanel extends com.jidesoft.swing.ContentContainer implements DockableBarHolder {
 {

	public DockableBarDockableHolderPanel() {
	}

	public DockableBarDockableHolderPanel(javax.swing.RootPaneContainer container) {
	}

	protected DefaultDockableBarManager createDockableBarManager(javax.swing.RootPaneContainer rootContainer, java.awt.Container container) {
	}

	protected DefaultDockingManager createDockingManager(javax.swing.RootPaneContainer rootContainer, java.awt.Container container) {
	}

	public DockingManager getDockingManager() {
	}

	public DockableBarManager getDockableBarManager() {
	}

	public LayoutPersistence getLayoutPersistence() {
	}

	public void dispose() {
	}

	/**
	 *  DockableBarManager manages the layout and the content of DockableBarDockableHolderPanel so we override this
	 *  setLayout method to do nothing, so calling this method will have no effect.
	 * 
	 *  @param mgr
	 *  @since 2.7.2
	 */
	@java.lang.Override
	public void setLayout(java.awt.LayoutManager mgr) {
	}
}
