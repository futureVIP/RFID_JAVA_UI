/**
 *  The package contains classes related to parsing CSV (comma-separated values) files and tab-separated files for JIDE Charts product.
 */
package com.jidesoft.csv;


/**
 *  A listener for <code>CsvParseEvent</code>s generated during parsing.
 *  @author Simon White (swhite@catalysoft.com)
 */
public interface CsvParseListener {

	public void parsed(CsvParseEvent e);
}
