/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A simple implementation of Positionable
 */
public class RealPosition {

	/**
	 *  Create a RealPosition from the supplied position parameter
	 *  @param position the position of the associated object as a double
	 */
	public RealPosition(double position) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public double position() {
	}

	@java.lang.Override
	public String toString() {
	}

	/**
	 *  This method enables RealPositions to be compared and sorted according to their position on the number line.
	 *  @param o some other Positionable
	 *  @return -1, 0, or 1 according to whether this object is considered to be less than, equal to or greater than
	 *  the supplied object
	 */
	public int compareTo(Positionable o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
