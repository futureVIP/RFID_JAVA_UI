/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A chart model that gets its y values by summing the corresponding values of its delegate chart models.
 *  The delegate chart models should have the same number of points. Points with the same index will be summed.
 */
public class SummingChartModel extends AbstractDelegatingChartModel implements RangeProvider {
 {

	/**
	 *  Default Constructor
	 */
	public SummingChartModel() {
	}

	/**
	 *  If your chart models are ChartModels rather than AnnotatedChartModels, consider using
	 *  the AnnotatedChartModelAdapter.
	 * 
	 *  @param delegates the chart models that we wish to sum over
	 */
	public SummingChartModel(String modelName, AnnotatedChartModel[] delegates) {
	}

	/**
	 *  Currently unsupported, but may become supported in the future
	 */
	@java.lang.Override
	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	/**
	 *  Currently unsupported so always returns 0
	 */
	@java.lang.Override
	public int getAnnotationCount() {
	}

	/**
	 *  Returns the nth point in the model. The nth point in the model is computed by summing the nth points of all
	 *  the delegate models
	 *  @param n the index in the model
	 *  @return the nth point in the model
	 */
	@java.lang.Override
	public Chartable getPoint(int n) {
	}

	/**
	 *  Returns the number of points in the model
	 *  @return the number of points in the model
	 */
	@java.lang.Override
	public int getPointCount() {
	}

	/**
	 *  Returns the x range of the model (as a Numeric Range)
	 *  @return the x range of the model
	 */
	public <any> getXRange() {
	}

	/**
	 *  Returns the y range of the model (as a Numeric Range)
	 *  @return the y range of the model
	 */
	public <any> getYRange() {
	}

	@java.lang.Override
	protected void update() {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}
}
