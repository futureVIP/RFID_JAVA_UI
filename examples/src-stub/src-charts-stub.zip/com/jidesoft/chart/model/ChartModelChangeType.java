/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  Used as the type of change in a ChartModelChangeEvent
 */
public final class ChartModelChangeType extends Enum {

	public static final ChartModelChangeType UNKNOWN;

	public static final ChartModelChangeType INSERT;

	public static final ChartModelChangeType REMOVE;

	public static final ChartModelChangeType MODIFY;

	public static ChartModelChangeType[] values() {
	}

	public static ChartModelChangeType valueOf(String name) {
	}
}
