/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 04-Dec-2010 at 11:24:32
 */
public interface LeanChartModel extends ChartModel {
 {

	public double[] getPointPositions(int n);
}
