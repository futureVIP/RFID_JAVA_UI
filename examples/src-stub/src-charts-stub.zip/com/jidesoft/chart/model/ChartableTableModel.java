/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  A simple class that is both chartable and can be displayed in a table
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartableTableModel extends javax.swing.table.AbstractTableModel implements AnnotatedChartModel {
 {

	public ChartableTableModel(String name, java.util.List chartables) {
	}

	/**
	 *  Models generally need a name so that they can be easily differentiated from one another without inspecting the
	 *  data
	 * 
	 *  @return the name of the model.
	 */
	public String getName() {
	}

	/**
	 *  @return the nth point of the data set
	 */
	public Chartable getPoint(int n) {
	}

	/**
	 *  @return the number of points
	 */
	public int getPointCount() {
	}

	public int getColumnCount() {
	}

	@java.lang.Override
	public String getColumnName(int column) {
	}

	public int getRowCount() {
	}

	public Object getValueAt(int row, int column) {
	}

	public boolean isCyclical() {
	}

	public com.jidesoft.chart.annotation.Annotation getAnnotation(int n) {
	}

	public int getAnnotationCount() {
	}

	public boolean isAnnotationsVisible() {
	}

	public void setAnnotationsVisible(boolean visible) {
	}

	public java.util.Iterator iterator() {
	}

	public void addChartModelListener(ChartModelListener listener) {
	}

	public void removeChartModelListener(ChartModelListener listener) {
	}

	public void update() {
	}

	protected void fireModelChanged() {
	}
}
