/**
 *  Contains models to support the Chart view (in a Model-View-Controller sense)
 */
package com.jidesoft.chart.model;


/**
 *  An interface that provides the facility to transform an instance of a type into another instance of the same type.
 *  For example, we can use this to transform a <code>Chartable</code> into a different <code>Chartable</code>, or a
 *  <code>Positionable</code> into a different <code>Positionable</code>.
 * 
 *  @author Simon White
 */
public interface Transform {

	public Object transform(Object t);
}
