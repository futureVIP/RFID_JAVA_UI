/**
 *  The package contains util classes for JIDE Charts product.
 */
package com.jidesoft.chart.util;


/**
 *  Implements the filter interface but does not filter out anything at all.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class IdentityFilter implements Filter {
 {

	public IdentityFilter() {
	}

	/**
	 *  @see Filter#isValueFiltered(java.lang.Object)
	 */
	public boolean isValueFiltered(Object other) {
	}
}
