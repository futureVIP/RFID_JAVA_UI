/**
 *  This package contains classes to support the dynamic generation of charts to serve up from a web server.
 *  It is currently experimental and subject to change.
 */
package com.jidesoft.chart.servlet;


public class ServletUtils {

	public ServletUtils() {
	}

	public static java.awt.Font parseFont(String fontDescription) {
	}

	/**
	 *  Converts a hexadecimal string to a Color
	 *  @param hexString the hexadecimal string representing the color
	 *  @return a Color instance
	 */
	public static java.awt.Color hexToColor(String hexString, java.awt.Color defaultColor) {
	}

	/**
	 *  Converts an even-lengthed string of hexadecimal values to an array of
	 *  decimal valued bytes
	 */
	public static int[] fromHexString(String hex) {
	}

	/**
	 *  Converts a 2-digit hexadecimal value 
	 *  (consisting entirely of hexadecimal digits) to a decimal value
	 *  as a byte.
	 *  <P>
	 *  <B>NOTE:</B> An input value such as " C" will not work. Use "0C" instead.
	 */
	public static int hex2int(String hex) {
	}
}
