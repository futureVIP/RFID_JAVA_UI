/**
 *  This package contains classes to support the dynamic generation of charts to serve up from a web server.
 *  It is currently experimental and subject to change.
 */
package com.jidesoft.chart.servlet;


/**
 *  This class is intended for use in servlet-based web servers (such as Apache Tomcat), so that charts can be generated
 *  dynamically and included in a web page. 
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class ChartServlet extends HttpServlet {

	public ChartServlet() {
	}

	public void setChartFactory(HttpComponentFactory factory) {
	}

	public void verifyLicense(String companyName, String projectName, String licenseKey) {
	}

	@java.lang.Override
	public void init(ServletConfig config) {
	}

	@java.lang.Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
	}
}
