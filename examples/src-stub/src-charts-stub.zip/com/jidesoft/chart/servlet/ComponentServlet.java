/**
 *  This package contains classes to support the dynamic generation of charts to serve up from a web server.
 *  It is currently experimental and subject to change.
 */
package com.jidesoft.chart.servlet;


public class ComponentServlet extends HttpServlet {

	public ComponentServlet() {
	}

	@java.lang.Override
	public void init(ServletConfig config) {
	}

	public HttpComponentFactory getComponentFactory() {
	}

	public void setComponentFactory(HttpComponentFactory componentFactory) {
	}

	@java.lang.Override
	public void doGet(HttpServletRequest request, HttpServletResponse response) {
	}

	public byte[] paintBytes(HttpServletRequest request) {
	}
}
