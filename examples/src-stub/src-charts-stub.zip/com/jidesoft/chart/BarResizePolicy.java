/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Used for specifying how a bar chart should behave with respect to the space available, if a bar width has been specified.
 *  (If a bar width is not specified then resizing occurs automatically.)
 */
public final class BarResizePolicy extends Enum {

	public static final BarResizePolicy RESIZE_ALL;

	public static final BarResizePolicy RESIZE_OFF;

	public static BarResizePolicy[] values() {
	}

	public static BarResizePolicy valueOf(String name) {
	}
}
