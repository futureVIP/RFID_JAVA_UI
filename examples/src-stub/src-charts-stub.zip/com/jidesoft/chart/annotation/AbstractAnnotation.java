/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


/**
 *  An abstract superclass of annotations
 * 
 *  @author Simon White (swhite@catalysoft.com)
 *  @see ChartLabel
 *  @see ChartImage
 */
public abstract class AbstractAnnotation implements Annotation {
 {

	public AbstractAnnotation() {
	}

	public void setZOrder(int zOrder) {
	}

	public int getZOrder() {
	}
}
