/**
 *  The package contains classes for annotating a chart with images and/or labels in JIDE Charts product.
 */
package com.jidesoft.chart.annotation;


public interface ChartAnnotation extends Annotation {
 {

	public void draw(java.awt.Graphics2D g, com.jidesoft.chart.Chart chart);

	public int getZOrder();
}
