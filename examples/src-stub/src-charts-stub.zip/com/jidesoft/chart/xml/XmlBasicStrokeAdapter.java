package com.jidesoft.chart.xml;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 17-Sep-2010 at 22:45:46
 */
public class XmlBasicStrokeAdapter extends javax.xml.bind.annotation.adapters.XmlAdapter {

	public XmlBasicStrokeAdapter() {
	}

	@java.lang.Override
	public BasicStrokeWrapper marshal(java.awt.BasicStroke v) {
	}

	@java.lang.Override
	public java.awt.BasicStroke unmarshal(BasicStrokeWrapper bs) {
	}
}
