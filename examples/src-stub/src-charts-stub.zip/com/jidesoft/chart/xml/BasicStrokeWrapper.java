package com.jidesoft.chart.xml;


/**
 *  Copyright (c) Catalysoft Ltd, 2005-2010 All Rights Reserved
 *  Created: 18-Sep-2010 at 01:38:04
 */
@javax.xml.bind.annotation.XmlType(propOrder={"dashPhase", "dashes", "miterLimit", "lineJoin", "endCap", "lineWidth"})
public class BasicStrokeWrapper {

	public BasicStrokeWrapper() {
	}

	public BasicStrokeWrapper(java.awt.BasicStroke bs) {
	}

	@javax.xml.bind.annotation.XmlAttribute
	public float getLineWidth() {
	}

	public void setLineWidth(float lineWidth) {
	}

	@javax.xml.bind.annotation.XmlAttribute
	public float getMiterLimit() {
	}

	public void setMiterLimit(float miterLimit) {
	}

	@javax.xml.bind.annotation.XmlAttribute
	public float[] getDashes() {
	}

	public void setDashes(float[] dashArray) {
	}

	@javax.xml.bind.annotation.XmlAttribute
	public float getDashPhase() {
	}

	public void setDashPhase(float dashPhase) {
	}

	@javax.xml.bind.annotation.XmlAttribute
	@javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter(com.jidesoft.chart.xml.XmlEndCapAdapter.class)
	public Integer getEndCap() {
	}

	public void setEndCap(Integer endCap) {
	}

	@javax.xml.bind.annotation.XmlAttribute
	@javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter(com.jidesoft.chart.xml.XmlEndJoinAdapter.class)
	public Integer getLineJoin() {
	}

	public void setLineJoin(Integer lineJoin) {
	}

	@java.lang.Override
	public String toString() {
	}
}
