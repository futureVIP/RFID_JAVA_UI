/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  This exception may be thrown when a value is outside of the expected range.
 *  For numeric ranges the value would be greater than the maximum allowed value; for other ranges the meaning
 *  is the same with an appropriately understood meaning of 'greater than'.
 *  @author Simon White (swhite@catalysoft.com)
 */
public class AboveBoundsException extends ChartBoundsException {

	public AboveBoundsException() {
	}

	public AboveBoundsException(double newBound) {
	}

	public AboveBoundsException(double newBound, String message) {
	}

	public AboveBoundsException(double newBound, Throwable throwable) {
	}

	public AboveBoundsException(double newBound, String message, Throwable throwable) {
	}

	public double getBound() {
	}
}
