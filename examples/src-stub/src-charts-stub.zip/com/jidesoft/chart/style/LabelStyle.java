/**
 *  A packaging for providing presentation styles for Chart traces/models.
 */
package com.jidesoft.chart.style;


/**
 *  Contains style information for a label
 */
public class LabelStyle extends AbstractStyle {

	/**
	 *  Create a new LabelStyle using the default font and font size
	 */
	public LabelStyle() {
	}

	/**
	 *  Create a new Label Style using the specified font
	 *  @param font the font to use for the label
	 */
	public LabelStyle(java.awt.Font font) {
	}

	/**
	 *  Create a new Label Style using the default font and font size, and specifying a rotation for the label
	 *  @param rotation the rotation of the label in radians
	 */
	public LabelStyle(double rotation) {
	}

	/**
	 *  Create a new Label Style using the specified color and font
	 *  @param color the color for the label
	 *  @param font the font to use for the label
	 */
	public LabelStyle(java.awt.Color color, java.awt.Font font) {
	}

	/**
	 *  Create a new Label Style using the specified color, font and rotation
	 *  @param color the color to use for the label
	 *  @param font the font to use for the label
	 *  @param rotation the rotation of the label in radians
	 */
	public LabelStyle(java.awt.Color color, java.awt.Font font, double rotation) {
	}

	/**
	 *  Returns the currently specified font
	 *  @return the currently specified font
	 */
	public java.awt.Font getFont() {
	}

	/**
	 *  Specify the font to use for the label
	 *  @param font the new font to use for the label
	 */
	public void setFont(java.awt.Font font) {
	}

	/**
	 *  Retrieve the rotation specified for the label
	 *  @return the currently specified rotation, given in radians
	 */
	public Double getRotation() {
	}

	/**
	 *  Specify the rotation of a label (in radians)
	 *  @param rotation the rotation of the label
	 */
	public void setRotation(Double rotation) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}
}
