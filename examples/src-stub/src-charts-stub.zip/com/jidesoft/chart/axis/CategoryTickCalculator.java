/**
 *  Classes relating to axes and tick calculation
 */
package com.jidesoft.chart.axis;


/**
 *  An interface implemented by objects that calculate tick positions from categories
 * 
 *  @param <T> the class of object used by the categories
 */
public interface CategoryTickCalculator extends TickCalculator {
 {
}
