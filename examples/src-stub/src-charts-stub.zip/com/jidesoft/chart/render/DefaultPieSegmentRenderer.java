/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  Fills in segments with a plain (or textured) color.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class DefaultPieSegmentRenderer extends AbstractPieSegmentRenderer implements PieSegmentRenderer2D {
 {

	public DefaultPieSegmentRenderer() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void renderSegments(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.Point center, int nominalRadius, int[] angles) {
	}

	public void renderSegments(java.awt.Graphics2D g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.geom.Point2D center, float nominalRadius, float[] angles) {
	}
}
