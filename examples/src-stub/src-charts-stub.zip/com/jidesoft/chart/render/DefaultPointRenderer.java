/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A point renderer that uses one of the PointShape constants as the shape of the point that it renders.
 *  The point shape and size is part of the ChartStyle used for a model.
 */
public class DefaultPointRenderer extends AbstractPointRenderer {

	public DefaultPointRenderer() {
	}

	/**
	 *  Draws the supplied shape onto the Graphics context, using x and y as the centre of the shape, pointSize as an
	 *  indication of the size of the shape, and shape as the shape type
	 */
	public java.awt.Shape renderPoint(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable point, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y) {
	}
}
