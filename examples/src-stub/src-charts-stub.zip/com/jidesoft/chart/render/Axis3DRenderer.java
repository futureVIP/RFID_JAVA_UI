/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A class that renderers a three dimensional 'platform'-like axis.
 */
public class Axis3DRenderer implements AxisRenderer {
 {

	/**
	 *  Create an Axis3DRenderer
	 */
	public Axis3DRenderer() {
	}

	/**
	 *  When rendering horizontally the supplied y coordinate is the centre of the rendered breadth
	 */
	public void renderAxis(java.awt.Graphics g, int x, int y, int length, com.jidesoft.chart.Orientation orientation) {
	}

	/**
	 *  Returns the breadth of the axis
	 *  @return the breadth of the axis
	 */
	public int getBreadth() {
	}

	/**
	 *  Specify the breadth of the axis
	 *  @param breadth the new breadth of the axis
	 */
	public void setBreadth(int breadth) {
	}
}
