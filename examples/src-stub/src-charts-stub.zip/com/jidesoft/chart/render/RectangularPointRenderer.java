/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A point renderer that draws a rectangle for each of its points. For this renderer, the width and height of each
 *  rectangle is taken from the 3rd and 4th dimension of the chart point (a ChartableND) of the ChartModel. In other
 *  words you can easily configure the size of each point individually.
 */
public class RectangularPointRenderer extends AbstractPointRenderer {

	public RectangularPointRenderer() {
	}

	public java.awt.Shape renderPoint(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable point, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y) {
	}
}
