/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A class that renders the bars of a bar chart in 3D
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class Bar3DRenderer extends AbstractBarRenderer {

	public Bar3DRenderer() {
	}

	public int getMinimumBreadth() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void renderBar(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y, int width, int height) {
	}

	protected java.awt.Paint createTopPaint(com.jidesoft.chart.Orientation orientation, java.awt.Color color, int x, int y, int width, int height, int depth) {
	}

	protected java.awt.Paint createSidePaint(com.jidesoft.chart.Orientation orientation, java.awt.Color color, int x, int y, int width, int height, int depth) {
	}

	protected java.awt.Paint createFrontPaint(com.jidesoft.chart.Orientation orientation, java.awt.Color color, int x, int y, int width, int height, int depth) {
	}

	public static int computeOffset(int barWidth) {
	}
}
