/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  This renderer takes account of negative heights. If a negative height is supplied, then the y coordinate and height
 *  are adjusted so that the height becomes positive and the shape is paintable. <p>NOTE: Widths are currently assumed to
 *  be positive</p>
 */
public class DefaultBarRenderer extends AbstractBarRenderer {

	public DefaultBarRenderer() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void renderBar(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel m, com.jidesoft.chart.model.Chartable p, boolean isSelected, boolean hasRollover, boolean hasFocus, int x, int y, int width, int height) {
	}

	public int getMinimumBreadth() {
	}
}
