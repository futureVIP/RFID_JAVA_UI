/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A pie label renderer that draws lines from the label to its corresponding segment in the pie chart.
 */
public class LinePieLabelRenderer implements PieLabelRenderer2D {
 {

	public LinePieLabelRenderer() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public PointLabeler getPointLabeler() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setPointLabeler(PointLabeler pointLabeler) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public int getTickLength() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void setTickLength(int tickLength) {
	}

	public int getLabelXOffset() {
	}

	/**
	 *  Specifies the distance that the labels are offset from the pie in the x direction
	 *  @param labelXOffset the distance in pixels
	 */
	public void setLabelXOffset(int labelXOffset) {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void renderLabels(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.Point center, int width, int height, int[] angles, com.jidesoft.chart.style.ChartStyle style) {
	}

	public void renderLabels(java.awt.Graphics2D g2d, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.geom.Point2D center, double width, double height, float[] angles, com.jidesoft.chart.style.ChartStyle style) {
	}

	public void layout(java.util.List labels) {
	}
}
