/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  Renders the segments of a pie chart using paint colors to give a 'raised' effect
 */
public class RaisedPieSegmentRenderer extends AbstractPieSegmentRenderer {

	public RaisedPieSegmentRenderer() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public void renderSegments(java.awt.Graphics g, com.jidesoft.chart.Chart chart, com.jidesoft.chart.model.ChartModel model, java.awt.Point center, int radius, int[] angles) {
	}
}
