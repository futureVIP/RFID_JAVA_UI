/**
 *  Package containing renderers used by Chart, such as point renderers and line renderers.
 */
package com.jidesoft.chart.render;


/**
 *  A default implementation of the PointLabeler class
 */
public class DefaultPointLabeler implements PointLabeler {
 {

	public DefaultPointLabeler() {
	}

	/**
	 *  {@inheritDoc}
	 */
	public String getDisplayText(com.jidesoft.chart.model.Chartable p) {
	}
}
