/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  Used for indicating whether a chart item (such as an axis) is oriented vertically or horizontally.
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public final class Orientation extends Enum {

	public static final Orientation horizontal;

	public static final Orientation vertical;

	public static Orientation[] values() {
	}

	public static Orientation valueOf(String name) {
	}

	public Orientation toggle() {
	}
}
