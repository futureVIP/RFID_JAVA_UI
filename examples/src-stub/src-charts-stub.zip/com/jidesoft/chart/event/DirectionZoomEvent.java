/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A zoom event where the zoom specifies only the direction and is not on a particular point
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class DirectionZoomEvent extends ChartSelectionEvent {

	public DirectionZoomEvent(Object source, ZoomDirection direction) {
	}

	@java.lang.Override
	public ZoomDirection getDirection() {
	}

	public void setDirection(ZoomDirection direction) {
	}

	@java.lang.Override
	public Object getLocation() {
	}

	@java.lang.Override
	public String toString() {
	}
}
