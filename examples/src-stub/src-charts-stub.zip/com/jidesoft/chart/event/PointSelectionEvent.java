/**
 *  The package contains events and listeners for JIDE Charts product
 */
package com.jidesoft.chart.event;


/**
 *  A zoom event where the zoom is on a particular point
 * 
 *  @author Simon White (swhite@catalysoft.com)
 */
public class PointSelectionEvent extends ChartSelectionEvent {

	public PointSelectionEvent(Object source, java.awt.Point point, ZoomDirection direction) {
	}

	public PointSelectionEvent(Object source, java.awt.Point point, ZoomDirection direction, double zoomFactor) {
	}

	@java.lang.Override
	public java.awt.Point getLocation() {
	}

	@java.lang.Override
	public ZoomDirection getDirection() {
	}

	public void setDirection(ZoomDirection direction) {
	}

	public Double getZoomFactor() {
	}

	@java.lang.Override
	public String toString() {
	}
}
