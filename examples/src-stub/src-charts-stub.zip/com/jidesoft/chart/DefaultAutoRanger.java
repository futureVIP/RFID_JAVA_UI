/**
 *  The package contains the classes related to the JIDE Charts product.
 */
package com.jidesoft.chart;


/**
 *  A class that computes appropriate ranges for the x and y axes of a chart.
 *  By default the leading and trailing margin proportions for the x and y ranges are 10% of the difference between
 *  the maximum and the minimum (that is, the value is 0.1).
 *  If required, you can fix corner points of the x and y axes - for example to make sure the origin of the chart is
 *  at (0, 0) while allowing the maximum values to be auto-ranged.
 */
public class DefaultAutoRanger implements AutoRanger {
 {

	/**
	 *  Creates an auto ranger that does not constrain any of the corner points of the x or y axes, and with
	 *  default values for the leading and trailing margin proportions.
	 */
	public DefaultAutoRanger() {
	}

	/**
	 *  This constructor allows you to fix one or more parts of the ranges that are returned. A common
	 *  example of this would be when you are plotting a bar chart and you always want the minimum y value to be 0.
	 *  If you provide null as any of the values here, that part of the returned range is not fixed and an auto-range
	 *  value is computed as normal.
	 * 
	 *  @param fixMinX the fixed value for min x, or null to compute value automatically
	 *  @param fixMinY the fixed value for min y, or null to compute value automatically
	 *  @param fixMaxX the fixed value for max x, or null to compute value automatically
	 *  @param fixMaxY the fixed value for max y, or null to compute value automatically
	 */
	public DefaultAutoRanger(Double fixMinX, Double fixMinY, Double fixMaxX, Double fixMaxY) {
	}

	/**
	 *  Sets the margin proportions to apply to ranges when calculating minima and maxima.
	 *  If you are setting all the margin proportions this is easier to use than calling the
	 *  individual setters for each of the margins.
	 * 
	 *  @param top    the trailing y margin proportion
	 *  @param left   the leading x margin proportion
	 *  @param bottom the leading y margin proportion
	 *  @param right  the trailing x margin proportion
	 */
	public void setMarginProportions(double top, double left, double bottom, double right) {
	}

	public double getLeadingXMarginProportion() {
	}

	public void setLeadingXMarginProportion(double leadingXMarginProportion) {
	}

	public double getLeadingYMarginProportion() {
	}

	public void setLeadingYMarginProportion(double leadingYMarginProportion) {
	}

	public double getTrailingXMarginProportion() {
	}

	public void setTrailingXMarginProportion(double trailingXMarginProportion) {
	}

	public double getTrailingYMarginProportion() {
	}

	public void setTrailingYMarginProportion(double trailingYMarginProportion) {
	}

	/**
	 *  Computes appropriate x and y ranges for the supplied chart instance.
	 * 
	 *  @param chart the chart instance for which the ranges should be calculated
	 *  @return Ranges that can be used for the x and y axes of the supplied chart
	 */
	public util.Pair getRanges(Chart chart) {
	}

	/**
	 *  Returns the x range when plotting a stacked bar chart.
	 *  This is a special case for finding out the x and y range so is treated separately here
	 * 
	 *  @return the X Range for a stacked bar chart
	 */
	public util.Pair getStackedRanges(Chart chart) {
	}
}
