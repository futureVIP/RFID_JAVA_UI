/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  Wizard is a well-known user interface that is ideal to guide user through for complex and unfamiliar tasks. A typical
 *  usage of it is project wizard - which asks user a couple questions and generate source code of a project
 *  automatically for user.
 *  <p/>
 *  There are several wizard standards. The most famous two are Microsoft Wizard 97 standard and Java Wizard standard.
 *  Please see references for details. I strongly suggest you read those chapters before designing any wizards since
 *  those documents are also the specs for our wizard component. Both documents are very well-written.
 *  <p/>
 *  <a href=http://msdn.microsoft.com/library/default.asp?url=/library/en-us/wizard/sdkwizv4_7awn.asp>Micrsoft Wizard 97
 *  Standard</a> <br> <a href=http://java.sun.com/products/jlf/at/book/Wizards.html>Java LookAndFeel Wizard Standard</a>
 *  <p/>
 *  <p/>
 *  Correspondingly, there are two styles as you can set to WizardDialog - WIZARD97_STYLE and JAVA_STYLE. Because those
 *  two styles are not compatible completely, I suggest you only support one of the styles in your application. Some
 *  major differences are <ul> <li>Left Pane: Java style provides more flexibility in left pane. It can display steps,
 *  help, or graphics. In Wizard 97 style, it can only be graphics or nothing. <li>Banner: Wizard 97 uses Banner in each
 *  interior page to show title and subtitle. Java style doesn't use it at all but show title and subtitle in right side
 *  of each page. <li>Buttons: All buttons on bottom are aligned to left in Wizard 97. Java style aligned NEXT and BACK
 *  button to the right. </ul>
 */
public class WizardDialog extends StandardDialog {

	protected WizardDialogPane _wizardDialogPane;

	/**
	 *  Creates a wizard dialog with no owner.
	 * 
	 *  @exception HeadlessException if <code>GraphicsEnvironment.isHeadless()</code> returns <code>true</code>.
	 */
	public WizardDialog() {
	}

	/**
	 *  Creates a modal or non-modal wizard dialog without a title and with the specified owner.
	 *  <p/>
	 *  This constructor sets the component's locale property to the value returned by
	 *  <code>JComponent.getDefaultLocale</code>.
	 * 
	 *  @param owner the non-null <code>Frame</code> from which the dialog is displayed
	 *  @param modal true for a modal dialog, false for one that allows other windows to be active at the same time
	 *  @exception HeadlessException if <code>GraphicsEnvironment.isHeadless()</code> returns <code>true</code>.
	 */
	public WizardDialog(java.awt.Frame owner, boolean modal) {
	}

	/**
	 *  Creates a modal or non-modal wizard dialog without a title and with the specified owner.
	 *  <p/>
	 *  This constructor sets the component's locale property to the value returned by
	 *  <code>JComponent.getDefaultLocale</code>.
	 * 
	 *  @param owner the non-null <code>Frame</code> from which the dialog is displayed
	 *  @param title the <code>String</code> to display in the dialog's title bar
	 *  @exception HeadlessException if <code>GraphicsEnvironment.isHeadless()</code> returns <code>true</code>.
	 */
	public WizardDialog(java.awt.Frame owner, String title) {
	}

	/**
	 *  Creates a modal or non-modal wizard dialog without a title and with the specified owner.
	 *  <p/>
	 *  This constructor sets the component's locale property to the value returned by
	 *  <code>JComponent.getDefaultLocale</code>.
	 * 
	 *  @param owner the non-null <code>Frame</code> from which the dialog is displayed
	 *  @param title the <code>String</code> to display in the dialog's title bar
	 *  @param modal true for a modal dialog, false for one that allows other windows to be active at the same time
	 *  @exception HeadlessException if <code>GraphicsEnvironment.isHeadless()</code> returns <code>true</code>.
	 */
	public WizardDialog(java.awt.Frame owner, String title, boolean modal) {
	}

	/**
	 *  Creates a modal or non-modal wizard dialog without a title and with the specified owner.
	 *  <p/>
	 *  This constructor sets the component's locale property to the value returned by
	 *  <code>JComponent.getDefaultLocale</code>.
	 * 
	 *  @param owner the non-null <code>Dialog</code> from which the dialog is displayed
	 *  @param modal true for a modal dialog, false for one that allows other windows to be active at the same time
	 *  @exception HeadlessException if <code>GraphicsEnvironment.isHeadless()</code> returns <code>true</code>.
	 */
	public WizardDialog(java.awt.Dialog owner, boolean modal) {
	}

	/**
	 *  Creates a modal or non-modal wizard dialog without a title and with the specified owner.
	 *  <p/>
	 *  This constructor sets the component's locale property to the value returned by
	 *  <code>JComponent.getDefaultLocale</code>.
	 * 
	 *  @param owner the non-null <code>Dialog</code> from which the dialog is displayed
	 *  @param title the <code>String</code> to display in the dialog's title bar
	 *  @exception HeadlessException if <code>GraphicsEnvironment.isHeadless()</code> returns <code>true</code>.
	 */
	public WizardDialog(java.awt.Dialog owner, String title) {
	}

	/**
	 *  Creates a modal or non-modal wizard dialog without a title and with the specified owner.
	 *  <p/>
	 *  This constructor sets the component's locale property to the value returned by
	 *  <code>JComponent.getDefaultLocale</code>.
	 * 
	 *  @param owner the non-null <code>Dialog</code> from which the dialog is displayed
	 *  @param title the <code>String</code> to display in the dialog's title bar
	 *  @param modal true for a modal dialog, false for one that allows other windows to be active at the same time
	 *  @exception HeadlessException if <code>GraphicsEnvironment.isHeadless()</code> returns <code>true</code>.
	 */
	public WizardDialog(java.awt.Dialog owner, String title, boolean modal) {
	}

	/**
	 *  Customizes the wizard.
	 */
	protected void initWizard() {
	}

	/**
	 *  Subclass can override to create actions for buttons.
	 */
	protected void createActions() {
	}

	/**
	 *  Changes the default back action.
	 * 
	 *  @param backAction the back action
	 */
	public void setBackAction(javax.swing.AbstractAction backAction) {
	}

	/**
	 *  Get the back action.
	 * 
	 *  @return the back action.
	 */
	public javax.swing.AbstractAction getBackAction() {
	}

	/**
	 *  Changes the default next action.
	 * 
	 *  @param nextAction the next action
	 */
	public void setNextAction(javax.swing.AbstractAction nextAction) {
	}

	/**
	 *  Get the next action.
	 * 
	 *  @return the next action.
	 */
	public javax.swing.AbstractAction getNextAction() {
	}

	/**
	 *  Changes the default cancel action. When you write your own cancel action, make sure you call
	 *  wizard.closeCurrentPage(). Otherwise PAGE_CLOSING and PAGE_CLOSED event will not be fired. *
	 * 
	 *  @param cancelAction the cancel action
	 */
	public void setCancelAction(javax.swing.AbstractAction cancelAction) {
	}

	/**
	 *  Gets the cancel action.
	 * 
	 *  @return the cancel action
	 */
	public javax.swing.AbstractAction getCancelAction() {
	}

	/**
	 *  Gets the finish action.
	 * 
	 *  @return the finish action
	 */
	public javax.swing.AbstractAction getFinishAction() {
	}

	/**
	 *  Changes the default finish action. When you write your own finish action, make sure you call
	 *  wizard.closeCurrentPage(). Otherwise PAGE_CLOSING and PAGE_CLOSED event will not be fired.
	 * 
	 *  @param finishAction the finish action
	 */
	public void setFinishAction(javax.swing.AbstractAction finishAction) {
	}

	/**
	 *  Sets the page list to wizard dialog. The page list should contain a list of all wizard pages. Once page list is
	 *  set to wizard, you should not change the page list.
	 *  <p/>
	 *  Please note the pages in the page list should have an unique title so that the wizard can uniquely identify each
	 *  page by its title. Otherwise, IllegalArgumentException will be thrown.
	 * 
	 *  @param pageList the page list
	 *  @throws IllegalArgumentException if the pages have duplicated titles.
	 */
	public void setPageList(PageList pageList) {
	}

	/**
	 *  Gets the page list which have all the wizard pages.
	 * 
	 *  @return the page list.
	 */
	public PageList getPageList() {
	}

	/**
	 *  Gets the current selected page.
	 * 
	 *  @return the current selected page.
	 */
	public AbstractDialogPage getCurrentPage() {
	}

	/**
	 *  Sets the current selected page. Make it private since no class outside should call this method.
	 * 
	 *  @param pageTitle new page title.
	 *  @return true if set correctly. Otherwise false.
	 */
	public boolean setCurrentPage(String pageTitle) {
	}

	/**
	 *  Sets the current selected page. Make it private since no class outside should call this method.
	 * 
	 *  @param pageTitle new page title.
	 *  @param isBack    is this caused by BACK button.
	 *  @return true if set correctly. Otherwise false.
	 */
	protected boolean setCurrentPage(String pageTitle, boolean isBack) {
	}

	/**
	 *  Close current dialog page.
	 * 
	 *  @param newPage the new page. If current page is the same as nwe page, nothing will be done. It you will close the
	 *                 page and will not open any new page, for example, when finish or cancel button is pressed, you can
	 *                 pass in null.
	 *  @param source  the source that will be used in event.
	 *  @return false if current page doesn't allow it to be closed; true if the current page is close successfully.
	 */
	protected boolean closeCurrentPage(AbstractDialogPage newPage, Object source) {
	}

	/**
	 *  Close current dialog page.
	 * 
	 *  @return false if current page doesn't allow it to be closed; true if the current page is close successfully.
	 */
	public boolean closeCurrentPage() {
	}

	/**
	 *  Close current dialog page with an optional source object.
	 * 
	 *  @param source the source of the PageEvent that will be fired when closing the current page
	 *  @return false if current page doesn't allow it to be closed; true if the current page is close successfully.
	 */
	public boolean closeCurrentPage(Object source) {
	}

	/**
	 *  Sets the current selected page. Make it private since no class outside should call this method.
	 * 
	 *  @param currentPage new page.
	 *  @param isBack      is this caused by BACK button.
	 *  @return false if current page doesn't allow it to be closed; true if the current page is close successfully.
	 */
	protected boolean setCurrentPage(AbstractDialogPage currentPage, boolean isBack) {
	}

	/**
	 *  Sets the current selected page. Make it private since no class outside should call this method.
	 * 
	 *  @param currentPage new page.
	 *  @param isBack      is this caused by BACK button.
	 *  @param source      source for the event
	 *  @return false if current page doesn't allow it to be closed; true if the current page is close successfully.
	 */
	protected boolean setCurrentPage(AbstractDialogPage currentPage, boolean isBack, Object source) {
	}

	/**
	 *  Gets the left pane.
	 * 
	 *  @return the left pane
	 */
	public javax.swing.JComponent getLeftPanel() {
	}

	/**
	 *  Gets the pages panel.
	 * 
	 *  @return the pages panel.
	 */
	public javax.swing.JComponent getPagesPanel() {
	}

	/**
	 *  Gets the width of left panel.
	 * 
	 *  @return the width of left panel.
	 */
	public int getLeftPanelWidth() {
	}

	/**
	 *  Sets the left panel width.
	 * 
	 *  @param leftPanelWidth the width
	 */
	public void setLeftPanelWidth(int leftPanelWidth) {
	}

	/**
	 *  Gets the content pane size. The content pane is the wizard except button panel and banner panel.
	 * 
	 *  @return the content pane size.
	 */
	public java.awt.Dimension getContentSize() {
	}

	/**
	 *  Sets the content size.
	 * 
	 *  @param contentSize the size
	 */
	public void setContentSize(java.awt.Dimension contentSize) {
	}

	/**
	 *  Gets the standard size of content pane.
	 * 
	 *  @return the standard size of content pane.
	 */
	public java.awt.Dimension getContentStandardSize() {
	}

	/**
	 *  Gets the standard width of left pane.
	 * 
	 *  @return the standard width of left pane.
	 */
	public int getStandardLeftPaneWidth() {
	}

	/**
	 *  Gets the larger standard size of content pane when the standard size is not enough.
	 * 
	 *  @return the larger standard size of content pane.
	 */
	public java.awt.Dimension getContentLargerSize() {
	}

	/**
	 *  Gets the larger standard width of left pane when the larger standard size is used.
	 * 
	 *  @return the larger standard width of left pane.
	 */
	public int getLargerLeftPaneWidth() {
	}

	/**
	 *  Gets the page by the full title.
	 * 
	 *  @param title the title
	 *  @return the page with the title.
	 */
	public AbstractDialogPage getPageByTitle(String title) {
	}

	/**
	 *  Gets the default next page. In most case it will return null unless you set it. If the next page is null, it
	 *  means default next page will be used which is usually the next page to current one in the page list
	 * 
	 *  @return next page.
	 */
	public AbstractDialogPage getNextPage() {
	}

	/**
	 *  Sets the next page. It will jump to this page when NEXT button is pressed.
	 * 
	 *  @param nextPage next page instance
	 */
	public void setNextPage(AbstractDialogPage nextPage) {
	}

	/**
	 *  Gets list of visited pages.
	 * 
	 *  @return list of visited pages.
	 */
	public java.util.List getVisitedPages() {
	}

	/**
	 *  Gets the default graphic that will be displayed in left pane.
	 * 
	 *  @return the default graphic
	 */
	public java.awt.Image getDefaultGraphic() {
	}

	/**
	 *  Sets the default graphic that will be displayed in left pane.
	 * 
	 *  @param defaultGraphic the image
	 */
	public void setDefaultGraphic(java.awt.Image defaultGraphic) {
	}

	/**
	 *  Gets the steps pane if steps pane is used.
	 * 
	 *  @return the steps pane if steps pane is used. Otherwise null.
	 */
	public StepsPane getStepsPane() {
	}

	/**
	 *  Gets the help pane if help pane is used.
	 * 
	 *  @return the help pane if help pane is used. Otherwise null.
	 */
	public JavaHelpPane getHelpPane() {
	}

	/**
	 *  Creates WizardDialogPane.
	 * 
	 *  @return the WizardDialogPane.
	 */
	@java.lang.Override
	protected StandardDialogPane createStandardDialogPane() {
	}

	@java.lang.Override
	public void setLocale(java.util.Locale l) {
	}

	/**
	 *  Creates the banner panel for WizardDialog. It will delegate to WizardDialogPane to create the banner panel.
	 * 
	 *  @return the banner panel.
	 */
	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	/**
	 *  Creates the content panel for WizardDialog. It will delegate to WizardDialogPane to create the content panel.
	 * 
	 *  @return the content panel.
	 */
	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	/**
	 *  Creates the button panel for WizardDialog. It will delegate to WizardDialogPane to create the button panel.
	 * 
	 *  @return the button panel.
	 */
	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}

	/**
	 *  Checks if the steps pane can be clicked to navigate to the corresponding page.
	 * 
	 *  @return true or false.
	 */
	public boolean isStepsPaneNavigable() {
	}

	/**
	 *  Sets the steps pane navigable. If true, user can click on the steps pane to navigate to the corresponding page.
	 * 
	 *  @param stepsPaneNavigable true or false.
	 */
	public void setStepsPaneNavigable(boolean stepsPaneNavigable) {
	}
}
