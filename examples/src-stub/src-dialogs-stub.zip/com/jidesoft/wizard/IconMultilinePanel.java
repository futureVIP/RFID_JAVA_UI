/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  This is a panel with icon in the front and a multiple line label in the center.
 *  It is used in wizard page to addInfo() and addWarning().
 */
public class IconMultilinePanel extends javax.swing.JPanel {

	/**
	 *  Creates an IconMultilinePanel.
	 * 
	 *  @param icon
	 *  @param text
	 */
	public IconMultilinePanel(javax.swing.Icon icon, String text) {
	}
}
