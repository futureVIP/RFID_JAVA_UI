/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  JavaHelpPane is a pane used by Java L&F wizard standard to display a help message in the left
 *  pane.
 */
public class JavaHelpPane extends GraphicLeftPane {

	/**
	 *  Creates a JavaHelpPane.
	 */
	public JavaHelpPane() {
	}

	public JavaHelpPane(java.awt.Image image) {
	}

	/**
	 *  Sets the help text.
	 * 
	 *  @param text new help text.
	 */
	public void setHelpText(String text) {
	}
}
