/**
 *  The package contains classes related for Wizard copmonent for JIDE Dialogs product.
 */
package com.jidesoft.wizard;


/**
 *  <tt>DefaultWizardPage</tt> extends <tt>AbstractWizardPage</tt> to provide a way to create the content easily.
 *  <p/>
 *  You certainly can create the whatever wizard content. However most components in wizard content are laid out
 *  vertically and have a fixed gap in between. All you need to do is to override initConentPane() and call a bunch of
 *  add methods. <ul> <li><tt>public void addText(String text)</tt>: add a multiple line text <li><tt>public void
 *  addText(String text, Font font)</tt>: add a multiple line text with specified font <li><tt>public void
 *  addTitle(String text)</tt>: add a multiple line title (Wizard 97 Standard only) <li><tt>public void addWarning(String
 *  text)</tt>: add a multiple line warning text. It will show a warning icon before the text <li><tt>public void
 *  addInfo(String text)</tt>: add a multiple line important text but not yet warning. It will show an info icon before
 *  the text <li><tt>public void addIconText(Icon icon, String text)</tt>: add a multiple line text with any icon
 *  <li><tt>public void addComponent(JComponent component)</tt>: add any component <li><tt>public void addSpace()</tt>:
 *  add space. All components added after addSpace will align to bottom. </ul>
 */
public class DefaultWizardPage extends AbstractWizardPage {

	/**
	 *  Creates a DefaultWizardPage with title.
	 * 
	 *  @param title
	 */
	public DefaultWizardPage(String title) {
	}

	/**
	 *  Creates a DefaultWizardPage with title and description.
	 * 
	 *  @param title
	 *  @param description
	 */
	public DefaultWizardPage(String title, String description) {
	}

	/**
	 *  Creates a DefaultWizardPage with title and icon.
	 * 
	 *  @param title
	 *  @param icon
	 */
	public DefaultWizardPage(String title, javax.swing.Icon icon) {
	}

	/**
	 *  Creates a DefaultWizardPage with title, description and icon.
	 * 
	 *  @param title
	 *  @param description
	 *  @param icon
	 */
	public DefaultWizardPage(String title, String description, javax.swing.Icon icon) {
	}

	/**
	 *  Creates the content pane by add those pre-added components into a JPanel with JideBoxLayout.
	 * 
	 *  @return the content pane.
	 */
	protected javax.swing.JComponent createDefaultContentPane() {
	}

	/**
	 *  Adds a multiple line text.
	 * 
	 *  @param text
	 */
	public void addText(String text) {
	}

	/**
	 *  Adds a multiple line text with specified font.
	 * 
	 *  @param text
	 *  @param font
	 */
	public void addText(String text, java.awt.Font font) {
	}

	/**
	 *  Adds a multiple line title (Wizard 97 Standard only).
	 * 
	 *  @param text
	 */
	public void addTitle(String text) {
	}

	/**
	 *  Adds a multiple line warning text. It will show a warning icon before the text. It is using {@link
	 *  IconMultilinePanel}. You can set your own icon by creating your own IconMultilinePanel.
	 * 
	 *  @param text
	 */
	public void addWarning(String text) {
	}

	/**
	 *  Adds a multiple line important text. It will show a warning icon before the text. It is using {@link
	 *  IconMultilinePanel}. You can set your own icon by creating your own IconMultilinePanel.
	 * 
	 *  @param text
	 */
	public void addInfo(String text) {
	}

	/**
	 *  Adds a multiple line text with any icon.
	 * 
	 *  @param icon
	 *  @param text
	 */
	public void addIconText(javax.swing.Icon icon, String text) {
	}

	/**
	 *  Adds any component.
	 * 
	 *  @param component
	 */
	public void addComponent(javax.swing.JComponent component) {
	}

	/**
	 *  Adds any component.
	 * 
	 *  @param component
	 *  @param fill      true if the component should fill the whatever space left. Only one component can be added as
	 *                   fill. If several component are added as fill, the last one takes priority.
	 */
	public void addComponent(javax.swing.JComponent component, boolean fill) {
	}

	/**
	 *  Adds space. All components added before space will align to top and after space will align to bottom.
	 */
	public void addSpace() {
	}

	/**
	 *  Empty implementation.
	 */
	@java.lang.Override
	public void setupWizardButtons() {
	}

	/**
	 *  Subclasses should override this method to add components to wizard page.
	 */
	protected void initContentPane() {
	}

	@java.lang.Override
	public javax.swing.JComponent createWizardContent() {
	}

	/**
	 *  Gets the content border.
	 *  <p/>
	 *  By default it will use getContentThinBorder() if user didn't set it.
	 * 
	 *  @return the content border. It will return getContentThinBorder() if user didn't set it.
	 */
	public javax.swing.border.Border getContentBorder() {
	}

	/**
	 *  Sets the content border.
	 * 
	 *  @param contentBorder
	 */
	public void setContentBorder(javax.swing.border.Border contentBorder) {
	}
}
