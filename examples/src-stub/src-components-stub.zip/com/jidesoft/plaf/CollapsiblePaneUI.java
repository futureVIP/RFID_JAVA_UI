package com.jidesoft.plaf;


/**
 *  ComponentUI for CollapsiblePane.
 */
public abstract class CollapsiblePaneUI extends javax.swing.plaf.PanelUI {

	public CollapsiblePaneUI() {
	}

	public abstract java.awt.Component getTitlePane() {
	}

	public abstract javax.swing.Action getToggleAction() {
	}
}
