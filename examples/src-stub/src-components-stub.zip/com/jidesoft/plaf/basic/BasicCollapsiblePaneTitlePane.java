package com.jidesoft.plaf.basic;


/**
 *  Basic L&f implementation of title bar for CollapsiblePaneTitlePane
 */
public class BasicCollapsiblePaneTitlePane extends javax.swing.JComponent implements java.awt.event.FocusListener {
 {

	protected BasicCollapsiblePaneTitlePane.BasicCollapseButton _collapseButton;

	protected javax.swing.JComponent _titleLabel;

	protected javax.swing.JLabel _titleIconLabel;

	protected java.awt.Component _titleComponent;

	protected javax.swing.JPopupMenu _popupMenu;

	protected com.jidesoft.pane.CollapsiblePane _pane;

	protected java.beans.PropertyChangeListener _propertyChangeListener;

	protected String _collapseText;

	protected String _collapseToolTip;

	/**
	 *  It's the icon to be painted while the CollpasiblePane is not emphasized and is expanded while the style is #DROPDOWN_STYLE or #SEPARATOR_STYLE.
	 */
	protected javax.swing.ImageIcon _upIcon;

	/**
	 *  It's the icon to be painted while the CollpasiblePane is not emphasized and is collapsed while the style is #DROPDOWN_STYLE or #SEPARATOR_STYLE.
	 */
	protected javax.swing.ImageIcon _downIcon;

	/**
	 *  It's the icon to be painted while the CollpasiblePane is emphasized and is expanded while the style is #DROPDOWN_STYLE or #SEPARATOR_STYLE.
	 */
	protected javax.swing.ImageIcon _emphasizedUpIcon;

	/**
	 *  It's the icon to be painted while the CollpasiblePane is emphasized and is collapsed while the style is #DROPDOWN_STYLE or #SEPARATOR_STYLE.
	 */
	protected javax.swing.ImageIcon _emphasizedDownIcon;

	/**
	 *  It's the icon to be painted while the mouse is rollover the CollpasiblePane and the CollapsiblePane is expanded.
	 */
	protected javax.swing.ImageIcon _upRolloverIcon;

	/**
	 *  It's the icon to be painted while the mouse is rollover the CollpasiblePane and the CollapsiblePane is collapsed.
	 */
	protected javax.swing.ImageIcon _downRolloverIcon;

	/**
	 *  It's the icon to be painted while the CollpasiblePane is collapsed while the style is #TREE_STYLE or #PLAIN_STYLE.
	 */
	protected javax.swing.Icon _collapsedIcon;

	/**
	 *  It's the icon to be painted while the CollpasiblePane is expanded while the style is #TREE_STYLE or #PLAIN_STYLE.
	 */
	protected javax.swing.Icon _expandedIcon;

	public BasicCollapsiblePaneTitlePane(com.jidesoft.pane.CollapsiblePane f) {
	}

	protected void installTitlePane() {
	}

	protected void addSubComponents() {
	}

	protected void createActions() {
	}

	protected void installListeners() {
	}

	protected BasicCollapsiblePaneTitlePane.DropListener createDropListener() {
	}

	protected void uninstallListeners() {
	}

	protected void installDefaults() {
	}

	protected void uninstallDefaults() {
	}

	protected void createSubComponents() {
	}

	protected javax.swing.JLabel createDefaultTitleLabel() {
	}

	protected BasicCollapsiblePaneTitlePane.BasicCollapseButton createCollapseButton() {
	}

	protected void setupCollapseButton(BasicCollapsiblePaneTitlePane.BasicCollapseButton button) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void addPopupMenuItems(javax.swing.JPopupMenu popup) {
	}

	protected javax.swing.JPopupMenu createPopupMenu() {
	}

	@java.lang.Override
	public void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Invoked from paintComponent. Paints the background of the titlepane.  All text and icons will then be rendered on
	 *  top of this background.
	 * 
	 *  @param g the graphics to use to render the background
	 *  @since 1.4
	 */
	protected void paintTitleBackground(java.awt.Graphics g) {
	}

	protected void paintFocusIndicator(java.awt.Graphics g, int x, int y, int w, int h) {
	}

	protected java.awt.Dimension getActualTitlePaneDimension() {
	}

	protected String getTitle(String text, java.awt.FontMetrics fm, int availTextWidth) {
	}

	protected java.beans.PropertyChangeListener createPropertyChangeListener() {
	}

	protected java.awt.LayoutManager createLayout() {
	}

	/**
	 *  Sets the bounds while considering the leftToRight or rightToLeft if the sliding direction is north or south.
	 * 
	 *  @param container the title pane
	 *  @param component the child component on the title pane
	 *  @param x         x
	 *  @param y         y
	 *  @param width     width
	 *  @param height    height
	 */
	protected void setBounds(java.awt.Container container, java.awt.Component component, int x, int y, int width, int height) {
	}

	public void popupMenu(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Invoked when a component gains the keyboard focus.
	 */
	public void focusGained(java.awt.event.FocusEvent e) {
	}

	/**
	 *  Invoked when a component loses the keyboard focus.
	 */
	public void focusLost(java.awt.event.FocusEvent e) {
	}

	public boolean isRollover() {
	}

	public void setRollover(boolean rollover) {
	}

	protected java.awt.Color getCollapsiblePaneForeground() {
	}

	public ThemePainter getPainter() {
	}

	protected int getButtonSize() {
	}

	/**
	 *  This inner class is marked &quot;public&quot; due to a compiler bug. This class should be treated as a
	 *  &quot;protected&quot; inner class. Instantiate it only within subclasses of <Foo>.
	 */
	public class PropertyChangeHandler {


		public BasicCollapsiblePaneTitlePane.PropertyChangeHandler() {
		}

		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}
	}

	/**
	 *  This inner class is marked &quot;public&quot; due to a compiler bug. This class should be treated as a
	 *  &quot;protected&quot; inner class. Instantiate it only within subclasses of <Foo>.
	 */
	public class CollapsibleLayout {


		public BasicCollapsiblePaneTitlePane.CollapsibleLayout() {
		}

		public void addLayoutComponent(String name, java.awt.Component c) {
		}

		public void removeLayoutComponent(java.awt.Component c) {
		}

		public java.awt.Dimension preferredLayoutSize(java.awt.Container c) {
		}

		public java.awt.Dimension minimumLayoutSize(java.awt.Container c) {
		}

		public void layoutContainer(java.awt.Container c) {
		}
	}

	protected class BasicCollapseButton {


		public static final int UP_BUTTON = 0;

		public static final int DOWN_BUTTON = 1;

		public BasicCollapsiblePaneTitlePane.BasicCollapseButton() {
		}

		/**
		 *  Resets the UI property to a value from the current look and feel.
		 * 
		 *  @see javax.swing.JComponent#updateUI
		 */
		@java.lang.Override
		public void updateUI() {
		}

		public boolean isStill() {
		}

		public void setStill(boolean still) {
		}

		@java.lang.Override
		protected void paintComponent(java.awt.Graphics g) {
		}

		protected void paintIcon(java.awt.Graphics g) {
		}

		protected void paintIcon(java.awt.Graphics g, java.awt.Color textColor, javax.swing.Icon treeIcon, javax.swing.ImageIcon icon, javax.swing.ImageIcon rolloverIcon) {
		}

		@java.lang.Override
		public boolean isFocusable() {
		}

		@java.lang.Override
		public void requestFocus() {
		}

		@java.lang.Override
		public boolean isOpaque() {
		}

		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		public void mouseClicked(java.awt.event.MouseEvent e) {
		}

		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		public void mouseEntered(java.awt.event.MouseEvent e) {
		}

		public void mouseExited(java.awt.event.MouseEvent e) {
		}

		public int getType() {
		}

		public void setType(int type) {
		}

		/**
		 *  Invoked when a key has been typed. See the class description for {@link KeyEvent} for a definition of a key
		 *  typed event.
		 */
		public void keyTyped(java.awt.event.KeyEvent e) {
		}

		/**
		 *  Invoked when a key has been pressed. See the class description for {@link KeyEvent} for a definition of a key
		 *  pressed event.
		 */
		public void keyPressed(java.awt.event.KeyEvent e) {
		}

		/**
		 *  Invoked when a key has been released. See the class description for {@link KeyEvent} for a definition of a
		 *  key released event.
		 */
		public void keyReleased(java.awt.event.KeyEvent e) {
		}
	}
}
