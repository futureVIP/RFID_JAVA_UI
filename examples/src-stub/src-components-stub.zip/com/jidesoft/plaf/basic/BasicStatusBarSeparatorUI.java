package com.jidesoft.plaf.basic;


/**
 *  A Basic L&F implementation of StatusBarSeparatorUI.
 */
public class BasicStatusBarSeparatorUI extends com.jidesoft.plaf.StatusBarSeparatorUI {

	protected java.awt.Color shadow;

	protected java.awt.Color highlight;

	public BasicStatusBarSeparatorUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void installUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public void uninstallUI(javax.swing.JComponent c) {
	}

	protected void installDefaults(com.jidesoft.status.StatusBarSeparator s) {
	}

	protected void uninstallDefaults(com.jidesoft.status.StatusBarSeparator s) {
	}

	protected void installListeners(com.jidesoft.status.StatusBarSeparator s) {
	}

	protected void uninstallListeners(com.jidesoft.status.StatusBarSeparator s) {
	}

	public ThemePainter getPainter() {
	}

	@java.lang.Override
	public void paint(java.awt.Graphics g, javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getMinimumSize(javax.swing.JComponent c) {
	}

	@java.lang.Override
	public java.awt.Dimension getMaximumSize(javax.swing.JComponent c) {
	}

	protected class SeparatorPropertyChangeListener {


		protected BasicStatusBarSeparatorUI.SeparatorPropertyChangeListener() {
		}

		public void propertyChange(java.beans.PropertyChangeEvent evt) {
		}
	}
}
