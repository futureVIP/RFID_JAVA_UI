/**
 *  The package contains ComponentUI implementation for Longhorn style.
 */
package com.jidesoft.plaf.longhorn;


public class LonghornWindowsUtils {

	public LonghornWindowsUtils() {
	}

	public static void initClassDefaultsWithMenu(javax.swing.UIDefaults table) {
	}

	public static void initClassDefaults(javax.swing.UIDefaults table) {
	}

	public static void initComponentDefaultsWithMenu(javax.swing.UIDefaults table) {
	}

	public static void initComponentDefaults(javax.swing.UIDefaults table) {
	}

	public static void installAdditionalClassDefaults(javax.swing.UIDefaults table) {
	}

	public static void installAdditionalComponentDefaults(javax.swing.UIDefaults table) {
	}
}
