/**
 *  The package contains ComponentUI implementation for Longhorn style.
 */
package com.jidesoft.plaf.longhorn;


public class LonghornCollapsiblePaneUI extends com.jidesoft.plaf.basic.BasicCollapsiblePaneUI {

	public LonghornCollapsiblePaneUI() {
	}

	public LonghornCollapsiblePaneUI(com.jidesoft.pane.CollapsiblePane f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createTitlePane(com.jidesoft.pane.CollapsiblePane w) {
	}
}
