/**
 *  The package contains ComponentUI implementation for Longhorn style.
 */
package com.jidesoft.plaf.longhorn;


public class LonghornCollapsiblePaneTitlePane extends com.jidesoft.plaf.basic.BasicCollapsiblePaneTitlePane {

	public LonghornCollapsiblePaneTitlePane(com.jidesoft.pane.CollapsiblePane f) {
	}

	@java.lang.Override
	protected void paintTitleBackground(java.awt.Graphics g) {
	}

	@java.lang.Override
	protected void setupCollapseButton(com.jidesoft.plaf.basic.BasicCollapsiblePaneTitlePane.BasicCollapseButton button) {
	}
}
