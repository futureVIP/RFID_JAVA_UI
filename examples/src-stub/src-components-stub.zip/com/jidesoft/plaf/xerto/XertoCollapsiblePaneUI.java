package com.jidesoft.plaf.xerto;


public class XertoCollapsiblePaneUI extends com.jidesoft.plaf.basic.BasicCollapsiblePaneUI {

	protected javax.swing.ImageIcon s_oUpIcon;

	protected javax.swing.ImageIcon s_oUpOverIcon;

	protected javax.swing.ImageIcon s_oDownIcon;

	protected javax.swing.ImageIcon s_oDownOverIcon;

	public XertoCollapsiblePaneUI() {
	}

	public XertoCollapsiblePaneUI(com.jidesoft.pane.CollapsiblePane f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createTitlePane(com.jidesoft.pane.CollapsiblePane i_collapsiblePane) {
	}
}
