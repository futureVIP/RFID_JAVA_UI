/**
 *  The package contains different kinds of shadows for the BalloonToolTip component for JIDE Components product.
 */
package com.jidesoft.tooltip.shadows;


/**
 *  A drop shadow implementation
 */
public class RightBottomDrop extends DropShadow {

	/**
	 *  Creates a new instance of LeftTopShadow
	 */
	public RightBottomDrop() {
	}

	public void layout(java.awt.Rectangle balloonBounds, java.awt.Rectangle shadowBounds) {
	}
}
