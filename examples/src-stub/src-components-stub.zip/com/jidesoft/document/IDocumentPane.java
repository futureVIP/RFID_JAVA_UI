/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  Interface of any document interface.
 */
public interface IDocumentPane {

	public static final int CLOSE_ACTION_TO_CLOSE = 0;

	public static final int CLOSE_ACTION_TO_DOCK = 1;

	/**
	 *  Inserts the component into this pane.
	 * 
	 *  @param document document to be opened
	 */
	public void openDocument(DocumentComponent document);

	/**
	 *  Removes the component that identified by <code>name</code>.
	 * 
	 *  @param name name
	 */
	public void closeDocument(String name);

	/**
	 *  Closes all documents.
	 */
	public void closeAll();

	/**
	 *  Closes a single document. {@link #closeAll()} and {@link #closeAllButThis(String)} will eventually call this
	 *  method to close each document. This method will call {@link #closeDocument(String)} by default. However subclass
	 *  can override this method to do additional logic.
	 *  <p/>
	 *  You can refer to http://www.jidesoft.com/forum/viewtopic.php?p=10262#10262 to see the reason of adding this
	 *  method.
	 * 
	 *  @param documentName the document name.
	 */
	public void closeSingleDocument(String documentName);

	/**
	 *  Closes all documents except the one specified as parameter.
	 * 
	 *  @param documentName the document name.
	 */
	public void closeAllButThis(String documentName);

	/**
	 *  Sets the tab that identified by name as active.
	 * 
	 *  @param documentName the document name.
	 */
	public void setActiveDocument(String documentName);

	/**
	 *  Sets the tab that identified by name as active.
	 * 
	 *  @param documentName the document name.
	 *  @param requestFocus true to request focus on the document. Otherwise false.
	 */
	public void setActiveDocument(String documentName, boolean requestFocus);

	/**
	 *  Gets the active component.
	 * 
	 *  @return active component
	 */
	public DocumentComponent getActiveDocument();

	/**
	 *  Gets key of the active component.
	 * 
	 *  @return key of the active component
	 */
	public String getActiveDocumentName();

	/**
	 *  Sets next document as active.
	 */
	public void nextDocument();

	/**
	 *  Sets previous document as active.
	 */
	public void prevDocument();

	/**
	 *  Move the document identified by name to a new group whose index is <code>groupIndex</code>.
	 * 
	 *  @param name       name of the document
	 *  @param groupIndex index of dest group
	 */
	public void moveDocument(String name, int groupIndex);

	/**
	 *  Move the document identified by name to a new group whose index is <code>groupIndex</code>.
	 * 
	 *  @param name       name of the document
	 *  @param groupIndex index of dest group
	 *  @param tabIndex   index of the dest tab
	 */
	public void moveDocument(String name, int groupIndex, int tabIndex);

	/**
	 *  New a document group and put the document with name to the new group.
	 * 
	 *  @param name        name of the document
	 *  @param groupIndex  group index
	 *  @param orientation HORIZONTAL or VERTICAL. It will be ignored if there are groups already.
	 */
	public void newDocumentGroup(String name, int groupIndex, int orientation);

	/**
	 *  Gets name of document whose component is <code>component</code>.
	 * 
	 *  @param component the component of the document.
	 *  @return component with the specified name
	 */
	public String getNameOf(java.awt.Component component);

	/**
	 *  Gets document whose name is <code>name</code>.
	 * 
	 *  @param name name
	 *  @return document
	 */
	public DocumentComponent getDocument(String name);

	/**
	 *  Gets document at the specified index.
	 * 
	 *  @param index the index
	 *  @return document
	 */
	public DocumentComponent getDocumentAt(int index);

	/**
	 *  Activate the document group. Each document group can have its own selected document. But only the active group's
	 *  selected document is active document.
	 * 
	 *  @param documentGroup documentGroup to be activated
	 */
	public void activateGroup(IDocumentGroup documentGroup);

	/**
	 *  Gets the document group that contains the document with the specified document name.
	 * 
	 *  @param documentName the document name.
	 *  @return the document group that contains the document with the specified document name.
	 */
	public IDocumentGroup getDocumentGroup(String documentName);

	/**
	 *  Gets the title converter that convert the title.
	 * 
	 *  @return title converter
	 */
	public com.jidesoft.swing.StringConverter getTitleConverter();

	/**
	 *  Sets the title converter.
	 * 
	 *  @param titleConverter the new title converter.
	 */
	public void setTitleConverter(com.jidesoft.swing.StringConverter titleConverter);

	/**
	 *  Gets the popup menu customizer.
	 * 
	 *  @return popup menu customizer
	 */
	public PopupMenuCustomizer getPopupMenuCustomizer();

	/**
	 *  Sets the popup customizer.
	 * 
	 *  @param customizer the popup menu customizer.
	 */
	public void setPopupMenuCustomizer(PopupMenuCustomizer customizer);

	/**
	 *  Is document group allowed in this document pane.
	 * 
	 *  @return true if group is allowed
	 */
	public boolean isGroupsAllowed();

	/**
	 *  Sets if document group is allowed is this document pane.
	 * 
	 *  @param groupsAllowed true or false.
	 */
	public void setGroupsAllowed(boolean groupsAllowed);

	/**
	 *  Checks if document order is allowed to changed by user.
	 * 
	 *  @return true if group is allowed
	 */
	public boolean isReorderAllowed();

	/**
	 *  Sets if document order is allowed to be changed by user.
	 * 
	 *  @param reorderAllowed true or false.
	 */
	public void setReorderAllowed(boolean reorderAllowed);

	/**
	 *  Check if the document with the name is opened.
	 * 
	 *  @param name name of the document
	 *  @return true if the document is opened
	 */
	public boolean isDocumentOpened(String name);

	/**
	 *  Return the total number of open documents.
	 * 
	 *  @return the total number of open documents.
	 */
	public int getDocumentCount();

	/**
	 *  Gets document at position specified in <code>index</code>. The order is as the same as the order of when
	 *  documents are opened.
	 * 
	 *  @param index document position
	 *  @return name of document. Call <code>getDocument(name)</code> to get the DocumentComponent
	 */
	public String getDocumentNameAt(int index);

	/**
	 *  Return an array of DocumentComponents. The order is as the same as the order of when documents are opened.
	 * 
	 *  @return an array of all documents
	 */
	public String[] getDocumentNames();

	/**
	 *  Gets index of the document in it's group.
	 * 
	 *  @param name the name of the document.
	 *  @return index
	 */
	public int indexOfDocument(String name);

	/**
	 *  Gets group index of the document.
	 * 
	 *  @param name the name of the document.
	 *  @return the group index where the document is in.
	 */
	public int groupIndexOfDocument(String name);

	/**
	 *  Updates document title when user changes the title. User should call this method since we don't know the title of
	 *  a document is changed.
	 * 
	 *  @param documentName the document name.
	 */
	public void updateDocument(String documentName);

	/**
	 *  Renames the document with the old name to the new name.
	 * 
	 *  @param oldName old name
	 *  @param newName new name
	 */
	public void renameDocument(String oldName, String newName);

	/**
	 *  Gets the number of document groups.
	 * 
	 *  @return the number of document groups.
	 */
	public int getDocumentGroupCount();

	/**
	 *  Gets document group at the specified index.
	 * 
	 *  @param index the index.
	 *  @return the document group.
	 */
	public IDocumentGroup getDocumentGroupAt(int index);

	/**
	 *  Floating a document of the specified name.
	 * 
	 *  @param documentName the document name.
	 */
	public void floatDocument(String documentName);

	/**
	 *  Floating a document of the specified name into a specified floating container.
	 * 
	 *  @param floatingContainer the floating container.
	 *  @param documentName      the document name.
	 */
	public void floatDocument(FloatingDocumentContainer floatingContainer, String documentName);

	/**
	 *  Docks a floating document back that was floated before.
	 * 
	 *  @param documentName the name of document that is floating.
	 */
	public void dockDocument(String documentName);

	/**
	 *  Docks all floating documents inside the floating container.
	 * 
	 *  @param container the floating container.
	 */
	public void dockDocuments(FloatingDocumentContainer container);

	/**
	 *  Closes all floating documents inside the floating container.
	 * 
	 *  @param container the floating container.
	 */
	public void closeDocuments(FloatingDocumentContainer container);

	/**
	 *  Checks if the document is floating.
	 * 
	 *  @param documentName the name of the document
	 *  @return true if the document is floating. Otherwise false.
	 */
	public boolean isDocumentFloating(String documentName);

	/**
	 *  Gets the list of floating containers.
	 * 
	 *  @return the list of floating containers.
	 */
	public java.util.List getFloatingContainers();

	/**
	 *  Gets the selected document index in the document group at the specified index.
	 * 
	 *  @param index the index
	 *  @return the selected document index. It should return a non-negative number in normal cases. -1 if there is no
	 *          document selected. In current implementation of document group, it is impossible.
	 * 
	 *  @throws IndexOutOfBoundsException if the index passed in is less than 0 or greater than the number of document
	 *                                    groups.
	 */
	public int getSelectedIndexAtGroupIndex(int index);

	/**
	 *  Gets the layout persistence that can be used to persist the documents that are opened in document pane.
	 * 
	 *  @return the layout persistence.
	 */
	public LayoutPersistence getLayoutPersistence();

	/**
	 *  Sets the opened components. This method will not show those documents. After this method, load
	 * 
	 *  @param documentComponents the list of documents.
	 */
	public void setOpenedDocuments(java.util.List documentComponents);

	/**
	 *  Enables or disables the document that identified by <code>name</code>. If you disable a document, the tab for the
	 *  document will not be selectable. However if the document is active, it will remain active even you disable it. So
	 *  it is recommended to make another document active if you want to disable the active document.
	 * 
	 *  @param name    the name of the document.
	 *  @param enabled true to enable the document and false to disable.
	 */
	public void setDocumentEnabled(String name, boolean enabled);

	/**
	 *  Dispose DocumentPane.
	 */
	public void dispose();

	/**
	 *  @return true if the heavyweight component is enabled.
	 */
	public boolean isHeavyweightComponentEnabled();

	/**
	 *  Enables heavyweight component.
	 * 
	 *  @param heavyweightComponentEnabled true or false.
	 */
	public void setHeavyweightComponentEnabled(boolean heavyweightComponentEnabled);

	/**
	 *  Gets the action when the native close button is pressed on the floating container. It could be either {@link
	 *  #CLOSE_ACTION_TO_CLOSE} to close all documents inside the floating container, or {@link #CLOSE_ACTION_TO_DOCK} to
	 *  dock all documents.
	 * 
	 *  @return the close action.
	 */
	public int getFloatingContainerCloseAction();

	/**
	 *  Sets the action when the native close button is pressed on the floating container. It could be either {@link
	 *  #CLOSE_ACTION_TO_CLOSE} to close all documents inside the floating container, or {@link #CLOSE_ACTION_TO_DOCK} to
	 *  dock all documents.
	 * 
	 *  @param action the close action. Valid values are {@link #CLOSE_ACTION_TO_CLOSE} or {@link
	 *                #CLOSE_ACTION_TO_DOCK}.
	 */
	public void setFloatingContainerCloseAction(int action);
}
