/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  The container for the DocumentComponent when floating.
 */
public class FloatingDocumentContainer extends javax.swing.JFrame {

	public FloatingDocumentContainer(DocumentPane documentPane) {
	}

	public DocumentPane getDocumentPane() {
	}

	public IDocumentGroup getDocumentGroup() {
	}

	public java.awt.Component getRoutingComponent() {
	}

	public void setRoutingKeyStrokes(boolean routingKeyStrokes) {
	}

	public boolean isRoutingKeyStrokes() {
	}
}
