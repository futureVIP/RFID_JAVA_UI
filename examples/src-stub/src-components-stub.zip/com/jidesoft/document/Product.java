/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


public interface Product {

	public static final String NAME = "JIDE Components";
}
