/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  A factory to create document component automatically. It will be used if the customers want to load a layout without
 *  adding the document component before hand.
 */
public interface DocumentComponentFactory {

	/**
	 *  Create a default document component with the name
	 *  @param documentName the name of the document
	 *  @return the document component instance.
	 */
	public DocumentComponent create(String documentName);
}
