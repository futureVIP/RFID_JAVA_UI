/**
 *  The package contains the classes related to DocumentPane component for JIDE Components product.
 */
package com.jidesoft.document;


/**
 *  Adapter class for <code>DocumentComponentListener</code>.
 */
public class DocumentComponentAdapter implements DocumentComponentListener {
 {

	public DocumentComponentAdapter() {
	}

	/**
	 *  Invoked when a document has been opened.
	 * 
	 *  @param e event
	 */
	public void documentComponentOpened(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document is in the process of being closed. The close operation can be vetoed at this point. If
	 *  you don't want the document to be closed, just call setAllowClosing(false)
	 * 
	 *  @param e event
	 */
	public void documentComponentClosing(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document has been closed.
	 * 
	 *  @param e event
	 */
	public void documentComponentClosed(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document is in the process of being moved. The move operation can be vetoed at this point. If you
	 *  don't want the document to be closed, just call setAllowMoving(false)
	 * 
	 *  @param e event
	 */
	public void documentComponentMoving(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document has been closed.
	 * 
	 *  @param e event
	 */
	public void documentComponentMoved(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document is activated.
	 * 
	 *  @param e event
	 */
	public void documentComponentActivated(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document is de-activated.
	 * 
	 *  @param e event
	 */
	public void documentComponentDeactivated(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document is docked.
	 * 
	 *  @param e event
	 */
	public void documentComponentDocked(DocumentComponentEvent e) {
	}

	/**
	 *  Invoked when a document is floated.
	 * 
	 *  @param e event
	 */
	public void documentComponentFloated(DocumentComponentEvent e) {
	}
}
