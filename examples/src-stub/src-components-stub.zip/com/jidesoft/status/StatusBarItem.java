/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  Status bar item is the basic element for StatusBar. A status bar is composed of one or
 *  many status bar item. All status bar item has the same height, border, and font.
 */
public abstract class StatusBarItem extends NullPanel {

	/**
	 *  Default constructor.
	 */
	public StatusBarItem() {
	}

	/**
	 *  Gets item name.
	 * 
	 *  @return item name
	 */
	public abstract String getItemName() {
	}

	/**
	 *  Sets preferred width of the item.
	 * 
	 *  @param width
	 */
	public void setPreferredWidth(int width) {
	}

	/**
	 *  Gets preferred width. If it is set, the actual width will
	 *  be kept the same when there is enough space. If not set,
	 *  the width will be changing when content of the status bar item changes.
	 * 
	 *  @return preferred width
	 */
	public int getPreferredWidth() {
	}

	/**
	 *  If the <code>preferredSize</code> has been set to a
	 *  non-<code>null</code> value just returns it.
	 *  If the UI delegate's <code>getPreferredSize</code>
	 *  method returns a non <code>null</code> value then return that;
	 *  otherwise defer to the component's layout manager.
	 * 
	 *  @return the value of the <code>preferredSize</code> property
	 *  @see #setPreferredSize
	 *  @see ComponentUI
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	/**
	 *  Resets the UI property with a value from the current look and feel.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}
}
