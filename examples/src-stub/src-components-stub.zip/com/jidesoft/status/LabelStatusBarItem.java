/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  A status bar item with a JLabel.
 */
public class LabelStatusBarItem extends StatusBarItem {

	public LabelStatusBarItem() {
	}

	/**
	 *  Creates a label status bar item with name.
	 * 
	 *  @param name name of the status bar item
	 */
	public LabelStatusBarItem(String name) {
	}

	/**
	 *  Creates the label component used by LabelStatusBarItem.
	 * 
	 *  @return the label.
	 */
	protected javax.swing.JLabel createLabel() {
	}

	/**
	 *  Configures the label.
	 */
	protected void configureLabel(javax.swing.JLabel label) {
	}

	/**
	 *  Sets text to be displayed on the label.
	 * 
	 *  @param text
	 */
	public void setText(String text) {
	}

	/**
	 *  Gets text displayed on the label.
	 * 
	 *  @return the text on the label
	 */
	public String getText() {
	}

	/**
	 *  @deprecated replaced it with setToolTipText.
	 */
	@java.lang.Deprecated
	public void setToolTip(String tooltip) {
	}

	/**
	 *  Sets tooltip to be displayed on the label.
	 * 
	 *  @param tooltip the new tooltip.
	 */
	@java.lang.Override
	public void setToolTipText(String tooltip) {
	}

	/**
	 *  Gets tooltip displayed on the label.
	 * 
	 *  @return the tooltip on the label
	 */
	@java.lang.Override
	public String getToolTipText() {
	}

	@java.lang.Override
	public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Sets icon to be displayed on the label.
	 * 
	 *  @param icon
	 */
	public void setIcon(javax.swing.Icon icon) {
	}

	/**
	 *  Sets the text horizontal alignment. The valid values for alignment are defined in {@link
	 *  JLabel#setHorizontalAlignment(int)}.
	 * 
	 *  @param alignment
	 */
	public void setHorizontalAlignment(int alignment) {
	}

	/**
	 *  Gets the text horizontal alignment.
	 * 
	 *  @return alignment
	 */
	public int getHorizontalAlignment() {
	}

	/**
	 *  Gets icon displayed on the label.
	 * 
	 *  @return the icon on the label
	 */
	public javax.swing.Icon getIcon() {
	}

	/**
	 *  Enable or disable the StatusBar Item.
	 * 
	 *  @param enabled
	 */
	@java.lang.Override
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Adds the specified mouse listener to receive mouse events from this component. If listener <code>l</code> is
	 *  <code>null</code>, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the mouse listener
	 */
	@java.lang.Override
	public void addMouseListener(java.awt.event.MouseListener listener) {
	}

	/**
	 *  Sets the alignment.
	 * 
	 *  @param alignment
	 */
	public void setAlignment(int alignment) {
	}

	/**
	 *  Gets the actual component.
	 * 
	 *  @return the actual component. In this case, it's a label
	 */
	public java.awt.Component getComponent() {
	}

	/**
	 *  If the <code>preferredSize</code> has been set to a non-<code>null</code> value just returns it. If the UI
	 *  delegate's <code>getPreferredSize</code> method returns a non <code>null</code> value then return that; otherwise
	 *  defer to the component's layout manager.
	 * 
	 *  @return the value of the <code>preferredSize</code> property
	 * 
	 *  @see #setPreferredSize
	 *  @see ComponentUI
	 */
	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	public String getItemName() {
	}
}
