/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  A status bar item which can be used as resizable corner. You should always add it as the last status bar item on
 *  status bar as it will serve as a resizable target which user can drag it to resize the top level window. You probably
 *  shouldn't use it if the status bar is not used at the bottom of the top level window because it doesn't make sense to
 *  have a resizable target which is not at the bottom-right corner of the resizable window.
 *  <p/>
 *  Please note, if user uses ResizeStatusBarItem to resize the top level window, the resizing operation is not done via
 *  native code any more. So it flickers a lot on any JDK before JDK1.6 because of missing the double buffering feature.
 *  To make it feels better, we added a method {@link #setStopRepaintDuringResizing(boolean)}. If set to true, repaint
 *  event will be blocked, thus you won't see any flickerings. However, the content of the window is not shown either
 *  during resizing. There is better than flickering but still not as good as resizing using window's resize border. We
 *  just couldn't find a better way to do it yet. By default, we set it false if JDK is 1.6 and above, and true
 *  otherwise. Since JDK1.6 has the double buffer which reduces flickering a lot during resizing, it actually feels
 *  better when set to false.
 */
public class ResizeStatusBarItem extends LabelStatusBarItem {

	/**
	 *  Creates a resize status bar item. By default, it will be able to resize top level ancestor.
	 */
	public ResizeStatusBarItem() {
	}

	/**
	 *  Creates a resize status bar item. By default, it will be able to resize top level ancestor.
	 * 
	 *  @param name the name of this status bar item.
	 */
	public ResizeStatusBarItem(String name) {
	}

	/**
	 *  Creates a resize status bar item.
	 * 
	 *  @param resizeTopLevelAncestor if true, pressing on the component and dragging will resize the top level
	 *                                ancestor.
	 */
	public ResizeStatusBarItem(boolean resizeTopLevelAncestor) {
	}

	/**
	 *  @param name                   the name of this status bar item.
	 *  @param resizeTopLevelAncestor If true, pressing on the component and dragging will resize the top level ancestor.
	 *                                If false,  this component is simply an indicator to indicate top level ancestor is
	 *                                resizable. User still needs to press and drag and border of top level ancestor to
	 *                                resize.
	 */
	public ResizeStatusBarItem(String name, boolean resizeTopLevelAncestor) {
	}

	/**
	 *  Creates the label component used by LabelStatusBarItem.
	 * 
	 *  @return the label.
	 */
	@java.lang.Override
	protected javax.swing.JLabel createLabel() {
	}

	@java.lang.Override
	protected void configureLabel(javax.swing.JLabel label) {
	}

	/**
	 *  Checks if the status bar item should show resizable corner. Subclass can override this method to return different
	 *  value.
	 *  <p/>
	 *  The default implementation is: It will get the top level ancestor. If it is an instance of {@link Frame}, it will
	 *  return true only when {@link Frame#getExtendedState()} return {@link Frame#NORMAL}. If the top level ancestor is
	 *  not a Frame, it will always return true as there isn't enough information to determine it is resizable or not.
	 * 
	 *  @return true if the resizable corner is shown.
	 */
	protected boolean isResizable() {
	}

	/**
	 *  Sets to true if you want to stop repaint event during resizing. This will make resizing looks better. However it
	 *  is still not as good as the resizing by dragging the window border. We just haven't found a better way to do it.
	 *  <p/>
	 *  By default, we set it false if JDK is 1.6 and above, and true otherwise. Since JDK1.6 has the double buffer which
	 *  reduces flickering a lot during resizing, it actually feels better when set to false. If you are on JDK1.5 and
	 *  less, it'd better to set to true.
	 * 
	 *  @param stopRepaintDuringResizing
	 */
	public void setStopRepaintDuringResizing(boolean stopRepaintDuringResizing) {
	}

	/**
	 *  Mouse input listenr to control the resizing of <code>Resizable</code> component.
	 */
	public class ResizableMouseInputAdapter {


		protected static final int RESIZE_NONE = 0;

		public ResizeStatusBarItem.ResizableMouseInputAdapter() {
		}

		@java.lang.Override
		public void mousePressed(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseDragged(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseReleased(java.awt.event.MouseEvent e) {
		}

		/**
		 *  mouseMoved is for resize only. When mouse moves over borders and corners, it will change to differnt cursor
		 *  to indicate it's resizable.
		 * 
		 *  @param e mouse event
		 */
		@java.lang.Override
		public void mouseMoved(java.awt.event.MouseEvent e) {
		}

		@java.lang.Override
		public void mouseExited(java.awt.event.MouseEvent e) {
		}
	}
}
