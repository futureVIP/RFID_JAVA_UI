/**
 *  The package contains the classes related to StatusBar component for JIDE Components product.
 */
package com.jidesoft.status;


/**
 *  A status bar item that can be used to indicate the keyboard insert/overwrite status.
 */
public class OvrInsStatusBarItem extends LabelStatusBarItem {

	/**
	 *  Default constructor.
	 */
	public OvrInsStatusBarItem() {
	}

	/**
	 *  The insert/overwrite mode.
	 * 
	 *  @return true if it is overwrite mode.
	 */
	public boolean isOvrMode() {
	}

	/**
	 *  Sets the overwrite/insert mode.
	 * 
	 *  @param mode
	 */
	public void setOvrMode(boolean mode) {
	}
}
