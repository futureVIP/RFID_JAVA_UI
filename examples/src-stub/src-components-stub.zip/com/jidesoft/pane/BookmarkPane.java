/**
 *  The package contains the several panes such as OutlookTabbedPane, FloorTabbedPane, CollapsiblePane, BookmarkPane etc which can be used for navigation purpose for JIDE Components product.
 */
package com.jidesoft.pane;


/**
 *  <code>BookmarkPane</code> is still in development mode. We used it in G8.2 TradingHierarchicalTableDemo as an
 *  example. However it's not ready for public usage yet.
 */
public class BookmarkPane extends javax.swing.JTabbedPane {

	/**
	 *  Buttons.
	 */
	protected java.util.Vector _buttons;

	/**
	 *  Creates FloorTabbedPane with default animation settings for tab switching animation.
	 */
	public BookmarkPane() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel. Don't call super.updateUI() since it shouldn't
	 *  use default JTabbedPane UI at all.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	/**
	 *  Gets the buttons used by this TtabbedPane in a Vector.
	 * 
	 *  @return vector of buttons.
	 */
	public java.util.Vector getButtons() {
	}

	/**
	 *  Overrides to remove the button for the tab index. If the tab being removed is selected, it will try to select
	 *  next tab unless the removd tab is the last one. If so, it will select previous tab.
	 * 
	 *  @param index
	 */
	@java.lang.Override
	public void removeTabAt(int index) {
	}

	/**
	 *  Overrides to insert a button for this new tab.
	 * 
	 *  @param title
	 *  @param icon
	 *  @param component
	 *  @param tip
	 *  @param index
	 */
	@java.lang.Override
	public void insertTab(String title, javax.swing.Icon icon, java.awt.Component component, String tip, int index) {
	}

	/**
	 *  Creates the button used by FloorTabbedPane. Subclass can override it to create its own button. But those buttons
	 *  must implement UIResource. Otherwise, a runtime IllegalArgumentException will be thrown.
	 * 
	 *  @param action
	 *  @return button used by FloorTabbedPane.
	 */
	protected javax.swing.AbstractButton createButton(javax.swing.Action action) {
	}

	@java.lang.Override
	public int getMnemonicAt(int tabIndex) {
	}

	@java.lang.Override
	public void setMnemonicAt(int tabIndex, int mnemonic) {
	}

	@java.lang.Override
	public int getDisplayedMnemonicIndexAt(int tabIndex) {
	}

	@java.lang.Override
	public void setDisplayedMnemonicIndexAt(int tabIndex, int mnemonicIndex) {
	}

	@java.lang.Override
	public void setTitleAt(int index, String title) {
	}

	@java.lang.Override
	public String getTitleAt(int index) {
	}

	@java.lang.Override
	public javax.swing.Icon getIconAt(int index) {
	}

	@java.lang.Override
	public void setIconAt(int index, javax.swing.Icon icon) {
	}

	@java.lang.Override
	public javax.swing.Icon getDisabledIconAt(int index) {
	}

	@java.lang.Override
	public void setDisabledIconAt(int index, javax.swing.Icon disabledIcon) {
	}

	@java.lang.Override
	public String getToolTipTextAt(int index) {
	}

	@java.lang.Override
	public void setToolTipTextAt(int index, String toolTipText) {
	}

	@java.lang.Override
	public boolean isEnabledAt(int index) {
	}

	@java.lang.Override
	public void setEnabledAt(int index, boolean enabled) {
	}

	/**
	 *  Customizes the button used by FloorTabbedPane. Subclass can override it to customize the button.
	 * 
	 *  @param button
	 */
	protected void customizeButton(javax.swing.AbstractButton button) {
	}

	/**
	 *  Gets the AccessibleContext associated with this JTabbedPane. For tabbed panes, the AccessibleContext takes the
	 *  form of an AccessibleJTabbedPane. A new AccessibleJTabbedPane instance is created if necessary.
	 * 
	 *  @return an AccessibleJTabbedPane that serves as the AccessibleContext of this JTabbedPane
	 */
	@java.lang.Override
	public javax.accessibility.AccessibleContext getAccessibleContext() {
	}

	/**
	 *  Checks if the tab is selected.
	 * 
	 *  @param tabIndex the tab index.
	 *  @return true if selected. Otherwise false.
	 */
	public boolean isTabSelected(int tabIndex) {
	}

	/**
	 *  Sets the tab selected.
	 * 
	 *  @param tabIndex the tab index.
	 *  @param selected true or false. True to select the tab.
	 */
	public void setTabSelected(int tabIndex, boolean selected) {
	}

	/**
	 *  This class implements accessibility support for the <code>JTabbedPane</code> class.  It provides an
	 *  implementation of the Java Accessibility API appropriate to tabbed pane user-interface elements.
	 *  <p/>
	 *  <strong>Warning:</strong> Serialized objects of this class will not be compatible with future Swing releases. The
	 *  current serialization support is appropriate for short term storage or RMI between applications running the same
	 *  version of Swing.  As of 1.4, support for long term storage of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package. Please see {@link java.beans.XMLEncoder}.
	 */
	protected class AccessibleJTabbedPane {


		/**
		 *  Constructs an AccessibleJTabbedPane
		 */
		public BookmarkPane.AccessibleJTabbedPane() {
		}

		public void stateChanged(javax.swing.event.ChangeEvent e) {
		}

		/**
		 *  Get the role of this object.
		 * 
		 *  @return an instance of AccessibleRole describing the role of the object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleRole getAccessibleRole() {
		}

		/**
		 *  Returns the number of accessible children in the object.
		 * 
		 *  @return the number of accessible children in the object.
		 */
		@java.lang.Override
		public int getAccessibleChildrenCount() {
		}

		/**
		 *  Return the specified Accessible child of the object.
		 * 
		 *  @param i zero-based index of child
		 *  @return the Accessible child of the object
		 * 
		 *  @throws IllegalArgumentException if index is out of bounds
		 */
		@java.lang.Override
		public javax.accessibility.Accessible getAccessibleChild(int i) {
		}

		/**
		 *  Gets the <code>AccessibleSelection</code> associated with this object.  In the implementation of the Java
		 *  Accessibility API for this class, returns this object, which is responsible for implementing the
		 *  <code>AccessibleSelection</code> interface on behalf of itself.
		 * 
		 *  @return this object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleSelection getAccessibleSelection() {
		}

		/**
		 *  Returns the <code>Accessible</code> child contained at the local coordinate <code>Point</code>, if one
		 *  exists. Otherwise returns the currently selected tab.
		 * 
		 *  @return the <code>Accessible</code> at the specified location, if it exists
		 */
		@java.lang.Override
		public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
		}

		public int getAccessibleSelectionCount() {
		}

		public javax.accessibility.Accessible getAccessibleSelection(int i) {
		}

		public boolean isAccessibleChildSelected(int i) {
		}

		public void addAccessibleSelection(int i) {
		}

		public void removeAccessibleSelection(int i) {
		}

		public void clearAccessibleSelection() {
		}

		public void selectAllAccessibleSelection() {
		}
	}
}
