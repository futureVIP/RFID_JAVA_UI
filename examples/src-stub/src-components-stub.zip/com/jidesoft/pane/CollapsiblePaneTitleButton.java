/**
 *  The package contains the several panes such as OutlookTabbedPane, FloorTabbedPane, CollapsiblePane, BookmarkPane etc which can be used for navigation purpose for JIDE Components product.
 */
package com.jidesoft.pane;


/**
 *  <code>CollapsiblePaneTitleButton</code> provides a button that looks the same as the default title button on
 *  CollapsiblePane's title pane. If you want to provide your own buttons using CollapsiblePane's setTitleComponent
 *  method, you should use this class as your button class.
 */
public class CollapsiblePaneTitleButton extends javax.swing.JButton implements java.awt.event.MouseMotionListener, java.awt.event.MouseListener, java.awt.event.KeyListener {
 {

	public CollapsiblePaneTitleButton(CollapsiblePane pane, javax.swing.Icon icon) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel.
	 * 
	 *  @see javax.swing.JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	public ThemePainter getPainter() {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	protected void paintIcon(java.awt.Graphics g) {
	}

	protected void paintIcon(java.awt.Graphics g, java.awt.Color textColor, javax.swing.ImageIcon icon, javax.swing.ImageIcon rolloverIcon) {
	}

	@java.lang.Override
	public boolean isFocusable() {
	}

	@java.lang.Override
	public void requestFocus() {
	}

	@java.lang.Override
	public boolean isOpaque() {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	/**
	 *  Invoked when a key has been typed. See the class description for {@link KeyEvent} for a definition of a key typed
	 *  event.
	 */
	public void keyTyped(java.awt.event.KeyEvent e) {
	}

	/**
	 *  Invoked when a key has been pressed. See the class description for {@link KeyEvent} for a definition of a key
	 *  pressed event.
	 */
	public void keyPressed(java.awt.event.KeyEvent e) {
	}

	/**
	 *  Invoked when a key has been released. See the class description for {@link KeyEvent} for a definition of a key
	 *  released event.
	 */
	public void keyReleased(java.awt.event.KeyEvent e) {
	}

	protected javax.swing.Icon getIcon(javax.swing.AbstractButton b) {
	}
}
