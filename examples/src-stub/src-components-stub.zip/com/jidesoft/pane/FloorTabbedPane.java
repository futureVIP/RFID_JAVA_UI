/**
 *  The package contains the several panes such as OutlookTabbedPane, FloorTabbedPane, CollapsiblePane, BookmarkPane etc which can be used for navigation purpose for JIDE Components product.
 */
package com.jidesoft.pane;


/**
 *  <code>FloorTabbedPane</code> is a different version of <code>JTabbedPane</code>. As we all know,
 *  <code>JTabbedPane</code> provides a way to organize multiple panes and allows user to see one pane at a time.
 *  <code>FloorTabbedPane</code> serves the same purpose. However it organizes the panes in a vertical way like as you
 *  see in Outlook Bar as in Microsoft Outlook 2000. Since it looks like a multiple-floor building, thus gets the name of
 *  <code>FloorTabbedPane</code>.
 *  <p/>
 *  The interface and usage of <code>FloorTabbedPane</code> are the same as <code>JTabbedPane</code>. We even keep the
 *  name of methods to be the same so that you easily convert from <code>JTabbedPane</code> to
 *  <code>FloorTabbedPane</code>.
 *  <p/>
 *  When switching the tab, you can see animation. You do have control over the speed of the animation. {@link
 *  #setInitDelay(int)} is how many millisecond delay when you click on a new tab. {@link #setSteps(int)} is how many
 *  steps during the animation - the large number, the more smooth. {@link #setStepDelay(int)} is the delay between each
 *  step.
 *  <p/>
 *  You can also add <code>PropertyChangeListener</code> to listen for <code>PERCENTAGE_PROPERTY</code> change. It will
 *  fired during hen animation. The value will 100 when animates starts and 0 when animation ends. So you can use this
 *  value to determine if the <code>FloorTabbedPane</code> is in animation.
 *  <p/>
 */
public class FloorTabbedPane extends javax.swing.JTabbedPane {

	/**
	 *  Buttons.
	 */
	protected java.util.Vector _buttons;

	protected int _percentage;

	protected int _nextIndex;

	protected int _prevIndex;

	public static String PERCENTAGE_PROPERTY;

	public static String PROPERTY_ORIENTATION;

	/**
	 *  Creates FloorTabbedPane with default animation settings for tab switching animation.
	 */
	public FloorTabbedPane() {
	}

	/**
	 *  Creates FloorTabbedPane with specified animation settings for tab switching animation.
	 * 
	 *  @param initDelay the initial delay before animation starts. The value is in milliseconds.
	 *  @param stepDelay the delay between each step. The value is in milliseconds.
	 *  @param steps     the number of steps in the animation. The larger number, the more smooth the animation.
	 */
	public FloorTabbedPane(int initDelay, int stepDelay, int steps) {
	}

	/**
	 *  Resets the UI property to a value from the current look and feel. Don't call super.updateUI() since it shouldn't
	 *  use default JTabbedPane UI at all.
	 * 
	 *  @see JComponent#updateUI
	 */
	@java.lang.Override
	public void updateUI() {
	}

	protected java.awt.LayoutManager createLayout() {
	}

	protected javax.swing.Action createSwitchPageAction(String title, javax.swing.Icon icon, int index) {
	}

	/**
	 *  Gets the buttons used by this TtabbedPane in a Vector.
	 * 
	 *  @return vector of buttons.
	 */
	public java.util.Vector getButtons() {
	}

	/**
	 *  Overrides to remove the button for the tab index. If the tab being removed is selected, it will try to select
	 *  next tab unless the removed tab is the last one. If so, it will select previous tab.
	 * 
	 *  @param index the tab index
	 */
	@java.lang.Override
	public void removeTabAt(int index) {
	}

	/**
	 *  Overrides to insert a button for this new tab.
	 * 
	 *  @param title     the title to be displayed in this tab
	 *  @param icon      the icon to be displayed in this tab
	 *  @param component The component to be displayed when this tab is clicked.
	 *  @param tip       the tooltip to be displayed for this tab
	 *  @param index     the position to insert this new tab
	 */
	@java.lang.Override
	public void insertTab(String title, javax.swing.Icon icon, java.awt.Component component, String tip, int index) {
	}

	/**
	 *  Creates the button used by FloorTabbedPane. Subclass can override it to create its own button. But those buttons
	 *  must implement UIResource. Otherwise, a runtime IllegalArgumentException will be thrown.
	 * 
	 *  @param action the action for the button.
	 *  @return button used by FloorTabbedPane.
	 */
	protected javax.swing.AbstractButton createButton(javax.swing.Action action) {
	}

	/**
	 *  Sets the selected index.
	 * 
	 *  @param index the new selected index
	 */
	@java.lang.Override
	public void setSelectedIndex(int index) {
	}

	/**
	 *  Selects the button that represents the selected tab.
	 * 
	 *  @param index the selected tab index.
	 */
	protected void updateButtonSelectionState(int index) {
	}

	@java.lang.Override
	public int getMnemonicAt(int tabIndex) {
	}

	@java.lang.Override
	public void setMnemonicAt(int tabIndex, int mnemonic) {
	}

	@java.lang.Override
	public int getDisplayedMnemonicIndexAt(int tabIndex) {
	}

	@java.lang.Override
	public void setDisplayedMnemonicIndexAt(int tabIndex, int mnemonicIndex) {
	}

	@java.lang.Override
	public void setTitleAt(int index, String title) {
	}

	@java.lang.Override
	public String getTitleAt(int index) {
	}

	@java.lang.Override
	public javax.swing.Icon getIconAt(int index) {
	}

	@java.lang.Override
	public void setIconAt(int index, javax.swing.Icon icon) {
	}

	@java.lang.Override
	public javax.swing.Icon getDisabledIconAt(int index) {
	}

	@java.lang.Override
	public void setDisabledIconAt(int index, javax.swing.Icon disabledIcon) {
	}

	@java.lang.Override
	public String getToolTipTextAt(int index) {
	}

	@java.lang.Override
	public void setToolTipTextAt(int index, String toolTipText) {
	}

	@java.lang.Override
	public boolean isEnabledAt(int index) {
	}

	@java.lang.Override
	public void setEnabledAt(int index, boolean enabled) {
	}

	@java.lang.Override
	public void setForegroundAt(int index, java.awt.Color foreground) {
	}

	@java.lang.Override
	public java.awt.Color getForegroundAt(int index) {
	}

	@java.lang.Override
	public void setBackgroundAt(int index, java.awt.Color background) {
	}

	@java.lang.Override
	public java.awt.Color getBackgroundAt(int index) {
	}

	/**
	 *  Gets the initial delay when the button is pressed before it starts to switch.
	 * 
	 *  @return the initial delay
	 */
	public int getInitDelay() {
	}

	/**
	 *  Sets the initial delay when the button is pressed before it starts to switch, in ms. Default is 50ms.
	 * 
	 *  @param initDelay the initial delay
	 */
	public void setInitDelay(int initDelay) {
	}

	/**
	 *  Gets the delay in each step during animation.
	 * 
	 *  @return the delay in each step
	 */
	public int getStepDelay() {
	}

	/**
	 *  Sets the delay in each step during animation, in ms. Default is 5ms.
	 * 
	 *  @param stepDelay the delay in each step
	 */
	public void setStepDelay(int stepDelay) {
	}

	/**
	 *  Gets how many steps in the animation.
	 * 
	 *  @return number of the steps
	 */
	public int getSteps() {
	}

	/**
	 *  Sets how many steps in the animation, default is 10 steps.
	 * 
	 *  @param steps number of the steps. It should be a non-negative integer. Otherwise, IllegalArgumentException will
	 *               be thrown.
	 *  @throws IllegalArgumentException if the steps value is less than 0.
	 */
	public void setSteps(int steps) {
	}

	/**
	 *  Customizes the button used by FloorTabbedPane. Subclass can override it to customize the button.
	 * 
	 *  @param button the button to be customized
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void customizeButton(javax.swing.AbstractButton button) {
	}

	/**
	 *  Gets the orientation. By default it is SwingContent.VERTICAL which means the button sliding up and down to show
	 *  the tab content. You can also set the orientation to SwingContent.HORIZONTAL so that the button sliding left and
	 *  right.
	 * 
	 *  @return the orientation.
	 */
	public int getOrientation() {
	}

	/**
	 *  Sets the orientation. By default it is SwingContent.VERTICAL which means the button sliding up and down to show
	 *  the tab content. You can also set the orientation to SwingContent.HORIZONTAL so that the button sliding left and
	 *  right.
	 * 
	 *  @param orientation the orientation. The valid value is SwingContent.HORIZONTAL and SwingContent.VERTICAL.
	 */
	public void setOrientation(int orientation) {
	}

	/**
	 *  Gets the AccessibleContext associated with this JTabbedPane. For tabbed panes, the AccessibleContext takes the
	 *  form of an AccessibleJTabbedPane. A new AccessibleJTabbedPane instance is created if necessary.
	 * 
	 *  @return an AccessibleJTabbedPane that serves as the AccessibleContext of this JTabbedPane
	 */
	@java.lang.Override
	public javax.accessibility.AccessibleContext getAccessibleContext() {
	}

	public class FloorButton {


		public FloorTabbedPane.FloorButton(javax.swing.Action a) {
		}

		@java.lang.Override
		public void updateUI() {
		}

		/**
		 *  Gets the tab index for which the button is used to show.
		 * 
		 *  @return the tab index.
		 */
		public int getButtonIndex() {
		}
	}

	/**
	 *  This class implements accessibility support for the <code>JTabbedPane</code> class.  It provides an
	 *  implementation of the Java Accessibility API appropriate to tabbed pane user-interface elements.
	 *  <p/>
	 *  <strong>Warning:</strong> Serialized objects of this class will not be compatible with future Swing releases. The
	 *  current serialization support is appropriate for short term storage or RMI between applications running the same
	 *  version of Swing.  As of 1.4, support for long term storage of all JavaBeans<sup><font size="-2">TM</font></sup>
	 *  has been added to the <code>java.beans</code> package. Please see {@link java.beans.XMLEncoder}.
	 */
	protected class AccessibleJTabbedPane {


		/**
		 *  Constructs an AccessibleJTabbedPane
		 */
		public FloorTabbedPane.AccessibleJTabbedPane() {
		}

		public void stateChanged(javax.swing.event.ChangeEvent e) {
		}

		/**
		 *  Get the role of this object.
		 * 
		 *  @return an instance of AccessibleRole describing the role of the object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleRole getAccessibleRole() {
		}

		/**
		 *  Returns the number of accessible children in the object.
		 * 
		 *  @return the number of accessible children in the object.
		 */
		@java.lang.Override
		public int getAccessibleChildrenCount() {
		}

		/**
		 *  Return the specified Accessible child of the object.
		 * 
		 *  @param i zero-based index of child
		 *  @return the Accessible child of the object
		 * 
		 *  @throws IllegalArgumentException if index is out of bounds
		 */
		@java.lang.Override
		public javax.accessibility.Accessible getAccessibleChild(int i) {
		}

		/**
		 *  Gets the <code>AccessibleSelection</code> associated with this object.  In the implementation of the Java
		 *  Accessibility API for this class, returns this object, which is responsible for implementing the
		 *  <code>AccessibleSelection</code> interface on behalf of itself.
		 * 
		 *  @return this object
		 */
		@java.lang.Override
		public javax.accessibility.AccessibleSelection getAccessibleSelection() {
		}

		/**
		 *  Returns the <code>Accessible</code> child contained at the local coordinate <code>Point</code>, if one
		 *  exists. Otherwise returns the currently selected tab.
		 * 
		 *  @return the <code>Accessible</code> at the specified location, if it exists
		 */
		@java.lang.Override
		public javax.accessibility.Accessible getAccessibleAt(java.awt.Point p) {
		}

		public int getAccessibleSelectionCount() {
		}

		public javax.accessibility.Accessible getAccessibleSelection(int i) {
		}

		public boolean isAccessibleChildSelected(int i) {
		}

		public void addAccessibleSelection(int i) {
		}

		public void removeAccessibleSelection(int i) {
		}

		public void clearAccessibleSelection() {
		}

		public void selectAllAccessibleSelection() {
		}
	}
}
