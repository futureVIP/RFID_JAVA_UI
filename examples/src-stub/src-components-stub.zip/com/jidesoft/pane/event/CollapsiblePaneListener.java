/**
 *  The package contains the event class for the components in the com.jidesoft.pane package for JIDE Components product.
 */
package com.jidesoft.pane.event;


/**
 *  The listener interface for receiving collapsible pane events.
 */
public interface CollapsiblePaneListener extends java.util.EventListener {
 {

	/**
	 *  Called whenever the ContentPane of CollapsiblePane starts to expand.
	 */
	public void paneExpanding(CollapsiblePaneEvent event);

	/**
	 *  Called whenever the ContentPane of CollapsiblePane is expanded.
	 */
	public void paneExpanded(CollapsiblePaneEvent event);

	/**
	 *  Called whenever the ContentPane of CollapsiblePane starts to collapse.
	 */
	public void paneCollapsing(CollapsiblePaneEvent event);

	/**
	 *  Called whenever the ContentPane of CollapsiblePane is collapsed.
	 */
	public void paneCollapsed(CollapsiblePaneEvent event);
}
