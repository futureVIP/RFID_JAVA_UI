/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  An <code>AWTEvent</code> that adds support for <code>Dashboard</code> objects as the event source.
 * 
 *  @see com.jidesoft.dashboard.Gadget
 *  @see com.jidesoft.dashboard.GadgetListener
 */
public class DashboardEvent extends java.awt.AWTEvent {

	/**
	 *  The first number in the range of IDs used for <code>Dashboard</code> events.
	 */
	public static final int DASHBOARD_FIRST = 13099;

	/**
	 *  The last number in the range of IDs used for <code>Dashboard</code> events.
	 */
	public static final int DASHBOARD_LAST = 13103;

	/**
	 *  This event is delivered when the <code>Dashboard</code> is first added to DashboardManager.
	 */
	public static final int DASHBOARD_ADDED = 13099;

	/**
	 *  This event is delivered when the <code>Dashboard</code> is removed from DashboardManager.
	 */
	public static final int DASHBOARD_REMOVED = 13100;

	/**
	 *  This event is delivered when the <code>Dashboard</code> is moved in DashboardManager.
	 */
	public static final int DASHBOARD_MOVED = 13101;

	/**
	 *  This event is delivered when the <code>Dashboard</code> is activated.
	 */
	public static final int DASHBOARD_ACTIVATED = 13102;

	/**
	 *  This event is delivered when the <code>Dashboard</code> is deactivated.
	 */
	public static final int DASHBOARD_DEACTIVATED = 13103;

	/**
	 *  Constructs an <code>DashboardEvent</code> object.
	 * 
	 *  @param source the <code>Dashboard</code> object that originated the event
	 *  @param id     an integer indicating the type of event
	 *  @param index  the index of the dashboard in its parent.
	 */
	public DashboardEvent(Dashboard source, int id, int index) {
	}

	/**
	 *  Gets the dashboard index. If the dashboard is removed, the index will be the index before it was removed. In the
	 *  case of DashboardTabbedPane, this will be the tab index.
	 * 
	 *  @return the dashboard index.
	 */
	public int getIndex() {
	}

	/**
	 *  Returns a parameter string identifying this event. This method is useful for event logging and for debugging.
	 * 
	 *  @return a string identifying the event and its attributes
	 */
	@java.lang.Override
	public String paramString() {
	}

	/**
	 *  Returns the originator of the event.
	 * 
	 *  @return the <code>Dashboard</code> object that originated the event
	 */
	public Dashboard getDashboard() {
	}
}
