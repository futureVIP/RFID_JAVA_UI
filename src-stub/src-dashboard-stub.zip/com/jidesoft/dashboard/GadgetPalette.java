/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  The palette contains the gadget so that user can drag and drop the gadget to dashboard.
 */
public class GadgetPalette extends javax.swing.JPanel implements GadgetListener, java.beans.PropertyChangeListener {
 {

	/**
	 *  CONTEXT_BUTTON_ADD, CONTEXT_BUTTON_DONE, CONTEXT_BUTTON_DESCRIPTION are the name of the components in the
	 *  GadgetPalette description panel. With those names, you can easily find the corresponding component and change
	 *  their behavior, like set disable, invisible or add new action listener, etc.
	 */
	public static final String CONTEXT_BUTTON_ADD = "GadgetPalette.add";

	public static final String CONTEXT_BUTTON_DONE = "GadgetPalette.done";

	public static final String CONTEXT_BUTTON_DESCRIPTION = "GadgetPalette.description";

	protected javax.swing.ButtonGroup _buttonGroup;

	protected javax.swing.JComponent _status;

	protected java.awt.Container _gadgetList;

	public GadgetPalette(GadgetManager manager, GadgetPaletteInstaller installer) {
	}

	/**
	 *  Update opaque property to false for every child components in GadgetPalette. If you want to change this default
	 *  behavior, you could override this method to do nothing.
	 */
	protected void updateOpaque() {
	}

	protected javax.swing.JComponent createDescriptionLabel() {
	}

	/**
	 *  Creates the container for the gadget buttons. By default, we will create a new instance of ScrollableButtonPanel,
	 *  add it to SimpleScrollPane and return the scroll pane. In subsequent call to {@link #recreateGadgetButtons()}
	 *  method, we will create gadget buttons and add it to the ScrollableButtonPanel. <p>To make it easy for people to
	 *  override, the default code is inlcuded below. The _gadgetList is a field of ScrollableButtonPanel.
	 *  <code><pre>
	 *  _gadgetList = new JPanel(new GridLayout(1, 0, 4, 4));
	 *  JPanel panel = JideSwingUtilities.createCenterPanel(_gadgetList);
	 *  panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
	 *  SimpleScrollPane scrollPane = new SimpleScrollPane(_gadgetList) {
	 *      protected AbstractButton createScrollButton(int type) {
	 *          AbstractButton button = GadgetPalette.this.createScrollButton(type);
	 *          if (button != null) {
	 *              return button;
	 *          }
	 *          else {
	 *              return super.createScrollButton(type);
	 *          }
	 *      }
	 *  };
	 *  scrollPane.setRepeatDelay(100);
	 *  scrollPane.setBorder(BorderFactory.createEmptyBorder());
	 *  return scrollPane;
	 *  </pre></code>
	 * 
	 *  @return a scroll pane containing a ScrollableButtonPanel.
	 */
	protected java.awt.Container createGadgetButtonContainer() {
	}

	/**
	 *  Set the layout manager for the container contains gadget buttons.
	 * 
	 *  @param layout the layout manager
	 */
	public void setButtonLayout(java.awt.LayoutManager layout) {
	}

	/**
	 *  Recreates the gadget buttons and add them to the containers for the gadget buttons. Since this method is also
	 *  called when the gadgets are updated in the GadgetManager, so we need to clear the existing buttons from the
	 *  container first before adding new buttons.<p>To make it easy for people to override, the default code is inlcuded
	 *  below. The _gadgetList is a field of ScrollableButtonPanel.
	 *  <code><pre>
	 *  Component[] components = _gadgetList.getComponents();
	 *  for (Component component : components) {
	 *      if (component instanceof AbstractButton) {
	 *          uncustomizeButton(((AbstractButton) component));
	 *          _buttonGroup.remove(((AbstractButton) component));
	 *      }
	 *  }
	 *  _gadgetList.removeAll();
	 *  String[] elements = _manager.getGadgets();
	 *  for (String key : elements) {
	 *      Gadget element = _manager.getGadget(key);
	 *      AbstractButton button = createButton(element);
	 *      customizeButton(button);
	 *      _gadgetList.addButton(button);
	 *      _buttonGroup.add(button);
	 *  }
	 *  revalidate();
	 *  repaint();
	 *  </pre></code>
	 */
	protected void recreateGadgetButtons() {
	}

	/**
	 *  Creates the panel for the status label and two more buttons. Subclass can override to add more components. By
	 *  default, the layout of this panel is JideBoxLayout.
	 * 
	 *  @param statusComponent the status component.
	 *  @return the panel which contains the status
	 */
	protected javax.swing.JPanel createDescriptionPanel(java.awt.Component statusComponent) {
	}

	/**
	 *  Creates the scroll button for the SimpleScrollPane used by GadgetPalete when there aren't enough space to show
	 *  all gadgets on the palette.
	 * 
	 *  @param type left or right. It could be SwingConstants.WEST or SwingConstants.EAST.
	 *  @return the scroll button for the SimpleScrollPane used by GadgetPalete.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected javax.swing.AbstractButton createScrollButton(int type) {
	}

	@java.lang.Override
	public void updateUI() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	public GadgetManager getGadgetManager() {
	}

	public GadgetPaletteInstaller getInstaller() {
	}

	protected javax.swing.AbstractButton createButton(Gadget gadget) {
	}

	protected void customizeButton(javax.swing.AbstractButton button) {
	}

	protected void uncustomizeButton(javax.swing.AbstractButton button) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available
	 *  keys are defined in dashboard.properties.
	 * 
	 *  @param key the resource key.
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	public void eventHappened(GadgetEvent e) {
	}

	@java.lang.Override
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
