/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  <code>GadgetComponent</code> is the <code>Component</code> that is added to the <code>Dashboard</code>. The
 *  <code>Gadget</code> is responsible for the creation of <code>GadgetComponent</code>.
 *  <p/>
 *  <code>GadgetComponent</code> is an interface. So you implement your own <code>GadgetComponent</code>. However it must
 *  be a <code>Component</code> such as JPanel, JComponent or any other Swing or AWT components. Failed to do so will
 *  result in ClassCastException in the code.
 */
public interface GadgetComponent extends PlaceHolder {
 {

	/**
	 *  Gets the <code>Gadget</code> that creates this <code>GadgetComponent</code>.
	 *  <p/>
	 * 
	 *  @return the <code>Gadget</code>.
	 */
	public Gadget getGadget();

	/**
	 *  Gets the settings.
	 * 
	 *  @return a map of the settings. The key is the name of the setting and the value of the map is the value of the
	 *          setting. The value must be a string in order to be persisted in the xml format. If your original data
	 *          format is not string, you need to convert to string first. You could leverage ObjectConverterManager and
	 *          ObjectConverter to do it.
	 */
	public java.util.Map getSettings();

	/**
	 *  Sets the setting.
	 * 
	 *  @param settings a map of the settings. The key is the name of the setting and the value of the map is the value
	 *                  of the setting. The value is a string in order to be persisted in the xml format. If your
	 *                  original data format is not string, you need to convert from string to the type you expect first.
	 *                  You could leverage ObjectConverterManager and ObjectConverter to do it.
	 */
	public void setSettings(java.util.Map settings);
}
