/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  The listener interface for receiving gadget events.
 */
public interface GadgetListener extends java.util.EventListener {
 {

	/**
	 *  Invoked when a <code>Gadget</code> event happened
	 * 
	 *  @param e GadgetEvent
	 */
	public void eventHappened(GadgetEvent e);
}
