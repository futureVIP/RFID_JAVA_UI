/**
 *  The package contains classes related for JIDE Dashboard product.
 */
package com.jidesoft.dashboard;


/**
 *  You can view <code>GadgetManager</code> as the model of the whole JIDE Dashboard. It has a list of dashboards and
 *  gadgets.
 *  <p/>
 *  Any <code>DashboardHolder</code> must work with a <code>GadgetManager</code>. It should also listen to GadgetEvents
 *  or DashboardEvents fired by <code>GadgetManager</code> to update the UI.
 *  <p/>
 *  If you want to add or remove gadgets or dashboards, you should do it through methods provided by
 *  <code>GadgetManager</code>.
 */
public class GadgetManager {

	/**
	 *  A list of event listeners for this component.
	 */
	protected javax.swing.event.EventListenerList listenerList;

	public static final String PROPERTY_BATCH_PROCESSING = "batchProcessing";

	public static final String PROPERTY_ALLOW_DRAG_BETWEEN_DASHBOARD = "allowDragBetweenDashboard";

	public static final String PROPERTY_ALLOW_MULTIPLE_GADGET_INSTANCES = "allowMultipleGadgetInstances";

	public static final String PROPERTY_ALLOW_DRAG_OUTSIDE = "_allowDragOutside";

	public static final String PROPERTY_COLUMN_RESIZABLE = "columnResizable";

	public static final String PROPERTY_DISPOSE_GADGET_WHEN_HIDING_DASHBOARD = "disposeGadgetsWhenHidingDashboard";

	/**
	 *  Creates an empty <code>GadgetManager</code>.
	 */
	public GadgetManager() {
	}

	/**
	 *  Initializes the manager.
	 */
	protected void initManager() {
	}

	/**
	 *  Adds a new gadget at the specified index.
	 * 
	 *  @param gadget a new gadget to be added.
	 *  @param index  the gadget index.
	 */
	public void addGadget(Gadget gadget, int index) {
	}

	/**
	 *  Adds a new gadget.
	 * 
	 *  @param gadget a new gadget to be added.
	 */
	public void addGadget(Gadget gadget) {
	}

	/**
	 *  Adds new gadgets.
	 * 
	 *  @param gadgets new gadgets to be added.
	 */
	public void addGadgets(Gadget[] gadgets) {
	}

	/**
	 *  Removes existing gadgets.
	 * 
	 *  @param keys the keys of the existing gadgets to be removed.
	 */
	public void removeGadgets(String[] keys) {
	}

	/**
	 *  Removes an existing gadget.
	 * 
	 *  @param key the key of the gadget to be removed.
	 *  @return true if removed successfully. Otherwise false.
	 */
	public boolean removeGadget(String key) {
	}

	/**
	 *  The action to take while the gadget button is double clicked.
	 *  <p/>
	 *  By default, we will just get the active dashboard and put it at 0, 0. You could customize this behavior by overriding
	 *  this method.
	 *   
	 *  @param gadget the gadget
	 */
	protected void gadgetButtonDoubleClicked(Gadget gadget) {
	}

	/**
	 *  Shows a gadget. This method will create a GadgetComponent from the specified Gadget and show it at the first
	 *  position in the active dashboard.
	 * 
	 *  @param gadget the Gadget to be shown.
	 */
	public void showGadget(Gadget gadget) {
	}

	/**
	 *  Shows a gadget. This method will create a GadgetComponent from the specified Gadget and show it at the designated
	 *  position in the designated dashboard.
	 * 
	 *  @param gadget    the Gadget to be shown
	 *  @param dashboard the dashboard to display the gadget
	 *  @param column    the column in the dashboard to display the gadget. If the column is bigger than the column count
	 *                   of the dashboard, nothing will display
	 *  @param index     the index in the column to display the gadget. If the index is invalid, we will just add it to
	 *                   the last available position
	 */
	public void showGadget(Gadget gadget, Dashboard dashboard, int column, int index) {
	}

	/**
	 *  Check if a gadget is displayed already.
	 * 
	 *  @param key the key of the gadget
	 *  @return true if the gadget is displayed already. Otherwise false.
	 */
	public boolean isGadgetShown(String key) {
	}

	/**
	 *  Check if a gadget is displayed already.
	 * 
	 *  @param gadget the gadget
	 *  @return true if the gadget is displayed already. Otherwise false.
	 */
	public boolean isGadgetShown(Gadget gadget) {
	}

	/**
	 *  Hides the GadgetComponent.
	 * 
	 *  @param gadgetComponent the GadgetComponent to be hidden.
	 *  @deprecated replaced by {@link #hideGadgetComponent(GadgetComponent)}
	 */
	@java.lang.Deprecated
	public void hideGadget(GadgetComponent gadgetComponent) {
	}

	/**
	 *  Hides the GadgetComponent.
	 * 
	 *  @param gadgetComponent the GadgetComponent to be hidden.
	 */
	public void hideGadgetComponent(GadgetComponent gadgetComponent) {
	}

	/**
	 *  Maximize the designated GadgetComponent. It will do nothing if the GadgetComponent does not exist in normal
	 *  gadget container in its active dashboard.
	 * 
	 *  @param component the gadget component
	 *  @deprecated replaced by {@link #maximizeGadgetComponent(GadgetComponent)}
	 */
	@java.lang.Deprecated
	public void maximizeGadget(GadgetComponent component) {
	}

	/**
	 *  Maximize the designated GadgetComponent. It will do nothing if the GadgetComponent does not exist in normal
	 *  gadget container in its active dashboard.
	 * 
	 *  @param component the gadget component
	 */
	public void maximizeGadgetComponent(GadgetComponent component) {
	}

	/**
	 *  Maximize the GadgetComponent in designated column and row in the active dashboard. It will do nothing if the
	 *  parameter is invalid.
	 * 
	 *  @param column the column index
	 *  @param row    the row index
	 *  @deprecated replaced by {@link #maximizeGadgetComponent(int, int)}
	 */
	@java.lang.Deprecated
	public void maximizeGadget(int column, int row) {
	}

	/**
	 *  Maximize the GadgetComponent in designated column and row in the active dashboard. It will do nothing if the
	 *  parameter is invalid.
	 * 
	 *  @param column the column index
	 *  @param row    the row index
	 */
	public void maximizeGadgetComponent(int column, int row) {
	}

	/**
	 *  Restore the maximized GadgetComponent in the active dashboard.
	 *  @deprecated replaced by {@link #restoreGadgetComponent()}
	 */
	@java.lang.Deprecated
	public void restoreGadget() {
	}

	/**
	 *  Restore the maximized GadgetComponent in the active dashboard.
	 */
	public void restoreGadgetComponent() {
	}

	/**
	 *  Creates a gadget component. This method will create a GadgetComponent from the specified Gadget and return it.
	 * 
	 *  @param gadget the Gadget to be shown.
	 *  @return the GadgetComponent created from the gadget. Null if the Gadget doesn't belong to this GadgetManager or
	 *          Gadget returns null in its createGadgetComponent method.
	 */
	public GadgetComponent createGadgetComponent(Gadget gadget) {
	}

	/**
	 *  Gets the active Dashboard key.
	 * 
	 *  @return the active Dashboard key.
	 */
	public String getActiveDashboardKey() {
	}

	/**
	 *  Sets the active Dashboard by the key. This method will fire <code>DashboardEvent.DASHBOARD_DEACTIVATED</code> on
	 *  the previous active dashboard and fire <code>DashboardEvent.DASHBOARD_ACTIVATED</code> on the newly activated
	 *  dashboard. However it is up to the {@link com.jidesoft.dashboard.DashboardHolder} to listen to this event and
	 *  active the corresponding dashboard (for example, we did that in DashboardTabbedPane), or ignore it if there is
	 *  only one dashboard (such as <code>SingleDashboardHolder</code>)..
	 * 
	 *  @param key the key of the Dashboard to be activated.
	 */
	public void setActiveDashboardKey(String key) {
	}

	/**
	 *  Gets the gadget by the key.
	 * 
	 *  @param key the key of the gadget.
	 *  @return the gadget or null if not found.
	 */
	public Gadget getGadget(String key) {
	}

	/**
	 *  Gets all the gadgets added to be this <code>GadgetManager</code>.
	 * 
	 *  @return all the gadgets.
	 */
	public String[] getGadgets() {
	}

	/**
	 *  Adds a new dashboard.
	 * 
	 *  @param dashboard the dashboard to be added.
	 */
	public void addDashboard(Dashboard dashboard) {
	}

	/**
	 *  Removes a dashboard.
	 * 
	 *  @param key the key of the dashboard to be removed.
	 *  @return true if removed successfully. Otherwise false.
	 */
	public boolean removeDashboard(String key) {
	}

	/**
	 *  Moves an existing dashboard.
	 * 
	 *  @param key   the key of the dashboard to be moved.
	 *  @param index the new index.
	 */
	public void moveDashboard(String key, int index) {
	}

	/**
	 *  Removes all the dashboards.
	 */
	public void removeAllDashboards() {
	}

	/**
	 *  Gets the dashboard by the key.
	 * 
	 *  @param key the key of the dashboard.
	 *  @return the dashboard or null if not found.
	 */
	public Dashboard getDashboard(String key) {
	}

	/**
	 *  Gets the dashboard index.
	 * 
	 *  @param key the key of the dashboard.
	 *  @return the index of the dashboard. -1 if not found.
	 */
	public int getDashboardIndex(String key) {
	}

	/**
	 *  Gets the dashboard at the specified index.
	 * 
	 *  @param index the index
	 *  @return the dashboard at the index.
	 */
	public Dashboard getDashboard(int index) {
	}

	/**
	 *  Gets all the dashboards.
	 * 
	 *  @return all the dashboards.
	 */
	public String[] getDashboards() {
	}

	/**
	 *  Gets the number of dashboards.
	 * 
	 *  @return the number of dashboards.
	 */
	public int getDashboardCount() {
	}

	/**
	 *  A validation method before gadget is dropped to a target container. By default, it will return
	 *  {@link #validateGadgetDragging(Gadget, java.awt.Container)} to keep backward compatibility. You could override
	 *  this method to add some widgets or checking here.
	 * 
	 *  @param gadget          the dragging gadget
	 *  @param targetContainer the target container
	 *  @param index           the index where the dragging gadget would be put into the target container
	 *  @return true if dragging is allowed. Otherwise false.
	 */
	protected boolean validateGadgetDragging(Gadget gadget, java.awt.Container targetContainer, int index) {
	}

	/**
	 *  A validation method before gadget is dropped to a target container. By default, it will return true. You could
	 *  override this method to add some widgets or checking here.
	 * 
	 *  @param gadget          the dragging gadget
	 *  @param targetContainer the target container
	 *  @return true if dragging is allowed. Otherwise false.
	 */
	protected boolean validateGadgetDragging(Gadget gadget, java.awt.Container targetContainer) {
	}

	/**
	 *  Gets the mouse input listener needed to support drag-n-drop feature of the gadget component. In most cases, you
	 *  will never need to call this as the listener will be added to all gadget components created by GadgetPalette. But
	 *  if for whatever reason you have to create the gadget component yourself or your component has a child component
	 *  that also needs to support drag-n-drop, you can get this listener and add it yourself. Of course you can also
	 *  call {@link #installListeners(java.awt.Component)} which will get the listener and add it.
	 * 
	 *  @return the mouse input listener needed to support drag-n-drop feature of the gadget component.
	 */
	public javax.swing.event.MouseInputListener getDragAndDropMouseInputListener() {
	}

	/**
	 *  Gets the key listener. During any drag-n-drop, this key listener will response to ESCAPE to cancel the operation.
	 *  Same as getDragAndDropMouseInputListener, this key listener is added to the necessary component by default if the
	 *  drag-n-drop is starting from the palette. But if you are starting any drag-n-drop from your code, you can add
	 *  this listener to the component which will receive key event during the drag-n-drop.
	 * 
	 *  @return the key listener which will response to ESCAPE key and stop the drag-n-drop operation.
	 */
	public java.awt.event.KeyListener getCancelDragAndDropKeyListener() {
	}

	/**
	 *  Installs getDragAndDropMouseInputListener and getCancelDragAndDropKeyListener to the components.
	 * 
	 *  @param component the component where two listeners will be added.
	 */
	public void installListeners(java.awt.Component component) {
	}

	/**
	 *  Uninstalls getDragAndDropMouseInputListener and getCancelDragAndDropKeyListener from the components.
	 * 
	 *  @param component the component where two listeners were added.
	 */
	public void uninstallListeners(java.awt.Component component) {
	}

	/**
	 *  Adds the specified listener to receive gadget events from this gadget.
	 * 
	 *  @param l the gadget listener
	 */
	public void addGadgetListener(GadgetListener l) {
	}

	/**
	 *  Removes the specified gadget listener so that it no longer receives gadget events.
	 * 
	 *  @param l the gadget listener
	 */
	public void removeGadgetListener(GadgetListener l) {
	}

	/**
	 *  Returns an array of all the <code>GadgetListener</code>s added to this <code>GadgetGroup</code> with
	 *  <code>addGadgetListener</code>.
	 * 
	 *  @return all of the <code>GadgetListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addGadgetListener
	 */
	public GadgetListener[] getGadgetListeners() {
	}

	/**
	 *  Fires a gadget event.
	 * 
	 *  @param e the event
	 */
	protected void fireGadgetEvent(GadgetEvent e) {
	}

	/**
	 *  Adds the specified listener to receive dashboard events from this dashboard.
	 * 
	 *  @param l the dashboard listener
	 */
	public void addDashboardListener(DashboardListener l) {
	}

	/**
	 *  Removes the specified dashboard listener so that it no longer receives dashboard events.
	 * 
	 *  @param l the dashboard listener
	 */
	public void removeDashboardListener(DashboardListener l) {
	}

	/**
	 *  Returns an array of all the <code>DashboardListener</code>s added to this <code>DashboardGroup</code> with
	 *  <code>addDashboardListener</code>.
	 * 
	 *  @return all of the <code>DashboardListener</code>s added or an empty array if no listeners have been added
	 * 
	 *  @see #addDashboardListener
	 */
	public DashboardListener[] getDashboardListeners() {
	}

	/**
	 *  Fires a dashboard event.
	 * 
	 *  @param e the event
	 */
	protected void fireDashboardEvent(DashboardEvent e) {
	}

	/**
	 *  Gets an optional version string.
	 * 
	 *  @return version string.
	 */
	public String getVersion() {
	}

	/**
	 *  Sets version string.
	 * 
	 *  @param version the new version
	 */
	public void setVersion(String version) {
	}

	/**
	 *  Checks the flag whether the gadgets will be disposed when the dashborad is hidden.
	 * 
	 *  @return true or false.
	 */
	public boolean isDisposeGadgetsWhenHidingDashboard() {
	}

	/**
	 *  Sets the flag whether the gadgets will be disposed when the dashborad is hidden. Default is true. But when you
	 *  load the layout, this flag should be tempararily set to false. Here is the right way to load the layout.
	 *  <pre><code>
	 *  DashboardPersistenceUtils.load(_documentPane, the layout file saved by DashboardPersistenceUtils);
	 *  try {
	 *      _documentPane.getGadgetManager().setDisposeGadgetsWhenHidingDashboard(false);
	 *      _documentPane.getLayoutPersistence().loadLayoutData();
	 *  }
	 *  finally {
	 *      _documentPane.getGadgetManager().setDisposeGadgetsWhenHidingDashboard(true);
	 *  }
	 *  </code></pre>
	 * 
	 *  @param disposeGadgetsWhenHidingDashboard
	 *          true or false.
	 */
	public void setDisposeGadgetsWhenHidingDashboard(boolean disposeGadgetsWhenHidingDashboard) {
	}

	/**
	 *  Get the flag indicating if the column is resizable.
	 *  <p/>
	 *  The default value of this flag is false to keep consistent behavior with earlier release.
	 * 
	 *  @return the flag
	 */
	public boolean isColumnResizable() {
	}

	/**
	 *  Set the flag indicating if the column is resizable.
	 * 
	 *  @param columnResizable the flag
	 */
	public void setColumnResizable(boolean columnResizable) {
	}

	/**
	 *  Get the flag indicating if the gadget is allowed to be dropped in the closest location upon dragged outside of
	 *  the Dashboard.
	 *  <p/>
	 *  The default value is true to keep the original behavior.
	 * 
	 *  @return the flag.
	 */
	public boolean isAllowDragOutside() {
	}

	/**
	 *  Set the flag indicating if the gadget is allowed to be dropped in the closest location upon dragged outside of
	 *  the Dashboard.
	 * 
	 *  @param allowDragOutside the flag
	 */
	public void setAllowDragOutside(boolean allowDragOutside) {
	}

	/**
	 *  Get the flag indicating if the gadget is allowed to be dropped from one dashboard to another.
	 *  <p/>
	 *  By default the value is true.
	 * 
	 *  @return true if allow dragging between dashboard. Otherwise false.
	 */
	public boolean isAllowDragBetweenDashboard() {
	}

	/**
	 *  Set the flag indicating if the gadget is allowed to be dropped from one dashboard to another.
	 * 
	 *  @param allowDragBetweenDashboard the flag
	 *  @see #isAllowDragBetweenDashboard()
	 */
	public void setAllowDragBetweenDashboard(boolean allowDragBetweenDashboard) {
	}

	/**
	 *  Get the flag indicating if the gadget manager allows multiple gadget instances.
	 *  <p/>
	 *  The default value is true, which means you can drag the button to create as many gadget components as you want.
	 *  You could set it to false if you want only one gadget component to be created for one gadget.
	 * 
	 *  @return true if multiple gadget instances are allowed. Otherwise false.
	 */
	public boolean isAllowMultipleGadgetInstances() {
	}

	/**
	 *  Set the flag indicating if the gadget manager allows multiple gadget instances.
	 *  <p/>
	 * 
	 *  @param allowMultipleGadgetInstances the flag
	 *  @see #isAllowMultipleGadgetInstances()
	 */
	public void setAllowMultipleGadgetInstances(boolean allowMultipleGadgetInstances) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 * 
	 *  @param listener the property change listener to be added
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 */
	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 *  @see #removePropertyChangeListener(java.lang.String,java.beans.PropertyChangeListener)
	 */
	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners registered on this gadget manager.
	 * 
	 *  @return all of this manager's <code>PropertyChangeListener</code>s or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 */
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list for a specific property.
	 * 
	 *  @param propertyName one of the property names listed above
	 *  @param listener     the property change listener to be added
	 *  @see #removePropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 */
	public void addPropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a <code>PropertyChangeListener</code> from the listener list for a specific property.
	 * 
	 *  @param propertyName a valid property name
	 *  @param listener     the PropertyChangeListener to be removed
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners(java.lang.String)
	 *  @see #removePropertyChangeListener(java.beans.PropertyChangeListener)
	 */
	public void removePropertyChangeListener(String propertyName, java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the listeners which have been associated with the named property.
	 * 
	 *  @param  propertyName the name of the property
	 *  @return all of the <code>PropertyChangeListener</code>s associated with the named property; if no such listeners
	 *          have been added or if <code>propertyName</code> is <code>null</code>, an empty array is returned
	 * 
	 *  @see #addPropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #removePropertyChangeListener(java.lang.String, java.beans.PropertyChangeListener)
	 *  @see #getPropertyChangeListeners
	 */
	public java.beans.PropertyChangeListener[] getPropertyChangeListeners(String propertyName) {
	}

	/**
	 *  Support for reporting bound property changes for Object properties.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue     the property's previous value
	 *  @param newValue     the property's new value
	 */
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}
}
