/**
 *  The package contains classes related for paging and page navigation support for JIDE Data Grids product.
 */
package com.jidesoft.paging;


/**
 *  Defines a listener interface which listens for <code>PageNavigationEvent</code>.
 */
public interface PageNavigationListener extends java.util.EventListener {
 {

	/**
	 *  Invoked when the target of the listener has fired a <code>PageNavigationEvent</code>.
	 * 
	 *  @param e a PageNavigationEvent object
	 */
	public void pageNavigationEventFired(PageNavigationEvent e);
}
