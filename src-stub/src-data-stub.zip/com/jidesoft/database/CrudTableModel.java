/**
 *  The package contains classes related for Database/JDBC support for JIDE Data Grids product.
 */
package com.jidesoft.database;


public interface CrudTableModel extends javax.swing.table.TableModel {
 {

	/**
	 *  Add a row to the table model.
	 * 
	 *  @param columns the data array
	 *  @throws Exception if encouting any database update error.
	 */
	public void insertRow(Object[] columns);

	/**
	 *  Read data of a designated row.
	 * 
	 *  @param rowIndex the row index
	 *  @return the data array.
	 *  @throws Exception if encouting any database read error.
	 */
	public Object[] readRow(int rowIndex);

	/**
	 *  Update data of a desginated row with data.
	 * 
	 *  @param rowIndex the row index
	 *  @param columns the data array
	 *  @throws Exception if encouting any database update error.
	 */
	public void updateRow(int rowIndex, Object[] columns);

	/**
	 *  Delete data of a designated row.
	 * 
	 *  @param rowIndex the row index
	 *  @throws Exception if encouting any database update error.
	 */
	public void deleteRow(int rowIndex);
}
