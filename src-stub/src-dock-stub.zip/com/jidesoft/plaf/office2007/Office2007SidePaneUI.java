package com.jidesoft.plaf.office2007;


/**
 *  JideSidePane UI implementation
 */
public class Office2007SidePaneUI extends com.jidesoft.plaf.basic.BasicSidePaneUI {

	public Office2007SidePaneUI() {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent c) {
	}

	@java.lang.Override
	protected void installDefaults() {
	}

	@java.lang.Override
	protected void uninstallDefaults() {
	}

	@java.lang.Override
	protected java.awt.Color[] getGradientColors(SidePaneItem item) {
	}

	@java.lang.Override
	public ThemePainter getPainter() {
	}

	@java.lang.Override
	protected boolean isRoundedCorner() {
	}
}
