package com.jidesoft.plaf.vsnet;


/**
 *  DockableFrame UI implementation
 */
public class VsnetDockableFrameUI extends com.jidesoft.plaf.basic.BasicDockableFrameUI {

	public VsnetDockableFrameUI() {
	}

	public VsnetDockableFrameUI(com.jidesoft.docking.DockableFrame f) {
	}

	public static javax.swing.plaf.ComponentUI createUI(javax.swing.JComponent b) {
	}
}
