package com.jidesoft.plaf;


/**
 *  ComponentUI for DockableFrame.
 */
public abstract class DockableFrameUI extends javax.swing.plaf.ComponentUI {

	public DockableFrameUI() {
	}

	public abstract java.awt.Component getTitlePane() {
	}
}
