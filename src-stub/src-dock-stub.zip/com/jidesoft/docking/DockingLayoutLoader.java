/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  <code>DockingLayoutLoader</code> is a utility that loads a layout produced by docking framework without actually
 *  loading it into a DockingManager. You can use it to find out what dockable frames are in the layout without loading
 *  it.
 *  <p/>
 *  Here is how you use it.
 *  <code><pre>
 *  DockingLayoutLoader loader = new DockingLayoutLoader();
 *  loader.setProfileKey("jidesoft");
 *  loader.loadLayoutData();
 *  </pre></code>
 *  After that, you can call loader's getContext() to find out what dockable frames are in the layout and what initial
 *  states they are in.
 */
public class DockingLayoutLoader extends AbstractLayoutPersistence {

	public DockingLayoutLoader() {
	}

	public void loadInitialLayout(org.w3c.dom.Document layoutDocument) {
	}

	@java.lang.Override
	public boolean loadLayoutFrom(org.w3c.dom.Document document) {
	}

	public boolean loadLayoutFrom(java.io.InputStream in) {
	}

	public boolean isLoadDataSuccessful() {
	}

	@java.lang.Override
	public void saveLayoutTo(org.w3c.dom.Document document) {
	}

	public void saveLayoutTo(java.io.OutputStream out) {
	}

	public void resetToDefault() {
	}

	public void beginLoadLayoutData() {
	}

	public java.awt.Rectangle getBounds() {
	}

	public int getState() {
	}

	public java.util.Map getContexts() {
	}

	public static void main(String[] args) {
	}
}
