/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Default implementation of <code>DockableHolder</code> for JWindow.
 */
@java.lang.SuppressWarnings("serial")
public class DefaultWindowDockableHolder extends javax.swing.JWindow implements DockableHolder {
 {

	protected boolean _autoDispose;

	public DefaultWindowDockableHolder() {
	}

	public DefaultWindowDockableHolder(java.awt.GraphicsConfiguration gc) {
	}

	public DefaultWindowDockableHolder(java.awt.Frame owner) {
	}

	public DefaultWindowDockableHolder(java.awt.Window owner) {
	}

	public DefaultWindowDockableHolder(java.awt.Window owner, java.awt.GraphicsConfiguration gc) {
	}

	protected DockingManager createDockingManager(java.awt.Container contentContainer) {
	}

	/**
	 *  Gets the default docking manager.
	 * 
	 *  @return docking manager
	 */
	public DockingManager getDockingManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableHolder, it's the same value that is returned from
	 *  getDockingManager().
	 * 
	 *  @return layout persistence.
	 */
	public LayoutPersistence getLayoutPersistence() {
	}

	protected boolean isContentPaneCheckingEnabled() {
	}

	protected void setContentPaneCheckingEnabled(boolean contentPaneCheckingEnabled) {
	}

	/**
	 *  Releases all of the native screen resources used by this Window, its subcomponents, and all of its owned
	 *  children. That is, the resources for these Components will be destroyed, any memory they consume will be returned
	 *  to the OS, and they will be marked as undisplayable. <p/> The Window and its subcomponents can be made
	 *  displayable again by rebuilding the native resources with a subsequent call to <code>pack</code> or
	 *  <code>show</code>. The states of the recreated Window and its subcomponents will be identical to the states of
	 *  these objects at the point where the Window was disposed (not accounting for additional modifcations between
	 *  those actions). </p>
	 * 
	 *  @see Component#isDisplayable
	 *  @see #pack
	 *  @see #show
	 */
	@java.lang.Override
	public void dispose() {
	}

	/**
	 *  Checks if the docking manager will be disposed when the JFrame is disposed.
	 * 
	 *  @return true or false.
	 */
	public boolean isAutoDispose() {
	}

	/**
	 *  Sets the auto dispose flag. If true, the docking manager will be disposed when the JFrame is disposed.
	 * 
	 *  @param autoDispose true or false.
	 */
	public void setAutoDispose(boolean autoDispose) {
	}
}
