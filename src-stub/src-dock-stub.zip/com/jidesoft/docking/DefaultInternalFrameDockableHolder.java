/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  A JInternalFrame implementation of <code>DockableHolder</code>.
 */
@java.lang.SuppressWarnings("serial")
public class DefaultInternalFrameDockableHolder extends javax.swing.JInternalFrame implements DockableHolder {
 {

	protected DockingManager _dockingManager;

	protected javax.swing.JPanel _contentContainer;

	public DefaultInternalFrameDockableHolder() {
	}

	public DefaultInternalFrameDockableHolder(String title) {
	}

	public DefaultInternalFrameDockableHolder(String title, boolean resizable) {
	}

	public DefaultInternalFrameDockableHolder(String title, boolean resizable, boolean closable) {
	}

	public DefaultInternalFrameDockableHolder(String title, boolean resizable, boolean closable, boolean maximizable) {
	}

	public DefaultInternalFrameDockableHolder(String title, boolean resizable, boolean closable, boolean maximizable, boolean iconifiable) {
	}

	/**
	 *  Creates a content container and add it to CENTER of JFrame content pane. It will also create a default
	 *  DockingManager.
	 * 
	 *  @param container the container where the docking manager is installed.
	 */
	protected void initFrame(java.awt.Container container) {
	}

	/**
	 *  Creates the docking manager.
	 * 
	 *  @param contentContainer the container where the docking manager is installed.
	 *  @return docking manager.
	 */
	protected DockingManager createDockingManager(java.awt.Container contentContainer) {
	}

	/**
	 *  Gets the default docking manager.
	 * 
	 *  @return docking manager.
	 */
	public DockingManager getDockingManager() {
	}

	/**
	 *  Gets the layout persistence. In the case of DefaultDockableHolder, it's the same value that is returned from
	 *  getDockingManager().
	 * 
	 *  @return layout persistence.
	 */
	public LayoutPersistence getLayoutPersistence() {
	}

	/**
	 *  Releases all of the native screen resources used by this Window, its subcomponents, and all of its owned
	 *  children. That is, the resources for these Components will be destroyed, any memory they consume will be returned
	 *  to the OS, and they will be marked as undisplayable. <p/> The Window and its subcomponents can be made
	 *  displayable again by rebuilding the native resources with a subsequent call to <code>pack</code> or
	 *  <code>show</code>. The states of the recreated Window and its subcomponents will be identical to the states of
	 *  these objects at the point where the Window was disposed (not accounting for additional modifcations between
	 *  those actions). </p>
	 * 
	 *  @see java.awt.Component#isDisplayable
	 *  @see #pack
	 *  @see #show
	 */
	@java.lang.Override
	public void dispose() {
	}

	protected boolean isContentPaneCheckingEnabled() {
	}

	protected void setContentPaneCheckingEnabled(boolean contentPaneCheckingEnabled) {
	}
}
