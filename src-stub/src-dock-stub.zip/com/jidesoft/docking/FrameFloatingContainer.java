/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  Container to hold DockableFrame when they are floating. This implementation is based on  {@link Frame}.
 */
@java.lang.SuppressWarnings("serial")
public class FrameFloatingContainer extends ResizableFrame implements FloatingContainer {
 {

	public FrameFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager) {
	}

	public FrameFloatingContainer(DockingManager dockingManager, FloatingContainer.FloatingContainerManager floatingContainerManager, String title) {
	}

	protected void initListeners() {
	}

	protected void doHideFloatingFrame() {
	}

	public boolean hasTitleBar() {
	}

	@java.lang.Override
	public java.awt.Rectangle getInitialBounds(java.awt.Rectangle savedBounds) {
	}

	public void updateUndecorated() {
	}

	public void updateBorders() {
	}

	public java.awt.Component getRoutingComponent() {
	}

	public DockingManager getDockingManager() {
	}

	public java.awt.Component asComponent() {
	}

	public void hideItselfIfEmpty() {
	}

	public void updateTitle() {
	}

	/**
	 *  Gets the dock ID.
	 * 
	 *  @return dock ID
	 */
	public int getDockID() {
	}

	/**
	 *  Sets the dock ID.
	 * 
	 *  @param id new ID
	 */
	public void setDockID(int id) {
	}

	/**
	 *  Resets dock ID.
	 */
	public void resetDockID() {
	}

	/**
	 *  Overridden to ask the embedded dockableFrame for its most recently focused subcomponent. When the
	 *  floatingContainer is activated, its content has been docked in another container; so the floatingContainer does
	 *  not have a saved mostRecentFocusOwner.
	 * 
	 *  @return the subcomponent
	 */
	@java.lang.Override
	public java.awt.Component getMostRecentFocusOwner() {
	}

	@java.lang.Override
	public void setResizable(boolean resizable) {
	}

	@java.lang.Override
	protected void beginResizing() {
	}
}
