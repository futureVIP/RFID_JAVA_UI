/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


public interface DockableFrameFactory {

	public DockableFrame create(String key);
}
