/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  A object that stores state, mode and size information of a DockableFrame.
 */
@java.lang.SuppressWarnings("serial")
public class DockContext implements java.io.Serializable {
 {

	/**
	 *  Floatable means the window can be floated in a floating container.
	 */
	public static final int MODE_FLOATABLE = 1;

	/**
	 *  Autohide means the window is docked to a side but still is above any other components, like a sliding door. It
	 *  will automatically hide itself if it loses focus.
	 */
	public static final int MODE_AUTOHIDABLE = 2;

	/**
	 *  Dockable means the window can be docked inside the main window.
	 */
	public static final int MODE_DOCKABLE = 4;

	/**
	 *  Hidable means the window can be hided.
	 */
	public static final int MODE_HIDABLE = 8;

	public static final int MODE_ALL = 15;

	/**
	 *  There are six states for each window.
	 *  <p/>
	 *  Hidden state: means the window is hidden. User need to choose a menu item in View Menu to make the window
	 *  visible.
	 *  <p/>
	 *  Floating state: means the window is floating around, not docks to any side.
	 *  <p/>
	 *  Autohide state: aka auto hide state, the window is hidden behind one of the four SideBar. In sliding active
	 *  state, the window is visible and active.
	 *  <p/>
	 *  FrameDocked state: the window is docked inside the main frame.
	 */
	public static final int STATE_HIDDEN = 0;

	public static final int STATE_FLOATING = 1;

	public static final int STATE_AUTOHIDE = 2;

	public static final int STATE_AUTOHIDE_SHOWING = 3;

	public static final int STATE_FRAMEDOCKED = 4;

	public static final String[] STATE_NAMES;

	/**
	 *  Which side of the frame the window can swing to and is docking to.
	 */
	public static final int DOCK_SIDE_NORTH = 1;

	public static final int DOCK_SIDE_SOUTH = 2;

	public static final int DOCK_SIDE_EAST = 4;

	public static final int DOCK_SIDE_WEST = 8;

	public static final int DOCK_SIDE_CENTER = 16;

	public static final int DOCK_SIDE_UNKNOWN = 32;

	public static final int DOCK_SIDE_HORIZONTAL = 3;

	public static final int DOCK_SIDE_VERTICAL = 12;

	public static final int DOCK_SIDE_ALL = 15;

	public static final int DOCK_SIDE_ALL_AND_CENTER = 31;

	public static final String[] SIDE_NAMES;

	/**
	 *  Default constructor.
	 */
	public DockContext() {
	}

	/**
	 *  Gets initial state.
	 * 
	 *  @return initial state
	 */
	public int getInitMode() {
	}

	/**
	 *  Sets the initial state. The available states are defined in {@link com.jidesoft.docking.DockContext}. They are
	 *  <code>STATE_HIDDEN</code>, <code>STATE_FLOATING</code>, <code>STATE_AUTOHIDE</code> and
	 *  <code>STATE_FRAMEDOCKED</code>. It also supports a few negative value such as <code>STATE_HIDDEN -
	 *  STATE_FLOATING</code>, <code>STATE_HIDDEN - STATE_AUTOHIDE</code> and <code>STATE_HIDDEN -
	 *  STATE_FRAMEDOCKED</code>. In those nagative cases, the frame will initially be hidden. But when showFrame is
	 *  called on this frame, it will use the corrponding mode to show the frame. For example, if initMode is set to
	 *  <code>STATE_HIDDEN - STATE_FLOATING</code>, the frame will initially be hidden. When showFrame is called, the
	 *  frame will be floated.
	 * 
	 *  @param initMode initial state
	 */
	public void setInitMode(int initMode) {
	}

	/**
	 *  Gets current state.
	 * 
	 *  @return current state
	 */
	public int getCurrentMode() {
	}

	/**
	 *  Checks if it's in hidden state.
	 * 
	 *  @return true if it's in hidden state
	 */
	public boolean isHidden() {
	}

	/**
	 *  Checks if it's in frame docked state.
	 * 
	 *  @return true if it's in frame docked state
	 */
	public boolean isDocked() {
	}

	/**
	 *  Checks if it's in floating state.
	 * 
	 *  @return true if it's in floating state
	 */
	public boolean isFloated() {
	}

	/**
	 *  Checks if it's in autohide state.
	 * 
	 *  @return true if it's in autohide state
	 */
	public boolean isAutohide() {
	}

	/**
	 *  Checks if it's in autohide showing state.
	 * 
	 *  @return true if it's in autohide showing state
	 */
	public boolean isAutohideShowing() {
	}

	/**
	 *  Sets current state.
	 * 
	 *  @param currentMode current state
	 */
	public void setCurrentMode(int currentMode) {
	}

	/**
	 *  Gets initial side.
	 * 
	 *  @return the initial side
	 */
	public int getInitSide() {
	}

	/**
	 *  Sets the initial side. The valid values are {@link #DOCK_SIDE_EAST}, {@link #DOCK_SIDE_WEST}, {@link
	 *  #DOCK_SIDE_SOUTH}, {@link #DOCK_SIDE_NORTH}, and {@link #DOCK_SIDE_CENTER}. If you ever use {@link
	 *  #DOCK_SIDE_CENTER}, dockable frame will appear in workspace area thus you need to cal {@link
	 *  Workspace#setAcceptDockableFrame(boolean)} and set it to true. If so, you shouldn't add any other arbitrary
	 *  components to workspace area.
	 * 
	 *  @param initSide the initial side
	 */
	public void setInitSide(int initSide) {
	}

	public boolean isInitPosition() {
	}

	public void setInitPosition(boolean initPosition) {
	}

	/**
	 *  Gets initial index.
	 * 
	 *  @return the initial index
	 */
	public int getInitIndex() {
	}

	/**
	 *  Sets initial index. After seting initial side and mode, user can use this parameter to define initial position.
	 *  <br> If all frames's initMode are FRAMEDOCKED and initSide are SOUTH, the all frames with the same index will
	 *  form a tabbed pane. Frames with index 0 will appear before frames with index 1. In this case, only 0 and 1 is
	 *  allowed. <br> If initMode is AUTOHIDE, the same indexed frames will form a group. In this case, any index greater
	 *  than 0 is allowed. <br> If initMode is FLOATING, the same indexed frames will form a tabbed pane and in one
	 *  floating window. In this case, any index greater than 0 is allowed.
	 * 
	 *  @param initIndex the initial index
	 */
	public void setInitIndex(int initIndex) {
	}

	public int getCurrentDockSide() {
	}

	public void setCurrentDockSide(int currentDockSide) {
	}

	public java.awt.Rectangle getUndockedBounds() {
	}

	public void setUndockedBounds(java.awt.Rectangle bound) {
	}

	public int getAutohideWidth() {
	}

	public void setAutohideWidth(int width) {
	}

	public int getAutohideHeight() {
	}

	public void setAutohideHeight(int height) {
	}

	public int getDockedWidth() {
	}

	public void setDockedWidth(int dockedWidth) {
	}

	public int getDockedHeight() {
	}

	public void setDockedHeight(int dockedHeight) {
	}

	public PreviousState getHiddenPreviousState() {
	}

	public void setHiddenPreviousState(PreviousState hiddenPreviousState) {
	}

	public PreviousState getClosePreviousState() {
	}

	public void setClosePreviousState(PreviousState closePreviousState) {
	}

	public PreviousState getDockPreviousState() {
	}

	public void setDockPreviousState(PreviousState dockPreviousState) {
	}

	public PreviousState getFloatPreviousState() {
	}

	public void setFloatPreviousState(PreviousState floatPreviousState) {
	}

	public PreviousState getAutohidePreviousState() {
	}

	public void setAutohidePreviousState(PreviousState autohidePreviousState) {
	}

	public static String getDockSideName(int side) {
	}

	public static String getStateName(int mode) {
	}

	public int getDockID() {
	}

	public void setDockID(DockingManager dockingManager, int dockID) {
	}

	public void resetDockID(DockingManager dockingManager) {
	}

	public int getCanMode() {
	}

	public void setCanMode(int canMode) {
	}

	public boolean isDockable() {
	}

	public void setDockable(boolean dockable) {
	}

	public boolean isHidable() {
	}

	public void setHidable(boolean hidable) {
	}

	public boolean isAutohidable() {
	}

	public void setAutohidable(boolean autohidable) {
	}

	public boolean isFloatable() {
	}

	public void setFloatable(boolean floatable) {
	}

	public PreviousState getAvailablePreviousState() {
	}

	public void setAvailablePreviousState(PreviousState availablePreviousState) {
	}

	public boolean isAvailable() {
	}

	public void setAvailable(boolean available) {
	}

	public PreviousState getMaximizedPreviousState() {
	}

	public void setMaximizedPreviousState(PreviousState maximizePreviousState) {
	}

	/**
	 *  Clones a <code>DockContext</code>. Not all information are cloned. The information closed are initSide, initMode,
	 *  initIndex, undockedBounds, autohideHeight, autohideWidth, dockedHeight, dockedWidth, currentMode, canMode, and
	 *  currentDockSide. All other informations are ignored.
	 * 
	 *  @return a cloned <code>DockContext</code>.
	 */
	@java.lang.Override
	public Object clone() {
	}
}
