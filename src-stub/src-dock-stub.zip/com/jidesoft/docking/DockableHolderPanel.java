/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  A JPanel which can be used as DockableHolder.
 */
@java.lang.SuppressWarnings("serial")
public class DockableHolderPanel extends com.jidesoft.swing.ContentContainer implements DockableHolder {
 {

	public DockableHolderPanel() {
	}

	public DockableHolderPanel(javax.swing.RootPaneContainer container) {
	}

	/**
	 *  Creates DockingManager for this panel. By default, it will return <tt>new DefaultDockingManager(container,
	 *  this)</tt>. Subclass can override it to return your own instance of DockingManager.
	 * 
	 *  @param container
	 *  @return DockingManager.
	 */
	protected DockingManager createDockingManager(javax.swing.RootPaneContainer container) {
	}

	public DockingManager getDockingManager() {
	}

	public void dispose() {
	}

	/**
	 *  DockingManager manages the layout and the content of DockableHolderPanel so we override this setLayout method to
	 *  do nothing, so calling this method will have no effect.
	 * 
	 *  @param mgr
	 *  @since 2.7.2
	 */
	@java.lang.Override
	public void setLayout(java.awt.LayoutManager mgr) {
	}
}
