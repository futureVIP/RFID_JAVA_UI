/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  <code>DockableFramePopup</code> is a component that integrates JidePopup with DockableFrame. In attached mode,
 *  DockableFramePopup is just like a regular JidePopup. However in detached mode, it becomes a DocakbleFrame.
 *  <p/>
 *  This component, which is part of JidePopup component, is still in beta. You can use it but with caWe might change it
 *  in the future.
 */
@java.lang.SuppressWarnings("serial")
public abstract class DockableFramePopup extends JidePopup {

	public DockableFrame _dockableFrame;

	public DockableFramePopup(DockingManager dockingManager) {
	}

	@java.lang.Override
	protected void internalShowPopup(int x, int y) {
	}

	@java.lang.Override
	protected void internalShowPopup(int x, int y, java.awt.Component owner) {
	}

	@java.lang.Override
	protected ResizableWindow createHeavyweightPopupContainer(java.awt.Component owner) {
	}

	public abstract DockableFrame createDockableFrame() {
	}

	/**
	 *  Gets the dockable frame. If the dockable frame is null, it will call createDockableFrame() to create one.
	 * 
	 *  @return the dockable frame.
	 */
	public DockableFrame getDockableFrame() {
	}

	@java.lang.Override
	public void setDetached(boolean detached) {
	}

	@java.lang.Override
	protected void endDragging() {
	}
}
