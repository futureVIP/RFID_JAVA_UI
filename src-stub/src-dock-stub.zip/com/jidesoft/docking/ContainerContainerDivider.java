/**
 *  The package contains classes for JIDE Docking Framework product.
 */
package com.jidesoft.docking;


/**
 *  The divider between DockableFrames in Docking Framework. It is actually the divider of JideSplitPane.
 */
@java.lang.SuppressWarnings("serial")
public class ContainerContainerDivider extends JideSplitPaneDivider {

	public ContainerContainerDivider(JideSplitPane splitPane) {
	}

	@java.lang.Override
	protected MouseHandler createMouseHandler() {
	}
}
