/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>AbstractDiffPane</code> is the base for the diff/merge panes. We introduced this level of abstraction so that we can support different kinds of diff components, to compare string arrays, folders etc.
 *  <p/>
 *  The methods that subclass can override are
 *  <pre>
 *  <ul>
 *  <li>{@link #createPane(Object, int)}: override to use a different component to display the objects to be compared.
 *  <li>{@link #createToolBar()}: override to create a different component for the toolbar.
 *  <li>{@link #createStatusBar()}: override to create a different component for the status bar.
 *  <li>{@link #createLegendBar()}: override to customize the legend bar. It is part of the status bar.
 *  <li>{@link #initLayout(javax.swing.JComponent, javax.swing.JComponent, javax.swing.JComponent)}: override to arrange
 *  the pane, the toolbar and the status bar.
 *  </ul>
 *  </pre>
 */
public abstract class AbstractDiffPane extends javax.swing.JPanel {

	protected java.awt.Color _insertedColor;

	protected java.awt.Color _changedColor;

	protected java.awt.Color _deletedColor;

	protected java.util.Map _actions;

	public static final String COMMAND_FIRST = "first";

	public static final String COMMAND_PREVIOUS = "previous";

	public static final String COMMAND_NEXT = "next";

	public static final String COMMAND_LAST = "last";

	/**
	 *  Creates an <code>AbstractDiffPane</code>.
	 * 
	 *  @param items items to be compared.
	 */
	public AbstractDiffPane(Object[] items) {
	}

	/**
	 *  Initialize the layout. This method will arrange the layout of the split pane, the tool bar and the status bar. By default, we use a BorderLayout with split pane at the center, toolbar and status bar on the north and south side respectively.
	 * 
	 *  @param contentArea the content area. It is a JideSplitPane by default.
	 *  @param toolBar     the tool bar.
	 *  @param statusBar   the status bar.
	 */
	protected void initLayout(javax.swing.JComponent contentArea, javax.swing.JComponent toolBar, javax.swing.JComponent statusBar) {
	}

	/**
	 *  Creates the content area. By default, it is a JideSplitPane and each pane contains a component that displays one item to be compared.
	 * 
	 *  @param panes the panes. Each pane contains a component that displays one item to be compared.
	 *  @return the content area of the diff pane.
	 */
	protected javax.swing.JComponent createContentArea(javax.swing.JComponent[] panes) {
	}

	/**
	 *  Adjusts the DiffDivider's left and right offset.
	 * 
	 *  @param divider the DiffDivider.
	 *  @param index   the index of the DiffDivider.
	 */
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	/**
	 *  Creates the toolbar component for the DiffPane.
	 * 
	 *  @return a JToolBar. You can subclass it to create a CommandBar if you have JIDE Action Framework.
	 */
	protected javax.swing.JComponent createToolBar() {
	}

	/**
	 *  Creates the button. Our default code is
	 *  <code><pre>
	 *  protected AbstractButton createButton(Action action) {
	 *      AbstractButton button = new JideButton(action);
	 *      button.setName("" + action.getValue(Action.ACTION_COMMAND_KEY));
	 *      button.setDisabledIcon((Icon) action.getValue("disabledIcon"));
	 *      button.setRequestFocusEnabled(false);
	 *      AutoRepeatButtonUtils.install(button, 50, 200);
	 *      return button;
	 *  }
	 *  </pre></code>
	 * 
	 *  @param action the action for the button.
	 *  @return a button.
	 */
	protected javax.swing.AbstractButton createButton(javax.swing.Action action) {
	}

	/**
	 *  Gets the localized string from resource bundle. Subclass can override it to provide its own string. Available keys are defined in grids.properties that begin with "Pane.".
	 * 
	 *  @param key the key
	 *  @return the localized string.
	 */
	protected String getResourceString(String key) {
	}

	/**
	 *  Creates the actions used by the diff pane. We kept map of actions on field _actions. All actions used by the tool bar buttons are added to this map. Each action has a name. We will use this name to find out the text, tooltip and icon from diff.properties. By default, the text is empty and the icon is getting from the icon files under icons folder. You can follow the same pattern if you want to add more buttons to the tool bar.
	 */
	protected void createActions() {
	}

	/**
	 *  Customizes the action for a command string by getting the text, tooltip, mnemonic, icon etc from the resource file.
	 * 
	 *  @param action  the action.
	 *  @param command the command string.
	 *  @return the action.
	 */
	@java.lang.SuppressWarnings({"unchecked", "ConstantConditions"})
	protected javax.swing.Action customizeAction(javax.swing.Action action, String command) {
	}

	/**
	 *  Adds components to the toolbar. By default, we added four buttons to the tool bar.
	 * 
	 *  @param toolBar the tool bar where we will add the buttons.
	 */
	protected void customizeToolBar(javax.swing.JComponent toolBar) {
	}

	/**
	 *  Creates the status bar component. The status bar appears on the bottom of the diff pane by default. It has a message label which shows the status. You can call {@link #setMessage(String)} to change the status. It also has a legend area which shows the meaning of the colors used by the diff pane. The legend component can be customized by overriding {@link #createLegendBar()}.
	 * 
	 *  @return a status bar component.
	 */
	protected javax.swing.JComponent createStatusBar() {
	}

	/**
	 *  Creates the legend area which shows the meaning of the colors used by the diff pane. By default, it appears on the bottom right of the diff pane on the same line as the status label.
	 * 
	 *  @return the legend area.
	 */
	protected javax.swing.JComponent createLegendBar() {
	}

	public java.awt.Color getInsertedColor() {
	}

	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	public java.awt.Color getChangedColor() {
	}

	public void setChangedColor(java.awt.Color changedColor) {
	}

	public java.awt.Color getDeletedColor() {
	}

	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	/**
	 *  Subclass implements it to use a different component to display the objects to be compared.
	 * 
	 *  @param item  item to be compared. The component should be able to display the item.
	 *  @param index the index of the pane. For example, for a type diff pane to compare two items before and after modification, the index 0 will be the original item before modification, the index 1 will be the item after modification.
	 *  @return the component to display the item to be compared.
	 */
	public abstract javax.swing.JComponent createPane(Object item, int index) {
	}

	/**
	 *  Subclass implements it to create a DiffDivider that appears between the panes.
	 * 
	 *  @param index the index of the DiffDivider
	 *  @return the DiffDivider.
	 */
	public abstract DiffDivider createDivider(int index) {
	}

	/**
	 *  Changes the message.
	 * 
	 *  @param message the new message.
	 */
	public void setMessage(String message) {
	}

	/**
	 *  Get the message.
	 * 
	 *  @return the message.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public String getMessage() {
	}

	/**
	 *  Updates the enable/disable states of the actions on the toolbar buttons.
	 * 
	 *  @param index the pane index. This is the pane that triggers the update.
	 */
	protected void updateActions(int index) {
	}

	/**
	 *  Goes to the first change.
	 */
	protected void firstChange() {
	}

	/**
	 *  Goes to the previous change.
	 */
	protected void previousChange() {
	}

	/**
	 *  Goes to the next change.
	 */
	protected void nextChange() {
	}

	/**
	 *  Goes to the last change.
	 */
	protected void lastChange() {
	}

	/**
	 *  Installs the listeners. Subclass can override this method to install the necessary listeners. This method is called only in the constructor.
	 */
	protected void installListeners() {
	}
}
