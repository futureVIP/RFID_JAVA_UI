/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>AbstractMergePane</code> extends <code>AbstractDiffPane</code> to add one more pane since it is for a three-way
 *  merge. It also adds one more button to the toolbar to accept all non-conflicting changes.
 */
public abstract class AbstractMergePane extends AbstractDiffPane {

	protected java.awt.Color _conflictedColor;

	public static final String COMMAND_ACCEPT = "accept";

	public AbstractMergePane(String[] texts) {
	}

	public java.awt.Color getConflictedColor() {
	}

	public void setConflictedColor(java.awt.Color conflictedColor) {
	}

	protected void createActions() {
	}

	/**
	 *  Overrides to add accept button to the toolbar.
	 * 
	 *  @param toolBar the tool bar where we will add the buttons.
	 */
	@java.lang.Override
	protected void customizeToolBar(javax.swing.JComponent toolBar) {
	}

	@java.lang.Override
	protected javax.swing.JComponent createLegendBar() {
	}

	protected void acceptNonConflicts() {
	}
}
