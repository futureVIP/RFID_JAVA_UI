/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  <code>CodeEditorDiffPane</code> is a diff pane based on <code>CodeEditor</code> component in JIDE Code Editor product. It can be used to compare two block of multiple line texts. The text will be displayed in a <code>CodeEditor</code> to have syntax coloring. It also uses the highlight features provided by <code>CodeEditor</code> to make it easy to see the differences.
 */
public class CodeEditorDiffPane extends AbstractDiffPane {

	protected final int GAP_TITLE_PANE = 2;

	protected CodeEditor _fromEditor;

	protected CodeEditor _toEditor;

	protected DiffMargin _fromDiffMargin;

	protected DiffMargin _toDiffMargin;

	/**
	 *  Creates a CodeEditorDiffPane. The text to be compared can be set using {@link #setFromText(String)} and {@link #setToText(String)} methods.
	 */
	public CodeEditorDiffPane() {
	}

	public CodeEditorDiffPane(String fromText, String toText) {
	}

	public javax.swing.JComponent createPane(Object item, int index) {
	}

	public DiffDivider createDivider(int index) {
	}

	@java.lang.Override
	public void setChangedColor(java.awt.Color changedColor) {
	}

	@java.lang.Override
	public void setInsertedColor(java.awt.Color insertedColor) {
	}

	@java.lang.Override
	public void setDeletedColor(java.awt.Color deletedColor) {
	}

	@java.lang.Override
	protected void adjustDividerOffset(DiffDivider divider, int index) {
	}

	protected javax.swing.JComponent createFromTitle() {
	}

	protected javax.swing.JComponent createToTitle() {
	}

	public String getFromTitle() {
	}

	public void setFromTitle(String title) {
	}

	public String getToTitle() {
	}

	public void setToTitle(String title) {
	}

	protected CodeEditor createEditor() {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	protected void customizeEditor(CodeEditor editor, int index) {
	}

	protected DiffDivider.RowConverter createFromRowConverter() {
	}

	/**
	 *  Sets the text for the from editor.
	 * 
	 *  @param fromText the new text for the from editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setFromText(String fromText) {
	}

	public String getFromText() {
	}

	/**
	 *  Sets the text for the to editor.
	 * 
	 *  @param toText the new text for the to editor.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setToText(String toText) {
	}

	public String getToText() {
	}

	protected DiffDivider.RowConverter createToRowConverter() {
	}

	protected void synchronizeViewport(DiffDivider diffDivider, boolean startFrom) {
	}

	@java.lang.Override
	protected void updateActions(int index) {
	}

	@java.lang.Override
	protected void installListeners() {
	}

	protected String[] splitString(String string, String lineBreak) {
	}

	@java.lang.SuppressWarnings("UnusedDeclaration")
	public java.util.List getDifferences() {
	}

	/**
	 *  Runs the different algorithm and returns the list of Differences.
	 * 
	 *  @param fromText the fromText.
	 *  @param toText   the toText
	 *  @return the list of Differences.
	 */
	protected java.util.List diff(String fromText, String toText) {
	}

	/**
	 *  Runs the diff algorithm and displays the differences on this diff pane.
	 * 
	 *  @return the list of Differences.
	 */
	public java.util.List diff() {
	}

	/**
	 */
	public void clearDiff() {
	}

	/**
	 *  Checks if the highlightExactChange flag is on. If on, we will display what changed exactly if one line in the fromEditor is changed in the toEditor if and only if there is just one change between the two lines. Otherwise, the whole line will be highlighted.
	 * 
	 *  @return true or false.
	 */
	public boolean isHighlightExactChange() {
	}

	/**
	 *  Checks if the diff pane is read only. A read only diff pane will not show the buttons to apply changes.
	 * 
	 *  @return true or false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public boolean isReadOnly() {
	}

	/**
	 *  Sets the read only flag. A read only diff pane will not show the buttons to apply changes.
	 * 
	 *  @param readOnly the new read only flag.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setReadOnly(boolean readOnly) {
	}

	/**
	 *  Sets the highlightExactChange flag.
	 * 
	 *  @param highlightExactChange true or false.
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void setHighlightExactChange(boolean highlightExactChange) {
	}

	/**
	 *  Accepts the specified Difference and return a new list of Differences.
	 * 
	 *  @param differences the list of Differences.
	 *  @param c           the Difference to be accepted.
	 *  @return a new list of Differences.
	 */
	protected java.util.List acceptDifference(java.util.List differences, Difference c) {
	}

	/**
	 *  Deletes number of lines from the specified started line in the toEditor.
	 * 
	 *  @param line             the starting line
	 *  @param numberOfLines    the number of lines to be deleted.
	 *  @param runDiffAfterward true of run the diff() again after deleting the lines.
	 */
	public void delete(int line, int numberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Inserts some lines from the fromEditor to the toEditor.
	 * 
	 *  @param line              the insersion line in the toEditor
	 *  @param fromLine          the starting line in the fromEditor
	 *  @param fromNumberOfLines the number of lines in the fromEditor to be inserted to the toEditor.
	 *  @param runDiffAfterward  true of run the diff() again after inserting the lines.
	 */
	public void insert(int line, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	/**
	 *  Replaces number of lines from the specified started line in the toEditor with some lines from the fromEditor.
	 * 
	 *  @param line              the starting line in the toEditor
	 *  @param numberOfLines     the number of lines to be replaced from the toEditor.
	 *  @param fromLine          the starting line in the fromEditor
	 *  @param fromNumberOfLines the number of lines in the fromEditor to be copied to the toEditor.
	 *  @param runDiffAfterward  true of run the diff() again after replacing the lines.
	 */
	public void replace(int line, int numberOfLines, int fromLine, int fromNumberOfLines, boolean runDiffAfterward) {
	}

	@java.lang.Override
	public void firstChange() {
	}

	@java.lang.Override
	public void previousChange() {
	}

	@java.lang.Override
	public void nextChange() {
	}

	@java.lang.Override
	public void lastChange() {
	}
}
