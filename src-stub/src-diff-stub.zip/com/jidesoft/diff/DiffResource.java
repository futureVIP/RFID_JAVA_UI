/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


public class DiffResource {

	public DiffResource() {
	}

	public static java.util.ResourceBundle getResourceBundle(java.util.Locale locale) {
	}
}
