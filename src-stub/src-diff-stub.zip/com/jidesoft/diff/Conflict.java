/**
 *  The package contains classes related for JIDE Diff product.
 */
package com.jidesoft.diff;


/**
 *  Represents a conflict, as used in <code>Merge</code>. A conflict consists of three pairs of starting and ending
 *  points, each pair representing either the "from" or the "to" or the "other" collection passed to <code>Merge</code>.
 *  If an ending point is -1, then the difference was either a deletion or an addition. For example, if
 *  <code>getDeletedEnd()</code> returns -1, then the difference represents an addition. There are two set of delete
 *  starting and ending points. The delete starting point could be -1. If both of the delete starting point are not -1,
 *  it means this difference is a conflict.
 */
public class Conflict extends Difference {

	public Conflict(int deletedStart, int deletedEnd, int addedStart, int addedEnd, int deleted2Start, int deleted2End) {
	}

	public int getDeleted2Start() {
	}

	public int getDeleted2End() {
	}

	/**
	 *  Sets the point as added. The start and end points will be modified to include the given line.
	 */
	public void setDeleted2(int line) {
	}

	@java.lang.Override
	public boolean equals(Object obj) {
	}

	/**
	 *  Returns a string representation of this difference.
	 */
	public String toString() {
	}

	public boolean isConflicted() {
	}

	/**
	 *  Checks if the list of Conflicts has any conflicting changes.
	 * 
	 *  @param conflicts the list of Conflicts.
	 *  @return true or false.
	 */
	public static boolean isConflicted(java.util.List conflicts) {
	}
}
