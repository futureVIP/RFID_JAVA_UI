/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  <code>MouseShortcut</code> represents a kind of shortcuts that triggered by mouse. It can be single click of one of
 *  the mouse buttons, or double clicks, or even triple clicks if you want. It can also have modifiers which is status of
 *  keyboard's ctrl (or command on Mac OS X), shift or alt (or option key on Mac OS X).
 */
public class MouseShortcut extends Shortcut {

	public MouseShortcut() {
	}

	public MouseShortcut(int button, int clickCount, int modifiers) {
	}

	public MouseShortcut(java.awt.event.MouseEvent e) {
	}

	public MouseShortcut(int button, int clickCount, int modifiers, String context) {
	}

	public int getClickCount() {
	}

	public void setClickCount(int clickCount) {
	}

	public int getButton() {
	}

	public void setButton(int button) {
	}

	public int getModifiers() {
	}

	public void setModifiers(int modifiers) {
	}

	@java.lang.Override
	public String toString() {
	}

	public static MouseShortcut parse(String s) {
	}

	public static String getMouseShortcutString(MouseShortcut shortcut) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	public static String getModifiersExText(int modifiers) {
	}
}
