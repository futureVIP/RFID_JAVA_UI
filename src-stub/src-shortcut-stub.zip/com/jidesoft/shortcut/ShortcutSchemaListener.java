/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  A listener interface to receive ShortcutSchemaEvent.
 */
public interface ShortcutSchemaListener extends java.util.EventListener {
 {

	/**
	 *  Invoked when the target of the listener has changed the schema.
	 * 
	 *  @param e a ShortcutSchemaEvent object
	 */
	public void shortcutSchemaChanged(ShortcutSchemaEvent e);
}
