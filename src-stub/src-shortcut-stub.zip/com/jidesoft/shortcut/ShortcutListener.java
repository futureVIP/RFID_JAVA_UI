/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  A listener interface to receive ShortcutEvent.
 */
public interface ShortcutListener extends java.util.EventListener {
 {

	/**
	 *  Invoked when the target of the listener has changed shortcuts.
	 * 
	 *  @param e a ShortcutEvent object
	 */
	public void shortcutChanged(ShortcutEvent e);
}
