/**
 *  The package contains classes for JIDE Shortcut Editor product.
 */
package com.jidesoft.shortcut;


/**
 *  <code>ShortcutEditor</code> is an editor for <code>ShortcutSchemaManager</code>.
 */
@java.lang.SuppressWarnings("UnusedDeclaration")
public class ShortcutEditor extends javax.swing.JPanel {

	protected javax.swing.JList _schemaList;

	protected javax.swing.JButton _setActiveButton;

	protected javax.swing.JButton _copyButton;

	protected javax.swing.JButton _deleteButton;

	protected javax.swing.JLabel _parentSchemaLabel;

	protected QuickFilterField _filterField;

	protected javax.swing.JList _commandsList;

	protected javax.swing.JCheckBox _overriddenOnlyCheckBox;

	protected javax.swing.JComboBox _shortcutsComboBox;

	protected ShortcutLabel _shortcutLabel;

	protected javax.swing.JButton _removeButton;

	protected ShortcutField _shortcutField;

	protected javax.swing.JButton _assignButton;

	protected javax.swing.JComboBox _contextComboBox;

	protected javax.swing.DefaultListModel _schemaListModel;

	public ShortcutEditor(ShortcutSchemaManager manager) {
	}

	public ShortcutEditor(ShortcutSchemaManager manager, boolean allowMultipleShortcuts) {
	}

	/**
	 *  Creates ShortcutEditor.
	 * 
	 *  @param manager  the ShortcutSchemaManager
	 *  @param contexts a list of contexts. Please note, the first context must be "Global". You can give it a different name if you want such as "Default". But it means if the short cut doesn't
	 *                  explicitly specified a context, it defaults to this context. Null context in shortcut means this one too.
	 */
	public ShortcutEditor(ShortcutSchemaManager manager, String[] contexts) {
	}

	/**
	 *  Creates ShortcutEditor.
	 * 
	 *  @param manager                  the ShortcutSchemaManager
	 *  @param contexts                 a list of contexts. Please note, the first context must be "Global". You can give it a different name if you want such as "Default". But it means if the short
	 *                                  cut doesn't explicitly specified a context, it defaults to this context. Null context in shortcut means this one too.
	 *  @param multipleShortcutsAllowed whether multiple shortcuts is allowed for each command.
	 */
	public ShortcutEditor(ShortcutSchemaManager manager, String[] contexts, boolean multipleShortcutsAllowed) {
	}

	protected void initComponents() {
	}

	/**
	 *  Creates the panel that contains the schema JList as well as the buttons for it.
	 * 
	 *  @return the schema panel.
	 */
	protected javax.swing.JPanel createSchemaPanel() {
	}

	/**
	 *  This method is called when the selected schema is changed in the schema JList.
	 */
	protected void selectedSchemaChanged() {
	}

	/**
	 *  Creates the panel that contains the shortcut filter field.
	 * 
	 *  @return the shortcut filter panel.
	 */
	protected javax.swing.JPanel createShortcutFilterPanel() {
	}

	/**
	 *  Creates a QuickListFilterField for the command JList.
	 * 
	 *  @return a QuickListFilterField.
	 */
	protected QuickFilterField createFilterField() {
	}

	protected void initData(boolean keepSelection) {
	}

	/**
	 *  Updates the command list after the filtering in the filter field.
	 */
	protected void updateCommandList() {
	}

	/**
	 *  Updates the command JList's list mode based on the filter field's filtered result.
	 * 
	 *  @param field the filter field.
	 */
	protected void updateCommandListModel(QuickFilterField field) {
	}

	/**
	 *  Updates the filter field's list model from the command list.
	 * 
	 *  @param field the filter field.
	 *  @param model the list model.
	 */
	protected void updateFilterField(QuickFilterField field, javax.swing.ListModel model) {
	}

	/**
	 *  Create the panel that contains the shortcut JList.
	 * 
	 *  @return the shortcut list panel.
	 */
	protected javax.swing.JPanel createShortcutListPanel() {
	}

	/**
	 *  This method is called when the selected command is changed.
	 * 
	 *  @param selectLast true to select the last command in the shortcutsCombobox.
	 */
	protected void selectedCommandChanged(boolean selectLast) {
	}

	/**
	 *  Creates the panel for the existing shortcut.
	 * 
	 *  @return the existing shortcut panel.
	 */
	protected javax.swing.JPanel createExistingShortcutPanel() {
	}

	/**
	 *  Creates the editing panel for the shortcut.
	 * 
	 *  @return the editing panel for the shortcut.
	 */
	protected javax.swing.JPanel createEditingShortcutPanel() {
	}

	/**
	 *  Creates the shortcut field.
	 * 
	 *  @return the shortcut field.
	 */
	protected ShortcutField createShortcutField() {
	}

	/**
	 *  Creates the panel for the conflicting shortcuts.
	 * 
	 *  @return the panel for the conflicting shortcuts.
	 */
	protected javax.swing.JPanel createConflictingShortcutPanel() {
	}

	protected void updateEditable() {
	}

	public ShortcutSchema getSelectedShortcutSchema() {
	}

	public void setSelectedShortcutSchema(ShortcutSchema selectedShortcutSchema) {
	}

	public String getSelectedCommand() {
	}

	public void setSelectedCommand(String selectedCommand) {
	}

	public QuickFilterField getFilterField() {
	}

	public boolean isMultipleShortcutsAllowed() {
	}

	public boolean isConflictedShortcutsAllowed() {
	}

	public void setConflictedShortcutsAllowed(boolean conflictedShortcutsAllowed) {
	}

	/**
	 *  Gets the ShortcutField. It is the field user defines the keystroke shortcut or mouse shortcut.
	 * 
	 *  @return the ShortcutField.
	 */
	public ShortcutField getShortcutField() {
	}

	public ShortcutSchemaManager getShortcutSchemaManager() {
	}

	/**
	 *  Gets the resource bundle for the ShortcutEditor.
	 * 
	 *  @return the resource bundle for the ShortcutEditor.
	 */
	protected java.util.ResourceBundle getResourceBundle() {
	}

	/**
	 *  Get the flag indicating if the new shortcut should be inserted in the first place of the list.
	 * 
	 *  @return true if new shortcut for the same action should be inserted to the first place. Otherwise false.
	 * 
	 *  @see #setNewShortcutOnTop(boolean)
	 */
	public boolean isNewShortcutOnTop() {
	}

	/**
	 *  Set the flag indicating if the new shortcut should be inserted in the first place of the list.
	 *  <p/>
	 *  By default, the flag is false to keep the original behavior.
	 * 
	 *  @param newShortcutOnTop the flag
	 */
	public void setNewShortcutOnTop(boolean newShortcutOnTop) {
	}
}
