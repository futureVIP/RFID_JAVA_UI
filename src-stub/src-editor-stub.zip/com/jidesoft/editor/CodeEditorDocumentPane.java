/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>CodeEditorDocumentPane</code> is a special DocumentPane for CodeEditors. The only difference between this and
 *  the DocuemntPane is this one changes the "New Horizontal Group" and "New Vertical Group" context menu items to
 *  "SplitHorizontallyy" and "Split Vertically" respectively. If you use <code>CodeEditorDocumentComponent</code> as the
 *  DocumentComponent, it will split the CodeEditor into two CodeEditors which are editing the same content.
 */
public class CodeEditorDocumentPane extends DocumentPane {

	public CodeEditorDocumentPane() {
	}
}
