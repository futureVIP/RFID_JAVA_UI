/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  A document implementation that can be tokenized by the syntax highlighting system.
 * 
 *  @author Slava Pestov
 *  @version $Id: SyntaxDocument.java,v 1.14 1999/12/13 03:40:30 sp Exp $
 */
public class SyntaxDocument extends javax.swing.text.PlainDocument implements LineBreak {
 {

	protected javax.swing.undo.UndoManager _undoManager;

	protected javax.swing.undo.CompoundEdit _compoundEdit;

	protected int _compoundEditCount;

	protected tokenmarker.TokenMarker tokenMarker;

	public SyntaxDocument() {
	}

	public String getLineText(int offset) {
	}

	public int getLineNumber(int offset) {
	}

	public void undo() {
	}

	public void redo() {
	}

	public javax.swing.undo.UndoManager getUndoManager() {
	}

	public void setUndoManager(javax.swing.undo.UndoManager u) {
	}

	/**
	 *  Returns the token marker that is to be used to split lines of this document up into tokens. May return null if
	 *  this document is not to be colorized.
	 * 
	 *  @return the token marker.
	 */
	public tokenmarker.TokenMarker getTokenMarker() {
	}

	/**
	 *  Sets the token marker that is to be used to split lines of this document up into tokens. May throw an exception
	 *  if this is not supported for this type of document.
	 * 
	 *  @param tm The new token marker
	 */
	public void setTokenMarker(tokenmarker.TokenMarker tm) {
	}

	/**
	 *  Reparses the document, by passing all lines to the token marker. This should be called after the document is
	 *  first loaded.
	 */
	public void tokenizeLines() {
	}

	/**
	 *  Reparses the document, by passing the specified lines to the token marker. This should be called after a large
	 *  quantity of text is first inserted.
	 * 
	 *  @param start The first line to parse
	 *  @param len   The number of lines, after the first one to parse
	 */
	public void tokenizeLines(int start, int len) {
	}

	/**
	 *  Check if the character in the offset is inside a comment or literal.
	 * 
	 *  @param offset the offset to check
	 *  @return true if it is inside a comment or literal. Otherwise false.
	 * 
	 *  @throws BadLocationException if the location is not correct.
	 */
	protected boolean isInCommentOrLiteral(int offset) {
	}

	/**
	 *  Starts a compound edit that can be undone in one operation. Subclasses that implement undo should override this
	 *  method; this class has no undo functionality so this method is empty.
	 */
	public void beginCompoundEdit() {
	}

	/**
	 *  Ends a compound edit that can be undone in one operation. Subclasses that implement undo should override this
	 *  method; this class has no undo functionality so this method is empty.
	 */
	public void endCompoundEdit() {
	}

	/**
	 *  Adds an undoable edit to this document's undo list. The edit should be ignored if something is currently being
	 *  undone.
	 * 
	 *  @param edit The undoable edit
	 */
	@java.lang.SuppressWarnings("UnusedDeclaration")
	public void addUndoableEdit(javax.swing.undo.UndoableEdit edit) {
	}

	/**
	 *  We overwrite this method to update the token marker state immediately so that any event listeners get a
	 *  consistent token marker.
	 */
	@java.lang.Override
	protected void fireInsertUpdate(javax.swing.event.DocumentEvent evt) {
	}

	/**
	 *  We overwrite this method to update the token marker state immediately so that any event listeners get a
	 *  consistent token marker.
	 */
	@java.lang.Override
	protected void fireRemoveUpdate(javax.swing.event.DocumentEvent evt) {
	}

	public static int convertLineBreaks(String text, StringBuffer buffer) {
	}

	public static int convertLineBreaks(String text, StringBuffer buffer, String newLineBreak) {
	}

	public char charAt(int offset) {
	}

	@java.lang.Override
	protected void removeUpdate(javax.swing.text.AbstractDocument.DefaultDocumentEvent changed) {
	}

	protected void fireRemovingUpdate(javax.swing.event.DocumentEvent evt) {
	}

	public int getLookupBufferSize() {
	}

	public void setLookupBufferSize(int lookupBufferSize) {
	}

	public int findNext(String[] s, int fromIndex, int toIndex, boolean caseSensitive) {
	}

	public int findPrevious(String[] s, int fromIndex, int toIndex, boolean caseSensitive) {
	}

	public boolean isOffsetLoaded(int offset) {
	}

	public boolean isLineLoaded(int line) {
	}

	public int getLineCount() {
	}

	public int getLineStartOffset(int line) {
	}

	public int getLineEndOffset(int line) {
	}

	public int getLineLength(int line) {
	}

	protected class MyUndoableEditListener {


		protected SyntaxDocument.MyUndoableEditListener() {
		}

		public void undoableEditHappened(javax.swing.event.UndoableEditEvent e) {
		}
	}
}
