/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  Class with several utility functions used by the <code>CodeEditor</code>.
 * 
 *  @author Slava Pestov
 */
public class TextUtils {

	public TextUtils() {
	}

	public static int findPreviousOpenBracket(javax.swing.text.Document doc, int offset) {
	}

	/**
	 *  Returns the offset of the bracket matching the one at the
	 *  specified offset of the document, or -1 if the bracket is
	 *  unmatched (or if the character is not a bracket).
	 * 
	 *  @param doc    The document
	 *  @param offset The offset
	 *  @return the offset of the matching bracket in the doc. -1 if no matching bracket found.
	 *  @throws BadLocationException If an out-of-bounds access
	 *                               was attempted on the document text
	 */
	public static int findMatchingBracket(javax.swing.text.Document doc, int offset) {
	}

	/**
	 *  Locates the start of the word at the specified position.
	 * 
	 *  @param line      The text
	 *  @param pos       The position
	 *  @param noWordSep Characters that are non-alphanumeric, but
	 *                   should be treated as word characters anyway
	 *  @return the index of the first letter of the word.
	 */
	public static int findWordStart(String line, int pos, String noWordSep) {
	}

	/**
	 *  Locates the start of the word at the specified position.
	 * 
	 *  @param line             The text
	 *  @param pos              The position
	 *  @param noWordSep        Characters that are non-alphanumeric, but
	 *                          should be treated as word characters anyway
	 *  @param joinNonWordChars Treat consecutive non-alphanumeric
	 *                          characters as one word
	 *  @return the index of the first letter of the word.
	 */
	public static int findWordStart(String line, int pos, String noWordSep, boolean joinNonWordChars) {
	}

	/**
	 *  Locates the start of the word at the specified position.
	 * 
	 *  @param line             The text
	 *  @param pos              The position
	 *  @param noWordDelimiters Characters that are non-alphanumeric, but
	 *                          should be treated as word characters anyway
	 *  @param joinNonWordChars Treat consecutive non-alphanumeric
	 *                          characters as one word
	 *  @param eatWhitespace    Include whitespace at start of word
	 *  @return the index of the first letter of the word.
	 */
	public static int findWordStart(String line, int pos, String noWordDelimiters, boolean joinNonWordChars, boolean eatWhitespace) {
	}

	/**
	 *  Locates the end of the word at the specified position.
	 * 
	 *  @param line             The text
	 *  @param pos              The position
	 *  @param noWordDelimiters Characters that are non-alphanumeric, but
	 *                          should be treated as word characters anyway
	 *  @return the index of the last letter of the word.
	 */
	public static int findWordEnd(String line, int pos, String noWordDelimiters) {
	}

	/**
	 *  Locates the end of the word at the specified position.
	 * 
	 *  @param line             The text
	 *  @param pos              The position
	 *  @param noWordDelimiters Characters that are non-alphanumeric, but
	 *                          should be treated as word characters anyway
	 *  @param joinNonWordChars Treat consecutive non-alphanumeric
	 *                          characters as one word
	 *  @return the index of the last letter of the word.
	 */
	public static int findWordEnd(String line, int pos, String noWordDelimiters, boolean joinNonWordChars) {
	}

	/**
	 *  Locates the end of the word at the specified position.
	 * 
	 *  @param line             The text
	 *  @param pos              The position
	 *  @param noWordDelimiters Characters that are non-alphanumeric, but
	 *                          should be treated as word characters anyway
	 *  @param joinNonWordChars Treat consecutive non-alphanumeric
	 *                          characters as one word
	 *  @param eatWhitespace    Include whitespace at end of word
	 *  @return the index of the last letter of the word.
	 */
	public static int findWordEnd(String line, int pos, String noWordDelimiters, boolean joinNonWordChars, boolean eatWhitespace) {
	}

	public static String getLeadingWhitespace(String line) {
	}

	/**
	 *  Creates a string of white space with the specified length.<p>
	 *  <p/>
	 *  To get a whitespace string tuned to the current buffer's
	 *  settings, call this method as follows:
	 *  <p/>
	 *  <pre>myWhitespace = MiscUtilities.createWhiteSpace(myLength,
	 *      (buffer.getBooleanProperty("noTabs") ? 0
	 *      : buffer.getTabSize()));</pre>
	 * 
	 *  @param len     The length
	 *  @param tabSize The tab size, or 0 if tabs are not to be used
	 *  @param replaceTabWithSpaces the flag indicating if it will use space instead of tab
	 *  @param start   The start offset, for tab alignment
	 *  @return the created string.
	 */
	public static String createWhiteSpace(int len, int tabSize, boolean replaceTabWithSpaces, int start) {
	}

	/**
	 *  Creates a string of white space with the specified length.<p>
	 *  <p/>
	 *  To get a whitespace string tuned to the current buffer's
	 *  settings, call this method as follows:
	 *  <p/>
	 *  <pre>myWhitespace = TextUtils.createWhiteSpace(myLength,
	 *      (buffer.getBooleanProperty("noTabs") ? 0
	 *      : buffer.getTabSize()));</pre>
	 * 
	 *  @param len     The length
	 *  @param tabSize The tab size, or 0 if tabs are not to be used
	 *  @param replaceTabWithSpaces the flag indicating if it will use space instead of tab
	 *  @return the created string.
	 */
	public static String createWhiteSpace(int len, int tabSize, boolean replaceTabWithSpaces) {
	}

	public static String getLineBreak(int lineBreakType) {
	}

	public static boolean isBracket(char c) {
	}
}
