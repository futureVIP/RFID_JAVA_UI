/**
 *  The package contains classes for code folding for JIDE Code Editor product.
 */
package com.jidesoft.editor.folding;


/**
 *  The interface to represent the code folding information.
 */
public interface FoldingModel {

	/**
	 *  Adds a folding span to FoldingModel.
	 *  {@link FoldingSpanEvent#FOLDING_SPAN_ADDED} will be fired.
	 * 
	 *  @param startOffset  the start offset, inclusive
	 *  @param endOffset    the end offset, exclusive
	 *  @param description  the description of the folding span
	 *  @return the folding span that is just added.
	 */
	public FoldingSpan addFoldingSpan(int startOffset, int endOffset, String description);

	/**
	 *  Removes a folding span that was added before.
	 *  {@link FoldingSpanEvent#FOLDING_SPAN_REMOVED} will be fired if the folding span is removed
	 *  successfully.
	 * 
	 *  @param span the folding span
	 *  @return true if the folding span is removed. If the folding span doesn't exist, it will return false.
	 */
	public boolean removeFoldingSpan(FoldingSpan span);

	/**
	 *  Removes all folding spans that were added before. No events will be fired.
	 */
	public void removeAllFoldingSpans();

	/**
	 *  Checks if the folding model is in adjusting model.
	 * 
	 *  @return true if the folding model is in adjusting mode. Otherwise false.
	 */
	public boolean isAdjusting();

	/**
	 *  Sets the folding model to or from the adjusting mode.
	 * 
	 *  @param adjusting the flag
	 */
	public void setAdjusting(boolean adjusting);

	/**
	 *  When a folding span start or end offset, call this method to tell the folding model.
	 *  However if you are using DefaultFoldingSpan, there is no need for calling it because DefaultFoldingSpan
	 *  will call it automatically.
	 * 
	 *  @param span the folding span
	 */
	public void foldingSpanUpdated(FoldingSpan span);

	/**
	 *  Gets all the folding spans.
	 * 
	 *  @return all the folding spans.
	 */
	public FoldingSpan[] getFoldingSpans();

	/**
	 *  Enables or disables this folding model.
	 * 
	 *  @param flag the flag
	 */
	public void setEnabled(boolean flag);

	/**
	 *  Checks if the folding model is enabled.
	 * 
	 *  @return true if the folding model is enabled. Otherwise false.
	 */
	public boolean isEnabled();

	/**
	 *  Expands the folding span.
	 * 
	 *  @param span the folding span
	 */
	public void expandFoldingSpan(FoldingSpan span);

	/**
	 *  Collapses the folding span.
	 * 
	 *  @param span the folding span
	 */
	public void collapseFoldingSpan(FoldingSpan span);

	/**
	 *  Expands all the foldings.
	 */
	public void expandAll();

	/**
	 *  Collapses all the foldings.
	 */
	public void collapseAll();

	/**
	 *  Add a listener to the list that's notified each time a change
	 *  to the line marker occurs.
	 * 
	 *  @param l the FoldingSpanListener
	 */
	public void addFoldingSpanListener(FoldingSpanListener l);

	/**
	 *  Remove a listener from the list that's notified each time a
	 *  change to the line marker occurs.
	 * 
	 *  @param l the FoldingSpanListener
	 *  @see #addFoldingSpanListener
	 */
	public void removeFoldingSpanListener(FoldingSpanListener l);

	/**
	 *  Returns an array of all the <code>FoldingSpanListener</code>s added
	 *  to this FoldingModel with addFoldingSpanListener().
	 * 
	 *  @return all of the <code>FoldingSpanListener</code>s added or an empty
	 *          array if no listeners have been added
	 */
	public FoldingSpanListener[] getFoldingSpanListeners();
}
