/**
 *  The package contains classes for code folding for JIDE Code Editor product.
 */
package com.jidesoft.editor.folding;


/**
 *  A event to represent a change in the folding model.
 */
public class FoldingSpanEvent extends java.util.EventObject {

	/**
	 *  A folding span is added. The getFoldingSpan() method will give the folding span that is just added.
	 */
	public static final int FOLDING_SPAN_ADDED = 0;

	/**
	 *  A folding span is removed. The getFoldingSpan() method will give the folding span that is just removed.
	 */
	public static final int FOLDING_SPAN_REMOVED = 1;

	/**
	 *  A folding span is updated. The getFoldingSpan() method will give the folding span that is just updated.
	 */
	public static final int FOLDING_SPAN_UPDATED = 2;

	/**
	 *  A folding span is expanded. The getFoldingSpan() method will give the folding span that is just expanded.
	 */
	public static final int FOLDING_SPAN_EXPANDED = 3;

	/**
	 *  A folding span is collapsed. The getFoldingSpan() method will give the folding span that is just collapsed.
	 */
	public static final int FOLDING_SPAN_COLLAPSED = 4;

	/**
	 *  This event is used to signal the folding model starts to adjust. There should be more events to indicate the
	 *  changes but they will be all adjusting events until a FOLDING_SPAN_END_ADJUSTING event is received. In this
	 *  event, getFoldingSpan() is always null and isAdjusting is always true.
	 */
	public static final int FOLDING_SPAN_START_ADJUSTING = 5;

	/**
	 *  This event is used to signal the folding model is done adjusting. In this event, getFoldingSpan() is always null
	 *  and isAdjusting is always false.
	 */
	public static final int FOLDING_SPAN_END_ADJUSTING = 6;

	public FoldingSpanEvent(Object source, FoldingSpan foldingSpan, int type, boolean adjusting) {
	}

	public FoldingSpan getFoldingSpan() {
	}

	public boolean isAdjusting() {
	}

	public int getType() {
	}

	public static String getTypeName(int type) {
	}

	@java.lang.Override
	public String toString() {
	}
}
