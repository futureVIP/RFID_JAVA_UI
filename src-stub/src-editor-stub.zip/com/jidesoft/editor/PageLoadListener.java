/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


public interface PageLoadListener extends java.util.EventListener {
 {

	public void pageLoadingStart(PageLoadEvent e);

	public void pageLoaded(PageLoadEvent e);

	public void pageLoadFailed(PageLoadEvent e);
}
