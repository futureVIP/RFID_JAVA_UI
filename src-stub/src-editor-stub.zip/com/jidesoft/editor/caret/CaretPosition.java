/**
 *  The package contains classes for caret event and caret model for JIDE Code Editor product.
 */
package com.jidesoft.editor.caret;


/**
 *  This class is used to represent a caret position as in CodeEditor.
 *  It has two fields, line and column.
 */
public class CaretPosition implements Comparable {
 {

	/**
	 *  This line of the caret.
	 */
	public final int line;

	/**
	 *  The column of the caret.
	 */
	public final int column;

	public CaretPosition(int line, int column) {
	}

	@java.lang.Override
	public boolean equals(Object o) {
	}

	@java.lang.Override
	public int hashCode() {
	}

	@java.lang.Override
	public String toString() {
	}

	public String paramString() {
	}

	/**
	 *  Compares this <code>CaretPosition</code> to another <code>CaretPosition</code>.
	 * 
	 *  @param p the CaretPosition to compare to.
	 *  @return the difference between the line of the two positions if the line of the two positions are different. Otherwise,
	 *          it will return the column difference.
	 */
	public int compareTo(CaretPosition p) {
	}
}
