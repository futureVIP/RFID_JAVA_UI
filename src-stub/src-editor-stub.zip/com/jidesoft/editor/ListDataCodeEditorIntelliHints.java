/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>ListDataCodeEditorIntelliHints</code> is a concrete implementation of {@link com.jidesoft.hints.IntelliHints}. It
 *  provides hints from a known list of data. It is similar to auto complete text field except the list will be filtered
 *  depending on what user types in so far.
 */
public class ListDataCodeEditorIntelliHints extends AbstractListCodeEditorIntelliHints {

	/**
	 *  Constructor.
	 * 
	 *  @param codeEditor     the CodeEditor
	 *  @param completionList the list to be used
	 */
	public ListDataCodeEditorIntelliHints(CodeEditor codeEditor, java.util.List completionList) {
	}

	/**
	 *  Constructor.
	 * 
	 *  @param codeEditor     the CodeEditor
	 *  @param completionList the list to be used
	 */
	public ListDataCodeEditorIntelliHints(CodeEditor codeEditor, Object[] completionList) {
	}

	/**
	 *  Gets the list of hints.
	 * 
	 *  @return the list of hints.
	 */
	public java.util.List getCompletionList() {
	}

	/**
	 *  Sets a new list of hints.
	 * 
	 *  @param completionList a new list of hints.
	 */
	public void setCompletionList(java.util.List completionList) {
	}

	/**
	 *  Sets a new list of hints.
	 * 
	 *  @param completionList a new array of hints.
	 */
	public void setCompletionList(Object[] completionList) {
	}

	public boolean updateHints(Object context) {
	}

	/**
	 *  Compares the context with the object in the completion list.
	 * 
	 *  @param context the context returned from {@link #getContext()} method.
	 *  @param o       the object in the completion list.
	 *  @return true if the context matches with the object. Otherwise false.
	 */
	protected boolean compare(Object context, Object o) {
	}

	/**
	 *  Checks if it used case sensitive search. By default it's false.
	 * 
	 *  @see #setCaseSensitive(boolean)
	 *  @return if it's case sensitive.
	 */
	public boolean isCaseSensitive() {
	}

	/**
	 *  Sets the case sensitive flag. By default, it's false meaning it's a case insensitive search.
	 * 
	 *  @param caseSensitive true or false.
	 */
	public void setCaseSensitive(boolean caseSensitive) {
	}
}
