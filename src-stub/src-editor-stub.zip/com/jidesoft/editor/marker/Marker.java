/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>Marker</code> represents a range of text in code editor used by the {@link MarkerModel}. It has a start offset
 *  and an end offset. By default, there are two types of markers - error and warning. But you can always define your own
 *  types of markers. You can also associate a tooltip with a marker. The tooltip will be shown when user mouse moves
 *  over the marker stripe.
 */
public class Marker {

	/**
	 *  Problem which prevents the tool's normal completion.
	 */
	public static final int TYPE_ERROR = 0;

	/**
	 *  Problem which does not usually prevent the tool from completing normally.
	 */
	public static final int TYPE_WARNING = 1;

	/**
	 *  Problem similar to a warning, but is mandated by the tool's specification.  For example, the Java&trade; Language
	 *  Specification, 3rd Ed. mandates warnings on certain unchecked operations and the use of deprecated methods.
	 */
	public static final int TYPE_MANDATORY_WARNING = 2;

	/**
	 *  Informative message from the tool.
	 */
	public static final int TYPE_NOTE = 3;

	/**
	 *  Diagnostic which does not fit within the other kinds.
	 */
	public static final int TYPE_OTHER = 4;

	/**
	 *  The custom marker type start at 0x100, so that you could set a style for those marker types.
	 */
	public static final int TYPE_CUSTOM_STYLE = 128;

	public static final String PROPERTY_ENABLED = "enabled";

	public static final String PROPERTY_START_OFFSET = "startOffset";

	public static final String PROPERTY_END_OFFSET = "endOffset";

	public static final String PROPERTY_TYPE = "type";

	public static final String PROPERTY_TOOLTIP_TEXT = "tooltipText";

	/**
	 *  Creates a <code>Marker</code>.
	 * 
	 *  @param startOffset the start offset in code editor
	 *  @param endOffset   the end offset in code editor
	 *  @param type        the marker type
	 *  @param tooltip     the tooltip to show
	 */
	public Marker(int startOffset, int endOffset, int type, String tooltip) {
	}

	/**
	 *  Gets the start offset.
	 * 
	 *  @return the start offset.
	 */
	public int getStartOffset() {
	}

	/**
	 *  Sets the start offset.
	 * 
	 *  @param startOffset the start offset
	 */
	public void setStartOffset(int startOffset) {
	}

	/**
	 *  Gets the end offset.
	 * 
	 *  @return the end offset.
	 */
	public int getEndOffset() {
	}

	/**
	 *  Sets the end offset.
	 * 
	 *  @param endOffset the end offset
	 */
	public void setEndOffset(int endOffset) {
	}

	/**
	 *  Gets the type.
	 * 
	 *  @return the type.
	 */
	public int getType() {
	}

	/**
	 *  Sets the type.
	 * 
	 *  @param type the type
	 */
	public void setType(int type) {
	}

	/**
	 *  Gets the tooltip text.
	 * 
	 *  @return the tooltip text.
	 */
	public String getToolTipText() {
	}

	/**
	 *  Sets the tooltip text.
	 * 
	 *  @param tooltipText the tooltip text
	 */
	public void setToolTipText(String tooltipText) {
	}

	/**
	 *  Gets the flag if the marker is enabled.
	 * 
	 *  @return true if the marker is enabled. Otherwise false.
	 *  @see #setEnabled(boolean)
	 */
	public boolean isEnabled() {
	}

	/**
	 *  Sets the flag indicating if the marker is enabled.
	 *  <p/>
	 *  By default, the value is true.
	 * 
	 *  @param enabled the flag
	 */
	public void setEnabled(boolean enabled) {
	}

	/**
	 *  Adds a PropertyChangeListener to the listener list.
	 *  <p>
	 *  If <code>listener</code> is <code>null</code>,
	 *  no exception is thrown and no action is performed.
	 * 
	 *  @param    listener  the property change listener to be added
	 * 
	 *  @see #removePropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 */
	public synchronized void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Removes a PropertyChangeListener from the listener list. This method
	 *  should be used to remove PropertyChangeListeners that were registered
	 *  for this class.
	 *  <p>
	 *  If listener is null, no exception is thrown and no action is performed.
	 * 
	 *  @param listener the PropertyChangeListener to be removed
	 * 
	 *  @see #addPropertyChangeListener
	 *  @see #getPropertyChangeListeners
	 */
	public synchronized void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
	}

	/**
	 *  Returns an array of all the property change listeners
	 *  registered on this class.
	 * 
	 *  @return all of this class's <code>PropertyChangeListener</code>s
	 *          or an empty array if no property change
	 *          listeners are currently registered
	 * 
	 *  @see      #addPropertyChangeListener
	 *  @see      #removePropertyChangeListener
	 *  @see      java.beans.PropertyChangeSupport#getPropertyChangeListeners
	 */
	public synchronized java.beans.PropertyChangeListener[] getPropertyChangeListeners() {
	}

	/**
	 *  Support for reporting property changes for all properties.
	 *  This method can be called when a  property has changed and it will
	 *  send the appropriate PropertyChangeEvent to any registered
	 *  PropertyChangeListeners.
	 * 
	 *  @param propertyName the property whose value has changed
	 *  @param oldValue the property's previous value
	 *  @param newValue the property's new value
	 */
	protected void firePropertyChange(String propertyName, Object oldValue, Object newValue) {
	}

	@java.lang.Override
	public String toString() {
	}
}
