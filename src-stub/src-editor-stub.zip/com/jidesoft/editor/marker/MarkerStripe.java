/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerStripe</code> is a panel to display all the markers in a marker model. The paint of each stripe is done
 *  by a class called {@link MarkerStripePainter}. By default, {@link DefaultMarkerStripePainter} is used. You can always
 *  set your own painter by calling {@link #setPainter(MarkerStripePainter)}.
 */
public class MarkerStripe extends javax.swing.JPanel implements java.awt.event.MouseListener, java.awt.event.MouseMotionListener {
 {

	public MarkerStripe(com.jidesoft.editor.CodeEditor codeEditor, MarkerArea markerArea) {
	}

	/**
	 *  Gets the painter.
	 * 
	 *  @return the painter.
	 */
	public MarkerStripePainter getPainter() {
	}

	/**
	 *  Sets the painters.
	 * 
	 *  @param painter the marker stripe painter
	 */
	public void setPainter(MarkerStripePainter painter) {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	/**
	 *  Gets the markers at the y positions. Since each y position could represent a range of lines in code editor, thus
	 *  there could be multiple markers in that line range. That's why method returns a list of Markers. This method is
	 *  protected so subclass can use it get the markers then paint them.
	 * 
	 *  @param y the y position
	 *  @return the markers at the y positions.
	 */
	protected java.util.List getMarkersAt(int y) {
	}

	protected void paintLineMarker(java.awt.Graphics g, Marker marker) {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	protected static int lineToY(int line, int totalLines, int height, int lineHeight) {
	}

	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	public void mouseMoved(java.awt.event.MouseEvent e) {
	}

	public static void main(String[] args) {
	}
}
