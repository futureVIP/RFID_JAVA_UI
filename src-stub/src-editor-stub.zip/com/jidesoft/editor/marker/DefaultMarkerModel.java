/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


public class DefaultMarkerModel implements MarkerModel, java.beans.PropertyChangeListener {
 {

	protected javax.swing.event.EventListenerList _listenerList;

	public DefaultMarkerModel() {
	}

	/**
	 *  Gets the list of markers. The list returned from this method should be unmodifiable.
	 * 
	 *  @return the list of markers.
	 */
	public synchronized java.util.List getMarkers() {
	}

	/**
	 *  Gets the list of markers in the specified range.
	 * 
	 *  @param startOffset the start offset
	 *  @param endOffset   the end offset
	 *  @return Gets the markers in the specified range.
	 */
	public synchronized java.util.List getMarkersAt(int startOffset, int endOffset) {
	}

	/**
	 *  Checks if the marker model is adjusting.
	 * 
	 *  @return true if it is adjusting.
	 */
	public synchronized boolean isAdjusting() {
	}

	/**
	 *  Sets the marker model to adjusting mode. If it's in adjusting mode, all marker events fired will have isAdjusting
	 *  to be true.
	 * 
	 *  @param adjusting true or false.
	 */
	public synchronized void setAdjusting(boolean adjusting) {
	}

	/**
	 *  Adds a marker.
	 * 
	 *  @param startOffset the start offset
	 *  @param endOffset   the end offset
	 *  @param type        the type of the marker
	 *  @param tooltip     the tooltip of the marker
	 *  @return the marker just added.
	 */
	public synchronized Marker addMarker(int startOffset, int endOffset, int type, String tooltip) {
	}

	/**
	 *  Removes all markers.
	 */
	public synchronized void clearMarkers() {
	}

	/**
	 *  Removes a previous added marker.
	 * 
	 *  @param marker the marker
	 *  @return true if the marker is removed. Otherwise the marker doesn't exist.
	 */
	public synchronized boolean removeMarker(Marker marker) {
	}

	/**
	 *  Tells the marker model that this marker has been updated.
	 * 
	 *  @param marker the marker
	 */
	public synchronized void updateMarker(Marker marker) {
	}

	protected void fireMarkerChanged(Marker marker, int type, boolean isAdjusting) {
	}

	/**
	 *  Add a listener to the list that's notified each time a change to the line marker occurs.
	 * 
	 *  @param l the LineMarkerListener
	 */
	public void addMarkerListener(MarkerListener l) {
	}

	/**
	 *  Remove a listener from the list that's notified each time a change to the line marker occurs.
	 * 
	 *  @param l the LineMarkerListener
	 *  @see #addMarkerListener
	 */
	public void removeMarkerListener(MarkerListener l) {
	}

	/**
	 *  Returns an array of all the <code>MarkerListener</code>s added to this MarkerModel with addMarkerListener().
	 * 
	 *  @return all of the <code>MarkerListener</code>s added or an empty array if no listeners have been added
	 */
	public MarkerListener[] getMarkerListeners() {
	}

	@java.lang.Override
	public void propertyChange(java.beans.PropertyChangeEvent evt) {
	}
}
