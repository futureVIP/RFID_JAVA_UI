/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>MarkerArea</code> is an area next to code editor to display markers for error, warning, or whatever information in the code you would like to display. There are two parts in a
 *  <code>MarkerArea</code>. The top is an area called {@link MarkerEye}. It displays the current status of the code editor. You can use {@link MarkerEyePainter} to customize how to paint it. For
 *  example, if there are errors in the code, you can display a red box to indicate something is wrong. Or display a yellow box if there are just warnings. If everything is OK, display a green box. You
 *  can even display an icon if you want using {@link MarkerEyePainter}. The second part is called {@link MarkerStripe}. It displays stripes to indicate those errors or warnings or any other
 *  information. Each stripe is associated with a range of code and a tooltip for the message. For example, an error stripe usually has a tooltip of why there is an error. {@link MarkerStripePainter}
 *  is the painter class to paint the stripe.
 *  <p/>
 *  The whole MarkerArea is driven by a model class called {@link MarkerModel}. Each code editor has a <code>MarkerModel</code> that stores all the markers. You can use code to add or remove markers to
 *  this model. <code>MarkerArea</code> will display them immediately when something is changed.
 * 
 *  @see MarkerEye
 *  @see MarkerStripe
 *  @see MarkerModel
 *  @see DefaultMarkerModel
 */
public class MarkerArea extends javax.swing.JPanel {

	public static final int MODE_FINE = 0;

	public static final int MODE_WARNING = 100;

	public static final int MODE_ERROR = 200;

	public static final java.awt.Color DEFAULT_FINE_COLOR;

	public static final java.awt.Color DEFAULT_WARNING_COLOR;

	public static final java.awt.Color DEFAULT_ERROR_COLOR;

	public static final java.awt.Color DEFAULT_INSPECTING_COLOR;

	public MarkerArea(com.jidesoft.editor.CodeEditor codeEditor) {
	}

	/**
	 *  Creates a default MarkerStripe. Subclass can override this method to create your own MarkerStripe subclass.
	 * 
	 *  @param codeEditor the code editor.
	 *  @return the MarkerStripe.
	 */
	protected MarkerStripe createMarkerStripe(com.jidesoft.editor.CodeEditor codeEditor) {
	}

	/**
	 *  Creates a default MarkerEye. Subclass can override this method to create your own MarkerEye subclass.
	 * 
	 *  @param codeEditor the code editor.
	 *  @return the MarkerEye.
	 */
	protected MarkerEye createMarkerEye(com.jidesoft.editor.CodeEditor codeEditor) {
	}

	/**
	 *  Gets the MarkerStripe.
	 * 
	 *  @return the MarkerStripe.
	 */
	public MarkerStripe getMarkerStripe() {
	}

	/**
	 *  Gets the MarkerEye.
	 * 
	 *  @return the MarkerEye.
	 */
	public MarkerEye getMarkerEye() {
	}

	public MarkerEyePainter getEyePainter() {
	}

	public void setEyePainter(MarkerEyePainter eyePainter) {
	}

	public MarkerStripePainter getStripePainter() {
	}

	public void setStripePainter(MarkerStripePainter stripePainter) {
	}

	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor codeEditor) {
	}

	public boolean isInspecting() {
	}

	public void setInspecting(boolean inspecting) {
	}

	public int getMode() {
	}

	public void setMode(int mode) {
	}

	public void applyMinimumMode() {
	}

	public void requireMinimumMode(int minimum) {
	}

	public int getVisualLineCount() {
	}

	public java.awt.Color getColor(int type) {
	}

	/**
	 *  Update the height of the marker area according to the visibility of horizontal scroll bar in CodeEditor.
	 *  <p/>
	 *  In most cases, you don't have to invoke this method. This method is to make the height of the marker area in line with the CodeEditor.
	 */
	public void updateMarkerAreaHeight() {
	}
}
