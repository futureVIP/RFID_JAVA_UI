/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  An interface to paint the marker stripes.
 */
public interface MarkerStripePainter {

	/**
	 *  Paints the marker stripe.
	 *  <p/>
	 *  Please note, you don't need to reset the color used in this paint method
	 *  because we will reset it after the paint() of all painters are called.
	 * 
	 *  @param markerArea
	 *  @param g
	 *  @param marker
	 *  @param rect
	 */
	public void paint(MarkerArea markerArea, java.awt.Graphics g, Marker marker, java.awt.Rectangle rect);
}
