/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  A painter interface to paint the marker eye area.
 */
public interface MarkerEyePainter {

	/**
	 *  Paints the marker eye.
	 * 
	 *  @param markerArea
	 *  @param g
	 *  @param rect
	 */
	public void paint(MarkerArea markerArea, java.awt.Graphics g, java.awt.Rectangle rect);

	/**
	 *  Gets the tooltip text.
	 * 
	 *  @param markerArea
	 *  @return the tooltip text.
	 */
	public String getToolTipText(MarkerArea markerArea);
}
