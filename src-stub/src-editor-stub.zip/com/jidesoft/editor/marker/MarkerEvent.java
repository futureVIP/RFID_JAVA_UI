/**
 *  The package contains classes for marker area for JIDE Code Editor product.
 */
package com.jidesoft.editor.marker;


/**
 *  <code>Markerevent</code> is used to notify interested parties that marker has been changed in the
 *  <code>MarkerModel</code>.
 */
public class MarkerEvent extends java.util.EventObject {

	public static final int MARKER_ADDED = 0;

	public static final int MARKER_REMOVED = 1;

	public static final int MARKER_UPDATED = 2;

	/**
	 *  Creates a <code>MarkerEvent</code>.
	 * 
	 *  @param source
	 *  @param marker
	 *  @param type
	 */
	public MarkerEvent(Object source, Marker marker, int type) {
	}

	/**
	 *  Creates a <code>MarkerEvent</code>.
	 * 
	 *  @param source
	 *  @param marker
	 *  @param type
	 *  @param isAdjusting
	 */
	public MarkerEvent(Object source, Marker marker, int type, boolean isAdjusting) {
	}

	/**
	 *  Gets the marker that is changed.
	 * 
	 *  @return the marker.
	 */
	public Marker getMarker() {
	}

	/**
	 *  Checks if the change is part of several marker change events. If you want to repaint the whole marker area, you
	 *  might want to hold the repaint until isAdjusting returns false.
	 * 
	 *  @return true or false.
	 */
	public boolean isAdjusting() {
	}

	/**
	 *  Gets the type of the <code>MarkerEvent</code>.
	 * 
	 *  @return the type.
	 */
	public int getType() {
	}

	public static String getTypeName(int type) {
	}

	@java.lang.Override
	public String toString() {
	}
}
