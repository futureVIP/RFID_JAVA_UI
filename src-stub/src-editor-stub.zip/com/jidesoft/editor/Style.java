/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  <code>Style</code> is a markup interface for styles.
 */
public interface Style {
}
