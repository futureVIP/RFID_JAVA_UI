/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  <code>BraceMatchingMarginPainter</code> is a margin painter that can paint the brace matching information on any
 *  margin. Brace matching is a line on the margin that draw from the start position of a brace to the matching end
 *  brace. It will be drawn only if the caret is placed on the begin brace or the end brace.
 */
public class BraceMatchingMarginPainter extends AbstractMarginPainter {

	public BraceMatchingMarginPainter() {
	}

	@java.lang.Override
	public int getLayer() {
	}

	public void paintMargin(java.awt.Graphics g, com.jidesoft.editor.CodeEditor editor) {
	}
}
