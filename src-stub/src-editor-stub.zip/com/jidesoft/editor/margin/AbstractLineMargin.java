/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  An abstract class which is the base of any line margins such as <code>LineNumberMargin</code>. It implements {@link
 *  #paintMargin(java.awt.Graphics)} in {@link AbstractMargin} and added a new abstract method {@link
 *  #paintLineMargin(java.awt.Graphics,java.awt.Rectangle,int)} to paint the margin for a particular line. In addition,
 *  it allows you to provide a tooltip for each line by implementing {@link #getToolTipText(int)}.
 */
public abstract class AbstractLineMargin extends AbstractMargin implements com.jidesoft.editor.folding.FoldingSpanListener, java.awt.event.MouseListener, java.awt.event.MouseMotionListener {
 {

	protected java.util.List _lineMarginPainters;

	public AbstractLineMargin(com.jidesoft.editor.CodeEditor editor) {
	}

	public void paintMargin(java.awt.Graphics g) {
	}

	public void addLineMarginPainter(LineMarginPainter painter) {
	}

	public void removeLineMarginPainter(LineMarginPainter painter) {
	}

	protected java.util.List getLineMarginPainters() {
	}

	/**
	 *  Returns the tooltip location in this component's coordinate system. If <code>null</code> is returned, Swing will
	 *  choose a location. The default implementation returns <code>null</code>.
	 * 
	 *  @param event the <code>MouseEvent</code> that caused the <code>ToolTipManager</code> to show the tooltip
	 *  @return always returns <code>null</code>
	 */
	@java.lang.Override
	public java.awt.Point getToolTipLocation(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Returns the string to be used as the tooltip for <i>event</i>. By default this returns any string set using
	 *  <code>setToolTipText</code>.  If a component provides more extensive API to support differing tooltips at
	 *  different locations, this method should be overridden.
	 * 
	 *  @param event the mouse event.
	 */
	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Paint line margin.
	 * 
	 *  @param g    the Graphics instance
	 *  @param rect the rectangle to paint the line margin
	 *  @param line the view line index to be painted
	 */
	public abstract void paintLineMargin(java.awt.Graphics g, java.awt.Rectangle rect, int line) {
	}

	/**
	 *  Gets the tool tip text from the view line index.
	 * 
	 *  @param line the view line index
	 *  @return the tool tip text.
	 */
	public abstract String getToolTipText(int line) {
	}

	/**
	 *  Installs listeners on code editor.
	 */
	@java.lang.Override
	protected void installListenersOnEditor() {
	}

	/**
	 *  Uninstalls listeners on code editor.
	 */
	@java.lang.Override
	protected void uninstallListenersOnEditor() {
	}

	public void foldingSpanChanged(com.jidesoft.editor.folding.FoldingSpanEvent e) {
	}

	/**
	 *  Any mouse click will select the line in the code editor.
	 * 
	 *  @param e the mouse event
	 */
	public void mouseClicked(java.awt.event.MouseEvent e) {
	}

	protected void selectLine(int line) {
	}

	public void mousePressed(java.awt.event.MouseEvent e) {
	}

	public void mouseReleased(java.awt.event.MouseEvent e) {
	}

	public void mouseEntered(java.awt.event.MouseEvent e) {
	}

	public void mouseExited(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public void mouseDragged(java.awt.event.MouseEvent e) {
	}

	@java.lang.Override
	public void mouseMoved(java.awt.event.MouseEvent e) {
	}
}
