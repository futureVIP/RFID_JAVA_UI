/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  <tt>AbstractMargin</tt> is a component that usually appears on the left side of a code editor. It
 *  can be used to display information related to the code editor such as line number, bookmarks,
 *  breakpoints or code folding.
 *  <p/>
 *  This is an abstract class. Two methods are abstract. They are {@link
 *  #paintMargin(java.awt.Graphics)} and {@link #getPreferredWidth()}.
 *  <p/>
 *  There are two types of Margin. One is {@link AbstractLineMargin}. The reason we call it line
 *  margin is because the marker for this kind of margin is painted according to the line in the code
 *  editor.
 */
public abstract class AbstractMargin extends javax.swing.JComponent implements Margin {
 {

	protected com.jidesoft.editor.CodeEditor _editor;

	protected java.awt.Dimension _preferredSize;

	protected java.util.List _marginPainters;

	protected AbstractMargin() {
	}

	public AbstractMargin(com.jidesoft.editor.CodeEditor editor) {
	}

	@java.lang.Override
	public void invalidate() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	protected void paintBackground(java.awt.Graphics g) {
	}

	@java.lang.Override
	public java.awt.Dimension getPreferredSize() {
	}

	public com.jidesoft.editor.CodeEditor getCodeEditor() {
	}

	public void setCodeEditor(com.jidesoft.editor.CodeEditor editor) {
	}

	protected void installListenersOnEditor() {
	}

	protected void uninstallListenersOnEditor() {
	}

	public java.awt.Component getMarginComponent() {
	}

	public void addMarginPainter(MarginPainter painter) {
	}

	public void removeMarginPainter(MarginPainter painter) {
	}

	protected java.util.List getMarginPainters() {
	}
}
