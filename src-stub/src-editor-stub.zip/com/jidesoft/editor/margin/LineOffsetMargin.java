/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  A margin component for line offset.
 */
public class LineOffsetMargin extends AbstractLineMargin implements javax.swing.event.DocumentListener {
 {

	public LineOffsetMargin(com.jidesoft.editor.CodeEditor editor) {
	}

	@java.lang.Override
	public void paintLineMargin(java.awt.Graphics g, java.awt.Rectangle rect, int line) {
	}

	public int getPreferredWidth() {
	}

	@java.lang.Override
	public String getToolTipText(int line) {
	}

	public void insertUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void removeUpdate(javax.swing.event.DocumentEvent e) {
	}

	public void changedUpdate(javax.swing.event.DocumentEvent e) {
	}
}
