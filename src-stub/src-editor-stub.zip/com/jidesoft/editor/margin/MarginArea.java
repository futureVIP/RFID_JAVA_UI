/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  A container for <code>Margin</code>. You can add one or margin
 *  to this area. By default, there is already a <code>MarginArea</code>
 *  on the left side of the <code>CodeEditor</code>. So all you need to
 *  do is to create <code>Margin</code> and add it to this area.
 */
public class MarginArea extends javax.swing.JPanel {

	public MarginArea(com.jidesoft.editor.CodeEditor editor) {
	}

	@java.lang.Override
	public java.awt.Font getFont() {
	}

	@java.lang.Override
	protected void paintComponent(java.awt.Graphics g) {
	}

	public java.awt.Component addMarginComponent(Margin margin) {
	}

	@java.lang.Override
	public void invalidate() {
	}

	public java.awt.Component addMarginComponent(int index, Margin margin) {
	}

	public void removeMarginComponent(Margin margin) {
	}
}
