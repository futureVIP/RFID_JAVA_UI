/**
 *  The package contains classes for margin area for JIDE Code Editor product.
 */
package com.jidesoft.editor.margin;


/**
 *  A painter interface to paint the code folding.
 */
public interface CodeFoldingPainter {

	/**
	 *  Paints the start of the folding.
	 * 
	 *  @param c
	 *  @param g
	 *  @param span
	 *  @param rect
	 *  @param state
	 *  @return return the y value after the start of the folding is paint. paintFoldingLine method will use this y value as the starting point of the line.
	 */
	public int paintFoldingStart(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state);

	/**
	 *  Paints the end of the folding.
	 * 
	 *  @param c
	 *  @param g
	 *  @param span
	 *  @param rect
	 *  @param state
	 *  @return return the y value at where the end of the folding is painted. paintFoldingLine method will use this y value as the ending point of the line.
	 */
	public int paintFoldingEnd(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state);

	/**
	 *  Paints the collapsed folding.
	 * 
	 *  @param c
	 *  @param g
	 *  @param span
	 *  @param rect
	 *  @param state
	 */
	public void paintCollapsedFolding(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state);

	/**
	 *  Paints the expanded folding.
	 * 
	 *  @param c
	 *  @param g
	 *  @param span
	 *  @param rect
	 *  @param state
	 */
	public void paintExpandedFolding(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state);

	/**
	 *  Paints the folding line between the start and the end of the folding.
	 * 
	 *  @param c
	 *  @param g
	 *  @param span
	 *  @param rect
	 *  @param state
	 */
	public void paintFoldingLine(java.awt.Component c, java.awt.Graphics g, com.jidesoft.editor.Span span, java.awt.Rectangle rect, int state);

	/**
	 *  Paints the background of the code folding area. It's for the whole code folding margin, not just for one code folding.
	 * 
	 *  @param c
	 *  @param g
	 *  @param rect
	 */
	public void paintBackground(java.awt.Component c, java.awt.Graphics g, java.awt.Rectangle rect);

	/**
	 *  Gets preferred width.
	 * 
	 *  @return the preferred width.
	 */
	public int getPreferredWidth();
}
