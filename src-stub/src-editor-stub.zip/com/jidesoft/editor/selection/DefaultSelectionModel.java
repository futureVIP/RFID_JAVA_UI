/**
 *  The package contains classes for the selection model for JIDE Code Editor product.
 */
package com.jidesoft.editor.selection;


public class DefaultSelectionModel implements SelectionModel {
 {

	public DefaultSelectionModel(com.jidesoft.editor.CodeEditor editor) {
	}

	public synchronized int getSelectionStart() {
	}

	public synchronized int getSelectionEnd() {
	}

	public synchronized void setSelectionStart(int selectionStart) {
	}

	public synchronized void setSelectionEnd(int selectionEnd) {
	}

	public synchronized int getSelectionStartLine() {
	}

	public synchronized int getSelectionEndLine() {
	}

	public synchronized String getSelectedText() {
	}

	public synchronized void setSelection(int start, int end) {
	}

	public synchronized void clearSelection() {
	}

	public synchronized boolean hasSelection() {
	}

	public synchronized boolean isColumnSelectionMode() {
	}

	public synchronized void setColumnSelectionMode(boolean columnSelectionMode) {
	}

	public synchronized void addSelectionListener(SelectionListener selectionlistener) {
	}

	public synchronized void removeSelectionListener(SelectionListener selectionlistener) {
	}

	public synchronized SelectionListener[] getSelectionListeners() {
	}

	protected void fireSelectionChangeEvent(int oldSelectionStart, int oldSelectionEnd, int newSelectionStart, int newSelectionEnd) {
	}
}
