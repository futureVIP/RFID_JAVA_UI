/**
 *  The package contains classes for the selection model for JIDE Code Editor product.
 */
package com.jidesoft.editor.selection;


/**
 *  An interface to represent the selection in CodeEditor.
 */
public interface SelectionModel {

	/**
	 *  Gets the offset of the selection start.
	 * 
	 *  @return the offset of the selection start.
	 */
	public int getSelectionStart();

	/**
	 *  Gets the offset of the selection end.
	 * 
	 *  @return the offset of the selection end.
	 */
	public int getSelectionEnd();

	/**
	 *  Gets the line number of the selection start.
	 * 
	 *  @return the line number of the selection start.
	 */
	public int getSelectionStartLine();

	/**
	 *  Gets the line number of the selection end.
	 * 
	 *  @return the line number of the selection end.
	 */
	public int getSelectionEndLine();

	/**
	 *  Gets the selected text.
	 * 
	 *  @return the selected text.
	 */
	public String getSelectedText();

	/**
	 *  Sets the selection.
	 * 
	 *  @param start
	 *  @param end
	 */
	public void setSelection(int start, int end);

	/**
	 *  Clears the selection.
	 */
	public void clearSelection();

	/**
	 *  Checks if the <code>SelectionModel</code> has any selection.
	 * 
	 *  @return true if it has selection. Otherwise false.
	 */
	public boolean hasSelection();

	/**
	 *  Checks if the <code>SelectionModel</code> is in column selection mode, a.k.a vertical selection.
	 * 
	 *  @return true if in column selection mode.
	 */
	public boolean isColumnSelectionMode();

	/**
	 *  Sets the <code>SelectionModel</code> to column selection mode.
	 * 
	 *  @param columnSelectionMode
	 */
	public void setColumnSelectionMode(boolean columnSelectionMode);

	/**
	 *  Adds a <code>SelectionListener</code> to the <code>SelectionModel</code> to receive any selection change event.
	 * 
	 *  @param selectionListener
	 */
	public void addSelectionListener(SelectionListener selectionListener);

	/**
	 *  Removes the <code>SelectionListener</code> from the <code>SelectionModel</code> that was added before.
	 * 
	 *  @param selectionListener
	 */
	public void removeSelectionListener(SelectionListener selectionListener);

	/**
	 *  Gets all the <code>SelectionListener</code>s added to this <code>SelectionModel</code>.
	 * 
	 *  @return all the <code>SelectionListener</code>s added to this <code>SelectionModel</code>.
	 */
	public SelectionListener[] getSelectionListeners();
}
