/**
 *  The package contains classes for settings panel for JIDE Code Editor product.
 */
package com.jidesoft.editor.settings;


/**
 *  A panel to have the list of available styles.
 */
public class StyleListPanel extends javax.swing.JPanel {

	public StyleListPanel() {
	}

	protected void installComponents() {
	}

	protected void installListeners() {
	}

	public String[] getNames() {
	}

	public void setNames(String[] names) {
	}

	public com.jidesoft.editor.SyntaxStyleSchema getStyles() {
	}

	public void setStyles(com.jidesoft.editor.SyntaxStyleSchema styles) {
	}

	public void saveData() {
	}

	public void loadData() {
	}

	public static void main(String[] args) {
	}
}
