/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  HTML token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: HTMLTokenMarker.java,v 1.34 1999/12/13 03:40:29 sp Exp $
 */
public class HTMLTokenMarker extends TokenMarker {

	public static final byte JAVASCRIPT = 100;

	public HTMLTokenMarker() {
	}

	public HTMLTokenMarker(boolean js) {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}
}
