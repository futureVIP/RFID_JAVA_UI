/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Oracle PL-SQL token marker.
 * 
 *  @author oliver henning
 *  @version $Id: PLSQLTokenMarker.java,v 1.9 1999/12/13 03:40:30 sp Exp $
 */
public class PLSQLTokenMarker extends SQLTokenMarker {

	public PLSQLTokenMarker() {
	}

	public static com.jidesoft.editor.KeywordMap getKeywordMap() {
	}
}
