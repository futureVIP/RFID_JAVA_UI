/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  Java token marker.
 * 
 *  @author Slava Pestov
 *  @version $Id: JavaTokenMarker.java,v 1.5 1999/12/13 03:40:30 sp Exp $
 */
public class JavaTokenMarker extends CTokenMarker {

	public JavaTokenMarker() {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}
}
