/**
 *  The package contains classes for all kinds of token markers for JIDE Code Editor product.
 */
package com.jidesoft.editor.tokenmarker;


/**
 *  VHDL token marker.
 * 
 *  @author Bogdan Mitu
 *  @version $Id: VHDLTokenMarker.java,v 1.1.1.1 2001/08/20 22:31:49 gfx Exp $
 */
public class VHDLTokenMarker extends TokenMarker {

	public static final int AS_IS = 0;

	public static final int LOWER_CASE = 1;

	public static final int UPPER_CASE = 2;

	public VHDLTokenMarker() {
	}

	@java.lang.Override
	public byte markTokensImpl(byte token, javax.swing.text.Segment line, int lineIndex) {
	}

	public static com.jidesoft.editor.KeywordMap getKeywords() {
	}

	public void setKeywordCase(int c) {
	}

	public int getKeywordCase() {
	}

	public void setAllLowerCase(boolean b) {
	}

	public boolean getAllLowerCase() {
	}
}
