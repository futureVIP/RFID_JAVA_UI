/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  An interface defined all kind of constants related to line breaks. <ul> <li>LF: Multics, Unix and Unix-like systems
 *  (GNU/Linux, AIX, Xenix, Mac OS X, FreeBSD, etc.), BeOS, Amiga, RISC OS, and others <li>CR+LF: DEC RT-11 and most
 *  other early non-Unix, non-IBM OSes, CP/M, MP/M, DOS, OS/2, Microsoft Windows, Symbian OS <li>CR: Commodore 8-bit
 *  machines, Apple II family, Mac OS up to version 9 and OS-9 </ul>
 */
public interface LineBreak {

	/**
	 *  CR. It is '\r'.
	 */
	public static final char CR = 13;

	/**
	 *  LF. It is '\n'.
	 */
	public static final char LF = 10;

	/**
	 *  CR. It is "\r".
	 */
	public static final String STRING_CR = "\r";

	/**
	 *  LF. It is "\n".
	 */
	public static final String STRING_LF = "\n";

	/**
	 *  CR+LF. It is "\n\r".
	 */
	public static final String STRING_CR_LF = "\r\n";

	/**
	 *  The link break used by <code>CodeEditor</code>. In <code>CodeEditor</code>, we will convert the text to use a
	 *  single line break style. That is LF only. Although it is the same as UNIX line break style, it has nothing to do
	 *  with UNIX. We could choose any char as the line break and end user shouldn't even know because we will convert it
	 *  to use the correct line break when user gets the text from the <code>CodeEditor</code>.
	 */
	public static final int LINE_BREAK_CODE_EDITOR = 1;

	/**
	 *  The PC line break style. It is CR + LF.
	 */
	public static final int LINE_BREAK_PC = 0;

	/**
	 *  The UNIX line break style. It is LF only.
	 */
	public static final int LINE_BREAK_UNIX = 1;

	/**
	 *  The Mac 9 line break style. It is CR only.
	 */
	public static final int LINE_BREAK_MAC = 2;

	/**
	 *  Mix line breaks. This means the text has mixed usage of different line break styles. When <code>CodeEditor</code>
	 *  loads a text that has mixed line breaks, {@link CodeEditor#getLineBreakStyle()} will return the default line
	 *  breaks depending on the platform. However if you want to know if the text has mixed line breaks, you can use
	 *  {@link com.jidesoft.editor.CodeEditor#isLineBreakStyleMixed()} to find out.
	 */
	public static final int LINE_BREAK_MIXED = -1;

	/**
	 *  Unknown. It means there is no line break in the given text.
	 */
	public static final int LINE_BREAK_UNKNOWN = -2;
}
