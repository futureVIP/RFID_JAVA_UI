/**
 *  The main package for JIDE Code Editor product.
 */
package com.jidesoft.editor;


/**
 *  The text area repaint manager. It performs double buffering and paints lines of text.
 * 
 *  @author Slava Pestov
 *  @version $Id: TextAreaPainter.java,v 1.24 1999/12/13 03:40:30 sp Exp $
 */
public class CodeEditorPainter extends javax.swing.JComponent implements javax.swing.text.TabExpander {
 {

	protected int currentLineIndex;

	protected tokenmarker.Token currentLineTokens;

	protected javax.swing.text.Segment currentLine;

	protected CodeEditor _editor;

	protected java.awt.FontMetrics _fm;

	public java.awt.font.TextLayout _composedTextLayout;

	public int _composedCaretX;

	/**
	 *  Creates a new repaint manager. This should be not be called directly.
	 * 
	 *  @param editor the code editor instance
	 */
	public CodeEditorPainter(CodeEditor editor) {
	}

	/**
	 *  Returns if this component can be traversed by pressing the Tab key. This returns false.
	 */
	@java.lang.Override
	public final boolean isManagingFocus() {
	}

	/**
	 *  Returns the font metrics used by this component.
	 * 
	 *  @return the font metrics
	 */
	public java.awt.FontMetrics getFontMetrics() {
	}

	/**
	 *  Sets the font for this component. This is overridden to update the cached font metrics and to recalculate which lines are visible.
	 * 
	 *  @param font The font
	 */
	@java.lang.Override
	public void setFont(java.awt.Font font) {
	}

	@java.lang.Override
	public String getToolTipText(java.awt.event.MouseEvent event) {
	}

	/**
	 *  Repaints the text.
	 * 
	 *  @param g The graphics context
	 */
	@java.lang.Override
	public void paint(java.awt.Graphics g) {
	}

	protected void paintImeInput(java.awt.Graphics2D gfx, int screenLine, int physicalLine, int start, int end, int y) {
	}

	/**
	 *  Marks a view line as needing a repaint.
	 * 
	 *  @param line the view line index to invalidate
	 */
	public final void invalidateLine(int line) {
	}

	/**
	 *  @param startOffset start offset
	 *  @param endOffset   end offset
	 */
	public final void invalidateRange(int startOffset, int endOffset) {
	}

	/**
	 *  Marks a range of lines as needing a repaint.
	 * 
	 *  @param firstLine The first view line index to invalidate
	 *  @param lastLine  The last view line index to invalidate
	 */
	public final void invalidateLineRange(int firstLine, int lastLine) {
	}

	/**
	 *  Repaints the lines containing the selection.
	 */
	public final void invalidateSelectedLines() {
	}

	/**
	 *  Implementation of TabExpander interface. Returns next tab stop after a specified point.
	 * 
	 *  @param x         The x co-ordinate
	 *  @param tabOffset Ignored
	 *  @return The next tab stop after <i>x</i>
	 */
	public float nextTabStop(float x, int tabOffset) {
	}

	public int nextTabStop(int column) {
	}

	@java.lang.Override
	public java.awt.Font getFont() {
	}

	protected void paintLine(java.awt.Graphics g, tokenmarker.TokenMarker tokenMarker, int line, int viewLine, caret.CaretPosition selectionStartVp, caret.CaretPosition selectionEndVp, int x, int y, FoldingState state) {
	}

	/**
	 *  Check if the span is all selected.
	 *  
	 *  @param span                the span
	 *  @param viewLine            the view line the span in
	 *  @param column              the view column the span start with
	 *  @param selectionStartVp    the view position of selection start
	 *  @param selectionEndVp      the view position of selection end
	 *  @return true if the span is selected. Otherwise false.
	 */
	protected boolean isSpanSelected(folding.FoldingSpan span, int viewLine, int column, caret.CaretPosition selectionStartVp, caret.CaretPosition selectionEndVp) {
	}

	protected void paintPlainLine(java.awt.Graphics g, int line, int visualLine, caret.CaretPosition selectionStartVp, caret.CaretPosition selectionEndVp, java.awt.Font defaultFont, java.awt.Color defaultColor, int x, int y) {
	}

	protected int paintSyntaxLine(java.awt.Graphics g, tokenmarker.TokenMarker tokenMarker, int line, int viewLine, int start, int end, caret.CaretPosition selectionStartVp, caret.CaretPosition selectionEndVp, java.awt.Font defaultFont, java.awt.Color defaultColor, int x, int y, boolean paintHighlight) {
	}

	protected void paintHighlight(java.awt.Graphics g, int line, int viewLine, caret.CaretPosition selectionStartVp, caret.CaretPosition selectionEndVp, int y) {
	}

	protected void paintLineHighlight(java.awt.Graphics g, int line, int visualLine, caret.CaretPosition selectionStartVp, caret.CaretPosition selectionEndVp, int y) {
	}

	protected void paintLineSelection(java.awt.Graphics g, int visualLine, caret.CaretPosition selectionStartVp, caret.CaretPosition selectionEndVp, int y) {
	}

	protected void paintBracketHighlight(java.awt.Graphics g, int line, int y) {
	}

	protected void paintCaret(java.awt.Graphics g, int visualLine) {
	}

	public int getLineHeight() {
	}

	public CodeEditor getCodeEditor() {
	}

	public int paintFoldedText(java.awt.Graphics g, java.awt.Font font, String text, int x, int y, java.awt.FontMetrics fm) {
	}

	public void paintColumnGuides(java.awt.Graphics g, java.awt.Rectangle rect) {
	}
}
