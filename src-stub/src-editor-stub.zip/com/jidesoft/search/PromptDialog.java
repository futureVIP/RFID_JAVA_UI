/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>PromptDialog</code> is a dialog to promot user to repace or skip the current matching text during find and
 *  replace.
 */
public class PromptDialog extends StandardDialog {

	public static final int RESULT_REPLACE = 0;

	public static final int RESULT_SKIP = 1;

	public static final int RESULT_ALL = 2;

	public static final int RESULT_ALL_IN_FILE = 3;

	public PromptDialog(java.awt.Frame owner, String title, String message, boolean hasMoreFiles) {
	}

	public PromptDialog(java.awt.Dialog owner, String title, String message, boolean hasMoreFiles) {
	}

	@java.lang.Override
	public javax.swing.JComponent createBannerPanel() {
	}

	@java.lang.Override
	public javax.swing.JComponent createContentPanel() {
	}

	@java.lang.Override
	public ButtonPanel createButtonPanel() {
	}
}
