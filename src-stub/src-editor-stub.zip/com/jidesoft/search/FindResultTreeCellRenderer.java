/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  The TreeCellRenderer that renders <code>FindResult</code> and <code>FindResults</code> using StyledLabel.
 */
public class FindResultTreeCellRenderer extends StyledTreeCellRenderer {

	public FindResultTreeCellRenderer() {
	}

	@java.lang.Override
	protected void customizeStyledLabel(javax.swing.JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {
	}
}
