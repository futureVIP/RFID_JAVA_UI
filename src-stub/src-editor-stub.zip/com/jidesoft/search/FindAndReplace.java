/**
 *  The package contains the classes related to searching/replacing features for JIDE Code Editor product.
 */
package com.jidesoft.search;


/**
 *  <code>FindAndReplace</code> is the class that does the find and replace feature in CodeEditor, or as a matter of
 *  fact, anything that has a piece or several pieces of text.
 */
public class FindAndReplace {

	public static final int SCOPE_GLOBAL = 0;

	public static final int SCOPE_SELECTION = 1;

	public static final int ORIGIN_ENTIRE = 0;

	public static final int ORIGIN_FROM_CURSOR = 1;

	protected java.util.regex.Pattern _pattern;

	public FindAndReplace() {
	}

	public FindAndReplaceTarget getTarget() {
	}

	public void setTarget(FindAndReplaceTarget target) {
	}

	public void addTarget(FindAndReplaceTarget target) {
	}

	public void removeTarget(FindAndReplaceTarget target) {
	}

	public FindAndReplaceTarget[] getTargets() {
	}

	public String getFindText() {
	}

	public void setFindText(String findText) {
	}

	public String getReplaceText() {
	}

	public void setReplaceText(String replaceText) {
	}

	public java.util.Vector getFindHistory() {
	}

	public void setFindHistory(java.util.Vector findHistory) {
	}

	public java.util.Vector getReplaceHistory() {
	}

	public void setReplaceHistory(java.util.Vector replaceHistory) {
	}

	public boolean isUseRegexOrWildcards() {
	}

	public void setUseRegexOrWildcards(boolean useRegexOrWildcards) {
	}

	public boolean isUseWildcards() {
	}

	public void setUseWildcards(boolean useWildcards) {
	}

	public boolean isUseRegex() {
	}

	public void setUseRegex(boolean useRegex) {
	}

	public boolean isMatchWholeWord() {
	}

	public void setMatchWholeWord(boolean matchWholeWord) {
	}

	public boolean isMatchCase() {
	}

	public void setMatchCase(boolean matchCase) {
	}

	public int getScope() {
	}

	public void setScope(int scope) {
	}

	public int getOrigin() {
	}

	public void setOrigin(int origin) {
	}

	public void searchAgain() {
	}

	protected int getFlags() {
	}

	protected java.util.regex.Matcher getMatcher() {
	}

	protected void initialCharSequence() {
	}

	public void search() {
	}

	public FindResults searchAll() {
	}

	public void search(java.util.regex.Matcher m) {
	}

	protected int promptForReplace() {
	}

	public int replace(FindResult findResult, String replacement) {
	}

	public void textChanged() {
	}

	protected boolean repeatSearch() {
	}

	protected void searchFinished() {
	}

	public boolean isForward() {
	}

	public void setForward(boolean forward) {
	}

	public boolean isReversed() {
	}

	public void setReversed(boolean reversed) {
	}

	public boolean isReplace() {
	}

	public void setReplace(boolean replace) {
	}

	public boolean isShowFindAll() {
	}

	public void setShowFindAll(boolean showFindAll) {
	}

	public synchronized void addFindAndReplaceListener(FindAndReplaceListener FindAndReplaceListener) {
	}

	public synchronized void removeFindAndReplaceListener(FindAndReplaceListener FindAndReplaceListener) {
	}

	/**
	 *  Gets the FindAndReplaceListeners register on DefaultCaretModel.
	 * 
	 *  @return the FindAndReplaceListeners.
	 */
	public FindAndReplaceListener[] getFindAndReplaceListeners() {
	}

	protected void fireFindAndReplaceEvent(int status) {
	}

	protected void fireFindAndReplaceEvent(int status, FindResults findResults) {
	}

	protected void fireFindAndReplaceEvent(int status, FindResult findResult) {
	}

	protected void fireFindAndReplaceEvent(int status, FindResult findResult, String replaceString) {
	}

	protected void fireFindAndReplaceEvent(int status, String fileName, FindResults findResults) {
	}

	protected void fireFindAndReplaceEvent(int status, String fileName) {
	}
}
